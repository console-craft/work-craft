## @opentui/core-linux-arm64

> Prebuilt linux-arm64 binaries for `@opentui/core`.