## @opentui/core-win32-arm64

> Prebuilt win32-arm64 binaries for `@opentui/core`.