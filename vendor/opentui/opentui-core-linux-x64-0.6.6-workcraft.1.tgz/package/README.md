## @opentui/core-linux-x64

> Prebuilt linux-x64 binaries for `@opentui/core`.