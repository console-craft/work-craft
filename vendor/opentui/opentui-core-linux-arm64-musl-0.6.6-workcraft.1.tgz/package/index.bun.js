const module = await import("./libopentui.so", { with: { type: "file" } })

export default module.default
