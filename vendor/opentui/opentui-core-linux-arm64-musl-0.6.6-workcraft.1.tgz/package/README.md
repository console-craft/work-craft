## @opentui/core-linux-arm64-musl

> Prebuilt linux-arm64-musl binaries for `@opentui/core`.