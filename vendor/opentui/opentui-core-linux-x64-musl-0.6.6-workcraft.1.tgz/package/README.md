## @opentui/core-linux-x64-musl

> Prebuilt linux-x64-musl binaries for `@opentui/core`.