## @opentui/core-darwin-x64

> Prebuilt darwin-x64 binaries for `@opentui/core`.