import { type RuntimeModuleEntry, type RuntimePluginRewriteOptions, type RuntimeSpecifierPreserve } from "@opentui/core/runtime-plugin";
export interface ReactRuntimePluginSupportOptions {
    additional?: Record<string, RuntimeModuleEntry>;
    core?: RuntimeModuleEntry;
    preserve?: RuntimeSpecifierPreserve;
    rewrite?: RuntimePluginRewriteOptions;
}
export declare function ensureRuntimePluginSupport(options?: ReactRuntimePluginSupportOptions): boolean;
