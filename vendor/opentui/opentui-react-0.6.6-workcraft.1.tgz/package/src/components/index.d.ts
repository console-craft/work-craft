import { ASCIIFontRenderable, BoxRenderable, CodeRenderable, DiffRenderable, ImageRenderable, InputRenderable, LineNumberRenderable, MarkdownRenderable, ScrollBoxRenderable, SelectRenderable, TabSelectRenderable, TextareaRenderable, TextRenderable } from "@opentui/core";
import type { RenderableConstructor } from "../types/components.js";
import { BoldSpanRenderable, ItalicSpanRenderable, LineBreakRenderable, LinkRenderable, SpanRenderable, UnderlineSpanRenderable } from "./text.js";
export declare const baseComponents: {
    box: typeof BoxRenderable;
    text: typeof TextRenderable;
    code: typeof CodeRenderable;
    diff: typeof DiffRenderable;
    markdown: typeof MarkdownRenderable;
    input: typeof InputRenderable;
    select: typeof SelectRenderable;
    textarea: typeof TextareaRenderable;
    scrollbox: typeof ScrollBoxRenderable;
    "ascii-font": typeof ASCIIFontRenderable;
    "tab-select": typeof TabSelectRenderable;
    "line-number": typeof LineNumberRenderable;
    image: typeof ImageRenderable;
    span: typeof SpanRenderable;
    br: typeof LineBreakRenderable;
    b: typeof BoldSpanRenderable;
    strong: typeof BoldSpanRenderable;
    i: typeof ItalicSpanRenderable;
    em: typeof ItalicSpanRenderable;
    u: typeof UnderlineSpanRenderable;
    a: typeof LinkRenderable;
};
type ComponentCatalogue = Record<string, RenderableConstructor>;
export declare const componentCatalogue: ComponentCatalogue;
/**
 * Extend the component catalogue with new renderable components
 *
 * @example
 * ```tsx
 * // Extend with an object of components
 * extend({
 *   consoleButton: ConsoleButtonRenderable,
 *   customBox: CustomBoxRenderable
 * })
 * ```
 */
export declare function extend<T extends ComponentCatalogue>(objects: T): void;
export declare function getComponentCatalogue(): ComponentCatalogue;
export type { ExtendedComponentProps, ExtendedIntrinsicElements, RenderableConstructor } from "../types/components.js";
