import type { Pointer } from "./platform/ffi.js";
export interface NativeImageInfo {
    width: number;
    height: number;
    sourceWidth: number;
    sourceHeight: number;
    format: number;
    colorStatus: number;
    orientation: number;
    hasAlpha: number;
}
export type BuildOptions = {
    gpaSafeStats: boolean;
    gpaMemoryLimitTracking: boolean;
};
export declare const BuildOptionsStruct: import("bun-ffi-structs").DefineStructReturnType<[readonly ["gpaSafeStats", "bool_u8"], readonly ["gpaMemoryLimitTracking", "bool_u8"]], {}>;
export type AllocatorStats = {
    totalRequestedBytes: number;
    activeAllocations: number;
    smallAllocations: number;
    largeAllocations: number;
    requestedBytesValid: boolean;
};
export declare const AllocatorStatsStruct: import("bun-ffi-structs").DefineStructReturnType<[readonly ["totalRequestedBytes", "u64"], readonly ["activeAllocations", "u64"], readonly ["smallAllocations", "u64"], readonly ["largeAllocations", "u64"], readonly ["requestedBytesValid", "bool_u8"]], {}>;
export type NativeRenderStats = {
    nativeLastFrameTime: number;
    nativeAverageFrameTime: number;
    nativeFrameCount: number;
    cellsUpdated: number;
    averageCellsUpdated: number;
    nativeRenderTime?: number;
    nativeStdoutWriteTime?: number;
};
export type GrowthPolicy = "grow" | "block";
export type NativeSpanFeedOptions = {
    chunkSize?: number;
    initialChunks?: number;
    maxBytes?: bigint;
    growthPolicy?: GrowthPolicy;
    autoCommitOnFull?: boolean;
    spanQueueCapacity?: number;
};
export type NativeSpanFeedStats = {
    bytesWritten: bigint;
    spansCommitted: bigint;
    chunks: number;
    pendingSpans: number;
    outstandingSpans: number;
    outstandingBytes: bigint;
};
export type SpanInfo = {
    chunkPtr: Pointer;
    offset: number;
    len: number;
    chunkIndex: number;
    slotIndex: number;
    releaseId: bigint;
};
export type ReserveInfo = {
    ptr: Pointer;
    len: number;
};
export declare const NativeSpanFeedOptionsStruct: import("bun-ffi-structs").DefineStructReturnType<[readonly ["chunkSize", "u32", {
    readonly default: number;
}], readonly ["initialChunks", "u32", {
    readonly default: 2;
}], readonly ["maxBytes", "u64", {
    readonly default: 0n;
}], readonly ["growthPolicy", import("bun-ffi-structs").EnumDef<{
    grow: number;
    block: number;
}>, {
    readonly default: "grow";
}], readonly ["autoCommitOnFull", "bool_u8", {
    readonly default: true;
}], readonly ["spanQueueCapacity", "u32", {
    readonly default: 0;
}]], {}>;
export declare const NativeSpanFeedStatsStruct: import("bun-ffi-structs").DefineStructReturnType<[readonly ["bytesWritten", "u64"], readonly ["spansCommitted", "u64"], readonly ["chunks", "u32"], readonly ["pendingSpans", "u32"], readonly ["outstandingSpans", "u32"], readonly ["reserved", "u32", {
    readonly default: 0;
}], readonly ["outstandingBytes", "u64"]], {}>;
export declare const SpanInfoStruct: import("bun-ffi-structs").StructDef<{
    chunkPtr: Pointer;
    offset: number;
    len: number;
    chunkIndex: number;
    slotIndex: number;
    releaseId: bigint;
}, {
    chunkPtr: ArrayBufferLike | import("bun-ffi-structs").Pointer | ArrayBufferView<ArrayBufferLike>;
    offset: number;
    len: number;
    chunkIndex: number;
    slotIndex?: number | null | undefined;
    releaseId?: number | bigint | null | undefined;
}>;
export declare const ReserveInfoStruct: import("bun-ffi-structs").StructDef<{
    ptr: Pointer;
    len: number;
}, {
    len: number;
    ptr: ArrayBufferLike | import("bun-ffi-structs").Pointer | ArrayBufferView<ArrayBufferLike>;
    reserved?: number | null | undefined;
}>;
export type AudioCreateOptions = {
    sampleRate?: number;
    playbackChannels?: number;
};
export type AudioStartOptions = {
    periodSizeInFrames?: number;
    periodSizeInMilliseconds?: number;
    periods?: number;
    performanceProfile?: number;
    shareMode?: number;
    noPreSilencedOutputBuffer?: boolean;
    noClip?: boolean;
    noDisableDenormals?: boolean;
    noFixedSizedCallback?: boolean;
    wasapiNoAutoConvertSrc?: boolean;
    wasapiNoDefaultQualitySrc?: boolean;
    alsaNoMMap?: boolean;
    alsaNoAutoFormat?: boolean;
    alsaNoAutoChannels?: boolean;
    alsaNoAutoResample?: boolean;
};
export type AudioVoiceOptions = {
    volume?: number;
    pan?: number;
    loop?: boolean;
    groupId?: number;
};
export declare const NativeAudioStreamFormat: {
    readonly Mp3: 1;
    readonly Flac: 2;
    readonly Pcm: 3;
};
export type NativeAudioStreamFormat = (typeof NativeAudioStreamFormat)[keyof typeof NativeAudioStreamFormat];
export type AudioStreamCreateOptions = {
    capacityMs: number;
    startupMs: number;
    resumeMs: number;
    volume: number;
    pan: number;
    groupId: number;
    maxProbeBytes: number;
    format: NativeAudioStreamFormat;
    sampleRate?: number;
    channels?: number;
};
export type NativeAudioStreamStats = {
    bytesReceived: bigint;
    framesDecoded: bigint;
    framesPlayed: bigint;
    state: number;
    sampleRate: number;
    channels: number;
    bufferedFrames: number;
    capacityFrames: number;
    underruns: number;
    errorCode: number;
    readyGeneration: number;
};
export declare const NativeAudioStreamState: {
    readonly Initializing: 0;
    readonly Buffering: 1;
    readonly Playing: 2;
    readonly Ended: 3;
    readonly Failed: 4;
    readonly Cancelled: 5;
    readonly Reconnecting: 6;
};
export type NativeAudioStreamState = (typeof NativeAudioStreamState)[keyof typeof NativeAudioStreamState];
export declare const NativeAudioStreamStateNames: readonly ["initializing", "buffering", "playing", "ended", "errored", "disposed", "reconnecting"];
export declare const NativeAudioStreamCloseReason: {
    readonly PreserveNativeTerminal: 0;
    readonly TransportError: 1;
    readonly Disposed: 2;
};
export type NativeAudioStreamCloseReason = (typeof NativeAudioStreamCloseReason)[keyof typeof NativeAudioStreamCloseReason];
export type AudioStats = {
    soundsLoaded: number;
    voicesActive: number;
    framesMixed: bigint;
    lockMisses: number;
    lastPeak: number;
    lastRms: number;
};
export type NativeAudioCaptureStats = {
    framesReceived: bigint;
    framesRead: bigint;
    framesDropped: bigint;
    sampleRate: number;
    channels: number;
    bufferedFrames: number;
    capacityFrames: number;
};
export declare const AudioCreateOptionsStruct: import("bun-ffi-structs").DefineStructReturnType<[readonly ["sampleRate", "u32", {
    readonly default: 48000;
}], readonly ["playbackChannels", "u32", {
    readonly default: 2;
}]], {}>;
export declare const AudioStartOptionsStruct: import("bun-ffi-structs").DefineStructReturnType<[readonly ["periodSizeInFrames", "u32", {
    readonly default: 0;
}], readonly ["periodSizeInMilliseconds", "u32", {
    readonly default: 0;
}], readonly ["periods", "u32", {
    readonly default: 0;
}], readonly ["performanceProfile", "u8", {
    readonly default: 0;
}], readonly ["shareMode", "u8", {
    readonly default: 0;
}], readonly ["noPreSilencedOutputBuffer", "bool_u8", {
    readonly default: false;
}], readonly ["noClip", "bool_u8", {
    readonly default: false;
}], readonly ["noDisableDenormals", "bool_u8", {
    readonly default: false;
}], readonly ["noFixedSizedCallback", "bool_u8", {
    readonly default: false;
}], readonly ["wasapiNoAutoConvertSrc", "bool_u8", {
    readonly default: false;
}], readonly ["wasapiNoDefaultQualitySrc", "bool_u8", {
    readonly default: false;
}], readonly ["alsaNoMMap", "bool_u8", {
    readonly default: false;
}], readonly ["alsaNoAutoFormat", "bool_u8", {
    readonly default: false;
}], readonly ["alsaNoAutoChannels", "bool_u8", {
    readonly default: false;
}], readonly ["alsaNoAutoResample", "bool_u8", {
    readonly default: false;
}]], {}>;
export declare const AudioVoiceOptionsStruct: import("bun-ffi-structs").DefineStructReturnType<[readonly ["volume", "f32", {
    readonly default: 1;
}], readonly ["pan", "f32", {
    readonly default: 0;
}], readonly ["loop", "bool_u8", {
    readonly default: false;
}], readonly ["groupId", "u32", {
    readonly default: 0;
}]], {}>;
export declare const AudioStreamCreateOptionsStruct: import("bun-ffi-structs").DefineStructReturnType<[readonly ["capacityMs", "u32"], readonly ["startupMs", "u32"], readonly ["resumeMs", "u32"], readonly ["volume", "f32"], readonly ["pan", "f32"], readonly ["groupId", "u32"], readonly ["maxProbeBytes", "u32"], readonly ["format", "u32"], readonly ["sampleRate", "u32", {
    readonly default: 0;
}], readonly ["channels", "u32", {
    readonly default: 0;
}]], {}>;
export declare const AudioStreamStatsStruct: import("bun-ffi-structs").DefineStructReturnType<[readonly ["bytesReceived", "u64"], readonly ["framesDecoded", "u64"], readonly ["framesPlayed", "u64"], readonly ["state", "u32"], readonly ["sampleRate", "u32"], readonly ["channels", "u32"], readonly ["bufferedFrames", "u32"], readonly ["capacityFrames", "u32"], readonly ["underruns", "u32"], readonly ["errorCode", "i32"], readonly ["readyGeneration", "u32"]], {}>;
export declare const AudioCaptureStatsStruct: import("bun-ffi-structs").DefineStructReturnType<[readonly ["framesReceived", "u64"], readonly ["framesRead", "u64"], readonly ["framesDropped", "u64"], readonly ["sampleRate", "u32"], readonly ["channels", "u32"], readonly ["bufferedFrames", "u32"], readonly ["capacityFrames", "u32"]], {}>;
export declare const AudioStatsStruct: import("bun-ffi-structs").DefineStructReturnType<[readonly ["soundsLoaded", "u32"], readonly ["voicesActive", "u32"], readonly ["framesMixed", "u64"], readonly ["lockMisses", "u32"], readonly ["lastPeak", "f32"], readonly ["lastRms", "f32"]], {}>;
