import { RGBA } from "./lib/index.js";
import { type RenderLib, type NativeContextHandle, type NativeContextOptions, type NativeSceneFrameRequest, type SessionHandle, type SessionBuffer, type ContextBufferHandle, type NativeDrawingTarget, type NativeBufferGrid, type NativePaintRecorder, type SceneNodeHandle } from "./zig.js";
import type { PointerInput } from "./platform/ffi.js";
import type { NativeImage } from "./image.js";
import type { ImageRenderProtocol } from "./types.js";
import type { NativeScene } from "./NativeScene.js";
import { type BorderStyle, type BorderSides } from "./lib/index.js";
import { TargetChannel, type WidthMethod, type CapturedLine } from "./types.js";
import type { TextBufferView } from "./text-buffer-view.js";
import type { EditorView } from "./editor-view.js";
export interface BufferAccess {
    readonly width: number;
    readonly height: number;
    readonly generation: bigint;
    readonly char: Uint32Array;
    readonly fg: Uint16Array;
    readonly bg: Uint16Array;
    readonly attributes: Uint32Array;
}
export interface NativeResourceOwner {
    readonly resourceContext: ResourceContext;
}
/** Owns checked resources independently of the Sessions and scenes that use them. */
export declare class ResourceContext implements NativeResourceOwner {
    readonly renderLib: RenderLib;
    readonly context: NativeContextHandle;
    private _disposed;
    constructor(options: NativeContextOptions);
    get disposed(): boolean;
    get resourceContext(): ResourceContext;
    assertAlive(): void;
    destroy(): void;
}
export interface EncodedUnicode {
    data: Array<{
        width: number;
        char: number;
    }>;
}
export declare class OptimizedBuffer {
    private static fbIdCounter;
    id: string;
    lib: RenderLib;
    private source;
    private _width;
    private _height;
    private _widthMethod;
    respectAlpha: boolean;
    private _destroyed;
    private _nativePaintAccess;
    private _bufferTarget;
    private guard;
    /** Recording buffers queue drawing for native paint; they have no drawing target. */
    private get recorder();
    private checkedTarget;
    /** @internal Native built-ins may retain only buffers belonging to their Context. */
    _getSceneHandle(scene: NativeResourceOwner): ContextBufferHandle;
    /** @internal Resource controllers draw only within their owning Context. */
    _getSceneDrawTarget(scene: NativeScene): NativeDrawingTarget;
    private drawChecked;
    /** @internal Scene text draws its native node without exposing its buffer. */
    _drawSceneText(scene: NativeScene, node: SceneNodeHandle, x: number, y: number): void;
    /** Raw planes are available only during a synchronous post-process scope. Prefer withBuffers(). */
    get buffers(): {
        char: Uint32Array;
        fg: Uint16Array;
        bg: Uint16Array;
        attributes: Uint32Array;
    };
    /**
     * Borrows one live storage generation for a synchronous callback. Copy data
     * that must outlive the callback; saved arrays cannot be revoked after release.
     * Resize/destruction retains the old storage to scope exit, then reports stale
     * access. This is not a frozen frame or an atomic cell-edit transaction.
     * Do not use saved arrays after exit or change pooled grapheme/link IDs through
     * these planes. Use OptimizedBuffer drawing methods or contextDrawBuffer instead.
     * Styled-text/editor resources, hyperlinks, and images need their checked APIs.
     *
     * Session access without a scene ticket is storage-only. Rendering can change cells
     * without changing generation. `current` is the encoder's comparison buffer, not a
     * guaranteed last-presented frame; `next` is drawing storage cleared after encoding.
     * Finish drawing before submitting a frame. Acquisition rejects pending presentation
     * and non-rendering phases. Checked Session drawing requires an active scene ticket;
     * ticketless storage access does not grant drawing access.
     */
    withBuffers<T>(callback: (cells: BufferAccess) => T): T;
    /** Internal post-process scope. Ignores the callback's result; native views never escape the synchronous part. */
    _withNativePaint(callback: () => void): void;
    private constructor();
    /** @internal A frame buffer whose drawing records into a paint recording. */
    static fromRecorder(lib: RenderLib, context: NativeContextHandle, session: SessionHandle, recorder: NativePaintRecorder): OptimizedBuffer;
    static fromSession(lib: RenderLib, context: NativeContextHandle, session: SessionHandle, which: SessionBuffer, getFrame?: () => NativeSceneFrameRequest | null): OptimizedBuffer;
    static create(width: number, height: number, widthMethod: WidthMethod, options: {
        respectAlpha?: boolean;
        id?: string;
        owner: NativeResourceOwner;
    }): OptimizedBuffer;
    get widthMethod(): WidthMethod;
    get width(): number;
    get height(): number;
    setRespectAlpha(respectAlpha: boolean): void;
    getRealCharBytes(addLineBreaks?: boolean): Uint8Array;
    private withResolvedChars;
    getSpanLines(): CapturedLine[];
    clear(bg?: RGBA): void;
    setCell(x: number, y: number, char: string, fg: RGBA, bg: RGBA, attributes?: number): void;
    setCellWithAlphaBlending(x: number, y: number, char: string, fg: RGBA, bg: RGBA, attributes?: number): void;
    drawText(text: string, x: number, y: number, fg: RGBA, bg?: RGBA, attributes?: number, selection?: {
        start: number;
        end: number;
        bgColor?: RGBA;
        fgColor?: RGBA;
    } | null): void;
    fillRect(x: number, y: number, width: number, height: number, bg: RGBA): void;
    colorMatrix(matrix: Float32Array, cellMask: Float32Array, strength?: number, target?: TargetChannel): void;
    colorMatrixUniform(matrix: Float32Array, strength?: number, target?: TargetChannel): void;
    drawFrameBuffer(destX: number, destY: number, frameBuffer: OptimizedBuffer, sourceX?: number, sourceY?: number, sourceWidth?: number, sourceHeight?: number): void;
    destroy(): void;
    drawTextBuffer(textBufferView: TextBufferView, x: number, y: number): void;
    drawEditorView(editorView: EditorView, x: number, y: number): void;
    drawSuperSampleBuffer(x: number, y: number, pixelData: PointerInput | Uint8Array, pixelDataLength: number, format: "bgra8unorm" | "rgba8unorm", alignedBytesPerRow: number): void;
    drawImage(image: NativeImage, x: number, y: number, width: number, height: number, pixelWidth?: number, pixelHeight?: number, sourceX?: number, sourceY?: number, sourceWidth?: number, sourceHeight?: number, protocol?: ImageRenderProtocol): boolean;
    drawPackedBuffer(data: PointerInput | Uint8Array, dataLen: number, posX: number, posY: number, terminalWidthCells: number, terminalHeightCells: number): void;
    drawGrayscaleBuffer(posX: number, posY: number, intensities: Float32Array, srcWidth: number, srcHeight: number, fg?: RGBA | null, bg?: RGBA | null): void;
    drawGrayscaleBufferSupersampled(posX: number, posY: number, intensities: Float32Array, srcWidth: number, srcHeight: number, fg?: RGBA | null, bg?: RGBA | null): void;
    resize(width: number, height: number): void;
    drawBox(options: {
        x: number;
        y: number;
        width: number;
        height: number;
        borderStyle?: BorderStyle;
        customBorderChars?: Uint32Array;
        border: boolean | BorderSides[];
        borderColor: RGBA;
        backgroundColor: RGBA;
        shouldFill?: boolean;
        title?: string;
        titleColor?: RGBA;
        titleAlignment?: "left" | "center" | "right";
        bottomTitle?: string;
        bottomTitleAlignment?: "left" | "center" | "right";
    }): void;
    pushScissorRect(x: number, y: number, width: number, height: number): void;
    popScissorRect(): void;
    clearScissorRects(): void;
    pushOpacity(opacity: number): void;
    popOpacity(): void;
    getCurrentOpacity(): number;
    clearOpacity(): void;
    private stackChecked;
    encodeUnicode(text: string): EncodedUnicode;
    freeUnicode(encoded: EncodedUnicode): void;
    drawGrid(options: NativeBufferGrid): void;
    drawChar(char: number, x: number, y: number, fg: RGBA, bg: RGBA, attributes?: number): void;
}
