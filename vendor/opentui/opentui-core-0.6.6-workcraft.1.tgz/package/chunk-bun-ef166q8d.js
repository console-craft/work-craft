// @bun
import {
  nativeConstants,
  toArrayBuffer,
  singleton,
  getSingleton,
  destroySingleton,
  registerEnvVar2,
  env2,
  stringWidth,
  Worker,
  DEFAULT_FOREGROUND_RGB2,
  DEFAULT_BACKGROUND_RGB2,
  ansi256IndexToRgb2,
  RGBA2,
  parseColor2,
  createTextAttributes2,
  isStyledText2,
  StyledText2,
  stringToStyledText2,
  YogaEnumKind,
  YogaFloatKind,
  YogaValueKind,
  sceneSetEnum,
  sceneGetEnum,
  sceneSetFloat,
  sceneGetFloat,
  sceneSetValue,
  sceneGetValue,
  sceneSetDimension,
  UNDEFINED_VALUE,
  parseYogaValue,
  isBunfsPath,
  normalizeBunfsPath,
  resolveDefaultParserAsset,
  resolveDefaultTreeSitterWorkerPath,
  resolveTreeSitterWasm,
  NativeStyleGroup,
  NativeStyleFlags,
  NATIVE_EDGE_NONE2,
  NativeBorder2,
  NativeSceneHook2,
  NativeSceneFrame2,
  NativeScenePaintPhase2,
  NativeError2,
  NativeClipboardOperationStatus2,
  NativeClipboardStartStatus2,
  NativeClipboardCopyStatus2,
  NativeClipboardDestroyStatus2,
  NativeClipboardShutdownStatus2,
  SceneStaging,
  NativePaintRecorder,
  resolveRenderLib2,
  Align2,
  BoxSizing2,
  Dimension2,
  Direction2,
  Edge2,
  FlexDirection2,
  Gutter2,
  Justify2,
  MeasureMode2,
  Overflow2,
  PositionType2,
  Unit2,
  Wrap2
} from "./chunk-bun-jztcnb74.js";

// src/Renderable.ts
import { EventEmitter as EventEmitter4 } from "events";

// src/lib/border.ts
var VALID_BORDER_STYLES = ["single", "double", "rounded", "heavy"];
function isValidBorderStyle2(value) {
  return typeof value === "string" && VALID_BORDER_STYLES.includes(value);
}
function parseBorderStyle2(value, fallback = "single") {
  if (isValidBorderStyle2(value)) {
    return value;
  }
  if (value !== undefined && value !== null) {
    console.warn(`Invalid borderStyle "${value}", falling back to "${fallback}". Valid values are: ${VALID_BORDER_STYLES.join(", ")}`);
  }
  return fallback;
}
var BorderChars2 = {
  single: {
    topLeft: "\u250C",
    topRight: "\u2510",
    bottomLeft: "\u2514",
    bottomRight: "\u2518",
    horizontal: "\u2500",
    vertical: "\u2502",
    topT: "\u252C",
    bottomT: "\u2534",
    leftT: "\u251C",
    rightT: "\u2524",
    cross: "\u253C"
  },
  double: {
    topLeft: "\u2554",
    topRight: "\u2557",
    bottomLeft: "\u255A",
    bottomRight: "\u255D",
    horizontal: "\u2550",
    vertical: "\u2551",
    topT: "\u2566",
    bottomT: "\u2569",
    leftT: "\u2560",
    rightT: "\u2563",
    cross: "\u256C"
  },
  rounded: {
    topLeft: "\u256D",
    topRight: "\u256E",
    bottomLeft: "\u2570",
    bottomRight: "\u256F",
    horizontal: "\u2500",
    vertical: "\u2502",
    topT: "\u252C",
    bottomT: "\u2534",
    leftT: "\u251C",
    rightT: "\u2524",
    cross: "\u253C"
  },
  heavy: {
    topLeft: "\u250F",
    topRight: "\u2513",
    bottomLeft: "\u2517",
    bottomRight: "\u251B",
    horizontal: "\u2501",
    vertical: "\u2503",
    topT: "\u2533",
    bottomT: "\u253B",
    leftT: "\u2523",
    rightT: "\u252B",
    cross: "\u254B"
  }
};
function getBorderFromSides2(sides) {
  const result = [];
  if (sides.top)
    result.push("top");
  if (sides.right)
    result.push("right");
  if (sides.bottom)
    result.push("bottom");
  if (sides.left)
    result.push("left");
  return result.length > 0 ? result : false;
}
function getBorderSides2(border) {
  return border === true ? { top: true, right: true, bottom: true, left: true } : Array.isArray(border) ? {
    top: border.includes("top"),
    right: border.includes("right"),
    bottom: border.includes("bottom"),
    left: border.includes("left")
  } : { top: false, right: false, bottom: false, left: false };
}
function borderCharsToArray2(chars) {
  const array = new Uint32Array(11);
  array[0] = chars.topLeft.codePointAt(0) ?? 32;
  array[1] = chars.topRight.codePointAt(0) ?? 32;
  array[2] = chars.bottomLeft.codePointAt(0) ?? 32;
  array[3] = chars.bottomRight.codePointAt(0) ?? 32;
  array[4] = chars.horizontal.codePointAt(0) ?? 32;
  array[5] = chars.vertical.codePointAt(0) ?? 32;
  array[6] = chars.topT.codePointAt(0) ?? 32;
  array[7] = chars.bottomT.codePointAt(0) ?? 32;
  array[8] = chars.leftT.codePointAt(0) ?? 32;
  array[9] = chars.rightT.codePointAt(0) ?? 32;
  array[10] = chars.cross.codePointAt(0) ?? 32;
  return array;
}
var BorderCharArrays2 = {
  single: borderCharsToArray2(BorderChars2.single),
  double: borderCharsToArray2(BorderChars2.double),
  rounded: borderCharsToArray2(BorderChars2.rounded),
  heavy: borderCharsToArray2(BorderChars2.heavy)
};
// src/lib/KeyHandler.ts
import { EventEmitter } from "events";

class KeyEvent2 {
  name;
  ctrl;
  meta;
  shift;
  option;
  sequence;
  number;
  raw;
  eventType;
  source;
  code;
  super;
  hyper;
  capsLock;
  numLock;
  baseCode;
  repeated;
  _defaultPrevented = false;
  _propagationStopped = false;
  constructor(key) {
    this.name = key.name;
    this.ctrl = key.ctrl;
    this.meta = key.meta;
    this.shift = key.shift;
    this.option = key.option;
    this.sequence = key.sequence;
    this.number = key.number;
    this.raw = key.raw;
    this.eventType = key.eventType;
    this.source = key.source;
    this.code = key.code;
    this.super = key.super;
    this.hyper = key.hyper;
    this.capsLock = key.capsLock;
    this.numLock = key.numLock;
    this.baseCode = key.baseCode;
    this.repeated = key.repeated;
  }
  get defaultPrevented() {
    return this._defaultPrevented;
  }
  get propagationStopped() {
    return this._propagationStopped;
  }
  preventDefault() {
    this._defaultPrevented = true;
  }
  stopPropagation() {
    this._propagationStopped = true;
  }
}

class PasteEvent2 {
  type = "paste";
  bytes;
  metadata;
  _defaultPrevented = false;
  _propagationStopped = false;
  constructor(bytes, metadata) {
    this.bytes = bytes;
    this.metadata = metadata;
  }
  get defaultPrevented() {
    return this._defaultPrevented;
  }
  get propagationStopped() {
    return this._propagationStopped;
  }
  preventDefault() {
    this._defaultPrevented = true;
  }
  stopPropagation() {
    this._propagationStopped = true;
  }
}

class KeyHandler2 extends EventEmitter {
  processParsedKey(parsedKey) {
    try {
      switch (parsedKey.eventType) {
        case "press":
          this.emit("keypress", new KeyEvent2(parsedKey));
          break;
        case "release":
          this.emit("keyrelease", new KeyEvent2(parsedKey));
          break;
        default:
          this.emit("keypress", new KeyEvent2(parsedKey));
          break;
      }
    } catch (error) {
      console.error(`[KeyHandler] Error processing parsed key:`, error);
      return true;
    }
    return true;
  }
  processPaste(bytes, metadata) {
    try {
      this.emit("paste", new PasteEvent2(bytes, metadata));
    } catch (error) {
      console.error(`[KeyHandler] Error processing paste:`, error);
    }
  }
}

class InternalKeyHandler2 extends KeyHandler2 {
  renderableHandlers = new Map;
  emit(event, ...args) {
    return this.emitWithPriority(event, ...args);
  }
  emitWithPriority(event, ...args) {
    let hasGlobalListeners = false;
    const globalListeners = this.listeners(event);
    if (globalListeners.length > 0) {
      hasGlobalListeners = true;
      for (const listener of globalListeners) {
        try {
          listener(...args);
        } catch (error) {
          console.error(`[KeyHandler] Error in global ${event} handler:`, error);
        }
        if (event === "keypress" || event === "keyrelease" || event === "paste") {
          const keyEvent = args[0];
          if (keyEvent.propagationStopped) {
            return hasGlobalListeners;
          }
        }
      }
    }
    const renderableSet = this.renderableHandlers.get(event);
    const renderableHandlers = renderableSet && renderableSet.size > 0 ? [...renderableSet] : [];
    let hasRenderableListeners = false;
    if (renderableSet && renderableSet.size > 0) {
      hasRenderableListeners = true;
      if (event === "keypress" || event === "keyrelease" || event === "paste") {
        const keyEvent = args[0];
        if (keyEvent.defaultPrevented)
          return hasGlobalListeners || hasRenderableListeners;
        if (keyEvent.propagationStopped)
          return hasGlobalListeners || hasRenderableListeners;
      }
      for (const handler of renderableHandlers) {
        try {
          handler(...args);
        } catch (error) {
          console.error(`[KeyHandler] Error in renderable ${event} handler:`, error);
        }
        if (event === "keypress" || event === "keyrelease" || event === "paste") {
          const keyEvent = args[0];
          if (keyEvent.propagationStopped) {
            return hasGlobalListeners || hasRenderableListeners;
          }
        }
      }
    }
    return hasGlobalListeners || hasRenderableListeners;
  }
  onInternal(event, handler) {
    if (!this.renderableHandlers.has(event)) {
      this.renderableHandlers.set(event, new Set);
    }
    this.renderableHandlers.get(event).add(handler);
  }
  offInternal(event, handler) {
    const handlers = this.renderableHandlers.get(event);
    if (handlers) {
      handlers.delete(handler);
    }
  }
}
// src/lib/fonts/block.json
var block_default = {
  name: "block",
  version: "0.2.0",
  homepage: "https://github.com/dominikwilkowski/cfonts",
  colors: 2,
  lines: 6,
  buffer: ["", "", "", "", "", ""],
  letterspace: [" ", " ", " ", " ", " ", " "],
  letterspace_size: 1,
  chars: {
    A: [
      " <c1>\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2> ",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>  \u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A\u2550\u255D  \u255A\u2550\u255D</c2>"
    ],
    B: [
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557 </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550\u2550\u255D </c2>"
    ],
    C: [
      " <c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550\u2550\u2550\u255D</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551     </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551     </c2>",
      "<c2>\u255A</c2><c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2> \u255A\u2550\u2550\u2550\u2550\u2550\u255D</c2>"
    ],
    D: [
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557 </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>  \u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>  \u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550\u2550\u255D </c2>"
    ],
    E: [
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550\u2550\u2550\u255D</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557  </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550\u255D  </c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550\u2550\u2550\u255D</c2>"
    ],
    F: [
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550\u2550\u2550\u255D</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557  </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550\u255D  </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551     </c2>",
      "<c2>\u255A\u2550\u255D     </c2>"
    ],
    G: [
      " <c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557 </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550\u2550\u2550\u255D </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>  \u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>   \u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A</c2><c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2> \u255A\u2550\u2550\u2550\u2550\u2550\u255D </c2>"
    ],
    H: [
      "<c1>\u2588\u2588</c1><c2>\u2557</c2><c1>  \u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>  \u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>  \u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A\u2550\u255D  \u255A\u2550\u255D</c2>"
    ],
    I: [
      "<c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A\u2550\u255D</c2>"
    ],
    J: [
      "<c1>     \u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>     \u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>     \u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588   \u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A</c2><c1>\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2> \u255A\u2550\u2550\u2550\u2550\u255D </c2>"
    ],
    K: [
      "<c1>\u2588\u2588</c1><c2>\u2557</c2><c1>  \u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1> \u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550</c2><c1>\u2588\u2588</c1><c2>\u2557 </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>  \u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A\u2550\u255D  \u255A\u2550\u255D</c2>"
    ],
    L: [
      "<c1>\u2588\u2588</c1><c2>\u2557     </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551     </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551     </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551     </c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550\u2550\u2550\u255D</c2>"
    ],
    M: [
      "<c1>\u2588\u2588\u2588</c1><c2>\u2557</c2><c1>   \u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2><c1> \u2588\u2588\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554</c2><c1>\u2588\u2588\u2588\u2588</c1><c2>\u2554</c2><c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551\u255A</c2><c1>\u2588\u2588</c1><c2>\u2554\u255D</c2><c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551 \u255A\u2550\u255D</c2><c1> \u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A\u2550\u255D     \u255A\u2550\u255D</c2>"
    ],
    N: [
      "<c1>\u2588\u2588\u2588</c1><c2>\u2557</c2><c1>   \u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2><c1>  \u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554</c2><c1>\u2588\u2588</c1><c2>\u2557</c2><c1> \u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551\u255A</c2><c1>\u2588\u2588</c1><c2>\u2557</c2><c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551 \u255A</c2><c1>\u2588\u2588\u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A\u2550\u255D  \u255A\u2550\u2550\u2550\u255D</c2>"
    ],
    O: [
      " <c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557 </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>   \u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>   \u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A</c2><c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2> \u255A\u2550\u2550\u2550\u2550\u2550\u255D </c2>"
    ],
    P: [
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557 </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550\u2550\u255D </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551     </c2>",
      "<c2>\u255A\u2550\u255D     </c2>"
    ],
    Q: [
      " <c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557 </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>   \u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>\u2584\u2584 \u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A</c2><c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2> \u255A\u2550\u2550</c2><c1>\u2580\u2580</c1><c2>\u2550\u255D </c2>"
    ],
    R: [
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557 </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>  \u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A\u2550\u255D  \u255A\u2550\u255D</c2>"
    ],
    S: [
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550\u2550\u2550\u255D</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550\u2550\u2550\u255D</c2>"
    ],
    T: [
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550\u255D</c2>",
      "<c1>   \u2588\u2588</c1><c2>\u2551   </c2>",
      "<c1>   \u2588\u2588</c1><c2>\u2551   </c2>",
      "<c1>   \u2588\u2588</c1><c2>\u2551   </c2>",
      "<c2>   \u255A\u2550\u255D   </c2>"
    ],
    U: [
      "<c1>\u2588\u2588</c1><c2>\u2557</c2><c1>   \u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>   \u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>   \u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>   \u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A</c2><c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2> \u255A\u2550\u2550\u2550\u2550\u2550\u255D </c2>"
    ],
    V: [
      "<c1>\u2588\u2588</c1><c2>\u2557</c2><c1>   \u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>   \u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>   \u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A</c2><c1>\u2588\u2588</c1><c2>\u2557</c2><c1> \u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2> \u255A</c2><c1>\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D </c2>",
      "<c2>  \u255A\u2550\u2550\u2550\u255D  </c2>"
    ],
    W: [
      "<c1>\u2588\u2588</c1><c2>\u2557    </c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551    </c2><c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1> \u2588</c1><c2>\u2557</c2><c1> \u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>\u2588\u2588\u2588</c1><c2>\u2557</c2><c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A</c2><c1>\u2588\u2588\u2588</c1><c2>\u2554</c2><c1>\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2> \u255A\u2550\u2550\u255D\u255A\u2550\u2550\u255D </c2>"
    ],
    X: [
      "<c1>\u2588\u2588</c1><c2>\u2557</c2><c1>  \u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A</c2><c1>\u2588\u2588</c1><c2>\u2557</c2><c1>\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2> \u255A</c2><c1>\u2588\u2588\u2588</c1><c2>\u2554\u255D </c2>",
      " <c1>\u2588\u2588</c1><c2>\u2554</c2><c1>\u2588\u2588</c1><c2>\u2557 </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u255D</c2><c1> \u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A\u2550\u255D  \u255A\u2550\u255D</c2>"
    ],
    Y: [
      "<c1>\u2588\u2588</c1><c2>\u2557</c2><c1>   \u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A</c2><c1>\u2588\u2588</c1><c2>\u2557</c2><c1> \u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2> \u255A</c2><c1>\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D </c2>",
      "<c2>  \u255A</c2><c1>\u2588\u2588</c1><c2>\u2554\u255D  </c2>",
      "<c1>   \u2588\u2588</c1><c2>\u2551   </c2>",
      "<c2>   \u255A\u2550\u255D   </c2>"
    ],
    Z: [
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A\u2550\u2550</c2><c1>\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c1>  \u2588\u2588\u2588</c1><c2>\u2554\u255D </c2>",
      " <c1>\u2588\u2588\u2588</c1><c2>\u2554\u255D  </c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550\u2550\u2550\u255D</c2>"
    ],
    "0": [
      " <c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557 </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550</c2><c1>\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>\u2588\u2588</c1><c2>\u2554</c2><c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2><c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A</c2><c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2> \u255A\u2550\u2550\u2550\u2550\u2550\u255D </c2>"
    ],
    "1": [
      " <c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A</c2><c1>\u2588\u2588</c1><c2>\u2551</c2>",
      " <c1>\u2588\u2588</c1><c2>\u2551</c2>",
      " <c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c2> \u255A\u2550\u255D</c2>"
    ],
    "2": [
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557 </c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      " <c1>\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550\u2550\u255D </c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550\u2550\u2550\u255D</c2>"
    ],
    "3": [
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557 </c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      " <c1>\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2> \u255A\u2550\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550\u2550\u255D </c2>"
    ],
    "4": [
      "<c1>\u2588\u2588</c1><c2>\u2557</c2><c1>  \u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>  \u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>     \u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>     \u255A\u2550\u255D</c2>"
    ],
    "5": [
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550\u2550\u2550\u255D</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550\u2550\u2550\u255D</c2>"
    ],
    "6": [
      " <c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557 </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550\u2550\u2550\u255D </c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557 </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A</c2><c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2> \u255A\u2550\u2550\u2550\u2550\u2550\u255D </c2>"
    ],
    "7": [
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>    \u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c1>   \u2588\u2588</c1><c2>\u2554\u255D </c2>",
      "<c1>   \u2588\u2588</c1><c2>\u2551  </c2>",
      "<c2>   \u255A\u2550\u255D  </c2>"
    ],
    "8": [
      " <c1>\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557 </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A</c2><c1>\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A</c2><c1>\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2> \u255A\u2550\u2550\u2550\u2550\u255D </c2>"
    ],
    "9": [
      " <c1>\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557 </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A</c2><c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2551</c2>",
      "<c2> \u255A\u2550\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2551</c2>",
      " <c1>\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2> \u255A\u2550\u2550\u2550\u2550\u255D </c2>"
    ],
    "!": [
      "<c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A\u2550\u255D</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A\u2550\u255D</c2>"
    ],
    "?": [
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557 </c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>  \u2584\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c1>  \u2580\u2580</c1><c2>\u2550\u2550\u255D </c2>",
      "<c1>  \u2588\u2588</c1><c2>\u2557   </c2>",
      "<c2>  \u255A\u2550\u255D   </c2>"
    ],
    ".": ["   ", "   ", "   ", "   ", "<c1>\u2588\u2588</c1><c2>\u2557</c2>", "<c2>\u255A\u2550\u255D</c2>"],
    "+": [
      "       ",
      "<c1>  \u2588\u2588</c1><c2>\u2557  </c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2> \u255A</c2><c1>\u2588\u2588</c1><c2>\u2554\u2550\u255D</c2>",
      "<c2>  \u255A\u2550\u255D  </c2>",
      "       "
    ],
    "-": ["      ", "      ", "<c1>\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>", "<c2>\u255A\u2550\u2550\u2550\u2550\u255D</c2>", "      ", "      "],
    _: ["        ", "        ", "        ", "        ", "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>", "<c2>\u255A\u2550\u2550\u2550\u2550\u2550\u2550\u255D</c2>"],
    "=": [
      "       ",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550\u2550\u255D</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550\u2550\u255D</c2>",
      "       "
    ],
    "@": [
      " <c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557 </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>\u2588\u2588</c1><c2>\u2557</c2><c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551</c2><c1>\u2588\u2588</c1><c2>\u2551</c2><c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A</c2><c1>\u2588</c1><c2>\u2551</c2><c1>\u2588\u2588\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2> \u255A\u255D\u255A\u2550\u2550\u2550\u255D </c2>"
    ],
    "#": [
      " <c1>\u2588\u2588</c1><c2>\u2557</c2><c1> \u2588\u2588</c1><c2>\u2557 </c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A</c2><c1>\u2588\u2588</c1><c2>\u2554\u2550</c2><c1>\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A</c2><c1>\u2588\u2588</c1><c2>\u2554\u2550</c2><c1>\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2> \u255A\u2550\u255D \u255A\u2550\u255D </c2>"
    ],
    $: [
      "<c1>\u2584\u2584\u2588\u2588\u2588\u2584\u2584</c1><c2>\xB7</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550\u2550\u2550\u2550\u255D</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550</c2><c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2551</c2>",
      "<c2>\u255A\u2550</c2><c1>\u2580\u2580\u2580</c1><c2>\u2550\u2550\u255D</c2>"
    ],
    "%": [
      "<c1>\u2588\u2588</c1><c2>\u2557</c2><c1> \u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A\u2550\u255D</c2><c1>\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c1>  \u2588\u2588</c1><c2>\u2554\u255D </c2>",
      " <c1>\u2588\u2588</c1><c2>\u2554\u255D  </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u255D</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2>\u255A\u2550\u255D \u255A\u2550\u255D</c2>"
    ],
    "&": [
      "<c1>   \u2588\u2588</c1><c2>\u2557   </c2>",
      "<c1>   \u2588\u2588</c1><c2>\u2551   </c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u2550</c2><c1>\u2588\u2588</c1><c2>\u2554\u2550\u255D</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2551  </c2>",
      "<c2>\u255A\u2550\u2550\u2550\u2550\u2550\u255D  </c2>"
    ],
    "(": [
      " <c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2551 ",
      "<c1>\u2588\u2588</c1><c2>\u2551 ",
      "<c2>\u255A</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      "<c2> \u255A\u2550\u255D</c2>"
    ],
    ")": [
      "<c1>\u2588\u2588</c1><c2>\u2557 </c2>",
      "<c2>\u255A</c2><c1>\u2588\u2588</c1><c2>\u2557</c2>",
      " <c1>\u2588\u2588</c1><c2>\u2551</c2>",
      " <c1>\u2588\u2588</c1><c2>\u2551</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c2>\u255A\u2550\u255D </c2>"
    ],
    "/": [
      "<c1>    \u2588\u2588</c1><c2>\u2557</c2>",
      "<c1>   \u2588\u2588</c1><c2>\u2554\u255D</c2>",
      "<c1>  \u2588\u2588</c1><c2>\u2554\u255D </c2>",
      " <c1>\u2588\u2588</c1><c2>\u2554\u255D  </c2>",
      "<c1>\u2588\u2588</c1><c2>\u2554\u255D   </c2>",
      "<c2>\u255A\u2550\u255D    </c2>"
    ],
    ":": ["   ", "<c1>\u2588\u2588</c1><c2>\u2557</c2>", "<c2>\u255A\u2550\u255D</c2>", "<c1>\u2588\u2588</c1><c2>\u2557</c2>", "<c2>\u255A\u2550\u255D</c2>", "   "],
    ";": ["   ", "   ", "<c1>\u2588\u2588</c1><c2>\u2557</c2>", "<c2>\u255A\u2550\u255D</c2>", "<c1>\u2584\u2588</c1><c2>\u2557</c2>", "<c1>\u2580</c1><c2>\u2550\u255D</c2>"],
    ",": ["   ", "   ", "   ", "   ", "<c1>\u2584\u2588</c1><c2>\u2557</c2>", "<c1>\u2580</c1><c2>\u2550\u255D</c2>"],
    "'": ["<c1>\u2588</c1><c2>\u2557</c2> ", "<c2>\u255A\u255D</c2> ", "   ", "   ", "   ", "   "],
    '"': ["<c1>\u2588</c1><c2>\u2557</c2><c1>\u2588</c1><c2>\u2557</c2> ", "<c2>\u255A\u255D\u255A\u255D</c2> ", "     ", "     ", "     ", "     "],
    " ": ["   ", "   ", "   ", "   ", "   ", "   "]
  }
};
// src/lib/fonts/shade.json
var shade_default = {
  name: "shade",
  version: "0.2.0",
  homepage: "https://github.com/dominikwilkowski/cfonts",
  colors: 2,
  lines: 8,
  buffer: ["", "", "", "", "", "", "", ""],
  letterspace: [
    "<c2>\u2591</c2>",
    "<c2>\u2591</c2>",
    "<c2>\u2591</c2>",
    "<c2>\u2591</c2>",
    "<c2>\u2591</c2>",
    "<c2>\u2591</c2>",
    "<c2>\u2591</c2>",
    "<c2>\u2591</c2>"
  ],
  letterspace_size: 1,
  chars: {
    A: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588\u2588</c1><c2>\u2591</c2>",
      "<c1>\u2588  \u2588</c1>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "<c1>\u2588  \u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      " <c2>\u2591\u2591</c2> ",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    B: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588</c1><c2>\u2591</c2>",
      "<c1>\u2588  \u2588</c1>",
      "<c1>\u2588\u2588\u2588</c1> ",
      "<c1>\u2588  \u2588</c1>",
      "<c1>\u2588\u2588\u2588</c1> ",
      "   <c2>\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    C: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "<c1>\u2588</c1>   ",
      "<c1>\u2588</c1><c2>\u2591\u2591\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "    ",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    D: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588</c1><c2>\u2591</c2>",
      "<c1>\u2588  \u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588\u2588\u2588</c1> ",
      "   <c2>\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    E: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "<c1>\u2588</c1>   ",
      "<c1>\u2588\u2588\u2588</c1><c2>\u2591</c2>",
      "<c1>\u2588</c1>  <c2>\u2591</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "    ",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    F: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "<c1>\u2588</c1>   ",
      "<c1>\u2588\u2588\u2588</c1><c2>\u2591</c2>",
      "<c1>\u2588</c1>  <c2>\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591\u2591\u2591</c2>",
      " <c2>\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    G: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588\u2588\u2588</c1>",
      "<c1>\u2588</c1>   ",
      "<c1>\u2588</c1><c2>\u2591</c2><c1>\u2588\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591</c2> <c1>\u2588</c1>",
      "<c1>\u2588\u2588\u2588</c1> ",
      "   <c2>\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    H: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "<c1>\u2588  \u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      " <c2>\u2591\u2591</c2> ",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    I: [
      "<c2>\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588</c1>",
      " <c1>\u2588</c1> ",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591</c2>",
      "<c1>\u2588\u2588\u2588</c1>",
      "   ",
      "<c2>\u2591\u2591\u2591</c2>"
    ],
    J: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588</c1><c2>\u2591</c2>",
      "  <c1>\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591\u2591</c2><c1>\u2588</c1><c2>\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591</c2><c1>\u2588</c1><c2>\u2591</c2>",
      "<c1>\u2588\u2588\u2588</c1><c2>\u2591</c2>",
      "   <c2>\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    K: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588\u2588\u2588</c1> ",
      "<c1>\u2588  \u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      " <c2>\u2591\u2591</c2> ",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    L: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591\u2591\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591\u2591\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591\u2591\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "    ",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    M: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "<c1>\u2588  \u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      " <c2>\u2591\u2591</c2> ",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    N: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588\u2588</c1><c2>\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588 \u2588\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591</c2> <c1>\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      " <c2>\u2591\u2591</c2> ",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    O: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588\u2588</c1><c2>\u2591</c2>",
      "<c1>\u2588  \u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      " <c1>\u2588\u2588</c1> ",
      "<c2>\u2591  \u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    P: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588</c1><c2>\u2591</c2>",
      "<c1>\u2588  \u2588</c1>",
      "<c1>\u2588\u2588\u2588</c1> ",
      "<c1>\u2588</c1>  <c2>\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591\u2591\u2591</c2>",
      " <c2>\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    Q: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588\u2588</c1><c2>\u2591</c2>",
      "<c1>\u2588  \u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      " <c1>\u2588\u2588\u2588</c1>",
      "<c2>\u2591</c2>   ",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    R: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588</c1><c2>\u2591</c2>",
      "<c1>\u2588  \u2588</c1>",
      "<c1>\u2588\u2588\u2588</c1> ",
      "<c1>\u2588  \u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      " <c2>\u2591\u2591</c2> ",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    S: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588\u2588\u2588</c1>",
      "<c1>\u2588</c1>   ",
      " <c1>\u2588\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591</c2>  <c1>\u2588</c1>",
      "<c1>\u2588\u2588\u2588</c1> ",
      "   <c2>\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    T: [
      "<c2>\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588</c1>",
      " <c1>\u2588</c1> ",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591 \u2591</c2>",
      "<c2>\u2591\u2591\u2591</c2>"
    ],
    U: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      " <c1>\u2588\u2588</c1> ",
      "<c2>\u2591  \u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    V: [
      "<c2>\u2591\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591\u2591</c2><c1>\u2588</c1>",
      " <c1>\u2588</c1><c2>\u2591</c2><c1>\u2588</c1> ",
      "<c2>\u2591</c2> <c1>\u2588</c1> <c2>\u2591</c2>",
      "<c2>\u2591\u2591 \u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591\u2591</c2>"
    ],
    W: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "<c1>\u2588  \u2588</c1>",
      " <c2>\u2591\u2591</c2> ",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    X: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      " <c1>\u2588\u2588</c1> ",
      "<c1>\u2588  \u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588</c1>",
      " <c2>\u2591\u2591</c2> ",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    Y: [
      "<c2>\u2591\u2591\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588\u2588\u2588</c1>",
      " <c1>\u2588</c1> ",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591 \u2591</c2>",
      "<c2>\u2591\u2591\u2591</c2>"
    ],
    Z: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "  <c1>\u2588</c1> ",
      "<c2>\u2591</c2><c1>\u2588</c1> <c2>\u2591</c2>",
      "<c1>\u2588</c1> <c2>\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "    ",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    "0": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588\u2588</c1><c2>\u2591</c2>",
      "<c1>\u2588  \u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591</c2><c1>\u258C\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591</c2> <c1>\u2588</c1>",
      " <c1>\u2588\u2588</c1> ",
      "<c2>\u2591  \u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    "1": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588</c1><c2>\u2591\u2591</c2>",
      " <c1>\u2588</c1><c2>\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588</c1><c2>\u2591</c2>",
      "   <c2>\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    "2": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2590\u2588\u2588</c1><c2>\u2591</c2>",
      "   <c1>\u2588</c1>",
      "<c2>\u2591\u2591</c2><c1>\u2588</c1> ",
      "<c2>\u2591</c2><c1>\u2588</c1> <c2>\u2591</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "    ",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    "3": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "   <c1>\u2588</c1>",
      "<c2>\u2591\u2591</c2><c1>\u2588\u2588</c1>",
      "<c2>\u2591\u2591</c2> <c1>\u2588</c1>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "    ",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    "4": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591\u2591\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591</c2><c1>\u2588</c1><c2>\u2591</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "   <c1>\u2588</c1>",
      "<c2>\u2591\u2591\u2591</c2><c1>\u2588</c1>",
      "<c2>\u2591\u2591\u2591</c2> ",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    "5": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "<c1>\u2588</c1>   ",
      "<c1>\u2588\u2588\u2588</c1><c2>\u2591</c2>",
      "   <c1>\u2588</c1>",
      "<c1>\u2588\u2588\u2588</c1> ",
      "   <c2>\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    "6": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588\u2588\u2588</c1>",
      "<c1>\u2588</c1>   ",
      "<c1>\u2588\u2588\u2588</c1><c2>\u2591</c2>",
      "<c1>\u2588  \u2588</c1>",
      " <c1>\u2588\u2588</c1> ",
      "<c2>\u2591  \u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    "7": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "   <c1>\u2588</c1>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      " <c1>\u2588</c1>  ",
      "<c1>\u2588</c1> <c2>\u2591\u2591</c2>",
      " <c2>\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    "8": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588\u2588</c1><c2>\u2591</c2>",
      "<c1>\u2588  \u2588</c1>",
      " <c1>\u2588\u2588</c1> ",
      "<c1>\u2588  \u2588</c1>",
      " <c1>\u2588\u2588</c1> ",
      "<c2>\u2591  \u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    "9": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588\u2588</c1><c2>\u2591</c2>",
      "<c1>\u2588  \u2588</c1>",
      " <c1>\u2588\u2588\u2588</c1>",
      "<c2>\u2591</c2>  <c1>\u2588</c1>",
      "<c2>\u2591\u2591</c2><c1>\u2588</c1> ",
      "<c2>\u2591\u2591 \u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    "!": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591  \u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591  \u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    "?": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2590\u2588\u2588</c1><c2>\u2591</c2>",
      "   <c1>\u2588</c1>",
      "<c2>\u2591\u2591</c2><c1>\u2588</c1> ",
      "<c2>\u2591\u2591 \u2591</c2>",
      "<c2>\u2591\u2591</c2><c1>\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591\u2591 \u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    ".": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591</c2><c1>\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591\u2591 \u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    "+": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591</c2><c1>\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588\u2588\u2588</c1>",
      "<c2>\u2591</c2> <c1>\u2588</c1> ",
      "<c2>\u2591\u2591 \u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    "-": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "    ",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    _: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "    "
    ],
    "=": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "    ",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      "    ",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    "@": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588\u2588</c1><c2>\u2591</c2>",
      "<c1>\u2588  \u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591</c2><c1>\u258C\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591</c2><c1>\u2588</c1> ",
      " <c1>\u2588\u2588\u2588</c1>",
      "    ",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    "#": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u258C\u2590</c1><c2>\u2591</c2>",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      " <c1>\u258C\u2590</c1> ",
      "<c1>\u2588\u2588\u2588\u2588</c1>",
      " <c1>\u258C\u2590</c1> ",
      "<c2>\u2591  \u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    $: [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591</c2><c1>\u258C</c1><c2>\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588\u2588\u2588</c1>",
      "<c1>\u2588 \u2588</c1> ",
      " <c1>\u2588\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591\u2591</c2><c1>\u258C\u2588</c1>",
      "<c1>\u2588\u2588\u2588</c1> ",
      "   <c2>\u2591</c2>"
    ],
    "%": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588</c1><c2>\u2591</c2><c1>\u2588</c1> ",
      " <c2>\u2591</c2><c1>\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1> <c2>\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591</c2><c1>\u2588</c1>",
      "<c1>\u2588</c1> <c2>\u2591</c2> ",
      " <c2>\u2591\u2591\u2591</c2>"
    ],
    "&": [
      "<c2>\u2591\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591\u2591\u2591</c2>",
      "<c1>\u2588\u2588\u2588\u2588\u2588</c1>",
      "<c1>\u2588  \u2588</c1> ",
      "<c1>\u2588\u2588\u2588\u2588</c1><c2>\u2591</c2>",
      "<c2>    </c2> ",
      "<c2>\u2591\u2591\u2591\u2591\u2591</c2>"
    ],
    "(": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591</c2><c1>\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1> <c2>\u2591</c2>",
      "<c1>\u2588</c1> <c2>\u2591\u2591</c2>",
      "<c1>\u2588</c1><c2>\u2591\u2591\u2591</c2>",
      " <c1>\u2588</c1><c2>\u2591\u2591</c2>",
      "<c2>\u2591</c2> <c1>\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591\u2591 \u2591</c2>"
    ],
    ")": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591\u2591</c2>",
      "<c2>\u2591</c2> <c1>\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591\u2591</c2> <c1>\u2588</c1>",
      "<c2>\u2591\u2591\u2591</c2><c1>\u2588</c1>",
      "<c2>\u2591\u2591</c2><c1>\u2588</c1> ",
      "<c2>\u2591</c2><c1>\u2588</c1> <c2>\u2591</c2>",
      "<c2>\u2591 \u2591\u2591</c2>"
    ],
    "/": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591</c2><c1>\u2588</c1>",
      "<c2>\u2591\u2591</c2><c1>\u2588</c1> ",
      "<c2>\u2591\u2591</c2><c1>\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1> <c2>\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591\u2591</c2>",
      "<c1>\u2588</c1> <c2>\u2591\u2591</c2>",
      " <c2>\u2591\u2591\u2591</c2>"
    ],
    ":": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591\u2591</c2>",
      "<c2>\u2591 \u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591\u2591</c2>",
      "<c2>\u2591 \u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    ";": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591\u2591</c2>",
      "<c2>\u2591 \u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591\u2591</c2>"
    ],
    ",": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591</c2><c1>\u2588</c1><c2>\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1> <c2>\u2591</c2>"
    ],
    "'": [
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591\u2591</c2>",
      "<c2>\u2591 \u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591</c2>"
    ],
    '"': [
      "<c2>\u2591\u2591\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591</c2><c1>\u2588</c1><c2>\u2591</c2><c1>\u2588</c1><c2>\u2591\u2591</c2>",
      "<c2>\u2591 \u2591 \u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591\u2591\u2591\u2591</c2>"
    ],
    " ": [
      "<c2>\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591</c2>",
      "<c2>\u2591\u2591\u2591</c2>"
    ]
  }
};
// src/lib/fonts/slick.json
var slick_default = {
  name: "slick",
  version: "0.1.0",
  homepage: "https://github.com/dominikwilkowski/cfonts",
  colors: 2,
  lines: 6,
  buffer: ["", "", "", "", "", ""],
  letterspace: ["<c2>\u2571</c2>", "<c2>\u2571</c2>", "<c2>\u2571</c2>", "<c2>\u2571</c2>", "<c2>\u2571</c2>", "<c2>\u2571</c2>"],
  letterspace_size: 1,
  chars: {
    A: [
      "<c1>\u256D\u2501\u2501\u2501\u256E</c1>",
      "<c1>\u2503\u256D\u2501\u256E\u2503</c1>",
      "<c1>\u2503\u2503</c1><c2>\u2571</c2><c1>\u2503\u2503</c1>",
      "<c1>\u2503\u2570\u2501\u256F\u2503</c1>",
      "<c1>\u2503\u256D\u2501\u256E\u2503</c1>",
      "<c1>\u2570\u256F</c1><c2>\u2571</c2><c1>\u2570\u256F</c1>"
    ],
    B: [
      "<c1>\u256D\u2501\u2501\u256E</c1><c2>\u2571</c2>",
      "<c1>\u2503\u256D\u256E\u2503</c1><c2>\u2571</c2>",
      "<c1>\u2503\u2570\u256F\u2570\u256E</c1>",
      "<c1>\u2503\u256D\u2501\u256E\u2503</c1>",
      "<c1>\u2503\u2570\u2501\u256F\u2503</c1>",
      "<c1>\u2570\u2501\u2501\u2501\u256F</c1>"
    ],
    C: [
      "<c1>\u256D\u2501\u2501\u2501\u256E</c1>",
      "<c1>\u2503\u256D\u2501\u256E\u2503</c1>",
      "<c1>\u2503\u2503</c1><c2>\u2571</c2><c1>\u2570\u256F</c1>",
      "<c1>\u2503\u2503</c1><c2>\u2571</c2><c1>\u256D\u256E</c1>",
      "<c1>\u2503\u2570\u2501\u256F\u2503</c1>",
      "<c1>\u2570\u2501\u2501\u2501\u256F</c1>"
    ],
    D: [
      "<c1>\u256D\u2501\u2501\u2501\u256E</c1>",
      "<c1>\u2570\u256E\u256D\u256E\u2503</c1>",
      "<c2>\u2571</c2><c1>\u2503\u2503\u2503\u2503</c1>",
      "<c2>\u2571</c2><c1>\u2503\u2503\u2503\u2503</c1>",
      "<c1>\u256D\u256F\u2570\u256F\u2503</c1>",
      "<c1>\u2570\u2501\u2501\u2501\u256F</c1>"
    ],
    E: ["<c1>\u256D\u2501\u2501\u2501\u256E</c1>", "<c1>\u2503\u256D\u2501\u2501\u256F</c1>", "<c1>\u2503\u2570\u2501\u2501\u256E</c1>", "<c1>\u2503\u256D\u2501\u2501\u256F</c1>", "<c1>\u2503\u2570\u2501\u2501\u256E</c1>", "<c1>\u2570\u2501\u2501\u2501\u256F</c1>"],
    F: [
      "<c1>\u256D\u2501\u2501\u2501\u256E</c1>",
      "<c1>\u2503\u256D\u2501\u2501\u256F</c1>",
      "<c1>\u2503\u2570\u2501\u2501\u256E</c1>",
      "<c1>\u2503\u256D\u2501\u2501\u256F</c1>",
      "<c1>\u2503\u2503</c1><c2>\u2571\u2571\u2571</c2>",
      "<c1>\u2570\u256F</c1><c2>\u2571\u2571\u2571</c2>"
    ],
    G: [
      "<c1>\u256D\u2501\u2501\u2501\u256E</c1>",
      "<c1>\u2503\u256D\u2501\u256E\u2503</c1>",
      "<c1>\u2503\u2503</c1><c2>\u2571</c2><c1>\u2570\u256F</c1>",
      "<c1>\u2503\u2503\u256D\u2501\u256E</c1>",
      "<c1>\u2503\u2570\u253B\u2501\u2503</c1>",
      "<c1>\u2570\u2501\u2501\u2501\u256F</c1>"
    ],
    H: [
      "<c1>\u256D\u256E</c1><c2>\u2571</c2><c1>\u256D\u256E</c1>",
      "<c1>\u2503\u2503</c1><c2>\u2571</c2><c1>\u2503\u2503</c1>",
      "<c1>\u2503\u2570\u2501\u256F\u2503</c1>",
      "<c1>\u2503\u256D\u2501\u256E\u2503</c1>",
      "<c1>\u2503\u2503</c1><c2>\u2571</c2><c1>\u2503\u2503</c1>",
      "<c1>\u2570\u256F</c1><c2>\u2571</c2><c1>\u2570\u256F</c1>"
    ],
    I: [
      "<c1>\u256D\u2501\u2501\u256E</c1>",
      "<c1>\u2570\u252B\u2523\u256F</c1>",
      "<c2>\u2571</c2><c1>\u2503\u2503</c1><c2>\u2571</c2>",
      "<c2>\u2571</c2><c1>\u2503\u2503</c1><c2>\u2571</c2>",
      "<c1>\u256D\u252B\u2523\u256E</c1>",
      "<c1>\u2570\u2501\u2501\u256F</c1>"
    ],
    J: [
      "<c2>\u2571\u2571</c2><c1>\u256D\u256E</c1>",
      "<c2>\u2571\u2571</c2><c1>\u2503\u2503</c1>",
      "<c2>\u2571\u2571</c2><c1>\u2503\u2503</c1>",
      "<c1>\u256D\u256E\u2503\u2503</c1>",
      "<c1>\u2503\u2570\u256F\u2503</c1>",
      "<c1>\u2570\u2501\u2501\u256F</c1>"
    ],
    K: [
      "<c1>\u256D\u256E\u256D\u2501\u256E</c1>",
      "<c1>\u2503\u2503\u2503\u256D\u256F</c1>",
      "<c1>\u2503\u2570\u256F\u256F</c1><c2>\u2571</c2>",
      "<c1>\u2503\u256D\u256E\u2503</c1><c2>\u2571</c2>",
      "<c1>\u2503\u2503\u2503\u2570\u256E</c1>",
      "<c1>\u2570\u256F\u2570\u2501\u256F</c1>"
    ],
    L: [
      "<c1>\u256D\u256E</c1><c2>\u2571\u2571\u2571</c2>",
      "<c1>\u2503\u2503</c1><c2>\u2571\u2571\u2571</c2>",
      "<c1>\u2503\u2503</c1><c2>\u2571\u2571\u2571</c2>",
      "<c1>\u2503\u2503</c1><c2>\u2571</c2><c1>\u256D\u256E</c1>",
      "<c1>\u2503\u2570\u2501\u256F\u2503</c1>",
      "<c1>\u2570\u2501\u2501\u2501\u256F</c1>"
    ],
    M: [
      "<c1>\u256D\u2501\u256E\u256D\u2501\u256E</c1>",
      "<c1>\u2503\u2503\u2570\u256F\u2503\u2503</c1>",
      "<c1>\u2503\u256D\u256E\u256D\u256E\u2503</c1>",
      "<c1>\u2503\u2503\u2503\u2503\u2503\u2503</c1>",
      "<c1>\u2503\u2503\u2503\u2503\u2503\u2503</c1>",
      "<c1>\u2570\u256F\u2570\u256F\u2570\u256F</c1>"
    ],
    N: [
      "<c1>\u256D\u2501\u256E</c1><c2>\u2571</c2><c1>\u256D\u256E</c1>",
      "<c1>\u2503\u2503\u2570\u256E\u2503\u2503</c1>",
      "<c1>\u2503\u256D\u256E\u2570\u256F\u2503</c1>",
      "<c1>\u2503\u2503\u2570\u256E\u2503\u2503</c1>",
      "<c1>\u2503\u2503</c1><c2>\u2571</c2><c1>\u2503\u2503\u2503</c1>",
      "<c1>\u2570\u256F</c1><c2>\u2571</c2><c1>\u2570\u2501\u256F</c1>"
    ],
    O: [
      "<c1>\u256D\u2501\u2501\u2501\u256E</c1>",
      "<c1>\u2503\u256D\u2501\u256E\u2503</c1>",
      "<c1>\u2503\u2503</c1><c2>\u2571</c2><c1>\u2503\u2503</c1>",
      "<c1>\u2503\u2503</c1><c2>\u2571</c2><c1>\u2503\u2503</c1>",
      "<c1>\u2503\u2570\u2501\u256F\u2503</c1>",
      "<c1>\u2570\u2501\u2501\u2501\u256F</c1>"
    ],
    P: [
      "<c1>\u256D\u2501\u2501\u2501\u256E</c1>",
      "<c1>\u2503\u256D\u2501\u256E\u2503</c1>",
      "<c1>\u2503\u2570\u2501\u256F\u2503</c1>",
      "<c1>\u2503\u256D\u2501\u2501\u256F</c1>",
      "<c1>\u2503\u2503</c1><c2>\u2571\u2571\u2571</c2>",
      "<c1>\u2570\u256F</c1><c2>\u2571\u2571\u2571</c2>"
    ],
    Q: [
      "<c1>\u256D\u2501\u2501\u2501\u256E</c1><c2>\u2571</c2>",
      "<c1>\u2503\u256D\u2501\u256E\u2503</c1><c2>\u2571</c2>",
      "<c1>\u2503\u2503</c1><c2>\u2571</c2><c1>\u2503\u2503</c1><c2>\u2571</c2>",
      "<c1>\u2503\u2503</c1><c2>\u2571</c2><c1>\u2503\u2503</c1><c2>\u2571</c2>",
      "<c1>\u2503\u2570\u2501\u256F\u2503\u256E</c1>",
      "<c1>\u2570\u2501\u2501\u2501\u2501\u256F</c1>"
    ],
    R: ["<c1>\u256D\u2501\u2501\u2501\u256E</c1>", "<c1>\u2503\u256D\u2501\u256E\u2503</c1>", "<c1>\u2503\u2570\u2501\u256F\u2503</c1>", "<c1>\u2503\u256D\u256E\u256D\u256F</c1>", "<c1>\u2503\u2503\u2503\u2570\u256E</c1>", "<c1>\u2570\u256F\u2570\u2501\u256F</c1>"],
    S: ["<c1>\u256D\u2501\u2501\u2501\u256E</c1>", "<c1>\u2503\u256D\u2501\u256E\u2503</c1>", "<c1>\u2503\u2570\u2501\u2501\u256E</c1>", "<c1>\u2570\u2501\u2501\u256E\u2503</c1>", "<c1>\u2503\u2570\u2501\u256F\u2503</c1>", "<c1>\u2570\u2501\u2501\u2501\u256F</c1>"],
    T: [
      "<c1>\u256D\u2501\u2501\u2501\u2501\u256E</c1>",
      "<c1>\u2503\u256D\u256E\u256D\u256E\u2503</c1>",
      "<c1>\u2570\u256F\u2503\u2503\u2570\u256F</c1>",
      "<c2>\u2571\u2571</c2><c1>\u2503\u2503</c1><c2>\u2571\u2571</c2>",
      "<c2>\u2571\u2571</c2><c1>\u2503\u2503</c1><c2>\u2571\u2571</c2>",
      "<c2>\u2571\u2571</c2><c1>\u2570\u256F</c1><c2>\u2571\u2571</c2>"
    ],
    U: [
      "<c1>\u256D\u256E</c1><c2>\u2571</c2><c1>\u256D\u256E</c1>",
      "<c1>\u2503\u2503</c1><c2>\u2571</c2><c1>\u2503\u2503</c1>",
      "<c1>\u2503\u2503</c1><c2>\u2571</c2><c1>\u2503\u2503</c1>",
      "<c1>\u2503\u2503</c1><c2>\u2571</c2><c1>\u2503\u2503</c1>",
      "<c1>\u2503\u2570\u2501\u256F\u2503</c1>",
      "<c1>\u2570\u2501\u2501\u2501\u256F</c1>"
    ],
    V: [
      "<c1>\u256D\u256E</c1><c2>\u2571\u2571</c2><c1>\u256D\u256E</c1>",
      "<c1>\u2503\u2570\u256E\u256D\u256F\u2503</c1>",
      "<c1>\u2570\u256E\u2503\u2503\u256D\u256F</c1>",
      "<c2>\u2571</c2><c1>\u2503\u2570\u256F\u2503</c1><c2>\u2571</c2>",
      "<c2>\u2571</c2><c1>\u2570\u256E\u256D\u256F</c1><c2>\u2571</c2>",
      "<c2>\u2571\u2571</c2><c1>\u2570\u256F</c1><c2>\u2571\u2571</c2>"
    ],
    W: [
      "<c1>\u256D\u256E\u256D\u256E\u256D\u256E</c1>",
      "<c1>\u2503\u2503\u2503\u2503\u2503\u2503</c1>",
      "<c1>\u2503\u2503\u2503\u2503\u2503\u2503</c1>",
      "<c1>\u2503\u2570\u256F\u2570\u256F\u2503</c1>",
      "<c1>\u2570\u256E\u256D\u256E\u256D\u256F</c1>",
      "<c2>\u2571</c2><c1>\u2570\u256F\u2570\u256F</c1><c2>\u2571</c2>"
    ],
    X: [
      "<c1>\u256D\u2501\u256E\u256D\u2501\u256E</c1>",
      "<c1>\u2570\u256E\u2570\u256F\u256D\u256F</c1>",
      "<c2>\u2571</c2><c1>\u2570\u256E\u256D\u256F</c1><c2>\u2571</c2>",
      "<c2>\u2571</c2><c1>\u256D\u256F\u2570\u256E</c1><c2>\u2571</c2>",
      "<c1>\u256D\u256F\u256D\u256E\u2570\u256E</c1>",
      "<c1>\u2570\u2501\u256F\u2570\u2501\u256F</c1>"
    ],
    Y: [
      "<c1>\u256D\u256E</c1><c2>\u2571\u2571</c2><c1>\u256D\u256E</c1>",
      "<c1>\u2503\u2570\u256E\u256D\u256F\u2503</c1>",
      "<c1>\u2570\u256E\u2570\u256F\u256D\u256F</c1>",
      "<c2>\u2571</c2><c1>\u2570\u256E\u256D\u256F</c1><c2>\u2571</c2>",
      "<c2>\u2571\u2571</c2><c1>\u2503\u2503</c1><c2>\u2571\u2571</c2>",
      "<c2>\u2571\u2571</c2><c1>\u2570\u256F</c1><c2>\u2571\u2571</c2>"
    ],
    Z: [
      "<c1>\u256D\u2501\u2501\u2501\u2501\u256E</c1>",
      "<c1>\u2570\u2501\u2501\u256E\u2501\u2503</c1>",
      "<c2>\u2571\u2571</c2><c1>\u256D\u256F\u256D\u256F</c1>",
      "<c2>\u2571</c2><c1>\u256D\u256F\u256D\u256F</c1><c2>\u2571</c2>",
      "<c1>\u256D\u256F\u2501\u2570\u2501\u256E</c1>",
      "<c1>\u2570\u2501\u2501\u2501\u2501\u256F</c1>"
    ],
    "0": ["<c1>\u256D\u2501\u2501\u2501\u256E</c1>", "<c1>\u2503\u256D\u2501\u256E\u2503</c1>", "<c1>\u2503\u2503\u2503\u2503\u2503</c1>", "<c1>\u2503\u2503\u2503\u2503\u2503</c1>", "<c1>\u2503\u2570\u2501\u256F\u2503</c1>", "<c1>\u2570\u2501\u2501\u2501\u256F</c1>"],
    "1": [
      "<c2>\u2571</c2><c1>\u256D\u256E</c1><c2>\u2571</c2>",
      "<c1>\u256D\u256F\u2503</c1><c2>\u2571</c2>",
      "<c1>\u2570\u256E\u2503</c1><c2>\u2571</c2>",
      "<c2>\u2571</c2><c1>\u2503\u2503</c1><c2>\u2571</c2>",
      "<c1>\u256D\u256F\u2570\u256E</c1>",
      "<c1>\u2570\u2501\u2501\u256F</c1>"
    ],
    "2": ["<c1>\u256D\u2501\u2501\u2501\u256E</c1>", "<c1>\u2503\u256D\u2501\u256E\u2503</c1>", "<c1>\u2570\u256F\u256D\u256F\u2503</c1>", "<c1>\u256D\u2501\u256F\u256D\u256F</c1>", "<c1>\u2503\u2570\u2501\u2501\u256E</c1>", "<c1>\u2570\u2501\u2501\u2501\u256F</c1>"],
    "3": ["<c1>\u256D\u2501\u2501\u2501\u256E</c1>", "<c1>\u2503\u256D\u2501\u256E\u2503</c1>", "<c1>\u2570\u256F\u256D\u256F\u2503</c1>", "<c1>\u256D\u256E\u2570\u256E\u2503</c1>", "<c1>\u2503\u2570\u2501\u256F\u2503</c1>", "<c1>\u2570\u2501\u2501\u2501\u256F</c1>"],
    "4": [
      "<c1>\u256D\u256E</c1><c2>\u2571</c2><c1>\u256D\u256E</c1>",
      "<c1>\u2503\u2503</c1><c2>\u2571</c2><c1>\u2503\u2503</c1>",
      "<c1>\u2503\u2570\u2501\u256F\u2503</c1>",
      "<c1>\u2570\u2501\u2501\u256E\u2503</c1>",
      "<c2>\u2571\u2571\u2571</c2><c1>\u2503\u2503</c1>",
      "<c2>\u2571\u2571\u2571</c2><c1>\u2570\u256F</c1>"
    ],
    "5": ["<c1>\u256D\u2501\u2501\u2501\u256E</c1>", "<c1>\u2503\u256D\u2501\u2501\u256F</c1>", "<c1>\u2503\u2570\u2501\u2501\u256E</c1>", "<c1>\u2570\u2501\u2501\u256E\u2503</c1>", "<c1>\u256D\u2501\u2501\u256F\u2503</c1>", "<c1>\u2570\u2501\u2501\u2501\u256F</c1>"],
    "6": ["<c1>\u256D\u2501\u2501\u2501\u256E</c1>", "<c1>\u2503\u256D\u2501\u2501\u256F</c1>", "<c1>\u2503\u2570\u2501\u2501\u256E</c1>", "<c1>\u2503\u256D\u2501\u256E\u2503</c1>", "<c1>\u2503\u2570\u2501\u256F\u2503</c1>", "<c1>\u2570\u2501\u2501\u2501\u256F</c1>"],
    "7": [
      "<c1>\u256D\u2501\u2501\u2501\u256E</c1>",
      "<c1>\u2503\u256D\u2501\u256E\u2503</c1>",
      "<c1>\u2570\u256F\u256D\u256F\u2503</c1>",
      "<c2>\u2571\u2571</c2><c1>\u2503\u256D\u256F</c1>",
      "<c2>\u2571\u2571</c2><c1>\u2503\u2503</c1><c2>\u2571</c2>",
      "<c2>\u2571\u2571</c2><c1>\u2570\u256F</c1><c2>\u2571</c2>"
    ],
    "8": ["<c1>\u256D\u2501\u2501\u2501\u256E</c1>", "<c1>\u2503\u256D\u2501\u256E\u2503</c1>", "<c1>\u2503\u2570\u2501\u256F\u2503</c1>", "<c1>\u2503\u256D\u2501\u256E\u2503</c1>", "<c1>\u2503\u2570\u2501\u256F\u2503</c1>", "<c1>\u2570\u2501\u2501\u2501\u256F</c1>"],
    "9": ["<c1>\u256D\u2501\u2501\u2501\u256E</c1>", "<c1>\u2503\u256D\u2501\u256E\u2503</c1>", "<c1>\u2503\u2570\u2501\u256F\u2503</c1>", "<c1>\u2570\u2501\u2501\u256E\u2503</c1>", "<c1>\u256D\u2501\u2501\u256F\u2503</c1>", "<c1>\u2570\u2501\u2501\u2501\u256F</c1>"],
    "!": ["<c1>\u256D\u256E</c1>", "<c1>\u2503\u2503</c1>", "<c1>\u2503\u2503</c1>", "<c1>\u2570\u256F</c1>", "<c1>\u256D\u256E</c1>", "<c1>\u2570\u256F</c1>"],
    "?": [
      "<c1>\u256D\u2501\u2501\u2501\u256E</c1>",
      "<c1>\u2503\u256D\u2501\u256E\u2503</c1>",
      "<c1>\u2570\u256F\u256D\u256F\u2503</c1>",
      "<c2>\u2571\u2571</c2><c1>\u2503\u256D\u256F</c1>",
      "<c2>\u2571\u2571</c2><c1>\u256D\u256E</c1><c2>\u2571</c2>",
      "<c2>\u2571\u2571</c2><c1>\u2570\u256F</c1><c2>\u2571</c2>"
    ],
    ".": ["<c2>\u2571\u2571</c2>", "<c2>\u2571\u2571</c2>", "<c2>\u2571\u2571</c2>", "<c2>\u2571\u2571</c2>", "<c1>\u256D\u256E</c1>", "<c1>\u2570\u256F</c1>"],
    "+": [
      "<c2>\u2571\u2571\u2571\u2571</c2>",
      "<c2>\u2571\u2571\u2571\u2571</c2>",
      "<c2>\u2571</c2><c1>\u256D\u256E</c1><c2>\u2571</c2>",
      "<c1>\u256D\u256F\u2570\u256E</c1>",
      "<c1>\u2570\u256E\u256D\u256F</c1>",
      "<c2>\u2571</c2><c1>\u2570\u256F</c1><c2>\u2571</c2>"
    ],
    "-": ["<c2>\u2571\u2571\u2571\u2571</c2>", "<c2>\u2571\u2571\u2571\u2571</c2>", "<c2>\u2571\u2571\u2571\u2571</c2>", "<c1>\u256D\u2501\u2501\u256E</c1>", "<c1>\u2570\u2501\u2501\u256F</c1>", "<c2>\u2571\u2571\u2571\u2571</c2>"],
    _: ["<c2>\u2571\u2571\u2571\u2571</c2>", "<c2>\u2571\u2571\u2571\u2571</c2>", "<c2>\u2571\u2571\u2571\u2571</c2>", "<c2>\u2571\u2571\u2571\u2571</c2>", "<c1>\u256D\u2501\u2501\u256E</c1>", "<c1>\u2570\u2501\u2501\u256F</c1>"],
    "=": ["<c2>\u2571\u2571\u2571\u2571\u2571</c2>", "<c2>\u2571\u2571\u2571\u2571\u2571</c2>", "<c1>\u256D\u2501\u2501\u2501\u256E</c1>", "<c1>\u2570\u2501\u2501\u2501\u256F</c1>", "<c1>\u256D\u2501\u2501\u2501\u256E</c1>", "<c1>\u2570\u2501\u2501\u2501\u256F</c1>"],
    "@": [
      "<c1>\u256D\u2501\u2501\u2501\u2501\u256E</c1><c2>\u2571</c2>",
      "<c1>\u2503\u256D\u2501\u2501\u256E\u2503</c1><c2>\u2571</c2>",
      "<c1>\u2503\u2503\u256D\u2501\u2503\u2503</c1><c2>\u2571</c2>",
      "<c1>\u2503\u2503\u2570\u256F\u2503\u2503</c1><c2>\u2571</c2>",
      "<c1>\u2503\u2570\u2501\u2501\u256F\u2501\u256E</c1>",
      "<c1>\u2570\u2501\u2501\u2501\u2501\u2501\u256F</c1>"
    ],
    "#": [
      "<c2>\u2571</c2><c1>\u256D\u2501\u2501\u256E</c1><c2>\u2571</c2>",
      "<c1>\u256D\u256F\u256D\u256E\u2570\u256E</c1>",
      "<c1>\u2570\u256E\u2503\u2503\u256D\u256F</c1>",
      "<c1>\u256D\u256F\u2503\u2503\u2570\u256E</c1>",
      "<c1>\u2570\u256E\u2570\u256F\u256D\u256F</c1>",
      "<c2>\u2571</c2><c1>\u2570\u2501\u2501\u256F</c1><c2>\u2571</c2>"
    ],
    $: [
      "<c2>\u2571\u2571</c2><c1>\u256D\u256E</c1><c2>\u2571</c2>",
      "<c1>\u256D\u2501\u256F\u2570\u256E</c1>",
      "<c1>\u2503\u2570\u2501\u2501\u256E</c1>",
      "<c1>\u2570\u2501\u2501\u256E\u2503</c1>",
      "<c1>\u2570\u256E\u256D\u2501\u256F</c1>",
      "<c2>\u2571</c2><c1>\u2570\u256F</c1><c2>\u2571\u2571</c2>"
    ],
    "%": [
      "<c1>\u256D\u256E</c1><c2>\u2571\u2571</c2><c1>\u256D\u2501\u256E</c1>",
      "<c1>\u2570\u256F</c1><c2>\u2571</c2><c1>\u256D\u256F\u256D\u256F</c1>",
      "<c2>\u2571\u2571</c2><c1>\u256D\u256F\u256D\u256F</c1><c2>\u2571</c2>",
      "<c2>\u2571</c2><c1>\u256D\u256F\u256D\u256F</c1><c2>\u2571\u2571</c2>",
      "<c1>\u256D\u256F\u256D\u256F</c1><c2>\u2571</c2><c1>\u256D\u256E</c1>",
      "<c1>\u2570\u2501\u256F</c1><c2>\u2571\u2571</c2><c1>\u2570\u256F</c1>"
    ],
    "&": [
      "<c2>\u2571</c2><c1>\u256D\u2501\u2501\u256E</c1>",
      "<c2>\u2571</c2><c1>\u2503\u256D\u2501\u256F</c1>",
      "<c1>\u256D\u256F\u2570\u256E</c1><c2>\u2571</c2>",
      "<c1>\u2503\u256D\u256E\u2503</c1><c2>\u2571</c2>",
      "<c1>\u2503\u2570\u256F\u2503\u256E</c1>",
      "<c1>\u2570\u2501\u2501\u2501\u256F</c1>"
    ],
    "(": [
      "<c2>\u2571\u2571</c2><c1>\u256D\u2501\u256E</c1>",
      "<c2>\u2571</c2><c1>\u256D\u256F\u256D\u256F</c1>",
      "<c1>\u256D\u256F\u256D\u256F</c1><c2>\u2571</c2>",
      "<c1>\u2570\u256E\u2570\u256E</c1><c2>\u2571</c2>",
      "<c2>\u2571</c2><c1>\u2570\u256E\u2570\u256E</c1>",
      "<c2>\u2571\u2571</c2><c1>\u2570\u2501\u256F</c1>"
    ],
    ")": [
      "<c1>\u256D\u2501\u256E</c1><c2>\u2571\u2571</c2>",
      "<c1>\u2570\u256E\u2570\u256E</c1><c2>\u2571</c2>",
      "<c2>\u2571</c2><c1>\u2570\u256E\u2570\u256E</c1>",
      "<c2>\u2571</c2><c1>\u256D\u256F\u256D\u256F</c1>",
      "<c1>\u256D\u256F\u256D\u256F</c1><c2>\u2571</c2>",
      "<c1>\u2570\u2501\u256F</c1><c2>\u2571\u2571</c2>"
    ],
    "/": [
      "<c2>\u2571\u2571\u2571\u2571</c2><c1>\u256D\u2501\u256E</c1>",
      "<c2>\u2571\u2571\u2571</c2><c1>\u256D\u256F\u256D\u256F</c1>",
      "<c2>\u2571\u2571</c2><c1>\u256D\u256F\u256D\u256F</c1><c2>\u2571</c2>",
      "<c2>\u2571</c2><c1>\u256D\u256F\u256D\u256F</c1><c2>\u2571\u2571</c2>",
      "<c1>\u256D\u256F\u256D\u256F</c1><c2>\u2571\u2571\u2571</c2>",
      "<c1>\u2570\u2501\u256F</c1><c2>\u2571\u2571\u2571\u2571</c2>"
    ],
    ":": ["<c2>\u2571\u2571</c2>", "<c1>\u256D\u256E</c1>", "<c1>\u2570\u256F</c1>", "<c1>\u256D\u256E</c1>", "<c1>\u2570\u256F</c1>", "<c2>\u2571\u2571</c2>"],
    ";": ["<c1>\u256D\u256E</c1>", "<c1>\u2503\u2503</c1>", "<c1>\u2570\u256F</c1>", "<c1>\u256D\u256E</c1>", "<c1>\u2570\u252B</c1>", "<c2>\u2571</c2><c1>\u256F</c1>"],
    ",": ["<c2>\u2571\u2571</c2>", "<c2>\u2571\u2571</c2>", "<c2>\u2571\u2571</c2>", "<c1>\u256D\u256E</c1>", "<c1>\u2570\u252B</c1>", "<c2>\u2571</c2><c1>\u256F</c1>"],
    "'": ["<c1>\u256D\u256E</c1>", "<c1>\u2570\u256F</c1>", "<c2>\u2571\u2571</c2>", "<c2>\u2571\u2571</c2>", "<c2>\u2571\u2571</c2>", "<c2>\u2571\u2571</c2>"],
    '"': ["<c1>\u256D\u256E\u256D\u256E</c1>", "<c1>\u2570\u256F\u2570\u256F</c1>", "<c2>\u2571\u2571\u2571\u2571</c2>", "<c2>\u2571\u2571\u2571\u2571</c2>", "<c2>\u2571\u2571\u2571\u2571</c2>", "<c2>\u2571\u2571\u2571\u2571</c2>"],
    " ": ["<c2>\u2571\u2571\u2571</c2>", "<c2>\u2571\u2571\u2571</c2>", "<c2>\u2571\u2571\u2571</c2>", "<c2>\u2571\u2571\u2571</c2>", "<c2>\u2571\u2571\u2571</c2>", "<c2>\u2571\u2571\u2571</c2>"]
  }
};
// src/lib/fonts/tiny.json
var tiny_default = {
  name: "tiny",
  version: "0.2.0",
  homepage: "https://github.com/dominikwilkowski/cfonts",
  colors: 1,
  lines: 2,
  buffer: ["", ""],
  letterspace: [" ", " "],
  letterspace_size: 1,
  chars: {
    A: ["\u2584\u2580\u2588", "\u2588\u2580\u2588"],
    B: ["\u2588\u2584\u2584", "\u2588\u2584\u2588"],
    C: ["\u2588\u2580\u2580", "\u2588\u2584\u2584"],
    D: ["\u2588\u2580\u2584", "\u2588\u2584\u2580"],
    E: ["\u2588\u2580\u2580", "\u2588\u2588\u2584"],
    F: ["\u2588\u2580\u2580", "\u2588\u2580 "],
    G: ["\u2588\u2580\u2580", "\u2588\u2584\u2588"],
    H: ["\u2588 \u2588", "\u2588\u2580\u2588"],
    I: ["\u2588", "\u2588"],
    J: ["  \u2588", "\u2588\u2584\u2588"],
    K: ["\u2588\u2584\u2580", "\u2588 \u2588"],
    L: ["\u2588  ", "\u2588\u2584\u2584"],
    M: ["\u2588\u2580\u2584\u2580\u2588", "\u2588 \u2580 \u2588"],
    N: ["\u2588\u2584 \u2588", "\u2588 \u2580\u2588"],
    O: ["\u2588\u2580\u2588", "\u2588\u2584\u2588"],
    P: ["\u2588\u2580\u2588", "\u2588\u2580\u2580"],
    Q: ["\u2588\u2580\u2588", "\u2580\u2580\u2588"],
    R: ["\u2588\u2580\u2588", "\u2588\u2580\u2584"],
    S: ["\u2588\u2580\u2580", "\u2584\u2584\u2588"],
    T: ["\u2580\u2588\u2580", " \u2588 "],
    U: ["\u2588 \u2588", "\u2588\u2584\u2588"],
    V: ["\u2588 \u2588", "\u2580\u2584\u2580"],
    W: ["\u2588 \u2588 \u2588", "\u2580\u2584\u2580\u2584\u2580"],
    X: ["\u2580\u2584\u2580", "\u2588 \u2588"],
    Y: ["\u2588\u2584\u2588", " \u2588 "],
    Z: ["\u2580\u2588", "\u2588\u2584"],
    "0": ["\u259E\u2588\u259A", "\u259A\u2588\u259E"],
    "1": ["\u2584\u2588", " \u2588"],
    "2": ["\u2580\u2588", "\u2588\u2584"],
    "3": ["\u2580\u2580\u2588", "\u2584\u2588\u2588"],
    "4": ["\u2588 \u2588", "\u2580\u2580\u2588"],
    "5": ["\u2588\u2580", "\u2584\u2588"],
    "6": ["\u2588\u2584\u2584", "\u2588\u2584\u2588"],
    "7": ["\u2580\u2580\u2588", "  \u2588"],
    "8": ["\u2588\u2588\u2588", "\u2588\u2584\u2588"],
    "9": ["\u2588\u2580\u2588", "\u2580\u2580\u2588"],
    "!": ["\u2588", "\u2584"],
    "?": ["\u2580\u2588", " \u2584"],
    ".": [" ", "\u2584"],
    "+": ["\u2584\u2588\u2584", " \u2580 "],
    "-": ["\u2584\u2584", "  "],
    _: ["  ", "\u2584\u2584"],
    "=": ["\u2580\u2580", "\u2580\u2580"],
    "@": ["\u259B\u2588\u259C", "\u2599\u259F\u2583"],
    "#": ["\u259F\u2584\u2599", "\u259C\u2580\u259B"],
    $: ["\u2596\u2588\u2597", "\u2598\u2588\u259D"],
    "%": ["\u2580 \u2584\u2580", "\u2584\u2580 \u2584"],
    "&": ["\u2584\u2584\u2588", "\u2588\u2584\u2588"],
    "(": ["\u2584\u2580", "\u2580\u2584"],
    ")": ["\u2580\u2584", "\u2584\u2580"],
    "/": ["  \u2584\u2580", "\u2584\u2580  "],
    ":": ["\u2580", "\u2584"],
    ";": ["  ", "\u2584\u2580"],
    ",": [" ", "\u2588"],
    "'": ["\u2580", " "],
    '"': ["\u259B \u259C", "   "],
    " ": [" ", " "]
  }
};
// src/lib/fonts/huge.json
var huge_default = {
  name: "huge",
  version: "0.2.0",
  homepage: "https://github.com/dominikwilkowski/cfonts",
  colors: 2,
  lines: 11,
  buffer: ["", "", "", "", "", "", "", "", "", "", ""],
  letterspace: [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
  letterspace_size: 1,
  chars: {
    A: [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580         \u2580</c1> "
    ],
    B: [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1>  ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1> ",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1>  "
    ],
    C: [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> "
    ],
    D: [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1>  ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1> ",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1>  "
    ],
    E: [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> "
    ],
    F: [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      " <c1>\u2580</c1>           "
    ],
    G: [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C \u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C \u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> "
    ],
    H: [
      " <c1>\u2584         \u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580         \u2580</c1> "
    ],
    I: [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580</c1> ",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      " <c1>\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> "
    ],
    J: [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580</c1> ",
      "      <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>    ",
      "      <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>    ",
      "      <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>    ",
      "      <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>    ",
      "      <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>    ",
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>    ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>    ",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1>     "
    ],
    K: [
      " <c1>\u2584    \u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C  \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C \u2590</c1><c2>\u2591</c2><c1>\u258C</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>  ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1><c2>\u2591</c2><c1>\u258C</c1>   ",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>    ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1><c2>\u2591</c2><c1>\u258C</c1>   ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>  ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C \u2590</c1><c2>\u2591</c2><c1>\u258C</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C  \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580    \u2580</c1> "
    ],
    L: [
      " <c1>\u2584</c1>           ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> "
    ],
    M: [
      " <c1>\u2584\u2584       \u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C     \u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1><c2>\u2591</c2><c1>\u258C   \u2590</c1><c2>\u2591</c2><c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C\u2590</c1><c2>\u2591</c2><c1>\u258C \u2590</c1><c2>\u2591</c2><c1>\u258C\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C \u2590</c1><c2>\u2591</c2><c1>\u2590</c1><c2>\u2591</c2><c1>\u258C \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C  \u2590</c1><c2>\u2591</c2><c1>\u258C  \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C   \u2580   \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580         \u2580</c1> "
    ],
    N: [
      " <c1>\u2584\u2584        \u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C      \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1><c2>\u2591</c2><c1>\u258C     \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C\u2590</c1><c2>\u2591</c2><c1>\u258C    \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C \u2590</c1><c2>\u2591</c2><c1>\u258C   \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C  \u2590</c1><c2>\u2591</c2><c1>\u258C  \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C   \u2590</c1><c2>\u2591</c2><c1>\u258C \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C    \u2590</c1><c2>\u2591</c2><c1>\u258C\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C     \u2590</c1><c2>\u2591</c2><c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C      \u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580        \u2580\u2580</c1> "
    ],
    O: [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> "
    ],
    P: [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      " <c1>\u2580</c1>           "
    ],
    Q: [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580</c1> ",
      "        <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>  ",
      "         <c1>\u2580</c1>   "
    ],
    R: [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C     \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>  ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C      \u2590</c1><c2>\u2591</c2><c1>\u258C</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580         \u2580</c1> "
    ],
    S: [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "          <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> "
    ],
    T: [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580</c1> ",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      "      <c1>\u2580</c1>      "
    ],
    U: [
      " <c1>\u2584         \u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> "
    ],
    V: [
      " <c1>\u2584               \u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C             \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C           \u2590</c1><c2>\u2591</c2><c1>\u258C</c1> ",
      "  <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C         \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>  ",
      "   <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>   ",
      "    <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C     \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>    ",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C   \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      "      <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>      ",
      "       <c1>\u2590</c1><c2>\u2591</c2><c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>       ",
      "        <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>        ",
      "         <c1>\u2580</c1>         "
    ],
    W: [
      " <c1>\u2584         \u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C   \u2584   \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C  \u2590</c1><c2>\u2591</c2><c1>\u258C  \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C \u2590</c1><c2>\u2591</c2><c1>\u258C</c1><c2>\u2591</c2><c1>\u258C \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C\u2590</c1><c2>\u2591</c2><c1>\u258C \u2590</c1><c2>\u2591</c2><c1>\u258C\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1><c2>\u2591</c2><c1>\u258C   \u2590</c1><c2>\u2591</c2><c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C     \u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580       \u2580\u2580</c1> "
    ],
    X: [
      " <c1>\u2584       \u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C     \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C   \u2590</c1><c2>\u2591</c2><c1>\u258C</c1> ",
      "  <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>  ",
      "   <c1>\u2590</c1><c2>\u2591</c2><c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>   ",
      "    <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>    ",
      "   <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1><c2>\u2591</c2><c1>\u258C</c1>   ",
      "  <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>  ",
      " <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C   \u2590</c1><c2>\u2591</c2><c1>\u258C</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C     \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580       \u2580</c1> "
    ],
    Y: [
      " <c1>\u2584         \u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580</c1> ",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      "      <c1>\u2580</c1>      "
    ],
    Z: [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1> ",
      "    <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>  ",
      "   <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>   ",
      "  <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>    ",
      " <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> "
    ],
    "0": [
      "  <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1>  ",
      " <c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C\u2590</c1><c2>\u2591</c2><c1>\u258C    \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C \u2590</c1><c2>\u2591</c2><c1>\u258C   \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C  \u2590</c1><c2>\u2591</c2><c1>\u258C  \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C   \u2590</c1><c2>\u2591</c2><c1>\u258C \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C    \u2590</c1><c2>\u2591</c2><c1>\u258C\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1> ",
      "  <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1>  "
    ],
    "1": [
      "    <c1>\u2584\u2584\u2584\u2584</c1>     ",
      "  <c1>\u2584\u2588</c1><c2>\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>    ",
      " <c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>    ",
      "  <c1>\u2580\u2580 \u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>    ",
      "     <c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>    ",
      "     <c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>    ",
      "     <c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>    ",
      "     <c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>    ",
      " <c1>\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> "
    ],
    "2": [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "          <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "          <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> "
    ],
    "3": [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "          <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "          <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> "
    ],
    "4": [
      " <c1>\u2584         \u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "          <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "          <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "          <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "           <c1>\u2580</c1> "
    ],
    "5": [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "          <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "          <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> "
    ],
    "6": [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>          ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> "
    ],
    "7": [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "         <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1> ",
      "        <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>  ",
      "       <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>   ",
      "      <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>    ",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      "    <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>      ",
      "   <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>       ",
      "    <c1>\u2580</c1>        "
    ],
    "8": [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> "
    ],
    "9": [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "          <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> "
    ],
    "!": [
      " <c1>\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580</c1> ",
      " <c1>\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580</c1> "
    ],
    "?": [
      "    <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1>  ",
      "  <c1>\u2584\u2588</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u2588\u2584</c1> ",
      " <c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      "  <c1>\u2580\u2580  \u2584\u2584\u2584\u2588</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      "    <c1>\u2584\u2588</c1><c2>\u2591\u2591\u2591\u2591\u2591</c2><c1>\u2588</c1> ",
      "   <c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C\u2580\u2580\u2580\u2580</c1>  ",
      "   <c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>      ",
      "    <c1>\u2580\u2580</c1>       ",
      "    <c1>\u2584\u2584</c1>       ",
      "   <c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>      ",
      "    <c1>\u2580\u2580</c1>       "
    ],
    ".": [
      "    ",
      "    ",
      "    ",
      "    ",
      "    ",
      "    ",
      "    ",
      "    ",
      " <c1>\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580</c1> "
    ],
    "+": [
      "          ",
      "          ",
      "    <c1>\u2584\u2584</c1>    ",
      "   <c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>   ",
      " <c1>\u2584\u2584\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2588</c1><c2>\u2591\u2591</c2><c1>\u2588\u2580\u2580</c1> ",
      "   <c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>   ",
      "    <c1>\u2580\u2580</c1>    ",
      "          ",
      "          "
    ],
    "-": [
      "       ",
      "       ",
      "       ",
      "       ",
      " <c1>\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580</c1> ",
      "       ",
      "       ",
      "       ",
      "       "
    ],
    _: [
      "       ",
      "       ",
      "       ",
      "       ",
      "       ",
      "       ",
      "       ",
      " <c1>\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580</c1> ",
      "       "
    ],
    "=": [
      "       ",
      "       ",
      " <c1>\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580</c1> ",
      "       ",
      " <c1>\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580</c1> ",
      "       ",
      "       "
    ],
    "@": [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C        \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C  \u2584\u2584\u2584\u2584  \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C \u2588</c1><c2>\u2591\u2591\u2591\u2591</c2><c1>\u2588 \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C\u2590</c1><c2>\u2591</c2><c1>\u2588\u2588\u2588\u2588</c1><c2>\u2591</c2><c1>\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C \u2588</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C\u2584\u2584\u2588\u2588\u2588\u2588\u2588\u2588\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2580</c1> "
    ],
    "#": [
      "   <c1>\u2584         \u2584</c1>   ",
      "  <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>  ",
      " <c1>\u2584\u2588</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u2588\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2588</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u2588\u2580</c1> ",
      "  <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>  ",
      " <c1>\u2584\u2588</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u2588\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2588</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u2588\u2580</c1> ",
      "  <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C       \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>  ",
      "   <c1>\u2580         \u2580</c1>   "
    ],
    $: [
      "      <c1>\u2584</c1>      ",
      " <c1>\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580</c1> ",
      "      <c1>\u2580</c1>      "
    ],
    "%": [
      "         <c1>\u2584</c1> ",
      "  <c1>\u2584     \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C   \u2590</c1><c2>\u2591</c2><c1>\u258C</c1> ",
      "  <c1>\u2580   \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>  ",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>   ",
      "    <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>    ",
      "   <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      "  <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C   \u2584</c1>  ",
      " <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C   \u2590</c1><c2>\u2591</c2><c1>\u258C</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C     \u2580</c1>  ",
      " <c1>\u2580</c1>         "
    ],
    "&": [
      " <c1>\u2584\u2584\u2584\u2584\u2584\u2584\u2584</c1>     ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>    ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>    ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C   \u2590</c1><c2>\u2591</c2><c1>\u258C</c1>    ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>    ",
      " <c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>    ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2580\u2580\u2580\u2580\u2588</c1><c2>\u2591</c2><c1>\u258C \u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C     \u2590</c1><c2>\u2591</c2><c1>\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2588\u2584\u2584\u2584\u2584\u2588</c1><c2>\u2591</c2><c1>\u258C</c1>   ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>  ",
      " <c1>\u2580\u2580\u2580\u2580\u2580\u2580  \u2580</c1>   "
    ],
    "(": [
      "  <c1>\u2584\u2584\u2584\u2584\u2584</c1> ",
      " <c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u2588\u2580\u2580\u2580</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>    ",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>    ",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>    ",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>    ",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>    ",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u2588\u2584\u2584\u2584</c1> ",
      " <c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1>",
      "  <c1>\u2580\u2580\u2580\u2580\u2580</c1> "
    ],
    ")": [
      " <c1>\u2584\u2584\u2584\u2584\u2584</c1>  ",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1> ",
      " <c1>\u2580\u2580\u2580\u2588</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      "    <c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      "    <c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      "    <c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      "    <c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      "    <c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2584\u2584\u2584\u2588</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      "<c1>\u2590</c1><c2>\u2591\u2591\u2591\u2591\u2591</c2><c1>\u258C</c1> ",
      " <c1>\u2580\u2580\u2580\u2580\u2580</c1>  "
    ],
    "/": [
      "         <c1>\u2584</c1> ",
      "        <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>",
      "       <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1> ",
      "      <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>  ",
      "     <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>   ",
      "    <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>    ",
      "   <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>     ",
      "  <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>      ",
      " <c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>       ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u258C</c1>        ",
      " <c1>\u2580</c1>         "
    ],
    ":": [
      "    ",
      "    ",
      " <c1>\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580</c1> ",
      "    ",
      " <c1>\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580</c1> ",
      "    ",
      "    "
    ],
    ";": [
      "    ",
      "    ",
      " <c1>\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u2580</c1> ",
      "    ",
      " <c1>\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u258C</c1> ",
      " <c1>\u2580</c1>  ",
      "    "
    ],
    ",": [
      "    ",
      "    ",
      "    ",
      "    ",
      "    ",
      "    ",
      "    ",
      " <c1>\u2584\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591\u2591</c2><c1>\u258C</c1>",
      " <c1>\u2580\u258C</c1> ",
      " <c1>\u2580</c1>  "
    ],
    "'": [
      " <c1>\u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2590</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2590</c1>",
      " <c1>\u2580</c1> ",
      "   ",
      "   ",
      "   ",
      "   ",
      "   ",
      "   ",
      "   "
    ],
    '"': [
      " <c1>\u2584  \u2584</c1> ",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2590\u2590</c1><c2>\u2591</c2><c1>\u2590</c1>",
      "<c1>\u2590</c1><c2>\u2591</c2><c1>\u2590\u2590</c1><c2>\u2591</c2><c1>\u2590</c1>",
      " <c1>\u2580  \u2580</c1> ",
      "      ",
      "      ",
      "      ",
      "      ",
      "      ",
      "      ",
      "      "
    ],
    " ": ["    ", "    ", "    ", "    ", "    ", "    ", "    ", "    ", "    ", "    ", "    "]
  }
};
// src/lib/fonts/grid.json
var grid_default = {
  name: "grid",
  version: "0.1.0",
  homepage: "https://github.com/dominikwilkowski/cfonts",
  colors: 2,
  lines: 6,
  buffer: ["", "", "", "", "", ""],
  letterspace: ["<c2>\u254B</c2>", "<c2>\u254B</c2>", "<c2>\u254B</c2>", "<c2>\u254B</c2>", "<c2>\u254B</c2>", "<c2>\u254B</c2>"],
  letterspace_size: 1,
  chars: {
    A: ["<c2>\u254B\u254B\u254B\u254B</c2>", "<c1>\u250F\u2501\u2501\u2513</c1>", "<c1>\u2503\u250F\u2513\u2503</c1>", "<c1>\u2503\u250F\u2513\u2503</c1>", "<c1>\u2517\u251B\u2517\u251B</c1>", "<c2>\u254B\u254B\u254B\u254B</c2>"],
    B: [
      "<c1>\u250F\u2513</c1><c2>\u254B\u254B</c2>",
      "<c1>\u2503\u2517\u2501\u2513</c1>",
      "<c1>\u2503\u250F\u2513\u2503</c1>",
      "<c1>\u2503\u2517\u251B\u2503</c1>",
      "<c1>\u2517\u2501\u2501\u251B</c1>",
      "<c2>\u254B\u254B\u254B\u254B</c2>"
    ],
    C: ["<c2>\u254B\u254B\u254B\u254B</c2>", "<c1>\u250F\u2501\u2501\u2513</c1>", "<c1>\u2503\u250F\u2501\u251B</c1>", "<c1>\u2503\u2517\u2501\u2513</c1>", "<c1>\u2517\u2501\u2501\u251B</c1>", "<c2>\u254B\u254B\u254B\u254B</c2>"],
    D: [
      "<c2>\u254B\u254B</c2><c1>\u250F\u2513</c1>",
      "<c1>\u250F\u2501\u251B\u2503</c1>",
      "<c1>\u2503\u250F\u2513\u2503</c1>",
      "<c1>\u2503\u2517\u251B\u2503</c1>",
      "<c1>\u2517\u2501\u2501\u251B</c1>",
      "<c2>\u254B\u254B\u254B\u254B</c2>"
    ],
    E: ["<c2>\u254B\u254B\u254B\u254B</c2>", "<c1>\u250F\u2501\u2501\u2513</c1>", "<c1>\u2503\u2503\u2501\u252B</c1>", "<c1>\u2503\u2503\u2501\u252B</c1>", "<c1>\u2517\u2501\u2501\u251B</c1>", "<c2>\u254B\u254B\u254B\u254B</c2>"],
    F: [
      "<c2>\u254B</c2><c1>\u250F\u2501\u2513</c1>",
      "<c1>\u250F\u251B\u2517\u2513</c1>",
      "<c1>\u2517\u2513\u250F\u251B</c1>",
      "<c2>\u254B</c2><c1>\u2503\u2503</c1><c2>\u254B</c2>",
      "<c2>\u254B</c2><c1>\u2517\u251B</c1><c2>\u254B</c2>",
      "<c2>\u254B\u254B\u254B\u254B</c2>"
    ],
    G: ["<c2>\u254B\u254B\u254B\u254B</c2>", "<c1>\u250F\u2501\u2501\u2513</c1>", "<c1>\u2503\u250F\u2513\u2503</c1>", "<c1>\u2503\u2517\u251B\u2503</c1>", "<c1>\u2517\u2501\u2513\u2503</c1>", "<c1>\u2517\u2501\u2501\u251B</c1>"],
    H: [
      "<c1>\u250F\u2513</c1><c2>\u254B\u254B</c2>",
      "<c1>\u2503\u2517\u2501\u2513</c1>",
      "<c1>\u2503\u250F\u2513\u2503</c1>",
      "<c1>\u2503\u2503\u2503\u2503</c1>",
      "<c1>\u2517\u251B\u2517\u251B</c1>",
      "<c2>\u254B\u254B\u254B\u254B</c2>"
    ],
    I: ["<c1>\u250F\u2513</c1>", "<c1>\u2517\u251B</c1>", "<c1>\u250F\u2513</c1>", "<c1>\u2503\u2503</c1>", "<c1>\u2517\u251B</c1>", "<c2>\u254B\u254B</c2>"],
    J: [
      "<c2>\u254B</c2><c1>\u250F\u2513</c1>",
      "<c2>\u254B</c2><c1>\u2517\u251B</c1>",
      "<c2>\u254B</c2><c1>\u250F\u2513</c1>",
      "<c2>\u254B</c2><c1>\u2503\u2503</c1>",
      "<c1>\u250F\u251B\u2503</c1>",
      "<c1>\u2517\u2501\u251B</c1>"
    ],
    K: [
      "<c1>\u250F\u2513</c1><c2>\u254B\u254B</c2>",
      "<c1>\u2503\u2503\u250F\u2513</c1>",
      "<c1>\u2503\u2517\u251B\u251B</c1>",
      "<c1>\u2503\u250F\u2513\u2513</c1>",
      "<c1>\u2517\u251B\u2517\u251B</c1>",
      "<c2>\u254B\u254B\u254B\u254B</c2>"
    ],
    L: [
      "<c1>\u250F\u2513</c1><c2>\u254B</c2>",
      "<c1>\u2503\u2503</c1><c2>\u254B</c2>",
      "<c1>\u2503\u2503</c1><c2>\u254B</c2>",
      "<c1>\u2503\u2517\u2513</c1>",
      "<c1>\u2517\u2501\u251B</c1>",
      "<c2>\u254B\u254B\u254B</c2>"
    ],
    M: ["<c2>\u254B\u254B\u254B\u254B</c2>", "<c1>\u250F\u2513\u250F\u2513</c1>", "<c1>\u2503\u2517\u251B\u2503</c1>", "<c1>\u2503\u2503\u2503\u2503</c1>", "<c1>\u2517\u253B\u253B\u251B</c1>", "<c2>\u254B\u254B\u254B\u254B</c2>"],
    N: [
      "<c2>\u254B\u254B\u254B\u254B</c2>",
      "<c1>\u250F\u2501\u2513</c1><c2>\u254B</c2>",
      "<c1>\u2503\u250F\u2513\u2513</c1>",
      "<c1>\u2503\u2503\u2503\u2503</c1>",
      "<c1>\u2517\u251B\u2517\u251B</c1>",
      "<c2>\u254B\u254B\u254B\u254B</c2>"
    ],
    O: ["<c2>\u254B\u254B\u254B\u254B</c2>", "<c1>\u250F\u2501\u2501\u2513</c1>", "<c1>\u2503\u250F\u2513\u2503</c1>", "<c1>\u2503\u2517\u251B\u2503</c1>", "<c1>\u2517\u2501\u2501\u251B</c1>", "<c2>\u254B\u254B\u254B\u254B</c2>"],
    P: [
      "<c2>\u254B\u254B\u254B\u254B</c2>",
      "<c1>\u250F\u2501\u2501\u2513</c1>",
      "<c1>\u2503\u250F\u2513\u2503</c1>",
      "<c1>\u2503\u2517\u251B\u2503</c1>",
      "<c1>\u2503\u250F\u2501\u251B</c1>",
      "<c1>\u2517\u251B</c1><c2>\u254B\u254B</c2>"
    ],
    Q: [
      "<c2>\u254B\u254B\u254B\u254B</c2>",
      "<c1>\u250F\u2501\u2501\u2513</c1>",
      "<c1>\u2503\u250F\u2513\u2503</c1>",
      "<c1>\u2503\u2517\u251B\u2503</c1>",
      "<c1>\u2517\u2501\u2513\u2503</c1>",
      "<c2>\u254B\u254B</c2><c1>\u2517\u251B</c1>"
    ],
    R: [
      "<c2>\u254B\u254B\u254B</c2>",
      "<c1>\u250F\u2501\u2513</c1>",
      "<c1>\u2503\u250F\u251B</c1>",
      "<c1>\u2503\u2503</c1><c2>\u254B</c2>",
      "<c1>\u2517\u251B</c1><c2>\u254B</c2>",
      "<c2>\u254B\u254B\u254B</c2>"
    ],
    S: ["<c2>\u254B\u254B\u254B\u254B</c2>", "<c1>\u250F\u2501\u2501\u2513</c1>", "<c1>\u2503\u2501\u2501\u252B</c1>", "<c1>\u2523\u2501\u2501\u2503</c1>", "<c1>\u2517\u2501\u2501\u251B</c1>", "<c2>\u254B\u254B\u254B\u254B</c2>"],
    T: [
      "<c2>\u254B</c2><c1>\u250F\u2513</c1><c2>\u254B</c2>",
      "<c1>\u250F\u251B\u2517\u2513</c1>",
      "<c1>\u2517\u2513\u250F\u251B</c1>",
      "<c2>\u254B</c2><c1>\u2503\u2517\u2513</c1>",
      "<c2>\u254B</c2><c1>\u2517\u2501\u251B</c1>",
      "<c2>\u254B\u254B\u254B\u254B</c2>"
    ],
    U: ["<c2>\u254B\u254B\u254B\u254B</c2>", "<c1>\u250F\u2513\u250F\u2513</c1>", "<c1>\u2503\u2503\u2503\u2503</c1>", "<c1>\u2503\u2517\u251B\u2503</c1>", "<c1>\u2517\u2501\u2501\u251B</c1>", "<c2>\u254B\u254B\u254B\u254B</c2>"],
    V: [
      "<c2>\u254B\u254B\u254B\u254B</c2>",
      "<c1>\u250F\u2513\u250F\u2513</c1>",
      "<c1>\u2503\u2517\u251B\u2503</c1>",
      "<c1>\u2517\u2513\u250F\u251B</c1>",
      "<c2>\u254B</c2><c1>\u2517\u251B</c1><c2>\u254B</c2>",
      "<c2>\u254B\u254B\u254B\u254B</c2>"
    ],
    W: [
      "<c2>\u254B\u254B\u254B\u254B\u254B\u254B</c2>",
      "<c1>\u250F\u2513\u250F\u2513\u250F\u2513</c1>",
      "<c1>\u2503\u2517\u251B\u2517\u251B\u2503</c1>",
      "<c1>\u2517\u2513\u250F\u2513\u250F\u251B</c1>",
      "<c2>\u254B</c2><c1>\u2517\u251B\u2517\u251B</c1><c2>\u254B</c2>",
      "<c2>\u254B\u254B\u254B\u254B\u254B\u254B</c2>"
    ],
    X: ["<c2>\u254B\u254B\u254B\u254B</c2>", "<c1>\u250F\u2513\u250F\u2513</c1>", "<c1>\u2517\u254B\u254B\u251B</c1>", "<c1>\u250F\u254B\u254B\u2513</c1>", "<c1>\u2517\u251B\u2517\u251B</c1>", "<c2>\u254B\u254B\u254B\u254B</c2>"],
    Y: [
      "<c2>\u254B\u254B\u254B\u254B\u254B</c2>",
      "<c1>\u250F\u2513</c1><c2>\u254B</c2><c1>\u250F\u2513</c1>",
      "<c1>\u2503\u2517\u2501\u251B\u2503</c1>",
      "<c1>\u2517\u2501\u2513\u250F\u251B</c1>",
      "<c1>\u2517\u2501\u2501\u251B</c1><c2>\u254B</c2>",
      "<c2>\u254B\u254B\u254B\u254B\u254B</c2>"
    ],
    Z: ["<c2>\u254B\u254B\u254B\u254B\u254B</c2>", "<c1>\u250F\u2501\u2501\u2501\u2513</c1>", "<c1>\u2523\u2501\u2501\u2503\u2503</c1>", "<c1>\u2503\u2503\u2501\u2501\u252B</c1>", "<c1>\u2517\u2501\u2501\u2501\u251B</c1>", "<c2>\u254B\u254B\u254B\u254B\u254B</c2>"],
    "0": ["<c1>\u250F\u2501\u2501\u2501\u2513</c1>", "<c1>\u2503\u250F\u2501\u2513\u2503</c1>", "<c1>\u2503\u2503\u2503\u2503\u2503</c1>", "<c1>\u2503\u2503\u2503\u2503\u2503</c1>", "<c1>\u2503\u2517\u2501\u251B\u2503</c1>", "<c1>\u2517\u2501\u2501\u2501\u251B</c1>"],
    "1": [
      "<c2>\u254B</c2><c1>\u250F\u2513</c1><c2>\u254B</c2>",
      "<c1>\u250F\u251B\u2503</c1><c2>\u254B</c2>",
      "<c1>\u2517\u2513\u2503</c1><c2>\u254B</c2>",
      "<c2>\u254B</c2><c1>\u2503\u2503</c1><c2>\u254B</c2>",
      "<c1>\u250F\u251B\u2517\u2513</c1>",
      "<c1>\u2517\u2501\u2501\u251B</c1>"
    ],
    "2": ["<c1>\u250F\u2501\u2501\u2501\u2513</c1>", "<c1>\u2503\u250F\u2501\u2513\u2503</c1>", "<c1>\u2517\u251B\u250F\u251B\u2503</c1>", "<c1>\u250F\u2501\u251B\u250F\u251B</c1>", "<c1>\u2503\u2517\u2501\u253B\u2513</c1>", "<c1>\u2517\u2501\u2501\u2501\u251B</c1>"],
    "3": ["<c1>\u250F\u2501\u2501\u2501\u2513</c1>", "<c1>\u2503\u250F\u2501\u2513\u2503</c1>", "<c1>\u2517\u251B\u250F\u251B\u2503</c1>", "<c1>\u250F\u2513\u2517\u2513\u2503</c1>", "<c1>\u2503\u2517\u2501\u251B\u2503</c1>", "<c1>\u2517\u2501\u2501\u2501\u251B</c1>"],
    "4": [
      "<c1>\u250F\u2513</c1><c2>\u254B</c2><c1>\u250F\u2513</c1>",
      "<c1>\u2503\u2503</c1><c2>\u254B</c2><c1>\u2503\u2503</c1>",
      "<c1>\u2503\u2517\u2501\u251B\u2503</c1>",
      "<c1>\u2517\u2501\u2501\u2513\u2503</c1>",
      "<c2>\u254B\u254B\u254B</c2><c1>\u2503\u2503</c1>",
      "<c2>\u254B\u254B\u254B</c2><c1>\u2517\u251B</c1>"
    ],
    "5": ["<c1>\u250F\u2501\u2501\u2501\u2513</c1>", "<c1>\u2503\u250F\u2501\u2501\u251B</c1>", "<c1>\u2503\u2517\u2501\u2501\u2513</c1>", "<c1>\u2517\u2501\u2501\u2513\u2503</c1>", "<c1>\u250F\u2501\u2501\u251B\u2503</c1>", "<c1>\u2517\u2501\u2501\u2501\u251B</c1>"],
    "6": ["<c1>\u250F\u2501\u2501\u2501\u2513</c1>", "<c1>\u2503\u250F\u2501\u2501\u251B</c1>", "<c1>\u2503\u2517\u2501\u2501\u2513</c1>", "<c1>\u2503\u250F\u2501\u2513\u2503</c1>", "<c1>\u2503\u2517\u2501\u251B\u2503</c1>", "<c1>\u2517\u2501\u2501\u2501\u251B</c1>"],
    "7": [
      "<c1>\u250F\u2501\u2501\u2501\u2513</c1>",
      "<c1>\u2503\u250F\u2501\u2513\u2503</c1>",
      "<c1>\u2517\u251B\u250F\u251B\u2503</c1>",
      "<c2>\u254B\u254B</c2><c1>\u2503\u250F\u251B</c1>",
      "<c2>\u254B\u254B</c2><c1>\u2503\u2503</c1><c2>\u254B</c2>",
      "<c2>\u254B\u254B</c2><c1>\u2517\u251B</c1><c2>\u254B</c2>"
    ],
    "8": ["<c1>\u250F\u2501\u2501\u2501\u2513</c1>", "<c1>\u2503\u250F\u2501\u2513\u2503</c1>", "<c1>\u2503\u2517\u2501\u251B\u2503</c1>", "<c1>\u2503\u250F\u2501\u2513\u2503</c1>", "<c1>\u2503\u2517\u2501\u251B\u2503</c1>", "<c1>\u2517\u2501\u2501\u2501\u251B</c1>"],
    "9": ["<c1>\u250F\u2501\u2501\u2501\u2513</c1>", "<c1>\u2503\u250F\u2501\u2513\u2503</c1>", "<c1>\u2503\u2517\u2501\u251B\u2503</c1>", "<c1>\u2517\u2501\u2501\u2513\u2503</c1>", "<c1>\u250F\u2501\u2501\u251B\u2503</c1>", "<c1>\u2517\u2501\u2501\u2501\u251B</c1>"],
    "!": ["<c1>\u250F\u2513</c1>", "<c1>\u2503\u2503</c1>", "<c1>\u2503\u2503</c1>", "<c1>\u2517\u251B</c1>", "<c1>\u250F\u2513</c1>", "<c1>\u2517\u251B</c1>"],
    "?": [
      "<c1>\u250F\u2501\u2501\u2501\u2513</c1>",
      "<c1>\u2503\u250F\u2501\u2513\u2503</c1>",
      "<c1>\u2517\u251B\u250F\u251B\u2503</c1>",
      "<c2>\u254B\u254B</c2><c1>\u2503\u250F\u251B</c1>",
      "<c2>\u254B\u254B</c2><c1>\u250F\u2513</c1><c2>\u254B</c2>",
      "<c2>\u254B\u254B</c2><c1>\u2517\u251B</c1><c2>\u254B</c2>"
    ],
    ".": ["<c2>\u254B\u254B</c2>", "<c2>\u254B\u254B</c2>", "<c2>\u254B\u254B</c2>", "<c2>\u254B\u254B</c2>", "<c1>\u250F\u2513</c1>", "<c1>\u2517\u251B</c1>"],
    "+": [
      "<c2>\u254B\u254B\u254B\u254B</c2>",
      "<c2>\u254B</c2><c1>\u250F\u2513</c1><c2>\u254B</c2>",
      "<c1>\u250F\u251B\u2517\u2513</c1>",
      "<c1>\u2517\u2513\u250F\u251B</c1>",
      "<c2>\u254B</c2><c1>\u2517\u251B</c1><c2>\u254B</c2>",
      "<c2>\u254B\u254B\u254B\u254B</c2>"
    ],
    "-": ["<c2>\u254B\u254B\u254B\u254B</c2>", "<c2>\u254B\u254B\u254B\u254B</c2>", "<c1>\u250F\u2501\u2501\u2513</c1>", "<c1>\u2517\u2501\u2501\u251B</c1>", "<c2>\u254B\u254B\u254B\u254B</c2>", "<c2>\u254B\u254B\u254B\u254B</c2>"],
    _: ["<c2>\u254B\u254B\u254B\u254B</c2>", "<c2>\u254B\u254B\u254B\u254B</c2>", "<c2>\u254B\u254B\u254B\u254B</c2>", "<c2>\u254B\u254B\u254B\u254B</c2>", "<c1>\u250F\u2501\u2501\u2513</c1>", "<c1>\u2517\u2501\u2501\u251B</c1>"],
    "=": ["<c2>\u254B\u254B\u254B\u254B\u254B</c2>", "<c1>\u250F\u2501\u2501\u2501\u2513</c1>", "<c1>\u2517\u2501\u2501\u2501\u251B</c1>", "<c1>\u250F\u2501\u2501\u2501\u2513</c1>", "<c1>\u2517\u2501\u2501\u2501\u251B</c1>", "<c2>\u254B\u254B\u254B\u254B\u254B</c2>"],
    "@": [
      "<c1>\u250F\u2501\u2501\u2501\u2501\u2513</c1><c2>\u254B</c2>",
      "<c1>\u2503\u250F\u2501\u2501\u2513\u2503</c1><c2>\u254B</c2>",
      "<c1>\u2503\u2503\u250F\u2501\u2503\u2503</c1><c2>\u254B</c2>",
      "<c1>\u2503\u2503\u2517\u251B\u2503\u2503</c1><c2>\u254B</c2>",
      "<c1>\u2503\u2517\u2501\u2501\u251B\u2517\u2513</c1>",
      "<c1>\u2517\u2501\u2501\u2501\u2501\u2501\u251B</c1>"
    ],
    "#": [
      "<c2>\u254B</c2><c1>\u250F\u2501\u2501\u2501\u2513</c1><c2>\u254B</c2>",
      "<c1>\u250F\u251B\u250F\u2501\u2513\u2517\u2513</c1>",
      "<c1>\u2517\u2513\u2503\u2503\u2503\u250F\u251B</c1>",
      "<c1>\u250F\u251B\u2503\u2503\u2503\u2517\u2513</c1>",
      "<c1>\u2517\u2513\u2517\u2501\u251B\u250F\u251B</c1>",
      "<c2>\u254B</c2><c1>\u2517\u2501\u2501\u2501\u251B</c1><c2>\u254B</c2>"
    ],
    $: [
      "<c2>\u254B</c2><c1>\u250F\u2513</c1><c2>\u254B</c2>",
      "<c1>\u250F\u251B\u2517\u2513</c1>",
      "<c1>\u2503\u2501\u2501\u252B</c1>",
      "<c1>\u2523\u2501\u2501\u2503</c1>",
      "<c1>\u2517\u2513\u250F\u251B</c1>",
      "<c2>\u254B</c2><c1>\u2517\u251B</c1><c2>\u254B</c2>"
    ],
    "%": [
      "<c1>\u250F\u2513</c1><c2>\u254B\u254B</c2><c1>\u250F\u2501\u2513</c1>",
      "<c1>\u2517\u251B</c1><c2>\u254B</c2><c1>\u250F\u251B\u250F\u251B</c1>",
      "<c2>\u254B\u254B</c2><c1>\u250F\u251B\u250F\u251B</c1><c2>\u254B</c2>",
      "<c2>\u254B</c2><c1>\u250F\u251B\u250F\u251B</c1><c2>\u254B\u254B</c2>",
      "<c1>\u250F\u251B\u250F\u251B</c1><c2>\u254B</c2><c1>\u250F\u2513</c1>",
      "<c1>\u2517\u2501\u251B</c1><c2>\u254B\u254B</c2><c1>\u2517\u251B</c1>"
    ],
    "&": [
      "<c2>\u254B\u254B</c2><c1>\u250F\u2513</c1><c2>\u254B</c2>",
      "<c2>\u254B\u254B</c2><c1>\u2503\u2503</c1><c2>\u254B</c2>",
      "<c1>\u250F\u2501\u251B\u2517\u2513</c1>",
      "<c1>\u2503\u250F\u2513\u250F\u251B</c1>",
      "<c1>\u2503\u2517\u251B\u2503</c1><c2>\u254B</c2>",
      "<c1>\u2517\u2501\u2501\u251B</c1><c2>\u254B</c2>"
    ],
    "(": [
      "<c2>\u254B\u254B</c2><c1>\u250F\u2501\u2513</c1>",
      "<c2>\u254B</c2><c1>\u250F\u251B\u250F\u251B</c1>",
      "<c1>\u250F\u251B\u250F\u251B</c1><c2>\u254B</c2>",
      "<c1>\u2517\u2513\u2517\u2513</c1><c2>\u254B</c2>",
      "<c2>\u254B</c2><c1>\u2517\u2513\u2517\u2513</c1>",
      "<c2>\u254B\u254B</c2><c1>\u2517\u2501\u251B</c1>"
    ],
    ")": [
      "<c1>\u250F\u2501\u2513</c1><c2>\u254B\u254B</c2>",
      "<c1>\u2517\u2513\u2517\u2513</c1><c2>\u254B</c2>",
      "<c2>\u254B</c2><c1>\u2517\u2513\u2517\u2513</c1>",
      "<c2>\u254B</c2><c1>\u250F\u251B\u250F\u251B</c1>",
      "<c1>\u250F\u251B\u250F\u251B</c1><c2>\u254B</c2>",
      "<c1>\u2517\u2501\u251B</c1><c2>\u254B\u254B</c2>"
    ],
    "/": [
      "<c2>\u254B\u254B\u254B\u254B</c2><c1>\u250F\u2501\u2513</c1>",
      "<c2>\u254B\u254B\u254B</c2><c1>\u250F\u251B\u250F\u251B</c1>",
      "<c2>\u254B\u254B</c2><c1>\u250F\u251B\u250F\u251B</c1><c2>\u254B</c2>",
      "<c2>\u254B</c2><c1>\u250F\u251B\u250F\u251B</c1><c2>\u254B\u254B</c2>",
      "<c1>\u250F\u251B\u250F\u251B</c1><c2>\u254B\u254B\u254B</c2>",
      "<c1>\u2517\u2501\u251B</c1><c2>\u254B\u254B\u254B\u254B</c2>"
    ],
    ":": ["<c2>\u254B\u254B</c2>", "<c1>\u250F\u2513</c1>", "<c1>\u2517\u251B</c1>", "<c1>\u250F\u2513</c1>", "<c1>\u2517\u251B</c1>", "<c2>\u254B\u254B</c2>"],
    ";": ["<c2>\u254B\u254B</c2>", "<c1>\u250F\u2513</c1>", "<c1>\u2517\u251B</c1>", "<c2>\u254B\u254B</c2>", "<c1>\u250F\u2513</c1>", "<c1>\u2517\u252B</c1>"],
    ",": ["<c2>\u254B\u254B</c2>", "<c2>\u254B\u254B</c2>", "<c2>\u254B\u254B</c2>", "<c2>\u254B\u254B</c2>", "<c1>\u250F\u2513</c1>", "<c1>\u2517\u252B</c1>"],
    "'": ["<c1>\u250F\u2513</c1>", "<c1>\u2517\u251B</c1>", "<c2>\u254B\u254B</c2>", "<c2>\u254B\u254B</c2>", "<c2>\u254B\u254B</c2>", "<c2>\u254B\u254B</c2>"],
    '"': ["<c1>\u250F\u2513\u250F\u2513</c1>", "<c1>\u2517\u251B\u2517\u251B</c1>", "<c2>\u254B\u254B\u254B\u254B</c2>", "<c2>\u254B\u254B\u254B\u254B</c2>", "<c2>\u254B\u254B\u254B\u254B</c2>", "<c2>\u254B\u254B\u254B\u254B</c2>"],
    " ": ["<c2>\u254B\u254B</c2>", "<c2>\u254B\u254B</c2>", "<c2>\u254B\u254B</c2>", "<c2>\u254B\u254B</c2>", "<c2>\u254B\u254B</c2>", "<c2>\u254B\u254B</c2>"]
  }
};
// src/lib/fonts/pallet.json
var pallet_default = {
  name: "pallet",
  version: "0.1.0",
  homepage: "https://github.com/dominikwilkowski/cfonts",
  colors: 2,
  lines: 6,
  buffer: ["", "", "", "", "", ""],
  letterspace: ["<c2>\u2500</c2>", "<c2>\u2500</c2>", "<c2>\u2500</c2>", "<c2>\u2500</c2>", "<c2>\u2500</c2>", "<c2>\u2500</c2>"],
  letterspace_size: 1,
  chars: {
    A: [
      "<c1>\u2554\u2550\u2550\u2550\u2557</c1>",
      "<c1>\u2551\u2554\u2550\u2557\u2551</c1>",
      "<c1>\u2551\u2551</c1><c2>\u2500</c2><c1>\u2551\u2551</c1>",
      "<c1>\u2551\u255A\u2550\u255D\u2551</c1>",
      "<c1>\u2551\u2554\u2550\u2557\u2551</c1>",
      "<c1>\u255A\u255D</c1><c2>\u2500</c2><c1>\u255A\u255D</c1>"
    ],
    B: [
      "<c1>\u2554\u2550\u2550\u2557</c1><c2>\u2500</c2>",
      "<c1>\u2551\u2554\u2557\u2551</c1><c2>\u2500</c2>",
      "<c1>\u2551\u255A\u255D\u255A\u2557</c1>",
      "<c1>\u2551\u2554\u2550\u2557\u2551</c1>",
      "<c1>\u2551\u255A\u2550\u255D\u2551</c1>",
      "<c1>\u255A\u2550\u2550\u2550\u255D</c1>"
    ],
    C: [
      "<c1>\u2554\u2550\u2550\u2550\u2557</c1>",
      "<c1>\u2551\u2554\u2550\u2557\u2551</c1>",
      "<c1>\u2551\u2551</c1><c2>\u2500</c2><c1>\u255A\u255D</c1>",
      "<c1>\u2551\u2551</c1><c2>\u2500</c2><c1>\u2554\u2557</c1>",
      "<c1>\u2551\u255A\u2550\u255D\u2551</c1>",
      "<c1>\u255A\u2550\u2550\u2550\u255D</c1>"
    ],
    D: [
      "<c1>\u2554\u2550\u2550\u2550\u2557</c1>",
      "<c1>\u255A\u2557\u2554\u2557\u2551</c1>",
      "<c2>\u2500</c2><c1>\u2551\u2551\u2551\u2551</c1>",
      "<c2>\u2500</c2><c1>\u2551\u2551\u2551\u2551</c1>",
      "<c1>\u2554\u255D\u255A\u255D\u2551</c1>",
      "<c1>\u255A\u2550\u2550\u2550\u255D</c1>"
    ],
    E: ["<c1>\u2554\u2550\u2550\u2550\u2557</c1>", "<c1>\u2551\u2554\u2550\u2550\u255D</c1>", "<c1>\u2551\u255A\u2550\u2550\u2557</c1>", "<c1>\u2551\u2554\u2550\u2550\u255D</c1>", "<c1>\u2551\u255A\u2550\u2550\u2557</c1>", "<c1>\u255A\u2550\u2550\u2550\u255D</c1>"],
    F: [
      "<c1>\u2554\u2550\u2550\u2550\u2557</c1>",
      "<c1>\u2551\u2554\u2550\u2550\u255D</c1>",
      "<c1>\u2551\u255A\u2550\u2550\u2557</c1>",
      "<c1>\u2551\u2554\u2550\u2550\u255D</c1>",
      "<c1>\u2551\u2551</c1><c2>\u2500\u2500\u2500</c2>",
      "<c1>\u255A\u255D</c1><c2>\u2500\u2500\u2500</c2>"
    ],
    G: [
      "<c1>\u2554\u2550\u2550\u2550\u2557</c1>",
      "<c1>\u2551\u2554\u2550\u2557\u2551</c1>",
      "<c1>\u2551\u2551</c1><c2>\u2500</c2><c1>\u255A\u255D</c1>",
      "<c1>\u2551\u2551\u2554\u2550\u2557</c1>",
      "<c1>\u2551\u255A\u2569\u2550\u2551</c1>",
      "<c1>\u255A\u2550\u2550\u2550\u255D</c1>"
    ],
    H: [
      "<c1>\u2554\u2557</c1><c2>\u2500</c2><c1>\u2554\u2557</c1>",
      "<c1>\u2551\u2551</c1><c2>\u2500</c2><c1>\u2551\u2551</c1>",
      "<c1>\u2551\u255A\u2550\u255D\u2551</c1>",
      "<c1>\u2551\u2554\u2550\u2557\u2551</c1>",
      "<c1>\u2551\u2551</c1><c2>\u2500</c2><c1>\u2551\u2551</c1>",
      "<c1>\u255A\u255D</c1><c2>\u2500</c2><c1>\u255A\u255D</c1>"
    ],
    I: [
      "<c1>\u2554\u2550\u2550\u2557</c1>",
      "<c1>\u255A\u2563\u2560\u255D</c1>",
      "<c2>\u2500</c2><c1>\u2551\u2551</c1><c2>\u2500</c2>",
      "<c2>\u2500</c2><c1>\u2551\u2551</c1><c2>\u2500</c2>",
      "<c1>\u2554\u2563\u2560\u2557</c1>",
      "<c1>\u255A\u2550\u2550\u255D</c1>"
    ],
    J: [
      "<c2>\u2500\u2500</c2><c1>\u2554\u2557</c1>",
      "<c2>\u2500\u2500</c2><c1>\u2551\u2551</c1>",
      "<c2>\u2500\u2500</c2><c1>\u2551\u2551</c1>",
      "<c1>\u2554\u2557\u2551\u2551</c1>",
      "<c1>\u2551\u255A\u255D\u2551</c1>",
      "<c1>\u255A\u2550\u2550\u255D</c1>"
    ],
    K: [
      "<c1>\u2554\u2557\u2554\u2550\u2557</c1>",
      "<c1>\u2551\u2551\u2551\u2554\u255D</c1>",
      "<c1>\u2551\u255A\u255D\u255D</c1><c2>\u2500</c2>",
      "<c1>\u2551\u2554\u2557\u2551</c1><c2>\u2500</c2>",
      "<c1>\u2551\u2551\u2551\u255A\u2557</c1>",
      "<c1>\u255A\u255D\u255A\u2550\u255D</c1>"
    ],
    L: [
      "<c1>\u2554\u2557</c1><c2>\u2500\u2500\u2500</c2>",
      "<c1>\u2551\u2551</c1><c2>\u2500\u2500\u2500</c2>",
      "<c1>\u2551\u2551</c1><c2>\u2500\u2500\u2500</c2>",
      "<c1>\u2551\u2551</c1><c2>\u2500</c2><c1>\u2554\u2557</c1>",
      "<c1>\u2551\u255A\u2550\u255D\u2551</c1>",
      "<c1>\u255A\u2550\u2550\u2550\u255D</c1>"
    ],
    M: [
      "<c1>\u2554\u2550\u2557\u2554\u2550\u2557</c1>",
      "<c1>\u2551\u2551\u255A\u255D\u2551\u2551</c1>",
      "<c1>\u2551\u2554\u2557\u2554\u2557\u2551</c1>",
      "<c1>\u2551\u2551\u2551\u2551\u2551\u2551</c1>",
      "<c1>\u2551\u2551\u2551\u2551\u2551\u2551</c1>",
      "<c1>\u255A\u255D\u255A\u255D\u255A\u255D</c1>"
    ],
    N: [
      "<c1>\u2554\u2550\u2557</c1><c2>\u2500</c2><c1>\u2554\u2557</c1>",
      "<c1>\u2551\u2551\u255A\u2557\u2551\u2551</c1>",
      "<c1>\u2551\u2554\u2557\u255A\u255D\u2551</c1>",
      "<c1>\u2551\u2551\u255A\u2557\u2551\u2551</c1>",
      "<c1>\u2551\u2551</c1><c2>\u2500</c2><c1>\u2551\u2551\u2551</c1>",
      "<c1>\u255A\u255D</c1><c2>\u2500</c2><c1>\u255A\u2550\u255D</c1>"
    ],
    O: [
      "<c1>\u2554\u2550\u2550\u2550\u2557</c1>",
      "<c1>\u2551\u2554\u2550\u2557\u2551</c1>",
      "<c1>\u2551\u2551</c1><c2>\u2500</c2><c1>\u2551\u2551</c1>",
      "<c1>\u2551\u2551</c1><c2>\u2500</c2><c1>\u2551\u2551</c1>",
      "<c1>\u2551\u255A\u2550\u255D\u2551</c1>",
      "<c1>\u255A\u2550\u2550\u2550\u255D</c1>"
    ],
    P: [
      "<c1>\u2554\u2550\u2550\u2550\u2557</c1>",
      "<c1>\u2551\u2554\u2550\u2557\u2551</c1>",
      "<c1>\u2551\u255A\u2550\u255D\u2551</c1>",
      "<c1>\u2551\u2554\u2550\u2550\u255D</c1>",
      "<c1>\u2551\u2551</c1><c2>\u2500\u2500\u2500</c2>",
      "<c1>\u255A\u255D</c1><c2>\u2500\u2500\u2500</c2>"
    ],
    Q: [
      "<c1>\u2554\u2550\u2550\u2550\u2557</c1><c2>\u2500</c2>",
      "<c1>\u2551\u2554\u2550\u2557\u2551</c1><c2>\u2500</c2>",
      "<c1>\u2551\u2551</c1><c2>\u2500</c2><c1>\u2551\u2551</c1><c2>\u2500</c2>",
      "<c1>\u2551\u2551</c1><c2>\u2500</c2><c1>\u2551\u2551</c1><c2>\u2500</c2>",
      "<c1>\u2551\u255A\u2550\u255D\u2560\u2557</c1>",
      "<c1>\u255A\u2550\u2550\u2550\u2550\u255D</c1>"
    ],
    R: ["<c1>\u2554\u2550\u2550\u2550\u2557</c1>", "<c1>\u2551\u2554\u2550\u2557\u2551</c1>", "<c1>\u2551\u255A\u2550\u255D\u2551</c1>", "<c1>\u2551\u2554\u2557\u2554\u255D</c1>", "<c1>\u2551\u2551\u2551\u255A\u2557</c1>", "<c1>\u255A\u255D\u255A\u2550\u255D</c1>"],
    S: ["<c1>\u2554\u2550\u2550\u2550\u2557</c1>", "<c1>\u2551\u2554\u2550\u2557\u2551</c1>", "<c1>\u2551\u255A\u2550\u2550\u2557</c1>", "<c1>\u255A\u2550\u2550\u2557\u2551</c1>", "<c1>\u2551\u255A\u2550\u255D\u2551</c1>", "<c1>\u255A\u2550\u2550\u2550\u255D</c1>"],
    T: [
      "<c1>\u2554\u2550\u2550\u2550\u2550\u2557</c1>",
      "<c1>\u2551\u2554\u2557\u2554\u2557\u2551</c1>",
      "<c1>\u255A\u255D\u2551\u2551\u255A\u255D</c1>",
      "<c2>\u2500\u2500</c2><c1>\u2551\u2551</c1><c2>\u2500\u2500</c2>",
      "<c2>\u2500\u2500</c2><c1>\u2551\u2551</c1><c2>\u2500\u2500</c2>",
      "<c2>\u2500\u2500</c2><c1>\u255A\u255D</c1><c2>\u2500\u2500</c2>"
    ],
    U: [
      "<c1>\u2554\u2557</c1><c2>\u2500</c2><c1>\u2554\u2557</c1>",
      "<c1>\u2551\u2551</c1><c2>\u2500</c2><c1>\u2551\u2551</c1>",
      "<c1>\u2551\u2551</c1><c2>\u2500</c2><c1>\u2551\u2551</c1>",
      "<c1>\u2551\u2551</c1><c2>\u2500</c2><c1>\u2551\u2551</c1>",
      "<c1>\u2551\u255A\u2550\u255D\u2551</c1>",
      "<c1>\u255A\u2550\u2550\u2550\u255D</c1>"
    ],
    V: [
      "<c1>\u2554\u2557</c1><c2>\u2500\u2500</c2><c1>\u2554\u2557</c1>",
      "<c1>\u2551\u255A\u2557\u2554\u255D\u2551</c1>",
      "<c1>\u255A\u2557\u2551\u2551\u2554\u255D</c1>",
      "<c2>\u2500</c2><c1>\u2551\u255A\u255D\u2551</c1><c2>\u2500</c2>",
      "<c2>\u2500</c2><c1>\u255A\u2557\u2554\u255D</c1><c2>\u2500</c2>",
      "<c2>\u2500\u2500</c2><c1>\u255A\u255D</c1><c2>\u2500\u2500</c2>"
    ],
    W: [
      "<c1>\u2554\u2557\u2554\u2557\u2554\u2557</c1>",
      "<c1>\u2551\u2551\u2551\u2551\u2551\u2551</c1>",
      "<c1>\u2551\u2551\u2551\u2551\u2551\u2551</c1>",
      "<c1>\u2551\u255A\u255D\u255A\u255D\u2551</c1>",
      "<c1>\u255A\u2557\u2554\u2557\u2554\u255D</c1>",
      "<c2>\u2500</c2><c1>\u255A\u255D\u255A\u255D</c1><c2>\u2500</c2>"
    ],
    X: [
      "<c1>\u2554\u2550\u2557\u2554\u2550\u2557</c1>",
      "<c1>\u255A\u2557\u255A\u255D\u2554\u255D</c1>",
      "<c2>\u2500</c2><c1>\u255A\u2557\u2554\u255D</c1><c2>\u2500</c2>",
      "<c2>\u2500</c2><c1>\u2554\u255D\u255A\u2557</c1><c2>\u2500</c2>",
      "<c1>\u2554\u255D\u2554\u2557\u255A\u2557</c1>",
      "<c1>\u255A\u2550\u255D\u255A\u2550\u255D</c1>"
    ],
    Y: [
      "<c1>\u2554\u2557</c1><c2>\u2500\u2500</c2><c1>\u2554\u2557</c1>",
      "<c1>\u2551\u255A\u2557\u2554\u255D\u2551</c1>",
      "<c1>\u255A\u2557\u255A\u255D\u2554\u255D</c1>",
      "<c2>\u2500</c2><c1>\u255A\u2557\u2554\u255D</c1><c2>\u2500</c2>",
      "<c2>\u2500\u2500</c2><c1>\u2551\u2551</c1><c2>\u2500\u2500</c2>",
      "<c2>\u2500\u2500</c2><c1>\u255A\u255D</c1><c2>\u2500\u2500</c2>"
    ],
    Z: [
      "<c1>\u2554\u2550\u2550\u2550\u2550\u2557</c1>",
      "<c1>\u255A\u2550\u2550\u2557\u2550\u2551</c1>",
      "<c2>\u2500\u2500</c2><c1>\u2554\u255D\u2554\u255D</c1>",
      "<c2>\u2500</c2><c1>\u2554\u255D\u2554\u255D</c1><c2>\u2500</c2>",
      "<c1>\u2554\u255D\u2550\u255A\u2550\u2557</c1>",
      "<c1>\u255A\u2550\u2550\u2550\u2550\u255D</c1>"
    ],
    "0": ["<c1>\u2554\u2550\u2550\u2550\u2557</c1>", "<c1>\u2551\u2554\u2550\u2557\u2551</c1>", "<c1>\u2551\u2551\u2551\u2551\u2551</c1>", "<c1>\u2551\u2551\u2551\u2551\u2551</c1>", "<c1>\u2551\u255A\u2550\u255D\u2551</c1>", "<c1>\u255A\u2550\u2550\u2550\u255D</c1>"],
    "1": [
      "<c2>\u2500</c2><c1>\u2554\u2557</c1><c2>\u2500</c2>",
      "<c1>\u2554\u255D\u2551</c1><c2>\u2500</c2>",
      "<c1>\u255A\u2557\u2551</c1><c2>\u2500</c2>",
      "<c2>\u2500</c2><c1>\u2551\u2551</c1><c2>\u2500</c2>",
      "<c1>\u2554\u255D\u255A\u2557</c1>",
      "<c1>\u255A\u2550\u2550\u255D</c1>"
    ],
    "2": ["<c1>\u2554\u2550\u2550\u2550\u2557</c1>", "<c1>\u2551\u2554\u2550\u2557\u2551</c1>", "<c1>\u255A\u255D\u2554\u255D\u2551</c1>", "<c1>\u2554\u2550\u255D\u2554\u255D</c1>", "<c1>\u2551\u2551\u255A\u2550\u2557</c1>", "<c1>\u255A\u2550\u2550\u2550\u255D</c1>"],
    "3": ["<c1>\u2554\u2550\u2550\u2550\u2557</c1>", "<c1>\u2551\u2554\u2550\u2557\u2551</c1>", "<c1>\u255A\u255D\u2554\u255D\u2551</c1>", "<c1>\u2554\u2557\u255A\u2557\u2551</c1>", "<c1>\u2551\u255A\u2550\u255D\u2551</c1>", "<c1>\u255A\u2550\u2550\u2550\u255D</c1>"],
    "4": [
      "<c1>\u2554\u2557</c1><c2>\u2500</c2><c1>\u2554\u2557</c1>",
      "<c1>\u2551\u2551</c1><c2>\u2500</c2><c1>\u2551\u2551</c1>",
      "<c1>\u2551\u255A\u2550\u255D\u2551</c1>",
      "<c1>\u255A\u2550\u2550\u2557\u2551</c1>",
      "<c2>\u2500\u2500\u2500</c2><c1>\u2551\u2551</c1>",
      "<c2>\u2500\u2500\u2500</c2><c1>\u255A\u255D</c1>"
    ],
    "5": ["<c1>\u2554\u2550\u2550\u2550\u2557</c1>", "<c1>\u2551\u2554\u2550\u2550\u255D</c1>", "<c1>\u2551\u255A\u2550\u2550\u2557</c1>", "<c1>\u255A\u2550\u2550\u2557\u2551</c1>", "<c1>\u2554\u2550\u2550\u255D\u2551</c1>", "<c1>\u255A\u2550\u2550\u2550\u255D</c1>"],
    "6": ["<c1>\u2554\u2550\u2550\u2550\u2557</c1>", "<c1>\u2551\u2554\u2550\u2550\u255D</c1>", "<c1>\u2551\u255A\u2550\u2550\u2557</c1>", "<c1>\u2551\u2554\u2550\u2557\u2551</c1>", "<c1>\u2551\u255A\u2550\u255D\u2551</c1>", "<c1>\u255A\u2550\u2550\u2550\u255D</c1>"],
    "7": [
      "<c1>\u2554\u2550\u2550\u2550\u2557</c1>",
      "<c1>\u2551\u2554\u2550\u2557\u2551</c1>",
      "<c1>\u255A\u255D\u2554\u255D\u2551</c1>",
      "<c2>\u2500\u2500</c2><c1>\u2551\u2554\u255D</c1>",
      "<c2>\u2500\u2500</c2><c1>\u2551\u2551</c1><c2>\u2500</c2>",
      "<c2>\u2500\u2500</c2><c1>\u255A\u255D</c1><c2>\u2500</c2>"
    ],
    "8": ["<c1>\u2554\u2550\u2550\u2550\u2557</c1>", "<c1>\u2551\u2554\u2550\u2557\u2551</c1>", "<c1>\u2551\u255A\u2550\u255D\u2551</c1>", "<c1>\u2551\u2554\u2550\u2557\u2551</c1>", "<c1>\u2551\u255A\u2550\u255D\u2551</c1>", "<c1>\u255A\u2550\u2550\u2550\u255D</c1>"],
    "9": ["<c1>\u2554\u2550\u2550\u2550\u2557</c1>", "<c1>\u2551\u2554\u2550\u2557\u2551</c1>", "<c1>\u2551\u255A\u2550\u255D\u2551</c1>", "<c1>\u255A\u2550\u2550\u2557\u2551</c1>", "<c1>\u2554\u2550\u2550\u255D\u2551</c1>", "<c1>\u255A\u2550\u2550\u2550\u255D</c1>"],
    "!": ["<c1>\u2554\u2557</c1>", "<c1>\u2551\u2551</c1>", "<c1>\u2551\u2551</c1>", "<c1>\u255A\u255D</c1>", "<c1>\u2554\u2557</c1>", "<c1>\u255A\u255D</c1>"],
    "?": [
      "<c1>\u2554\u2550\u2550\u2550\u2557</c1>",
      "<c1>\u2551\u2554\u2550\u2557\u2551</c1>",
      "<c1>\u255A\u255D\u2554\u255D\u2551</c1>",
      "<c2>\u2500\u2500</c2><c1>\u2551\u2554\u255D</c1>",
      "<c2>\u2500\u2500</c2><c1>\u2554\u2557</c1><c2>\u2500</c2>",
      "<c2>\u2500\u2500</c2><c1>\u255A\u255D</c1><c2>\u2500</c2>"
    ],
    ".": ["<c2>\u2500\u2500</c2>", "<c2>\u2500\u2500</c2>", "<c2>\u2500\u2500</c2>", "<c2>\u2500\u2500</c2>", "<c1>\u2554\u2557</c1>", "<c1>\u255A\u255D</c1>"],
    "+": [
      "<c2>\u2500\u2500\u2500\u2500</c2>",
      "<c2>\u2500\u2500\u2500\u2500</c2>",
      "<c2>\u2500</c2><c1>\u2554\u2557</c1><c2>\u2500</c2>",
      "<c1>\u2554\u255D\u255A\u2557</c1>",
      "<c1>\u255A\u2557\u2554\u255D</c1>",
      "<c2>\u2500</c2><c1>\u255A\u255D</c1><c2>\u2500</c2>"
    ],
    "-": ["<c2>\u2500\u2500\u2500\u2500</c2>", "<c2>\u2500\u2500\u2500\u2500</c2>", "<c1>\u2554\u2550\u2550\u2557</c1>", "<c1>\u255A\u2550\u2550\u255D</c1>", "<c2>\u2500\u2500\u2500\u2500</c2>", "<c2>\u2500\u2500\u2500\u2500</c2>"],
    _: ["<c2>\u2500\u2500\u2500\u2500</c2>", "<c2>\u2500\u2500\u2500\u2500</c2>", "<c2>\u2500\u2500\u2500\u2500</c2>", "<c2>\u2500\u2500\u2500\u2500</c2>", "<c1>\u2554\u2550\u2550\u2557</c1>", "<c1>\u255A\u2550\u2550\u255D</c1>"],
    "=": ["<c2>\u2500\u2500\u2500\u2500\u2500</c2>", "<c1>\u2554\u2550\u2550\u2550\u2557</c1>", "<c1>\u255A\u2550\u2550\u2550\u255D</c1>", "<c1>\u2554\u2550\u2550\u2550\u2557</c1>", "<c1>\u255A\u2550\u2550\u2550\u255D</c1>", "<c2>\u2500\u2500\u2500\u2500\u2500</c2>"],
    "@": [
      "<c1>\u2554\u2550\u2550\u2550\u2550\u2557</c1><c2>\u2500</c2>",
      "<c1>\u2551\u2554\u2550\u2550\u2557\u2551</c1><c2>\u2500</c2>",
      "<c1>\u2551\u2551\u2554\u2550\u2551\u2551</c1><c2>\u2500</c2>",
      "<c1>\u2551\u2551\u255A\u255D\u2551\u2551</c1><c2>\u2500</c2>",
      "<c1>\u2551\u255A\u2550\u2550\u255D\u2560\u2557</c1>",
      "<c1>\u255A\u2550\u2550\u2550\u2550\u2550\u255D</c1>"
    ],
    "#": [
      "<c2>\u2500</c2><c1>\u2554\u2569\u2569\u2569\u2557</c1><c2>\u2500</c2>",
      "<c1>\u2554\u255D\u2554\u2550\u2557\u255A\u2557</c1>",
      "<c1>\u255A\u2557\u2560\u2550\u2563\u2554\u255D</c1>",
      "<c1>\u2554\u255D\u2560\u2550\u2563\u255A\u2557</c1>",
      "<c1>\u255A\u2557\u255A\u2550\u255D\u2554\u255D</c1>",
      "<c2>\u2500</c2><c1>\u255A\u2566\u2566\u2566\u255D</c1><c2>\u2500</c2>"
    ],
    $: ["<c1>\u2554\u255D\u2569\u255A\u2557</c1>", "<c1>\u2551\u2554\u2550\u2557\u2551</c1>", "<c1>\u2551\u255A\u2550\u2550\u2557</c1>", "<c1>\u255A\u2550\u2550\u2557\u2551</c1>", "<c1>\u2551\u255A\u2550\u255D\u2551</c1>", "<c1>\u255A\u2557\u2566\u2554\u255D</c1>"],
    "%": [
      "<c1>\u2554\u2557</c1><c2>\u2500\u2500</c2><c1>\u2554\u2550\u2557</c1>",
      "<c1>\u255A\u255D</c1><c2>\u2500</c2><c1>\u2554\u255D\u2554\u255D</c1>",
      "<c2>\u2500\u2500</c2><c1>\u2554\u255D\u2554\u255D</c1><c2>\u2500</c2>",
      "<c2>\u2500</c2><c1>\u2554\u255D\u2554\u255D</c1><c2>\u2500\u2500</c2>",
      "<c1>\u2554\u255D\u2554\u255D</c1><c2>\u2500</c2><c1>\u2554\u2557</c1>",
      "<c1>\u255A\u2550\u255D</c1><c2>\u2500\u2500</c2><c1>\u255A\u255D</c1>"
    ],
    "&": [
      "<c2>\u2500\u2500</c2><c1>\u2554\u2557</c1><c2>\u2500</c2>",
      "<c2>\u2500\u2500</c2><c1>\u2551\u2551</c1><c2>\u2500</c2>",
      "<c1>\u2554\u2550\u255D\u255A\u2557</c1>",
      "<c1>\u2551\u2554\u2557\u2554\u255D</c1>",
      "<c1>\u2551\u255A\u255D\u2551</c1><c2>\u2500</c2>",
      "<c1>\u255A\u2550\u2550\u255D</c1><c2>\u2500</c2>"
    ],
    "(": [
      "<c2>\u2500\u2500</c2><c1>\u2554\u2550\u2557</c1>",
      "<c2>\u2500</c2><c1>\u2554\u255D\u2554\u255D</c1>",
      "<c1>\u2554\u255D\u2554\u255D</c1><c2>\u2500</c2>",
      "<c1>\u255A\u2557\u255A\u2557</c1><c2>\u2500</c2>",
      "<c2>\u2500</c2><c1>\u255A\u2557\u255A\u2557</c1>",
      "<c2>\u2500\u2500</c2><c1>\u255A\u2550\u255D</c1>"
    ],
    ")": [
      "<c1>\u2554\u2550\u2557</c1><c2>\u2500\u2500</c2>",
      "<c1>\u255A\u2557\u255A\u2557</c1><c2>\u2500</c2>",
      "<c2>\u2500</c2><c1>\u255A\u2557\u255A\u2557</c1>",
      "<c2>\u2500</c2><c1>\u2554\u255D\u2554\u255D</c1>",
      "<c1>\u2554\u255D\u2554\u255D</c1><c2>\u2500</c2>",
      "<c1>\u255A\u2550\u255D</c1><c2>\u2500\u2500</c2>"
    ],
    "/": [
      "<c2>\u2500\u2500\u2500\u2500</c2><c1>\u2554\u2550\u2557</c1>",
      "<c2>\u2500\u2500\u2500</c2><c1>\u2554\u255D\u2554\u255D</c1>",
      "<c2>\u2500\u2500</c2><c1>\u2554\u255D\u2554\u255D</c1><c2>\u2500</c2>",
      "<c2>\u2500</c2><c1>\u2554\u255D\u2554\u255D</c1><c2>\u2500\u2500</c2>",
      "<c1>\u2554\u255D\u2554\u255D</c1><c2>\u2500\u2500\u2500</c2>",
      "<c1>\u255A\u2550\u255D</c1><c2>\u2500\u2500\u2500\u2500</c2>"
    ],
    ":": ["<c2>\u2500\u2500</c2>", "<c1>\u2554\u2557</c1>", "<c1>\u255A\u255D</c1>", "<c1>\u2554\u2557</c1>", "<c1>\u255A\u255D</c1>", "<c2>\u2500\u2500</c2>"],
    ";": ["<c2>\u2500\u2500</c2>", "<c2>\u2500\u2500</c2>", "<c2>\u2500\u2500</c2>", "<c1>\u2554\u2557</c1>", "<c1>\u255A\u2563</c1>", "<c2>\u2500</c2><c1>\u255D</c1>"],
    ",": ["<c1>\u2554\u2557</c1>", "<c1>\u2551\u2551</c1>", "<c1>\u255A\u255D</c1>", "<c1>\u2554\u2557</c1>", "<c1>\u255A\u2563</c1>", "<c2>\u2500</c2><c1>\u255D</c1>"],
    "'": ["<c1>\u2554\u2557</c1>", "<c1>\u2551\u2551</c1>", "<c1>\u255A\u255D</c1>", "<c2>\u2500\u2500</c2>", "<c2>\u2500\u2500</c2>", "<c2>\u2500\u2500</c2>"],
    '"': ["<c1>\u2554\u2557\u2554\u2557</c1>", "<c1>\u2551\u2551\u2551\u2551</c1>", "<c1>\u255A\u255D\u255A\u255D</c1>", "<c2>\u2500\u2500\u2500\u2500</c2>", "<c2>\u2500\u2500\u2500\u2500</c2>", "<c2>\u2500\u2500\u2500\u2500</c2>"],
    " ": ["<c2>\u2500\u2500\u2500</c2>", "<c2>\u2500\u2500\u2500</c2>", "<c2>\u2500\u2500\u2500</c2>", "<c2>\u2500\u2500\u2500</c2>", "<c2>\u2500\u2500\u2500</c2>", "<c2>\u2500\u2500\u2500</c2>"]
  }
};

// src/lib/ascii.font.ts
var fonts2 = {
  tiny: tiny_default,
  block: block_default,
  shade: shade_default,
  slick: slick_default,
  huge: huge_default,
  grid: grid_default,
  pallet: pallet_default
};
var parsedFonts = {};
function parseColorTags(text) {
  const segments = [];
  let currentIndex = 0;
  const colorTagRegex = /<c(\d+)>(.*?)<\/c\d+>/g;
  let lastIndex = 0;
  let match;
  while ((match = colorTagRegex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      const plainText = text.slice(lastIndex, match.index);
      if (plainText) {
        segments.push({ text: plainText, colorIndex: 0 });
      }
    }
    const colorIndex = parseInt(match[1]) - 1;
    const taggedText = match[2];
    segments.push({ text: taggedText, colorIndex: Math.max(0, colorIndex) });
    lastIndex = match.index + match[0].length;
  }
  if (lastIndex < text.length) {
    const remainingText = text.slice(lastIndex);
    if (remainingText) {
      segments.push({ text: remainingText, colorIndex: 0 });
    }
  }
  return segments;
}
function getParsedFont(fontKey) {
  if (!parsedFonts[fontKey]) {
    const fontDef = fonts2[fontKey];
    const parsedChars = {};
    for (const [char, lines] of Object.entries(fontDef.chars)) {
      parsedChars[char] = lines.map((line) => parseColorTags(line));
    }
    parsedFonts[fontKey] = {
      ...fontDef,
      colors: fontDef.colors || 1,
      chars: parsedChars
    };
  }
  return parsedFonts[fontKey];
}
function measureText2({ text, font = "tiny" }) {
  const fontDef = getParsedFont(font);
  if (!fontDef) {
    console.warn(`Font '${font}' not found`);
    return { width: 0, height: 0 };
  }
  let currentX = 0;
  for (let i = 0;i < text.length; i++) {
    const char = text[i].toUpperCase();
    const charDef = fontDef.chars[char];
    if (!charDef) {
      const spaceChar = fontDef.chars[" "];
      if (spaceChar && spaceChar[0]) {
        let spaceWidth = 0;
        for (const segment of spaceChar[0]) {
          spaceWidth += segment.text.length;
        }
        currentX += spaceWidth;
      } else {
        currentX += 1;
      }
      continue;
    }
    let charWidth = 0;
    if (charDef[0]) {
      for (const segment of charDef[0]) {
        charWidth += segment.text.length;
      }
    }
    currentX += charWidth;
    if (i < text.length - 1) {
      currentX += fontDef.letterspace_size;
    }
  }
  return {
    width: currentX,
    height: fontDef.lines
  };
}
function getCharacterPositions2(text, font = "tiny") {
  const fontDef = getParsedFont(font);
  if (!fontDef) {
    return [0];
  }
  const positions = [0];
  let currentX = 0;
  for (let i = 0;i < text.length; i++) {
    const char = text[i].toUpperCase();
    const charDef = fontDef.chars[char];
    let charWidth = 0;
    if (!charDef) {
      const spaceChar = fontDef.chars[" "];
      if (spaceChar && spaceChar[0]) {
        for (const segment of spaceChar[0]) {
          charWidth += segment.text.length;
        }
      } else {
        charWidth = 1;
      }
    } else if (charDef[0]) {
      for (const segment of charDef[0]) {
        charWidth += segment.text.length;
      }
    }
    currentX += charWidth;
    if (i < text.length - 1) {
      currentX += fontDef.letterspace_size;
    }
    positions.push(currentX);
  }
  return positions;
}
function coordinateToCharacterIndex2(x, text, font = "tiny") {
  const positions = getCharacterPositions2(text, font);
  if (x < 0) {
    return 0;
  }
  for (let i = 0;i < positions.length - 1; i++) {
    const currentPos = positions[i];
    const nextPos = positions[i + 1];
    if (x >= currentPos && x < nextPos) {
      const charMidpoint = currentPos + (nextPos - currentPos) / 2;
      return x < charMidpoint ? i : i + 1;
    }
  }
  if (positions.length > 0 && x >= positions[positions.length - 1]) {
    return text.length;
  }
  return 0;
}
function renderFontToFrameBuffer2(buffer, {
  text,
  x = 0,
  y = 0,
  color = [RGBA2.fromInts(255, 255, 255, 255)],
  backgroundColor = RGBA2.fromInts(0, 0, 0, 255),
  font = "tiny"
}) {
  const width = buffer.width;
  const height = buffer.height;
  const fontDef = getParsedFont(font);
  if (!fontDef) {
    console.warn(`Font '${font}' not found`);
    return { width: 0, height: 0 };
  }
  const colors = Array.isArray(color) ? color : [color];
  if (y < 0 || y + fontDef.lines > height) {
    return { width: 0, height: fontDef.lines };
  }
  let currentX = x;
  const startX = x;
  for (let i = 0;i < text.length; i++) {
    const char = text[i].toUpperCase();
    const charDef = fontDef.chars[char];
    if (!charDef) {
      const spaceChar = fontDef.chars[" "];
      if (spaceChar && spaceChar[0]) {
        let spaceWidth = 0;
        for (const segment of spaceChar[0]) {
          spaceWidth += segment.text.length;
        }
        currentX += spaceWidth;
      } else {
        currentX += 1;
      }
      continue;
    }
    let charWidth = 0;
    if (charDef[0]) {
      for (const segment of charDef[0]) {
        charWidth += segment.text.length;
      }
    }
    if (currentX >= width)
      break;
    if (currentX + charWidth < 0) {
      currentX += charWidth + fontDef.letterspace_size;
      continue;
    }
    for (let lineIdx = 0;lineIdx < fontDef.lines && lineIdx < charDef.length; lineIdx++) {
      const segments = charDef[lineIdx];
      const renderY = y + lineIdx;
      if (renderY >= 0 && renderY < height) {
        let segmentX = currentX;
        for (const segment of segments) {
          const segmentColor = colors[segment.colorIndex] || colors[0];
          for (let charIdx = 0;charIdx < segment.text.length; charIdx++) {
            const renderX = segmentX + charIdx;
            if (renderX >= 0 && renderX < width) {
              const fontChar = segment.text[charIdx];
              if (fontChar !== " ") {
                buffer.setCellWithAlphaBlending(renderX, renderY, fontChar, parseColor2(segmentColor), parseColor2(backgroundColor));
              }
            }
          }
          segmentX += segment.text.length;
        }
      }
    }
    currentX += charWidth;
    if (i < text.length - 1) {
      currentX += fontDef.letterspace_size;
    }
  }
  return {
    width: currentX - startX,
    height: fontDef.lines
  };
}
// src/lib/hast-styled-text.ts
function hastToTextChunks(node, syntaxStyle, parentStyles = []) {
  const chunks = [];
  if (node.type === "text") {
    const stylesToMerge = parentStyles.length > 0 ? parentStyles : ["default"];
    const mergedStyle = syntaxStyle.mergeStyles(...stylesToMerge);
    chunks.push({
      __isChunk: true,
      text: node.value,
      fg: mergedStyle.fg,
      bg: mergedStyle.bg,
      attributes: mergedStyle.attributes
    });
  } else if (node.type === "element") {
    let currentStyles = [...parentStyles];
    if (node.properties?.className) {
      const classes = node.properties.className.split(" ");
      for (const cls of classes) {
        currentStyles.push(cls);
      }
    }
    for (const child of node.children) {
      chunks.push(...hastToTextChunks(child, syntaxStyle, currentStyles));
    }
  }
  return chunks;
}
function hastToStyledText2(hast, syntaxStyle) {
  const chunks = hastToTextChunks(hast, syntaxStyle);
  return new StyledText2(chunks);
}
// src/lib/clock.ts
class SystemClock2 {
  now() {
    if (!globalThis.performance || typeof globalThis.performance.now !== "function") {
      throw new Error("SystemClock requires globalThis.performance.now()");
    }
    return globalThis.performance.now();
  }
  setTimeout(fn, delayMs) {
    return globalThis.setTimeout(fn, delayMs);
  }
  clearTimeout(handle) {
    globalThis.clearTimeout(handle);
  }
  setInterval(fn, delayMs) {
    return globalThis.setInterval(fn, delayMs);
  }
  clearInterval(handle) {
    globalThis.clearInterval(handle);
  }
}
// src/lib/parse.keypress.ts
import { Buffer as Buffer2 } from "buffer";

// src/lib/parse.keypress-kitty.ts
var kittyKeyMap = {
  27: "escape",
  9: "tab",
  13: "return",
  127: "backspace",
  57344: "escape",
  57345: "return",
  57346: "tab",
  57347: "backspace",
  57348: "insert",
  57349: "delete",
  57350: "left",
  57351: "right",
  57352: "up",
  57353: "down",
  57354: "pageup",
  57355: "pagedown",
  57356: "home",
  57357: "end",
  57358: "capslock",
  57359: "scrolllock",
  57360: "numlock",
  57361: "printscreen",
  57362: "pause",
  57363: "menu",
  57364: "f1",
  57365: "f2",
  57366: "f3",
  57367: "f4",
  57368: "f5",
  57369: "f6",
  57370: "f7",
  57371: "f8",
  57372: "f9",
  57373: "f10",
  57374: "f11",
  57375: "f12",
  57376: "f13",
  57377: "f14",
  57378: "f15",
  57379: "f16",
  57380: "f17",
  57381: "f18",
  57382: "f19",
  57383: "f20",
  57384: "f21",
  57385: "f22",
  57386: "f23",
  57387: "f24",
  57388: "f25",
  57389: "f26",
  57390: "f27",
  57391: "f28",
  57392: "f29",
  57393: "f30",
  57394: "f31",
  57395: "f32",
  57396: "f33",
  57397: "f34",
  57398: "f35",
  57399: "kp0",
  57400: "kp1",
  57401: "kp2",
  57402: "kp3",
  57403: "kp4",
  57404: "kp5",
  57405: "kp6",
  57406: "kp7",
  57407: "kp8",
  57408: "kp9",
  57409: "kpdecimal",
  57410: "kpdivide",
  57411: "kpmultiply",
  57412: "kpminus",
  57413: "kpplus",
  57414: "kpenter",
  57415: "kpequal",
  57416: "kpseparator",
  57417: "kpleft",
  57418: "kpright",
  57419: "kpup",
  57420: "kpdown",
  57421: "kppageup",
  57422: "kppagedown",
  57423: "kphome",
  57424: "kpend",
  57425: "kpinsert",
  57426: "kpdelete",
  57427: "clear",
  57428: "mediaplay",
  57429: "mediapause",
  57430: "mediaplaypause",
  57431: "mediareverse",
  57432: "mediastop",
  57433: "mediafastforward",
  57434: "mediarewind",
  57435: "medianext",
  57436: "mediaprev",
  57437: "mediarecord",
  57438: "volumedown",
  57439: "volumeup",
  57440: "mute",
  57441: "leftshift",
  57442: "leftctrl",
  57443: "leftalt",
  57444: "leftsuper",
  57445: "lefthyper",
  57446: "leftmeta",
  57447: "rightshift",
  57448: "rightctrl",
  57449: "rightalt",
  57450: "rightsuper",
  57451: "righthyper",
  57452: "rightmeta",
  57453: "iso_level3_shift",
  57454: "iso_level5_shift"
};
var kittyNamedSingleStrokeKeys = [...new Set(Object.values(kittyKeyMap))];
var printableKeypadText = {
  kp0: "0",
  kp1: "1",
  kp2: "2",
  kp3: "3",
  kp4: "4",
  kp5: "5",
  kp6: "6",
  kp7: "7",
  kp8: "8",
  kp9: "9",
  kpdecimal: ".",
  kpdivide: "/",
  kpmultiply: "*",
  kpminus: "-",
  kpplus: "+",
  kpequal: "=",
  kpseparator: ","
};
function getPrintableKittyKeyText(key) {
  return printableKeypadText[key.name];
}
function fromKittyMods(mod) {
  return {
    shift: !!(mod & 1),
    alt: !!(mod & 2),
    ctrl: !!(mod & 4),
    super: !!(mod & 8),
    hyper: !!(mod & 16),
    meta: !!(mod & 32),
    capsLock: !!(mod & 64),
    numLock: !!(mod & 128)
  };
}
var functionalKeyMap = {
  A: "up",
  B: "down",
  C: "right",
  D: "left",
  H: "home",
  F: "end",
  E: "clear",
  P: "f1",
  Q: "f2",
  S: "f4"
};
var tildeKeyMap = {
  "1": "home",
  "2": "insert",
  "3": "delete",
  "4": "end",
  "5": "pageup",
  "6": "pagedown",
  "7": "home",
  "8": "end",
  "11": "f1",
  "12": "f2",
  "13": "f3",
  "14": "f4",
  "15": "f5",
  "17": "f6",
  "18": "f7",
  "19": "f8",
  "20": "f9",
  "21": "f10",
  "23": "f11",
  "24": "f12",
  "29": "menu",
  "57427": "clear"
};
function parseKittySpecialKey(sequence) {
  const specialKeyRe = /^\x1b\[(\d+);(\d+):(\d+)([A-Z~])$/;
  const match = specialKeyRe.exec(sequence);
  if (!match)
    return null;
  const keyNumOrOne = match[1];
  const modifierStr = match[2];
  const eventTypeStr = match[3];
  const terminator = match[4];
  let keyName;
  if (terminator === "~") {
    keyName = tildeKeyMap[keyNumOrOne];
  } else {
    if (keyNumOrOne !== "1")
      return null;
    keyName = functionalKeyMap[terminator];
  }
  if (!keyName)
    return null;
  const key = {
    name: keyName,
    ctrl: false,
    meta: false,
    shift: false,
    option: false,
    number: false,
    sequence,
    raw: sequence,
    eventType: "press",
    source: "kitty",
    super: false,
    hyper: false,
    capsLock: false,
    numLock: false
  };
  if (modifierStr) {
    const modifierMask = parseInt(modifierStr, 10);
    if (!isNaN(modifierMask) && modifierMask > 1) {
      const mods = fromKittyMods(modifierMask - 1);
      key.shift = mods.shift;
      key.ctrl = mods.ctrl;
      key.meta = mods.alt || mods.meta;
      key.option = mods.alt;
      key.super = mods.super;
      key.hyper = mods.hyper;
      key.capsLock = mods.capsLock;
      key.numLock = mods.numLock;
    }
  }
  if (eventTypeStr === "1" || !eventTypeStr) {
    key.eventType = "press";
  } else if (eventTypeStr === "2") {
    key.eventType = "press";
    key.repeated = true;
  } else if (eventTypeStr === "3") {
    key.eventType = "release";
  }
  return key;
}
function parseKittyKeyboard(sequence) {
  const specialResult = parseKittySpecialKey(sequence);
  if (specialResult)
    return specialResult;
  const kittyRe = /^\x1b\[([^\x1b]+)u$/;
  const match = kittyRe.exec(sequence);
  if (!match)
    return null;
  const params = match[1];
  const fields = params.split(";");
  if (fields.length < 1)
    return null;
  const key = {
    name: "",
    ctrl: false,
    meta: false,
    shift: false,
    option: false,
    number: false,
    sequence,
    raw: sequence,
    eventType: "press",
    source: "kitty",
    super: false,
    hyper: false,
    capsLock: false,
    numLock: false
  };
  let text = "";
  const field1 = fields[0]?.split(":") || [];
  const codepointStr = field1[0];
  if (!codepointStr)
    return null;
  const codepoint = parseInt(codepointStr, 10);
  if (isNaN(codepoint))
    return null;
  let shiftedCodepoint;
  let baseCodepoint;
  if (field1[1]) {
    const shifted = parseInt(field1[1], 10);
    if (!isNaN(shifted) && shifted > 0 && shifted <= 1114111) {
      shiftedCodepoint = shifted;
    }
  }
  if (field1[2]) {
    const base = parseInt(field1[2], 10);
    if (!isNaN(base) && base > 0 && base <= 1114111) {
      baseCodepoint = base;
    }
  }
  const knownKey = kittyKeyMap[codepoint];
  if (knownKey) {
    key.name = knownKey;
    key.code = `[${codepoint}u`;
  } else if (codepoint === 0) {
    key.name = "";
  } else {
    if (codepoint > 0 && codepoint <= 1114111) {
      const char = String.fromCodePoint(codepoint);
      key.name = char === " " ? "space" : char;
      if (baseCodepoint) {
        key.baseCode = baseCodepoint;
      }
    } else {
      return null;
    }
  }
  if (fields[1]) {
    const field2 = fields[1].split(":");
    const modifierStr = field2[0];
    const eventTypeStr = field2[1];
    if (modifierStr) {
      const modifierMask = parseInt(modifierStr, 10);
      if (!isNaN(modifierMask) && modifierMask > 1) {
        const mods = fromKittyMods(modifierMask - 1);
        key.shift = mods.shift;
        key.ctrl = mods.ctrl;
        key.meta = mods.alt || mods.meta;
        key.option = mods.alt;
        key.super = mods.super;
        key.hyper = mods.hyper;
        key.capsLock = mods.capsLock;
        key.numLock = mods.numLock;
      }
    }
    if (eventTypeStr === "1" || !eventTypeStr) {
      key.eventType = "press";
    } else if (eventTypeStr === "2") {
      key.eventType = "press";
      key.repeated = true;
    } else if (eventTypeStr === "3") {
      key.eventType = "release";
    } else {
      key.eventType = "press";
    }
  }
  if (fields[2]) {
    const codepoints = fields[2].split(":");
    for (const cpStr of codepoints) {
      const cp = parseInt(cpStr, 10);
      if (!isNaN(cp) && cp > 0 && cp <= 1114111) {
        text += String.fromCodePoint(cp);
      }
    }
  }
  if (text === "") {
    text = getPrintableKittyKeyText(key) ?? "";
  }
  if (text === "") {
    const isPrintable = key.name.length > 0 && !kittyKeyMap[codepoint];
    if (isPrintable) {
      if (codepoint === 32) {
        text = " ";
      } else if (key.shift && shiftedCodepoint) {
        text = String.fromCodePoint(shiftedCodepoint);
      } else if (key.shift && key.name.length === 1) {
        text = key.name.toLocaleUpperCase();
      } else {
        text = key.name;
      }
    }
  }
  if (text) {
    if (codepoint === 0) {
      key.name = text;
    }
    key.sequence = text;
  }
  if (codepoint === 0 && text === "") {
    return null;
  }
  return key;
}

// src/lib/parse.keypress.ts
var metaKeyCodeRe = /^(?:\x1b)([a-zA-Z0-9])$/;
var fnKeyRe = /^(?:\x1b+)(O|N|\[|\[\[)(?:(\d+)(?:;(\d+))?([~^$])|(?:1;)?(\d+)?([a-zA-Z]))/;
var keyName = {
  OP: "f1",
  OQ: "f2",
  OR: "f3",
  OS: "f4",
  "[11~": "f1",
  "[12~": "f2",
  "[13~": "f3",
  "[14~": "f4",
  "[[A": "f1",
  "[[B": "f2",
  "[[C": "f3",
  "[[D": "f4",
  "[[E": "f5",
  "[15~": "f5",
  "[17~": "f6",
  "[18~": "f7",
  "[19~": "f8",
  "[20~": "f9",
  "[21~": "f10",
  "[23~": "f11",
  "[24~": "f12",
  "[29~": "menu",
  "[57427~": "clear",
  "[A": "up",
  "[B": "down",
  "[C": "right",
  "[D": "left",
  "[E": "clear",
  "[F": "end",
  "[H": "home",
  "[P": "f1",
  "[Q": "f2",
  "[S": "f4",
  OA: "up",
  OB: "down",
  OC: "right",
  OD: "left",
  OE: "clear",
  OF: "end",
  OH: "home",
  OM: "return",
  Oj: "*",
  Ok: "+",
  Ol: ",",
  Om: "-",
  On: ".",
  Oo: "/",
  Op: "0",
  Oq: "1",
  Or: "2",
  Os: "3",
  Ot: "4",
  Ou: "5",
  Ov: "6",
  Ow: "7",
  Ox: "8",
  Oy: "9",
  OX: "=",
  "[1~": "home",
  "[2~": "insert",
  "[3~": "delete",
  "[4~": "end",
  "[5~": "pageup",
  "[6~": "pagedown",
  "[[5~": "pageup",
  "[[6~": "pagedown",
  "[7~": "home",
  "[8~": "end",
  "[a": "up",
  "[b": "down",
  "[c": "right",
  "[d": "left",
  "[e": "clear",
  f: "right",
  b: "left",
  p: "up",
  n: "down",
  "[2$": "insert",
  "[3$": "delete",
  "[5$": "pageup",
  "[6$": "pagedown",
  "[7$": "home",
  "[8$": "end",
  Oa: "up",
  Ob: "down",
  Oc: "right",
  Od: "left",
  Oe: "clear",
  "[2^": "insert",
  "[3^": "delete",
  "[5^": "pageup",
  "[6^": "pagedown",
  "[7^": "home",
  "[8^": "end",
  "[Z": "tab"
};
var nonAlphanumericKeys2 = [...Object.values(keyName), "backspace"];
var terminalNamedSingleStrokeKeys2 = [
  ...new Set(["return", "linefeed", "tab", "escape", "space", ...nonAlphanumericKeys2, ...kittyNamedSingleStrokeKeys])
];
var isShiftKey = (code) => {
  return ["[a", "[b", "[c", "[d", "[e", "[2$", "[3$", "[5$", "[6$", "[7$", "[8$", "[Z"].includes(code);
};
var isCtrlKey = (code) => {
  return ["Oa", "Ob", "Oc", "Od", "Oe", "[2^", "[3^", "[5^", "[6^", "[7^", "[8^"].includes(code);
};
var getCtrlKeyName = (charCode) => {
  if (charCode === 0) {
    return "space";
  }
  if (charCode >= 1 && charCode <= 26) {
    return String.fromCharCode(charCode + 97 - 1);
  }
  if (charCode >= 28 && charCode <= 31) {
    return String.fromCharCode(charCode + 64);
  }
  return;
};
var ss3NumpadPrintable = {
  Op: "0",
  Oq: "1",
  Or: "2",
  Os: "3",
  Ot: "4",
  Ou: "5",
  Ov: "6",
  Ow: "7",
  Ox: "8",
  Oy: "9",
  Oj: "*",
  Ok: "+",
  Ol: ",",
  Om: "-",
  On: ".",
  Oo: "/",
  OX: "="
};
var modifyOtherKeysRe = /^\x1b\[27;(\d+);(\d+)~$/;
var parseKeypress2 = (s = "", options = {}) => {
  let parts;
  if (Buffer2.isBuffer(s)) {
    if (s[0] > 127 && s[1] === undefined) {
      s = "\x1B" + String.fromCharCode(s[0] - 128);
    } else {
      s = String(s);
    }
  } else if (s !== undefined && typeof s !== "string") {
    s = String(s);
  } else if (!s) {
    s = "";
  }
  if (/^\x1b\[<\d+;\d+;\d+[Mm]$/.test(s)) {
    return null;
  }
  if (/^\[<\d+;\d+;\d+[Mm]$/.test(s)) {
    return null;
  }
  if (/^\x1b\[<[\d;]*$/.test(s)) {
    return null;
  }
  if (/^\[<[\d;]*$/.test(s)) {
    return null;
  }
  if (s.startsWith("\x1B[M") && s.length >= 6) {
    return null;
  }
  if (/^\x1b\[\d+;\d+;\d+t$/.test(s)) {
    return null;
  }
  if (/^\x1b\[\d+;\d+R$/.test(s)) {
    return null;
  }
  if (/^\x1b\[\?[\d;]+c$/.test(s)) {
    return null;
  }
  if (/^\x1b\[\?[\d;]+\$y$/.test(s)) {
    return null;
  }
  if (s === "\x1B[I" || s === "\x1B[O") {
    return null;
  }
  if (/^\x1b\][\d;].*(\x1b\\|\x07)$/.test(s)) {
    return null;
  }
  if (s === "\x1B[200~" || s === "\x1B[201~") {
    return null;
  }
  const key = {
    name: "",
    ctrl: false,
    meta: false,
    shift: false,
    option: false,
    number: false,
    sequence: s,
    raw: s,
    eventType: "press",
    source: "raw"
  };
  key.sequence = key.sequence || s || key.name;
  const ctrlKeyName = s.length === 1 ? getCtrlKeyName(s.charCodeAt(0)) : undefined;
  const metaCtrlKeyName = s.length === 2 && s[0] === "\x1B" ? getCtrlKeyName(s.charCodeAt(1)) : undefined;
  if (options.useKittyKeyboard) {
    const kittyResult = parseKittyKeyboard(s);
    if (kittyResult) {
      return kittyResult;
    }
  }
  const modifyOtherKeysMatch = modifyOtherKeysRe.exec(s);
  if (modifyOtherKeysMatch) {
    const modifier = parseInt(modifyOtherKeysMatch[1], 10) - 1;
    const charCode = parseInt(modifyOtherKeysMatch[2], 10);
    key.ctrl = !!(modifier & 4);
    key.meta = !!(modifier & 2);
    key.shift = !!(modifier & 1);
    key.option = !!(modifier & 2);
    key.super = !!(modifier & 8);
    key.hyper = !!(modifier & 16);
    if (charCode === 13) {
      key.name = "return";
    } else if (charCode === 27) {
      key.name = "escape";
    } else if (charCode === 9) {
      key.name = "tab";
    } else if (charCode === 32) {
      key.name = "space";
    } else if (charCode === 127 || charCode === 8) {
      key.name = "backspace";
    } else {
      const char = String.fromCharCode(charCode);
      key.name = char;
      key.sequence = char;
      if (charCode >= 48 && charCode <= 57) {
        key.number = true;
      }
    }
    return key;
  }
  if (s === "\r" || s === "\x1B\r") {
    key.name = "return";
    key.meta = s.length === 2;
  } else if (s === `
` || s === `\x1B
`) {
    key.name = "linefeed";
    key.meta = s.length === 2;
  } else if (s === "\t") {
    key.name = "tab";
  } else if (s === "\b" || s === "\x1B\b" || s === "\x7F" || s === "\x1B\x7F") {
    key.name = "backspace";
    key.meta = s.charAt(0) === "\x1B";
  } else if (s === "\x1B" || s === "\x1B\x1B") {
    key.name = "escape";
    key.meta = s.length === 2;
  } else if (s === " " || s === "\x1B ") {
    key.name = "space";
    key.meta = s.length === 2;
  } else if (ctrlKeyName) {
    key.name = ctrlKeyName;
    key.ctrl = true;
  } else if (s.length === 1 && s >= "0" && s <= "9") {
    key.name = s;
    key.number = true;
  } else if (s.length === 1 && s >= "a" && s <= "z") {
    key.name = s;
  } else if (s.length === 1 && s >= "A" && s <= "Z") {
    key.name = s.toLowerCase();
    key.shift = true;
  } else if (s.length === 1 || s.length === 2 && s.codePointAt(0) > 65535) {
    key.name = s;
  } else if (parts = metaKeyCodeRe.exec(s)) {
    key.meta = true;
    const char = parts[1];
    const isUpperCase = /^[A-Z]$/.test(char);
    if (char === "F") {
      key.name = "right";
    } else if (char === "B") {
      key.name = "left";
    } else if (isUpperCase) {
      key.shift = true;
      key.name = char;
    } else {
      key.name = char;
    }
  } else if (metaCtrlKeyName) {
    key.meta = true;
    key.ctrl = true;
    key.name = metaCtrlKeyName;
  } else if (parts = fnKeyRe.exec(s)) {
    const segs = [...s];
    if (segs[0] === "\x1B" && segs[1] === "\x1B") {
      key.option = true;
      key.meta = true;
    }
    const code = [parts[1], parts[2], parts[4], parts[6]].filter(Boolean).join("");
    const modifier = parseInt(parts[3] || parts[5] || "1", 10) - 1;
    key.ctrl = key.ctrl || !!(modifier & 4);
    key.meta = key.meta || !!(modifier & 2);
    key.shift = key.shift || !!(modifier & 1);
    key.option = key.option || !!(modifier & 2);
    key.super = !!(modifier & 8);
    key.hyper = !!(modifier & 16);
    key.code = code;
    const keyNameResult = keyName[code];
    if (keyNameResult) {
      key.name = keyNameResult;
      key.shift = isShiftKey(code) || key.shift;
      key.ctrl = isCtrlKey(code) || key.ctrl;
      const ss3Char = ss3NumpadPrintable[code];
      if (ss3Char !== undefined) {
        key.sequence = ss3Char;
        if (key.name >= "0" && key.name <= "9") {
          key.number = true;
        }
      }
    } else {
      key.name = "";
      key.code = undefined;
    }
  } else if (s === "\x1B[3~") {
    key.name = "delete";
    key.meta = false;
    key.code = "[3~";
  }
  return key;
};
// src/lib/scroll-acceleration.ts
class LinearScrollAccel2 {
  tick(_now) {
    return 1;
  }
  reset() {}
}

class MacOSScrollAccel2 {
  opts;
  lastTickTime = 0;
  velocityHistory = [];
  historySize = 3;
  streakTimeout = 150;
  minTickInterval = 6;
  constructor(opts = {}) {
    this.opts = opts;
  }
  tick(now = Date.now()) {
    const A = this.opts.A ?? 0.8;
    const tau = this.opts.tau ?? 3;
    const maxMultiplier = this.opts.maxMultiplier ?? 6;
    const dt = this.lastTickTime ? now - this.lastTickTime : Infinity;
    if (dt === Infinity || dt > this.streakTimeout) {
      this.lastTickTime = now;
      this.velocityHistory = [];
      return 1;
    }
    if (dt < this.minTickInterval) {
      return 1;
    }
    this.lastTickTime = now;
    this.velocityHistory.push(dt);
    if (this.velocityHistory.length > this.historySize) {
      this.velocityHistory.shift();
    }
    const avgInterval = this.velocityHistory.reduce((a, b) => a + b, 0) / this.velocityHistory.length;
    const referenceInterval = 100;
    const velocity = referenceInterval / avgInterval;
    const x = velocity / tau;
    const multiplier = 1 + A * (Math.exp(x) - 1);
    return Math.min(multiplier, maxMultiplier);
  }
  reset() {
    this.lastTickTime = 0;
    this.velocityHistory = [];
  }
}
// src/lib/yoga.options.ts
function parseAlign2(value) {
  if (value == null) {
    return Align2.Auto;
  }
  switch (value.toLowerCase()) {
    case "auto":
      return Align2.Auto;
    case "flex-start":
      return Align2.FlexStart;
    case "center":
      return Align2.Center;
    case "flex-end":
      return Align2.FlexEnd;
    case "stretch":
      return Align2.Stretch;
    case "baseline":
      return Align2.Baseline;
    case "space-between":
      return Align2.SpaceBetween;
    case "space-around":
      return Align2.SpaceAround;
    case "space-evenly":
      return Align2.SpaceEvenly;
    default:
      return Align2.Auto;
  }
}
function parseAlignItems2(value) {
  if (value == null) {
    return Align2.Stretch;
  }
  switch (value.toLowerCase()) {
    case "auto":
      return Align2.Auto;
    case "flex-start":
      return Align2.FlexStart;
    case "center":
      return Align2.Center;
    case "flex-end":
      return Align2.FlexEnd;
    case "stretch":
      return Align2.Stretch;
    case "baseline":
      return Align2.Baseline;
    case "space-between":
      return Align2.SpaceBetween;
    case "space-around":
      return Align2.SpaceAround;
    case "space-evenly":
      return Align2.SpaceEvenly;
    default:
      return Align2.Stretch;
  }
}
function parseBoxSizing2(value) {
  if (value == null) {
    return BoxSizing2.BorderBox;
  }
  switch (value.toLowerCase()) {
    case "border-box":
      return BoxSizing2.BorderBox;
    case "content-box":
      return BoxSizing2.ContentBox;
    default:
      return BoxSizing2.BorderBox;
  }
}
function parseDimension2(value) {
  if (value == null) {
    return Dimension2.Width;
  }
  switch (value.toLowerCase()) {
    case "width":
      return Dimension2.Width;
    case "height":
      return Dimension2.Height;
    default:
      return Dimension2.Width;
  }
}
function parseDirection2(value) {
  if (value == null) {
    return Direction2.LTR;
  }
  switch (value.toLowerCase()) {
    case "inherit":
      return Direction2.Inherit;
    case "ltr":
      return Direction2.LTR;
    case "rtl":
      return Direction2.RTL;
    default:
      return Direction2.LTR;
  }
}
function parseDisplay2(value) {
  if (value == null) {
    return 0 /* Flex */;
  }
  switch (value.toLowerCase()) {
    case "flex":
      return 0 /* Flex */;
    case "none":
      return 1 /* None */;
    case "contents":
      return 2 /* Contents */;
    default:
      return 0 /* Flex */;
  }
}
function parseEdge2(value) {
  if (value == null) {
    return Edge2.All;
  }
  switch (value.toLowerCase()) {
    case "left":
      return Edge2.Left;
    case "top":
      return Edge2.Top;
    case "right":
      return Edge2.Right;
    case "bottom":
      return Edge2.Bottom;
    case "start":
      return Edge2.Start;
    case "end":
      return Edge2.End;
    case "horizontal":
      return Edge2.Horizontal;
    case "vertical":
      return Edge2.Vertical;
    case "all":
      return Edge2.All;
    default:
      return Edge2.All;
  }
}
function parseFlexDirection2(value) {
  if (value == null) {
    return FlexDirection2.Column;
  }
  switch (value.toLowerCase()) {
    case "column":
      return FlexDirection2.Column;
    case "column-reverse":
      return FlexDirection2.ColumnReverse;
    case "row":
      return FlexDirection2.Row;
    case "row-reverse":
      return FlexDirection2.RowReverse;
    default:
      return FlexDirection2.Column;
  }
}
function parseGutter2(value) {
  if (value == null) {
    return Gutter2.All;
  }
  switch (value.toLowerCase()) {
    case "column":
      return Gutter2.Column;
    case "row":
      return Gutter2.Row;
    case "all":
      return Gutter2.All;
    default:
      return Gutter2.All;
  }
}
function parseJustify2(value) {
  if (value == null) {
    return Justify2.FlexStart;
  }
  switch (value.toLowerCase()) {
    case "flex-start":
      return Justify2.FlexStart;
    case "center":
      return Justify2.Center;
    case "flex-end":
      return Justify2.FlexEnd;
    case "space-between":
      return Justify2.SpaceBetween;
    case "space-around":
      return Justify2.SpaceAround;
    case "space-evenly":
      return Justify2.SpaceEvenly;
    default:
      return Justify2.FlexStart;
  }
}
function parseLogLevel2(value) {
  if (value == null) {
    return 2 /* Info */;
  }
  switch (value.toLowerCase()) {
    case "error":
      return 0 /* Error */;
    case "warn":
      return 1 /* Warn */;
    case "info":
      return 2 /* Info */;
    case "debug":
      return 3 /* Debug */;
    case "verbose":
      return 4 /* Verbose */;
    case "fatal":
      return 5 /* Fatal */;
    default:
      return 2 /* Info */;
  }
}
function parseMeasureMode2(value) {
  if (value == null) {
    return MeasureMode2.Undefined;
  }
  switch (value.toLowerCase()) {
    case "undefined":
      return MeasureMode2.Undefined;
    case "exactly":
      return MeasureMode2.Exactly;
    case "at-most":
      return MeasureMode2.AtMost;
    default:
      return MeasureMode2.Undefined;
  }
}
function parseOverflow2(value) {
  if (value == null) {
    return Overflow2.Visible;
  }
  switch (value.toLowerCase()) {
    case "visible":
      return Overflow2.Visible;
    case "hidden":
      return Overflow2.Hidden;
    case "scroll":
      return Overflow2.Scroll;
    default:
      return Overflow2.Visible;
  }
}
function parsePositionType2(value) {
  if (value == null) {
    return PositionType2.Relative;
  }
  switch (value.toLowerCase()) {
    case "static":
      return PositionType2.Static;
    case "relative":
      return PositionType2.Relative;
    case "absolute":
      return PositionType2.Absolute;
    default:
      return PositionType2.Static;
  }
}
function parseUnit2(value) {
  if (value == null) {
    return Unit2.Point;
  }
  switch (value.toLowerCase()) {
    case "undefined":
      return Unit2.Undefined;
    case "point":
      return Unit2.Point;
    case "percent":
      return Unit2.Percent;
    case "auto":
      return Unit2.Auto;
    default:
      return Unit2.Point;
  }
}
function parseWrap2(value) {
  if (value == null) {
    return Wrap2.NoWrap;
  }
  switch (value.toLowerCase()) {
    case "no-wrap":
      return Wrap2.NoWrap;
    case "wrap":
      return Wrap2.Wrap;
    case "wrap-reverse":
      return Wrap2.WrapReverse;
    default:
      return Wrap2.NoWrap;
  }
}
// src/lib/parse.mouse.ts
class MouseParser2 {
  mouseButtonsPressed = new Set;
  static SCROLL_DIRECTIONS = {
    0: "up",
    1: "down",
    2: "left",
    3: "right"
  };
  reset() {
    this.mouseButtonsPressed.clear();
  }
  decodeInput(data) {
    const buf = Buffer.isBuffer(data) ? data : Buffer.from(data.buffer, data.byteOffset, data.byteLength);
    return buf.toString("latin1");
  }
  parseMouseEvent(data) {
    const str = this.decodeInput(data);
    const parsed = this.parseMouseSequenceAt(str, 0);
    return parsed?.event ?? null;
  }
  parseAllMouseEvents(data) {
    const str = this.decodeInput(data);
    const events = [];
    let offset = 0;
    while (offset < str.length) {
      const parsed = this.parseMouseSequenceAt(str, offset);
      if (!parsed) {
        break;
      }
      events.push(parsed.event);
      offset += parsed.consumed;
    }
    return events;
  }
  parseMouseSequenceAt(str, offset) {
    if (!str.startsWith("\x1B[", offset))
      return null;
    const introducer = str[offset + 2];
    if (introducer === "<") {
      return this.parseSgrSequence(str, offset);
    }
    if (introducer === "M") {
      return this.parseBasicSequence(str, offset);
    }
    return null;
  }
  parseSgrSequence(str, offset) {
    let index = offset + 3;
    const values = [0, 0, 0];
    let part = 0;
    let hasDigit = false;
    while (index < str.length) {
      const char = str[index];
      const charCode = str.charCodeAt(index);
      if (charCode >= 48 && charCode <= 57) {
        hasDigit = true;
        values[part] = values[part] * 10 + (charCode - 48);
        index++;
        continue;
      }
      switch (char) {
        case ";": {
          if (!hasDigit || part >= 2)
            return null;
          part++;
          hasDigit = false;
          index++;
          break;
        }
        case "M":
        case "m": {
          if (!hasDigit || part !== 2)
            return null;
          return {
            event: this.decodeSgrEvent(values[0], values[1], values[2], char),
            consumed: index - offset + 1
          };
        }
        default:
          return null;
      }
    }
    return null;
  }
  parseBasicSequence(str, offset) {
    if (offset + 6 > str.length)
      return null;
    const buttonByte = str.charCodeAt(offset + 3) - 32;
    const x = str.charCodeAt(offset + 4) - 33;
    const y = str.charCodeAt(offset + 5) - 33;
    return {
      event: this.decodeBasicEvent(buttonByte, x, y),
      consumed: 6
    };
  }
  decodeSgrEvent(rawButtonCode, wireX, wireY, pressRelease) {
    const button = rawButtonCode & 3;
    const isScroll = (rawButtonCode & 64) !== 0;
    const scrollDirection = !isScroll ? undefined : MouseParser2.SCROLL_DIRECTIONS[button];
    const isMotion = (rawButtonCode & 32) !== 0;
    const modifiers = {
      shift: (rawButtonCode & 4) !== 0,
      alt: (rawButtonCode & 8) !== 0,
      ctrl: (rawButtonCode & 16) !== 0
    };
    let type;
    let scrollInfo;
    if (isMotion) {
      const isDragging = this.mouseButtonsPressed.size > 0;
      if (button === 3) {
        type = "move";
      } else if (isDragging) {
        type = "drag";
      } else {
        type = "move";
      }
    } else if (isScroll && pressRelease === "M") {
      type = "scroll";
      scrollInfo = {
        direction: scrollDirection,
        delta: 1
      };
    } else {
      type = pressRelease === "M" ? "down" : "up";
      if (type === "down" && button !== 3) {
        this.mouseButtonsPressed.add(button);
      } else if (type === "up") {
        this.mouseButtonsPressed.delete(button);
      }
    }
    return {
      type,
      button: button === 3 ? 0 : button,
      x: wireX - 1,
      y: wireY - 1,
      modifiers,
      scroll: scrollInfo
    };
  }
  decodeBasicEvent(buttonByte, x, y) {
    const button = buttonByte & 3;
    const isScroll = (buttonByte & 64) !== 0;
    const isMotion = (buttonByte & 32) !== 0;
    const scrollDirection = !isScroll ? undefined : MouseParser2.SCROLL_DIRECTIONS[button];
    const modifiers = {
      shift: (buttonByte & 4) !== 0,
      alt: (buttonByte & 8) !== 0,
      ctrl: (buttonByte & 16) !== 0
    };
    let type;
    let actualButton;
    let scrollInfo;
    if (isMotion) {
      type = "move";
      actualButton = button === 3 ? -1 : button;
    } else if (isScroll) {
      type = "scroll";
      actualButton = 0;
      scrollInfo = {
        direction: scrollDirection,
        delta: 1
      };
    } else {
      type = button === 3 ? "up" : "down";
      actualButton = button === 3 ? 0 : button;
    }
    return {
      type,
      button: actualButton,
      x,
      y,
      modifiers,
      scroll: scrollInfo
    };
  }
}
// src/lib/selection.ts
class SelectionAnchor {
  renderable;
  relativeX;
  relativeY;
  constructor(renderable, absoluteX, absoluteY) {
    this.renderable = renderable;
    this.relativeX = absoluteX - Math.trunc(this.renderable.x);
    this.relativeY = absoluteY - Math.trunc(this.renderable.y);
  }
  get x() {
    return Math.trunc(this.renderable.x) + this.relativeX;
  }
  get y() {
    return Math.trunc(this.renderable.y) + this.relativeY;
  }
}

class Selection2 {
  _anchor;
  _focus;
  _selectedRenderables = [];
  _touchedRenderables = [];
  _isActive = true;
  _isDragging = true;
  _isStart = false;
  behavior;
  constructor(anchorRenderable, anchor, focus, behavior = "cell") {
    this._anchor = new SelectionAnchor(anchorRenderable, anchor.x, anchor.y);
    this._focus = { ...focus };
    this.behavior = behavior;
  }
  get isStart() {
    return this._isStart;
  }
  set isStart(value) {
    this._isStart = value;
  }
  get anchor() {
    return { x: this._anchor.x, y: this._anchor.y };
  }
  get focus() {
    return { ...this._focus };
  }
  set focus(value) {
    this._focus = { ...value };
  }
  get isActive() {
    return this._isActive;
  }
  set isActive(value) {
    this._isActive = value;
  }
  get isDragging() {
    return this._isDragging;
  }
  set isDragging(value) {
    this._isDragging = value;
  }
  get bounds() {
    const minX = Math.min(this._anchor.x, this._focus.x);
    const maxX = Math.max(this._anchor.x, this._focus.x);
    const minY = Math.min(this._anchor.y, this._focus.y);
    const maxY = Math.max(this._anchor.y, this._focus.y);
    const width = maxX - minX + 1;
    const height = maxY - minY + 1;
    return {
      x: minX,
      y: minY,
      width,
      height
    };
  }
  updateSelectedRenderables(selectedRenderables) {
    this._selectedRenderables = selectedRenderables;
  }
  get selectedRenderables() {
    return this._selectedRenderables;
  }
  updateTouchedRenderables(touchedRenderables) {
    this._touchedRenderables = touchedRenderables;
  }
  get touchedRenderables() {
    return this._touchedRenderables;
  }
  getSelectedText() {
    const selectedTextsByLine = new Map;
    const selectedRenderables = this._selectedRenderables.sort((a, b) => {
      const aY = a.y;
      const bY = b.y;
      if (aY !== bY) {
        return aY - bY;
      }
      return a.x - b.x;
    }).filter((renderable) => !renderable.isDestroyed);
    for (const renderable of selectedRenderables) {
      const text = renderable.getSelectedText();
      if (!text)
        continue;
      const lines = text.split(`
`);
      for (let index = 0;index < lines.length; index += 1) {
        const y = renderable.y + index;
        const line = selectedTextsByLine.get(y) ?? [];
        line.push({ x: renderable.x, text: lines[index] });
        selectedTextsByLine.set(y, line);
      }
    }
    return [...selectedTextsByLine.entries()].sort(([leftY], [rightY]) => leftY - rightY).map(([, line]) => line.sort((left, right) => left.x - right.x).map((segment) => segment.text).join("")).join(`
`);
  }
}
function convertGlobalToLocalSelection2(globalSelection, localX, localY) {
  if (!globalSelection?.isActive) {
    return null;
  }
  return {
    anchorX: globalSelection.anchor.x - localX,
    anchorY: globalSelection.anchor.y - localY,
    focusX: globalSelection.focus.x - localX,
    focusY: globalSelection.focus.y - localY,
    isActive: true,
    behavior: globalSelection.behavior
  };
}

class ASCIIFontSelectionHelper2 {
  getText;
  getFont;
  localSelection = null;
  constructor(getText, getFont) {
    this.getText = getText;
    this.getFont = getFont;
  }
  hasSelection() {
    return this.localSelection !== null;
  }
  getSelection() {
    return this.localSelection;
  }
  shouldStartSelection(localX, localY, width, height) {
    if (localX < 0 || localX >= width || localY < 0 || localY >= height) {
      return false;
    }
    const text = this.getText();
    const font = this.getFont();
    const charIndex = coordinateToCharacterIndex2(localX, text, font);
    return charIndex >= 0 && charIndex <= text.length;
  }
  onLocalSelectionChanged(localSelection, width, height) {
    const previousSelection = this.localSelection;
    if (!localSelection?.isActive) {
      this.localSelection = null;
      return previousSelection !== null;
    }
    const text = this.getText();
    const font = this.getFont();
    const positions = getCharacterPositions2(text, font);
    const minY = Math.min(localSelection.anchorY, localSelection.focusY);
    const maxY = Math.max(localSelection.anchorY, localSelection.focusY);
    if (maxY < 0 || minY > height - 1) {
      this.localSelection = null;
      return previousSelection !== null;
    }
    const indexAt = (x, y) => {
      if (y < 0)
        return 0;
      if (y > height - 1)
        return text.length;
      if (x < 0)
        return 0;
      if (x >= width)
        return text.length;
      for (let index = 1;index < positions.length; index += 1) {
        if (x < positions[index])
          return index - 1;
      }
      return text.length;
    };
    const anchorIndex = indexAt(localSelection.anchorX, localSelection.anchorY);
    const focusIndex = indexAt(localSelection.focusX, localSelection.focusY);
    const start = Math.min(anchorIndex, focusIndex);
    const end = Math.min(Math.max(anchorIndex, focusIndex) + 1, text.length);
    const samePoint = localSelection.anchorX === localSelection.focusX && localSelection.anchorY === localSelection.focusY;
    if (samePoint || start >= end) {
      this.localSelection = null;
    } else {
      this.localSelection = { start, end };
    }
    return previousSelection?.start !== this.localSelection?.start || previousSelection?.end !== this.localSelection?.end;
  }
}
// src/lib/stdin-parser.ts
import { Buffer as Buffer3 } from "buffer";
var DEFAULT_TIMEOUT_MS = 20;
var DEFAULT_MAX_PENDING_BYTES = 64 * 1024;
var INITIAL_PENDING_CAPACITY = 256;
var ESC = 27;
var BEL = 7;
var BRACKETED_PASTE_START = Buffer3.from("\x1B[200~");
var BRACKETED_PASTE_END = Buffer3.from("\x1B[201~");
var EMPTY_BYTES = new Uint8Array(0);
var KEY_DECODER = new TextDecoder;
var DEFAULT_PROTOCOL_CONTEXT = {
  kittyKeyboardEnabled: false,
  privateCapabilityRepliesActive: false,
  pixelResolutionQueryActive: false,
  explicitWidthCprActive: false,
  startupCursorCprActive: false
};
var RXVT_DOLLAR_CSI_RE = /^\x1b\[\d+\$$/;
var SYSTEM_CLOCK = new SystemClock2;

class ByteQueue {
  buf;
  start = 0;
  end = 0;
  constructor(capacity = INITIAL_PENDING_CAPACITY) {
    this.buf = new Uint8Array(capacity);
  }
  get length() {
    return this.end - this.start;
  }
  get capacity() {
    return this.buf.length;
  }
  view() {
    return this.buf.subarray(this.start, this.end);
  }
  take() {
    const chunk = this.view();
    this.start = 0;
    this.end = 0;
    return chunk;
  }
  append(chunk) {
    if (chunk.length === 0) {
      return;
    }
    this.ensureCapacity(this.length + chunk.length);
    this.buf.set(chunk, this.end);
    this.end += chunk.length;
  }
  consume(count) {
    if (count <= 0) {
      return;
    }
    if (count >= this.length) {
      this.start = 0;
      this.end = 0;
      return;
    }
    this.start += count;
    if (this.start >= this.buf.length / 2) {
      this.buf.copyWithin(0, this.start, this.end);
      this.end -= this.start;
      this.start = 0;
    }
  }
  clear() {
    this.start = 0;
    this.end = 0;
  }
  reset(capacity = INITIAL_PENDING_CAPACITY) {
    this.buf = new Uint8Array(capacity);
    this.start = 0;
    this.end = 0;
  }
  ensureCapacity(requiredLength) {
    const currentLength = this.length;
    if (requiredLength <= this.buf.length) {
      const availableAtEnd = this.buf.length - this.end;
      if (availableAtEnd >= requiredLength - currentLength) {
        return;
      }
      this.buf.copyWithin(0, this.start, this.end);
      this.end = currentLength;
      this.start = 0;
      if (requiredLength <= this.buf.length) {
        return;
      }
    }
    let nextCapacity = this.buf.length;
    while (nextCapacity < requiredLength) {
      nextCapacity *= 2;
    }
    const next = new Uint8Array(nextCapacity);
    next.set(this.view(), 0);
    this.buf = next;
    this.start = 0;
    this.end = currentLength;
  }
}
function normalizePositiveOption(value, fallback) {
  if (typeof value !== "number" || !Number.isFinite(value) || value <= 0) {
    return fallback;
  }
  return Math.floor(value);
}
function utf8SequenceLength(first) {
  if (first < 128)
    return 1;
  if (first >= 194 && first <= 223)
    return 2;
  if (first >= 224 && first <= 239)
    return 3;
  if (first >= 240 && first <= 244)
    return 4;
  return 0;
}
function bytesEqual(left, right) {
  if (left.length !== right.length) {
    return false;
  }
  for (let index = 0;index < left.length; index += 1) {
    if (left[index] !== right[index]) {
      return false;
    }
  }
  return true;
}
function isMouseSgrSequence(sequence) {
  if (sequence.length < 7) {
    return false;
  }
  if (sequence[0] !== ESC || sequence[1] !== 91 || sequence[2] !== 60) {
    return false;
  }
  const final = sequence[sequence.length - 1];
  if (final !== 77 && final !== 109) {
    return false;
  }
  let part = 0;
  let hasDigit = false;
  for (let index = 3;index < sequence.length - 1; index += 1) {
    const byte = sequence[index];
    if (byte >= 48 && byte <= 57) {
      hasDigit = true;
      continue;
    }
    if (byte === 59 && hasDigit && part < 2) {
      part += 1;
      hasDigit = false;
      continue;
    }
    return false;
  }
  return part === 2 && hasDigit;
}
function isAsciiDigit(byte) {
  return byte >= 48 && byte <= 57;
}
function parsePositiveDecimalPrefix(sequence, start, endExclusive) {
  if (start >= endExclusive)
    return null;
  let value = 0;
  let sawDigit = false;
  for (let index = start;index < endExclusive; index += 1) {
    const byte = sequence[index];
    if (!isAsciiDigit(byte))
      return null;
    sawDigit = true;
    value = value * 10 + (byte - 48);
  }
  return sawDigit ? value : null;
}
function parseKittyFirstFieldCodepoint(sequence, start, endExclusive) {
  if (start >= endExclusive)
    return null;
  let firstColon = -1;
  for (let index = start;index < endExclusive; index += 1) {
    if (sequence[index] === 58) {
      firstColon = index;
      break;
    }
  }
  if (firstColon === -1)
    return null;
  const codepoint = parsePositiveDecimalPrefix(sequence, start, firstColon);
  if (codepoint === null)
    return null;
  for (let index = firstColon + 1;index < endExclusive; index += 1) {
    const byte = sequence[index];
    if (byte !== 58 && !isAsciiDigit(byte))
      return null;
  }
  return codepoint;
}
function canStillBeKittyU(state) {
  return state.semicolons >= 1;
}
function canStillBeKittySpecial(state) {
  return state.semicolons === 1 && state.segments > 1;
}
function canStillBeExplicitWidthCpr(state) {
  return state.firstParamValue === 1 && state.semicolons === 1;
}
function canStillBeStartupCursorCpr(state) {
  return state.semicolons === 1;
}
function canStillBeStartupCursorCprPrefix(state) {
  return state.segments === 1 && state.semicolons <= 1;
}
function canStillBePixelResolution(state) {
  return state.firstParamValue === 4 && state.semicolons === 2;
}
function canStillBePixelResolutionPrefix(bytes) {
  const fixedPrefix = [ESC, 91, 52, 59];
  const fixedLength = Math.min(bytes.length, fixedPrefix.length);
  for (let index = 0;index < fixedLength; index += 1) {
    if (bytes[index] !== fixedPrefix[index])
      return false;
  }
  if (bytes.length <= fixedPrefix.length)
    return bytes.length > 0;
  let index = fixedPrefix.length;
  const heightStart = index;
  while (index < bytes.length && isAsciiDigit(bytes[index]))
    index += 1;
  if (index === bytes.length)
    return index > heightStart;
  if (index === heightStart || bytes[index] !== 59)
    return false;
  index += 1;
  const widthStart = index;
  while (index < bytes.length && isAsciiDigit(bytes[index]))
    index += 1;
  if (index === bytes.length)
    return true;
  return index > widthStart && bytes[index] === 116;
}
function canDeferParametricCsi(state, context) {
  return context.kittyKeyboardEnabled && (canStillBeKittyU(state) || canStillBeKittySpecial(state)) || context.explicitWidthCprActive && canStillBeExplicitWidthCpr(state) || context.startupCursorCprActive && canStillBeStartupCursorCpr(state) || context.pixelResolutionQueryActive && canStillBePixelResolution(state);
}
function canCompleteDeferredParametricCsi(state, byte, context) {
  if (context.kittyKeyboardEnabled) {
    if (state.hasDigit && byte === 117)
      return true;
    if (state.hasDigit && state.semicolons === 1 && state.segments > 1 && (byte === 126 || byte >= 65 && byte <= 90)) {
      return true;
    }
  }
  if (context.explicitWidthCprActive && state.hasDigit && state.firstParamValue === 1 && state.semicolons === 1 && byte === 82) {
    return true;
  }
  if (context.startupCursorCprActive && state.hasDigit && state.semicolons === 1 && byte === 82) {
    return true;
  }
  if (context.pixelResolutionQueryActive && state.hasDigit && state.firstParamValue === 4 && state.semicolons === 2 && byte === 116) {
    return true;
  }
  return false;
}
function classifyParametricCsiProtocol(state, finalByte) {
  if (finalByte === 82 && state.semicolons === 1 && state.segments === 1 && state.hasDigit) {
    return "cpr";
  }
  return "csi";
}
function canDeferPrivateReplyCsi(context) {
  return context.privateCapabilityRepliesActive;
}
function canCompleteDeferredPrivateReplyCsi(state, byte, context) {
  if (!context.privateCapabilityRepliesActive)
    return false;
  if (state.sawDollar)
    return state.hasDigit && byte === 121;
  if (byte === 99)
    return state.hasDigit || state.semicolons > 0;
  if (byte === 110)
    return state.hasDigit;
  return state.hasDigit && byte === 117;
}
function concatBytes(left, right) {
  if (left.length === 0) {
    return right;
  }
  if (right.length === 0) {
    return left;
  }
  const combined = new Uint8Array(left.length + right.length);
  combined.set(left, 0);
  combined.set(right, left.length);
  return combined;
}
function withEscPrefix(bytes) {
  const prefixed = new Uint8Array(bytes.length + 1);
  prefixed[0] = ESC;
  prefixed.set(bytes, 1);
  return prefixed;
}
function indexOfBytes(haystack, needle) {
  if (needle.length === 0) {
    return 0;
  }
  const limit = haystack.length - needle.length;
  for (let offset = 0;offset <= limit; offset += 1) {
    let matched = true;
    for (let index = 0;index < needle.length; index += 1) {
      if (haystack[offset + index] !== needle[index]) {
        matched = false;
        break;
      }
    }
    if (matched) {
      return offset;
    }
  }
  return -1;
}
function decodeLatin1(bytes) {
  return Buffer3.from(bytes.buffer, bytes.byteOffset, bytes.byteLength).toString("latin1");
}
function decodeUtf8(bytes) {
  return KEY_DECODER.decode(bytes);
}
function createPasteCollector() {
  return {
    tail: EMPTY_BYTES,
    parts: [],
    totalLength: 0
  };
}
function joinPasteBytes(parts, totalLength) {
  if (totalLength === 0) {
    return EMPTY_BYTES;
  }
  if (parts.length === 1) {
    return parts[0];
  }
  const bytes = new Uint8Array(totalLength);
  let offset = 0;
  for (const part of parts) {
    bytes.set(part, offset);
    offset += part.length;
  }
  return bytes;
}

class StdinParser2 {
  pending = new ByteQueue(INITIAL_PENDING_CAPACITY);
  events = [];
  timeoutMs;
  maxPendingBytes;
  armTimeouts;
  onTimeoutFlush;
  useKittyKeyboard;
  mouseParser = new MouseParser2;
  clock;
  protocolContext;
  timeoutId = null;
  destroyed = false;
  pendingSinceMs = null;
  pendingTimeoutPaused = false;
  suspendedPixelResolutionPrefixLength = 0;
  forceFlush = false;
  justFlushedEsc = false;
  state = { tag: "ground" };
  cursor = 0;
  unitStart = 0;
  paste = null;
  constructor(options = {}) {
    this.timeoutMs = normalizePositiveOption(options.timeoutMs, DEFAULT_TIMEOUT_MS);
    this.maxPendingBytes = normalizePositiveOption(options.maxPendingBytes, DEFAULT_MAX_PENDING_BYTES);
    this.armTimeouts = options.armTimeouts ?? true;
    this.onTimeoutFlush = options.onTimeoutFlush ?? null;
    this.useKittyKeyboard = options.useKittyKeyboard ?? true;
    this.clock = options.clock ?? SYSTEM_CLOCK;
    this.protocolContext = {
      ...DEFAULT_PROTOCOL_CONTEXT,
      kittyKeyboardEnabled: options.protocolContext?.kittyKeyboardEnabled ?? false,
      privateCapabilityRepliesActive: options.protocolContext?.privateCapabilityRepliesActive ?? false,
      pixelResolutionQueryActive: options.protocolContext?.pixelResolutionQueryActive ?? false,
      explicitWidthCprActive: options.protocolContext?.explicitWidthCprActive ?? false,
      startupCursorCprActive: options.protocolContext?.startupCursorCprActive ?? false
    };
  }
  get bufferCapacity() {
    return this.pending.capacity;
  }
  updateProtocolContext(patch) {
    this.ensureAlive();
    this.protocolContext = { ...this.protocolContext, ...patch };
    if (!this.protocolContext.pixelResolutionQueryActive && this.suspendedPixelResolutionPrefixLength > 0) {
      const prefixLength = this.suspendedPixelResolutionPrefixLength;
      this.state = { tag: "ground" };
      this.consumePrefix(prefixLength);
      this.scanPending();
    }
    this.reconcileDeferredStateWithProtocolContext();
    this.reconcileTimeoutState();
  }
  getAbortableStartupCursorCprState() {
    if (this.pending.length === 0) {
      return null;
    }
    switch (this.state.tag) {
      case "csi": {
        const bytes = this.pending.view();
        const firstParamStart = this.unitStart + 2;
        if (this.cursor < firstParamStart) {
          return null;
        }
        let firstParamValue = null;
        for (let index = firstParamStart;index < this.cursor; index += 1) {
          const byte = bytes[index];
          if (!isAsciiDigit(byte)) {
            return null;
          }
          firstParamValue = (firstParamValue ?? 0) * 10 + (byte - 48);
        }
        return {
          tag: "csi_parametric_ignored",
          semicolons: 0,
          segments: 1,
          hasDigit: this.cursor > firstParamStart,
          firstParamValue
        };
      }
      case "csi_parametric":
      case "csi_parametric_deferred":
        if (!canStillBeStartupCursorCprPrefix(this.state) || this.protocolContext.explicitWidthCprActive && canStillBeExplicitWidthCpr(this.state)) {
          return null;
        }
        return {
          tag: "csi_parametric_ignored",
          semicolons: this.state.semicolons,
          segments: this.state.segments,
          hasDigit: this.state.hasDigit,
          firstParamValue: this.state.firstParamValue
        };
    }
    return null;
  }
  abortPendingStartupCursorCpr() {
    this.ensureAlive();
    const nextState = this.getAbortableStartupCursorCprState();
    if (!nextState) {
      return;
    }
    this.state = nextState;
    if (this.pendingSinceMs === null) {
      this.markPending();
    }
    this.forceFlush = false;
    this.reconcileTimeoutState();
  }
  push(data) {
    this.ensureAlive();
    if (data.length === 0) {
      this.emitKeyOrResponse("unknown", "");
      return;
    }
    let remainder = data;
    while (remainder.length > 0) {
      if (this.paste) {
        remainder = this.consumePasteBytes(remainder);
        continue;
      }
      const immediatePasteStartIndex = this.state.tag === "ground" && this.pending.length === 0 ? indexOfBytes(remainder, BRACKETED_PASTE_START) : -1;
      const appendEnd = immediatePasteStartIndex === -1 ? remainder.length : immediatePasteStartIndex + BRACKETED_PASTE_START.length;
      this.pending.append(remainder.subarray(0, appendEnd));
      remainder = remainder.subarray(appendEnd);
      if (this.suspendedPixelResolutionPrefixLength > 0 && this.protocolContext.pixelResolutionQueryActive && !canStillBePixelResolutionPrefix(this.pending.view())) {
        const prefixLength = this.suspendedPixelResolutionPrefixLength;
        this.state = { tag: "ground" };
        this.consumePrefix(prefixLength);
      }
      this.scanPending();
      if (this.paste && this.pending.length > 0) {
        remainder = this.consumePasteBytes(this.takePendingBytes());
        continue;
      }
      if (!this.paste && this.pending.length > this.maxPendingBytes) {
        this.flushPendingOverflow();
        this.scanPending();
        if (this.paste && this.pending.length > 0) {
          remainder = this.consumePasteBytes(this.takePendingBytes());
        }
      }
    }
    this.reconcileTimeoutState();
  }
  read() {
    this.ensureAlive();
    if (this.events.length === 0 && this.forceFlush) {
      this.scanPending();
      this.reconcileTimeoutState();
    }
    return this.events.shift() ?? null;
  }
  drain(onEvent) {
    this.ensureAlive();
    while (true) {
      if (this.destroyed) {
        return;
      }
      const event = this.read();
      if (!event) {
        return;
      }
      onEvent(event);
    }
  }
  flushTimeout(nowMsValue = this.clock.now()) {
    this.ensureAlive();
    if (this.pendingSinceMs !== null && (nowMsValue < this.pendingSinceMs || nowMsValue - this.pendingSinceMs < this.timeoutMs)) {
      return;
    }
    this.tryForceFlush();
  }
  tryForceFlush() {
    if (this.paste || this.pendingSinceMs === null || this.pending.length === 0) {
      return;
    }
    this.forceFlush = true;
  }
  reset() {
    if (this.destroyed) {
      return;
    }
    this.clearTimeout();
    this.resetState();
  }
  hasPendingPixelResolutionResponse() {
    if (!this.protocolContext.pixelResolutionQueryActive || this.pending.length === 0)
      return false;
    return canStillBePixelResolutionPrefix(this.pending.view());
  }
  pausePendingTimeout() {
    this.ensureAlive();
    this.pendingTimeoutPaused = true;
    this.suspendedPixelResolutionPrefixLength = this.pending.length;
    this.clearTimeout();
  }
  resumePendingTimeout() {
    this.ensureAlive();
    if (this.pending.length === 0)
      this.pendingTimeoutPaused = false;
    this.reconcileTimeoutState();
  }
  resetMouseState() {
    this.ensureAlive();
    this.mouseParser.reset();
  }
  destroy() {
    if (this.destroyed) {
      return;
    }
    this.clearTimeout();
    this.destroyed = true;
    this.resetState();
  }
  ensureAlive() {
    if (this.destroyed) {
      throw new Error("StdinParser has been destroyed");
    }
  }
  scanPending() {
    while (!this.paste) {
      const bytes = this.pending.view();
      if (this.state.tag === "ground" && this.cursor >= bytes.length) {
        this.pending.clear();
        this.cursor = 0;
        this.unitStart = 0;
        this.pendingSinceMs = null;
        this.forceFlush = false;
        return;
      }
      const byte = this.cursor < bytes.length ? bytes[this.cursor] : -1;
      switch (this.state.tag) {
        case "ground": {
          this.unitStart = this.cursor;
          if (this.justFlushedEsc) {
            if (byte === 91) {
              this.justFlushedEsc = false;
              this.cursor += 1;
              this.state = { tag: "esc_recovery" };
              continue;
            }
            this.justFlushedEsc = false;
          }
          if (byte === ESC) {
            this.cursor += 1;
            this.state = { tag: "esc" };
            continue;
          }
          if (byte < 128) {
            this.emitKeyOrResponse("unknown", decodeUtf8(bytes.subarray(this.cursor, this.cursor + 1)));
            this.consumePrefix(this.cursor + 1);
            continue;
          }
          const expected = utf8SequenceLength(byte);
          if (expected === 0) {
            if (!this.forceFlush && this.cursor + 1 === bytes.length) {
              this.markPending();
              return;
            }
            this.emitLegacyHighByte(byte);
            this.consumePrefix(this.cursor + 1);
            continue;
          }
          this.cursor += 1;
          this.state = { tag: "utf8", expected, seen: 1 };
          continue;
        }
        case "utf8": {
          if (this.cursor >= bytes.length) {
            if (!this.forceFlush) {
              this.markPending();
              return;
            }
            this.emitLegacyHighByte(bytes[this.unitStart]);
            this.state = { tag: "ground" };
            this.consumePrefix(this.unitStart + 1);
            continue;
          }
          if ((byte & 192) !== 128) {
            this.emitLegacyHighByte(bytes[this.unitStart]);
            this.state = { tag: "ground" };
            this.consumePrefix(this.unitStart + 1);
            continue;
          }
          const nextSeen = this.state.seen + 1;
          this.cursor += 1;
          if (nextSeen < this.state.expected) {
            this.state = { tag: "utf8", expected: this.state.expected, seen: nextSeen };
            continue;
          }
          this.emitKeyOrResponse("unknown", decodeUtf8(bytes.subarray(this.unitStart, this.cursor)));
          this.state = { tag: "ground" };
          this.consumePrefix(this.cursor);
          continue;
        }
        case "esc": {
          if (this.cursor >= bytes.length) {
            if (!this.forceFlush) {
              this.markPending();
              return;
            }
            const flushedLoneEsc = this.cursor === this.unitStart + 1 && bytes[this.unitStart] === ESC;
            this.emitKeyOrResponse("unknown", decodeUtf8(bytes.subarray(this.unitStart, this.cursor)));
            this.justFlushedEsc = flushedLoneEsc;
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          switch (byte) {
            case 91:
              this.cursor += 1;
              this.state = { tag: "csi" };
              continue;
            case 79:
              this.cursor += 1;
              this.state = { tag: "ss3" };
              continue;
            case 93:
              this.cursor += 1;
              this.state = { tag: "osc", sawEsc: false };
              continue;
            case 80:
              this.cursor += 1;
              this.state = { tag: "dcs", sawEsc: false };
              continue;
            case 95:
              this.cursor += 1;
              this.state = { tag: "apc", sawEsc: false };
              continue;
            case ESC:
              this.cursor += 1;
              continue;
            default:
              this.cursor += 1;
              this.emitKeyOrResponse("unknown", decodeUtf8(bytes.subarray(this.unitStart, this.cursor)));
              this.state = { tag: "ground" };
              this.consumePrefix(this.cursor);
              continue;
          }
        }
        case "ss3": {
          if (this.cursor >= bytes.length) {
            if (!this.forceFlush) {
              this.markPending();
              return;
            }
            this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          if (byte === ESC) {
            this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          this.cursor += 1;
          this.emitKeyOrResponse("unknown", decodeUtf8(bytes.subarray(this.unitStart, this.cursor)));
          this.state = { tag: "ground" };
          this.consumePrefix(this.cursor);
          continue;
        }
        case "esc_recovery": {
          if (this.cursor >= bytes.length) {
            if (!this.forceFlush) {
              this.markPending();
              return;
            }
            this.emitKeyOrResponse("unknown", decodeUtf8(bytes.subarray(this.unitStart, this.cursor)));
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          if (byte === 60) {
            this.cursor += 1;
            this.state = { tag: "esc_less_mouse" };
            continue;
          }
          if (byte === 77) {
            this.cursor += 1;
            this.state = { tag: "esc_less_x10_mouse" };
            continue;
          }
          this.emitKeyOrResponse("unknown", decodeUtf8(bytes.subarray(this.unitStart, this.unitStart + 1)));
          this.state = { tag: "ground" };
          this.consumePrefix(this.unitStart + 1);
          continue;
        }
        case "csi": {
          if (this.cursor >= bytes.length) {
            if (!this.forceFlush) {
              this.markPending();
              return;
            }
            this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          if (byte === ESC) {
            this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          if (byte === 77 && this.cursor === this.unitStart + 2) {
            const end = this.cursor + 4;
            if (bytes.length < end) {
              if (!this.forceFlush) {
                this.markPending();
                return;
              }
              this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, bytes.length));
              this.state = { tag: "ground" };
              this.consumePrefix(bytes.length);
              continue;
            }
            this.emitMouse(bytes.subarray(this.unitStart, end), "x10");
            this.state = { tag: "ground" };
            this.consumePrefix(end);
            continue;
          }
          if (byte === 36) {
            const candidateEnd = this.cursor + 1;
            const candidate = decodeUtf8(bytes.subarray(this.unitStart, candidateEnd));
            if (RXVT_DOLLAR_CSI_RE.test(candidate)) {
              this.emitKeyOrResponse("csi", candidate);
              this.state = { tag: "ground" };
              this.consumePrefix(candidateEnd);
              continue;
            }
            if (!this.forceFlush && candidateEnd >= bytes.length) {
              this.markPending();
              return;
            }
          }
          if (byte === 60 && this.cursor === this.unitStart + 2) {
            this.cursor += 1;
            this.state = { tag: "csi_sgr_mouse", part: 0, hasDigit: false };
            continue;
          }
          if (byte === 91 && this.cursor === this.unitStart + 2) {
            this.cursor += 1;
            continue;
          }
          if (byte === 63 && this.cursor === this.unitStart + 2) {
            this.cursor += 1;
            this.state = { tag: "csi_private_reply", semicolons: 0, hasDigit: false, sawDollar: false };
            continue;
          }
          if (byte === 59) {
            const firstParamStart = this.unitStart + 2;
            const firstParamEnd = this.cursor;
            let firstParamValue = parsePositiveDecimalPrefix(bytes, firstParamStart, firstParamEnd);
            if (firstParamValue === null && this.protocolContext.kittyKeyboardEnabled) {
              firstParamValue = parseKittyFirstFieldCodepoint(bytes, firstParamStart, firstParamEnd);
            }
            if (firstParamValue !== null) {
              this.cursor += 1;
              this.state = {
                tag: "csi_parametric",
                semicolons: 1,
                segments: 1,
                hasDigit: false,
                firstParamValue
              };
              continue;
            }
          }
          if (byte >= 64 && byte <= 126) {
            const end = this.cursor + 1;
            const rawBytes = bytes.subarray(this.unitStart, end);
            if (bytesEqual(rawBytes, BRACKETED_PASTE_START)) {
              this.state = { tag: "ground" };
              this.consumePrefix(end);
              this.paste = createPasteCollector();
              continue;
            }
            if (isMouseSgrSequence(rawBytes)) {
              this.emitMouse(rawBytes, "sgr");
              this.state = { tag: "ground" };
              this.consumePrefix(end);
              continue;
            }
            this.emitKeyOrResponse("csi", decodeUtf8(rawBytes));
            this.state = { tag: "ground" };
            this.consumePrefix(end);
            continue;
          }
          this.cursor += 1;
          continue;
        }
        case "csi_sgr_mouse": {
          if (this.cursor >= bytes.length) {
            if (!this.forceFlush) {
              this.markPending();
              return;
            }
            this.state = { tag: "csi_sgr_mouse_deferred", part: this.state.part, hasDigit: this.state.hasDigit };
            this.pendingSinceMs = null;
            this.forceFlush = false;
            return;
          }
          if (byte === ESC) {
            this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          if (isAsciiDigit(byte)) {
            this.cursor += 1;
            this.state = { tag: "csi_sgr_mouse", part: this.state.part, hasDigit: true };
            continue;
          }
          if (byte === 59 && this.state.hasDigit && this.state.part < 2) {
            this.cursor += 1;
            this.state = { tag: "csi_sgr_mouse", part: this.state.part + 1, hasDigit: false };
            continue;
          }
          if (byte >= 64 && byte <= 126) {
            const end = this.cursor + 1;
            const rawBytes = bytes.subarray(this.unitStart, end);
            if (isMouseSgrSequence(rawBytes)) {
              this.emitMouse(rawBytes, "sgr");
            } else {
              this.emitKeyOrResponse("csi", decodeUtf8(rawBytes));
            }
            this.state = { tag: "ground" };
            this.consumePrefix(end);
            continue;
          }
          this.state = { tag: "csi" };
          continue;
        }
        case "csi_sgr_mouse_deferred": {
          if (this.cursor >= bytes.length) {
            this.pendingSinceMs = null;
            this.forceFlush = false;
            return;
          }
          if (byte === ESC) {
            this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          if (isAsciiDigit(byte) || byte === 59 || byte === 77 || byte === 109) {
            this.state = { tag: "csi_sgr_mouse", part: this.state.part, hasDigit: this.state.hasDigit };
            continue;
          }
          this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
          this.state = { tag: "ground" };
          this.consumePrefix(this.cursor);
          continue;
        }
        case "csi_parametric": {
          if (this.cursor >= bytes.length) {
            if (!this.forceFlush) {
              this.markPending();
              return;
            }
            if (canDeferParametricCsi(this.state, this.protocolContext)) {
              this.state = {
                tag: "csi_parametric_deferred",
                semicolons: this.state.semicolons,
                segments: this.state.segments,
                hasDigit: this.state.hasDigit,
                firstParamValue: this.state.firstParamValue
              };
              this.pendingSinceMs = null;
              this.forceFlush = false;
              return;
            }
            this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          if (byte === ESC) {
            this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          if (isAsciiDigit(byte)) {
            this.cursor += 1;
            this.state = {
              tag: "csi_parametric",
              semicolons: this.state.semicolons,
              segments: this.state.segments,
              hasDigit: true,
              firstParamValue: this.state.firstParamValue
            };
            continue;
          }
          if (byte === 58 && this.state.hasDigit && this.state.segments < 3) {
            this.cursor += 1;
            this.state = {
              tag: "csi_parametric",
              semicolons: this.state.semicolons,
              segments: this.state.segments + 1,
              hasDigit: false,
              firstParamValue: this.state.firstParamValue
            };
            continue;
          }
          if (byte === 59 && this.state.semicolons < 2) {
            this.cursor += 1;
            this.state = {
              tag: "csi_parametric",
              semicolons: this.state.semicolons + 1,
              segments: 1,
              hasDigit: false,
              firstParamValue: this.state.firstParamValue
            };
            continue;
          }
          if (byte >= 64 && byte <= 126) {
            const end = this.cursor + 1;
            const protocol = classifyParametricCsiProtocol(this.state, byte);
            this.emitKeyOrResponse(protocol, decodeUtf8(bytes.subarray(this.unitStart, end)));
            this.state = { tag: "ground" };
            this.consumePrefix(end);
            continue;
          }
          this.state = { tag: "csi" };
          continue;
        }
        case "csi_parametric_deferred": {
          if (this.cursor >= bytes.length) {
            this.pendingSinceMs = null;
            this.forceFlush = false;
            return;
          }
          if (byte === ESC) {
            this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          if (isAsciiDigit(byte) || byte === 58 || byte === 59) {
            this.state = {
              tag: "csi_parametric",
              semicolons: this.state.semicolons,
              segments: this.state.segments,
              hasDigit: this.state.hasDigit,
              firstParamValue: this.state.firstParamValue
            };
            continue;
          }
          if (canCompleteDeferredParametricCsi(this.state, byte, this.protocolContext)) {
            this.state = {
              tag: "csi_parametric",
              semicolons: this.state.semicolons,
              segments: this.state.segments,
              hasDigit: this.state.hasDigit,
              firstParamValue: this.state.firstParamValue
            };
            continue;
          }
          this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
          this.state = { tag: "ground" };
          this.consumePrefix(this.cursor);
          continue;
        }
        case "csi_parametric_ignored": {
          if (this.cursor >= bytes.length) {
            if (!this.forceFlush) {
              this.markPending();
              return;
            }
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          if (byte === ESC) {
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          if (isAsciiDigit(byte)) {
            this.cursor += 1;
            this.state = {
              tag: "csi_parametric_ignored",
              semicolons: this.state.semicolons,
              segments: this.state.segments,
              hasDigit: true,
              firstParamValue: this.state.semicolons === 0 ? (this.state.firstParamValue ?? 0) * 10 + (byte - 48) : this.state.firstParamValue
            };
            continue;
          }
          if (byte === 59 && this.state.semicolons === 0 && this.state.hasDigit) {
            if (this.protocolContext.explicitWidthCprActive && this.state.firstParamValue === 1) {
              this.state = { tag: "csi" };
              continue;
            }
            this.cursor += 1;
            this.state = {
              tag: "csi_parametric_ignored",
              semicolons: 1,
              segments: 1,
              hasDigit: false,
              firstParamValue: this.state.firstParamValue
            };
            continue;
          }
          if (byte === 82 && this.state.semicolons === 1 && this.state.hasDigit) {
            const end = this.cursor + 1;
            this.state = { tag: "ground" };
            this.consumePrefix(end);
            continue;
          }
          if (this.state.semicolons === 0) {
            this.state = { tag: "csi" };
            continue;
          }
          this.state = { tag: "ground" };
          this.consumePrefix(this.cursor);
          continue;
        }
        case "csi_private_reply": {
          if (this.cursor >= bytes.length) {
            if (!this.forceFlush) {
              this.markPending();
              return;
            }
            if (canDeferPrivateReplyCsi(this.protocolContext)) {
              this.state = {
                tag: "csi_private_reply_deferred",
                semicolons: this.state.semicolons,
                hasDigit: this.state.hasDigit,
                sawDollar: this.state.sawDollar
              };
              this.pendingSinceMs = null;
              this.forceFlush = false;
              return;
            }
            this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          if (byte === ESC) {
            this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          if (isAsciiDigit(byte)) {
            this.cursor += 1;
            this.state = {
              tag: "csi_private_reply",
              semicolons: this.state.semicolons,
              hasDigit: true,
              sawDollar: this.state.sawDollar
            };
            continue;
          }
          if (byte === 59) {
            this.cursor += 1;
            this.state = {
              tag: "csi_private_reply",
              semicolons: this.state.semicolons + 1,
              hasDigit: false,
              sawDollar: false
            };
            continue;
          }
          if (byte === 36 && this.state.hasDigit && !this.state.sawDollar) {
            this.cursor += 1;
            this.state = {
              tag: "csi_private_reply",
              semicolons: this.state.semicolons,
              hasDigit: true,
              sawDollar: true
            };
            continue;
          }
          if (byte >= 64 && byte <= 126) {
            const end = this.cursor + 1;
            this.emitOpaqueResponse("csi", bytes.subarray(this.unitStart, end));
            this.state = { tag: "ground" };
            this.consumePrefix(end);
            continue;
          }
          this.state = { tag: "csi" };
          continue;
        }
        case "csi_private_reply_deferred": {
          if (this.cursor >= bytes.length) {
            this.pendingSinceMs = null;
            this.forceFlush = false;
            return;
          }
          if (byte === ESC) {
            this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          if (isAsciiDigit(byte) || byte === 59 || byte === 36) {
            this.state = {
              tag: "csi_private_reply",
              semicolons: this.state.semicolons,
              hasDigit: this.state.hasDigit,
              sawDollar: this.state.sawDollar
            };
            continue;
          }
          if (canCompleteDeferredPrivateReplyCsi(this.state, byte, this.protocolContext)) {
            this.state = {
              tag: "csi_private_reply",
              semicolons: this.state.semicolons,
              hasDigit: this.state.hasDigit,
              sawDollar: this.state.sawDollar
            };
            continue;
          }
          this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
          this.state = { tag: "ground" };
          this.consumePrefix(this.cursor);
          continue;
        }
        case "osc": {
          if (this.cursor >= bytes.length) {
            if (!this.forceFlush) {
              this.markPending();
              return;
            }
            this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          if (this.state.sawEsc) {
            if (byte === 92) {
              const end = this.cursor + 1;
              this.emitOpaqueResponse("osc", bytes.subarray(this.unitStart, end));
              this.state = { tag: "ground" };
              this.consumePrefix(end);
              continue;
            }
            this.state = { tag: "osc", sawEsc: false };
            continue;
          }
          if (byte === BEL) {
            const end = this.cursor + 1;
            this.emitOpaqueResponse("osc", bytes.subarray(this.unitStart, end));
            this.state = { tag: "ground" };
            this.consumePrefix(end);
            continue;
          }
          if (byte === ESC) {
            this.cursor += 1;
            this.state = { tag: "osc", sawEsc: true };
            continue;
          }
          this.cursor += 1;
          continue;
        }
        case "dcs": {
          if (this.cursor >= bytes.length) {
            if (!this.forceFlush) {
              this.markPending();
              return;
            }
            this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          if (this.state.sawEsc) {
            if (byte === 92) {
              const end = this.cursor + 1;
              this.emitOpaqueResponse("dcs", bytes.subarray(this.unitStart, end));
              this.state = { tag: "ground" };
              this.consumePrefix(end);
              continue;
            }
            this.state = { tag: "dcs", sawEsc: false };
            continue;
          }
          if (byte === ESC) {
            this.cursor += 1;
            this.state = { tag: "dcs", sawEsc: true };
            continue;
          }
          this.cursor += 1;
          continue;
        }
        case "apc": {
          if (this.cursor >= bytes.length) {
            if (!this.forceFlush) {
              this.markPending();
              return;
            }
            this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          if (this.state.sawEsc) {
            if (byte === 92) {
              const end = this.cursor + 1;
              this.emitOpaqueResponse("apc", bytes.subarray(this.unitStart, end));
              this.state = { tag: "ground" };
              this.consumePrefix(end);
              continue;
            }
            this.state = { tag: "apc", sawEsc: false };
            continue;
          }
          if (byte === ESC) {
            this.cursor += 1;
            this.state = { tag: "apc", sawEsc: true };
            continue;
          }
          this.cursor += 1;
          continue;
        }
        case "esc_less_mouse": {
          if (this.cursor >= bytes.length) {
            if (!this.forceFlush) {
              this.markPending();
              return;
            }
            this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
            this.state = { tag: "ground" };
            this.consumePrefix(this.cursor);
            continue;
          }
          if (byte >= 48 && byte <= 57 || byte === 59) {
            this.cursor += 1;
            continue;
          }
          if (byte === 77 || byte === 109) {
            const end = this.cursor + 1;
            const rawBytes = bytes.subarray(this.unitStart, end);
            const prefixed = withEscPrefix(rawBytes);
            if (isMouseSgrSequence(prefixed)) {
              this.emitMouse(prefixed, "sgr");
            } else {
              this.emitOpaqueResponse("unknown", rawBytes);
            }
            this.state = { tag: "ground" };
            this.consumePrefix(end);
            continue;
          }
          this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, this.cursor));
          this.state = { tag: "ground" };
          this.consumePrefix(this.cursor);
          continue;
        }
        case "esc_less_x10_mouse": {
          const end = this.unitStart + 5;
          if (bytes.length < end) {
            if (!this.forceFlush) {
              this.markPending();
              return;
            }
            this.emitOpaqueResponse("unknown", bytes.subarray(this.unitStart, bytes.length));
            this.state = { tag: "ground" };
            this.consumePrefix(bytes.length);
            continue;
          }
          const rawBytes = bytes.subarray(this.unitStart, end);
          this.emitMouse(withEscPrefix(rawBytes), "x10");
          this.state = { tag: "ground" };
          this.consumePrefix(end);
          continue;
        }
      }
    }
  }
  emitKeyOrResponse(protocol, raw) {
    const parsed = parseKeypress2(raw, { useKittyKeyboard: this.useKittyKeyboard });
    if (parsed) {
      this.events.push({
        type: "key",
        raw: parsed.raw,
        key: parsed
      });
      return;
    }
    this.events.push({
      type: "response",
      protocol,
      sequence: raw
    });
  }
  emitMouse(rawBytes, encoding) {
    const event = this.mouseParser.parseMouseEvent(rawBytes);
    if (!event) {
      this.emitOpaqueResponse("unknown", rawBytes);
      return;
    }
    this.events.push({
      type: "mouse",
      raw: decodeLatin1(rawBytes),
      encoding,
      event
    });
  }
  emitLegacyHighByte(byte) {
    const parsed = parseKeypress2(Buffer3.from([byte]), { useKittyKeyboard: this.useKittyKeyboard });
    if (parsed) {
      this.events.push({
        type: "key",
        raw: parsed.raw,
        key: parsed
      });
      return;
    }
    this.events.push({
      type: "response",
      protocol: "unknown",
      sequence: String.fromCharCode(byte)
    });
  }
  emitOpaqueResponse(protocol, rawBytes) {
    this.events.push({
      type: "response",
      protocol,
      sequence: decodeLatin1(rawBytes)
    });
  }
  consumePrefix(endExclusive) {
    this.pending.consume(endExclusive);
    this.pendingTimeoutPaused = false;
    this.suspendedPixelResolutionPrefixLength = 0;
    this.cursor = 0;
    this.unitStart = 0;
    this.pendingSinceMs = null;
    this.forceFlush = false;
  }
  takePendingBytes() {
    const buffered = this.pending.take();
    this.cursor = 0;
    this.unitStart = 0;
    this.pendingSinceMs = null;
    this.forceFlush = false;
    return buffered;
  }
  flushPendingOverflow() {
    if (this.pending.length === 0) {
      return;
    }
    this.emitOpaqueResponse("unknown", this.pending.view());
    this.pending.clear();
    this.cursor = 0;
    this.unitStart = 0;
    this.pendingSinceMs = null;
    this.pendingTimeoutPaused = false;
    this.suspendedPixelResolutionPrefixLength = 0;
    this.forceFlush = false;
    this.state = { tag: "ground" };
  }
  markPending() {
    this.pendingSinceMs = this.clock.now();
  }
  consumePasteBytes(chunk) {
    const paste = this.paste;
    const combined = concatBytes(paste.tail, chunk);
    const endIndex = indexOfBytes(combined, BRACKETED_PASTE_END);
    if (endIndex !== -1) {
      this.pushPasteBytes(combined.subarray(0, endIndex));
      this.events.push({
        type: "paste",
        bytes: joinPasteBytes(paste.parts, paste.totalLength)
      });
      this.paste = null;
      return combined.subarray(endIndex + BRACKETED_PASTE_END.length);
    }
    const keep = Math.min(BRACKETED_PASTE_END.length - 1, combined.length);
    const stableLength = combined.length - keep;
    if (stableLength > 0) {
      this.pushPasteBytes(combined.subarray(0, stableLength));
    }
    paste.tail = Uint8Array.from(combined.subarray(stableLength));
    return EMPTY_BYTES;
  }
  pushPasteBytes(bytes) {
    if (bytes.length === 0) {
      return;
    }
    this.paste.parts.push(Uint8Array.from(bytes));
    this.paste.totalLength += bytes.length;
  }
  reconcileDeferredStateWithProtocolContext() {
    switch (this.state.tag) {
      case "csi_parametric_deferred":
        if (!canDeferParametricCsi(this.state, this.protocolContext)) {
          this.emitOpaqueResponse("unknown", this.pending.view().subarray(this.unitStart, this.cursor));
          this.state = { tag: "ground" };
          this.consumePrefix(this.cursor);
        }
        return;
      case "csi_private_reply_deferred":
        if (!canDeferPrivateReplyCsi(this.protocolContext)) {
          this.emitOpaqueResponse("unknown", this.pending.view().subarray(this.unitStart, this.cursor));
          this.state = { tag: "ground" };
          this.consumePrefix(this.cursor);
        }
        return;
    }
  }
  reconcileTimeoutState() {
    if (!this.armTimeouts) {
      return;
    }
    if (this.pendingTimeoutPaused) {
      this.clearTimeout();
      return;
    }
    if (this.paste || this.pendingSinceMs === null || this.pending.length === 0) {
      this.clearTimeout();
      return;
    }
    this.clearTimeout();
    this.timeoutId = this.clock.setTimeout(() => {
      this.timeoutId = null;
      if (this.destroyed) {
        return;
      }
      try {
        this.tryForceFlush();
        this.onTimeoutFlush?.();
      } catch (error) {
        console.error("stdin parser timeout flush failed", error);
      }
    }, this.timeoutMs);
  }
  clearTimeout() {
    if (!this.timeoutId) {
      return;
    }
    this.clock.clearTimeout(this.timeoutId);
    this.timeoutId = null;
  }
  resetState() {
    this.pending.reset(INITIAL_PENDING_CAPACITY);
    this.events.length = 0;
    this.pendingSinceMs = null;
    this.pendingTimeoutPaused = false;
    this.suspendedPixelResolutionPrefixLength = 0;
    this.forceFlush = false;
    this.justFlushedEsc = false;
    this.state = { tag: "ground" };
    this.cursor = 0;
    this.unitStart = 0;
    this.paste = null;
    this.mouseParser.reset();
  }
}
// src/lib/tree-sitter-styled-text.ts
registerEnvVar2({ name: "OTUI_TS_STYLE_WARN", default: false, description: "Enable warnings for missing syntax styles" });
function getSpecificity(group) {
  return group.split(".").length;
}
function shouldSuppressInInjection(group, meta) {
  if (meta?.isInjection) {
    return false;
  }
  return group === "markup.raw.block";
}
function treeSitterToTextChunks2(content, highlights, syntaxStyle, options) {
  const chunks = [];
  const ranges = options?.ranges;
  const defaultStyle = syntaxStyle.getStyle("default");
  const concealEnabled = options?.enabled ?? true;
  const baseStyle = options?.baseHighlight ? syntaxStyle.getStyle(options.baseHighlight) : undefined;
  const injectionContainerRanges = [];
  const boundaries = [];
  for (let i = 0;i < highlights.length; i++) {
    const [start, end, , meta] = highlights[i];
    if (start === end)
      continue;
    if (meta?.containsInjection) {
      injectionContainerRanges.push({ start, end });
    }
    boundaries.push({ offset: start, type: "start", highlightIndex: i });
    boundaries.push({ offset: end, type: "end", highlightIndex: i });
  }
  boundaries.sort((a, b) => {
    if (a.offset !== b.offset)
      return a.offset - b.offset;
    if (a.type === "end" && b.type === "start")
      return -1;
    if (a.type === "start" && b.type === "end")
      return 1;
    return 0;
  });
  const activeHighlights = new Set;
  let currentOffset = 0;
  for (let i = 0;i < boundaries.length; i++) {
    const boundary = boundaries[i];
    if (currentOffset < boundary.offset && activeHighlights.size > 0) {
      const segmentText = content.slice(currentOffset, boundary.offset);
      const activeGroups = [];
      for (const idx of activeHighlights) {
        const [, , group, meta] = highlights[idx];
        activeGroups.push({ group, meta, index: idx });
      }
      const concealHighlight = concealEnabled ? activeGroups.find((h) => h.meta?.conceal !== undefined || h.group === "conceal" || h.group.startsWith("conceal.")) : undefined;
      if (concealHighlight) {
        let replacementText = "";
        if (concealHighlight.meta?.conceal !== undefined) {
          replacementText = concealHighlight.meta.conceal;
        } else if (concealHighlight.group === "conceal.with.space") {
          replacementText = " ";
        }
        if (replacementText) {
          chunks.push({
            __isChunk: true,
            text: replacementText,
            fg: defaultStyle?.fg,
            bg: defaultStyle?.bg,
            attributes: defaultStyle ? createTextAttributes2({
              bold: defaultStyle.bold,
              italic: defaultStyle.italic,
              underline: defaultStyle.underline,
              dim: defaultStyle.dim
            }) : 0
          });
          ranges?.push({ start: currentOffset, end: boundary.offset });
        }
      } else {
        const insideInjectionContainer = injectionContainerRanges.some((range) => currentOffset >= range.start && currentOffset < range.end);
        const validGroups = activeGroups.filter((h) => {
          if (insideInjectionContainer && shouldSuppressInInjection(h.group, h.meta)) {
            return false;
          }
          return true;
        });
        const sortedGroups = validGroups.sort((a, b) => {
          const aSpec = getSpecificity(a.group);
          const bSpec = getSpecificity(b.group);
          if (aSpec !== bSpec)
            return aSpec - bSpec;
          return a.index - b.index;
        });
        const mergedStyle = baseStyle ? { ...baseStyle } : {};
        for (const { group } of sortedGroups) {
          let styleForGroup = syntaxStyle.getStyle(group);
          if (!styleForGroup && group.includes(".")) {
            const baseName = group.split(".")[0];
            styleForGroup = syntaxStyle.getStyle(baseName);
          }
          if (styleForGroup) {
            if (styleForGroup.fg !== undefined)
              mergedStyle.fg = styleForGroup.fg;
            if (styleForGroup.bg !== undefined)
              mergedStyle.bg = styleForGroup.bg;
            if (styleForGroup.bold !== undefined)
              mergedStyle.bold = styleForGroup.bold;
            if (styleForGroup.italic !== undefined)
              mergedStyle.italic = styleForGroup.italic;
            if (styleForGroup.underline !== undefined)
              mergedStyle.underline = styleForGroup.underline;
            if (styleForGroup.dim !== undefined)
              mergedStyle.dim = styleForGroup.dim;
          } else {
            if (group.includes(".")) {
              const baseName = group.split(".")[0];
              if (env2.OTUI_TS_STYLE_WARN) {
                console.warn(`Syntax style not found for group "${group}" or base scope "${baseName}", using default style`);
              }
            } else {
              if (env2.OTUI_TS_STYLE_WARN) {
                console.warn(`Syntax style not found for group "${group}", using default style`);
              }
            }
          }
        }
        const finalStyle = Object.keys(mergedStyle).length > 0 ? mergedStyle : defaultStyle;
        chunks.push({
          __isChunk: true,
          text: segmentText,
          fg: finalStyle?.fg,
          bg: finalStyle?.bg,
          attributes: finalStyle ? createTextAttributes2({
            bold: finalStyle.bold,
            italic: finalStyle.italic,
            underline: finalStyle.underline,
            dim: finalStyle.dim
          }) : 0
        });
        ranges?.push({ start: currentOffset, end: boundary.offset });
      }
    } else if (currentOffset < boundary.offset) {
      const text = content.slice(currentOffset, boundary.offset);
      const style = baseStyle ?? defaultStyle;
      chunks.push({
        __isChunk: true,
        text,
        fg: style?.fg,
        bg: style?.bg,
        attributes: style ? createTextAttributes2({
          bold: style.bold,
          italic: style.italic,
          underline: style.underline,
          dim: style.dim
        }) : 0
      });
      ranges?.push({ start: currentOffset, end: boundary.offset });
    }
    if (boundary.type === "start") {
      activeHighlights.add(boundary.highlightIndex);
    } else {
      activeHighlights.delete(boundary.highlightIndex);
      if (concealEnabled) {
        const [, , group, meta] = highlights[boundary.highlightIndex];
        if (meta?.concealLines !== undefined) {
          if (boundary.offset < content.length && content[boundary.offset] === `
`) {
            currentOffset = boundary.offset + 1;
            continue;
          }
        }
        if (meta?.conceal !== undefined) {
          if (meta.conceal === " ") {
            if (boundary.offset < content.length && content[boundary.offset] === " ") {
              currentOffset = boundary.offset + 1;
              continue;
            }
          } else if (meta.conceal === "" && group === "conceal" && !meta.isInjection) {
            if (boundary.offset < content.length && content[boundary.offset] === " ") {
              currentOffset = boundary.offset + 1;
              continue;
            }
          }
        }
      }
    }
    currentOffset = boundary.offset;
  }
  if (currentOffset < content.length) {
    const text = content.slice(currentOffset);
    const style = baseStyle ?? defaultStyle;
    chunks.push({
      __isChunk: true,
      text,
      fg: style?.fg,
      bg: style?.bg,
      attributes: style ? createTextAttributes2({
        bold: style.bold,
        italic: style.italic,
        underline: style.underline,
        dim: style.dim
      }) : 0
    });
    ranges?.push({ start: currentOffset, end: content.length });
  }
  return chunks;
}
async function treeSitterToStyledText2(content, filetype, syntaxStyle, client, options) {
  const result = await client.highlightOnce(content, filetype);
  if (result.highlights && result.highlights.length > 0 || options?.baseHighlight) {
    const chunks = treeSitterToTextChunks2(content, result.highlights ?? [], syntaxStyle, {
      enabled: options?.conceal?.enabled ?? true,
      baseHighlight: options?.baseHighlight
    });
    return new StyledText2(chunks);
  } else {
    const defaultStyle = syntaxStyle.mergeStyles("default");
    const chunks = [
      {
        __isChunk: true,
        text: content,
        fg: defaultStyle.fg,
        bg: defaultStyle.bg,
        attributes: defaultStyle.attributes
      }
    ];
    return new StyledText2(chunks);
  }
}
// src/lib/tree-sitter/client.ts
import { EventEmitter as EventEmitter2 } from "events";

// src/lib/debounce.ts
var TIMERS_MAP = new Map;

class DebounceController {
  scopeId;
  constructor(scopeId) {
    this.scopeId = scopeId;
    if (!TIMERS_MAP.has(this.scopeId)) {
      TIMERS_MAP.set(this.scopeId, new Map);
    }
  }
  debounce(id, ms, fn) {
    const scopeMap = TIMERS_MAP.get(this.scopeId);
    return new Promise((resolve, reject) => {
      if (scopeMap.has(id)) {
        clearTimeout(scopeMap.get(id));
      }
      const timerId = setTimeout(() => {
        try {
          resolve(fn());
        } catch (error) {
          reject(error);
        }
        scopeMap.delete(id);
      }, ms);
      scopeMap.set(id, timerId);
    });
  }
  clearDebounce(id) {
    const scopeMap = TIMERS_MAP.get(this.scopeId);
    if (scopeMap && scopeMap.has(id)) {
      clearTimeout(scopeMap.get(id));
      scopeMap.delete(id);
    }
  }
  clear() {
    const scopeMap = TIMERS_MAP.get(this.scopeId);
    if (scopeMap) {
      scopeMap.forEach((timerId) => clearTimeout(timerId));
      scopeMap.clear();
    }
  }
}
function createDebounce(scopeId) {
  return new DebounceController(scopeId);
}
function clearDebounceScope(scopeId) {
  const scopeMap = TIMERS_MAP.get(scopeId);
  if (scopeMap) {
    scopeMap.forEach((timerId) => clearTimeout(timerId));
    scopeMap.clear();
  }
}

// src/lib/queue.ts
class ProcessQueue {
  processor;
  queue = [];
  processing = false;
  autoProcess = true;
  constructor(processor, autoProcess = true) {
    this.processor = processor;
    this.autoProcess = autoProcess;
  }
  enqueue(item) {
    this.queue.push(item);
    if (!this.processing && this.autoProcess) {
      this.processQueue();
    }
  }
  processQueue() {
    if (this.queue.length === 0) {
      return;
    }
    this.processing = true;
    queueMicrotask(async () => {
      if (this.queue.length === 0) {
        this.processing = false;
        return;
      }
      const item = this.queue.shift();
      try {
        await this.processor(item);
      } catch (error) {
        console.error("Error processing queue item:", error);
      }
      if (this.queue.length > 0) {
        this.processQueue();
      } else {
        this.processing = false;
      }
    });
  }
  clear() {
    this.queue = [];
  }
  isProcessing() {
    return this.processing;
  }
  size() {
    return this.queue.length;
  }
}

// src/lib/tree-sitter/default-parsers.ts
var defaultParserDescriptors = [
  {
    filetype: "javascript",
    aliases: ["javascriptreact"],
    queries: { highlights: ["assets/javascript/highlights.scm"] },
    wasm: "assets/javascript/tree-sitter-javascript.wasm"
  },
  {
    filetype: "typescript",
    queries: { highlights: ["assets/typescript/highlights.scm"] },
    wasm: "assets/typescript/tree-sitter-typescript.wasm"
  },
  {
    filetype: "typescriptreact",
    queries: { highlights: ["assets/typescriptreact/highlights.scm"] },
    wasm: "assets/typescriptreact/tree-sitter-tsx.wasm"
  },
  {
    filetype: "markdown",
    queries: {
      highlights: ["assets/markdown/highlights.scm"],
      injections: ["assets/markdown/injections.scm"]
    },
    wasm: "assets/markdown/tree-sitter-markdown.wasm",
    injectionMapping: {
      nodeTypes: { inline: "markdown_inline", pipe_table_cell: "markdown_inline" },
      infoStringMap: {
        javascript: "javascript",
        js: "javascript",
        jsx: "javascriptreact",
        javascriptreact: "javascriptreact",
        typescript: "typescript",
        ts: "typescript",
        tsx: "typescriptreact",
        typescriptreact: "typescriptreact",
        markdown: "markdown",
        md: "markdown"
      }
    }
  },
  {
    filetype: "markdown_inline",
    queries: { highlights: ["assets/markdown_inline/highlights.scm"] },
    wasm: "assets/markdown_inline/tree-sitter-markdown_inline.wasm"
  },
  {
    filetype: "zig",
    queries: { highlights: ["assets/zig/highlights.scm"] },
    wasm: "assets/zig/tree-sitter-zig.wasm"
  }
];
var defaultParserAssetPaths = [
  ...new Set(defaultParserDescriptors.flatMap((parser) => [
    ...parser.queries.highlights,
    parser.wasm,
    ...parser.queries.injections ?? []
  ]))
];
var cachedParsers;
function getParsers() {
  cachedParsers ??= Promise.all(defaultParserDescriptors.map(resolveDefaultParser));
  return cachedParsers;
}
async function resolveDefaultParser(parser) {
  const queries = {
    highlights: await Promise.all(parser.queries.highlights.map(resolveParserAsset))
  };
  if (parser.queries.injections) {
    queries.injections = await Promise.all(parser.queries.injections.map(resolveParserAsset));
  }
  return {
    filetype: parser.filetype,
    ...parser.aliases ? { aliases: [...parser.aliases] } : {},
    queries,
    wasm: await resolveParserAsset(parser.wasm),
    ...parser.injectionMapping ? { injectionMapping: parser.injectionMapping } : {}
  };
}
function resolveParserAsset(relativePath) {
  return resolveDefaultParserAsset(relativePath, new URL(`./${relativePath}`, import.meta.url));
}

// src/lib/tree-sitter/client.ts
import { resolve, isAbsolute, parse } from "path";
import { existsSync } from "fs";
registerEnvVar2({
  name: "OTUI_TREE_SITTER_WORKER_PATH",
  description: "Path to the TreeSitter worker entry script",
  type: "string",
  default: ""
});
var DEFAULT_PARSER_OVERRIDES = [];
function addDefaultParsers2(parsers) {
  for (const parser of parsers) {
    DEFAULT_PARSER_OVERRIDES = [
      ...DEFAULT_PARSER_OVERRIDES.filter((existingParser) => existingParser.filetype !== parser.filetype),
      parser
    ];
  }
}
var isUrl = (path) => path.startsWith("http://") || path.startsWith("https://");

class TreeSitterClient2 extends EventEmitter2 {
  initialized = false;
  worker;
  buffers = new Map;
  initializePromise;
  initializeResolvers;
  messageCallbacks = new Map;
  messageIdCounter = 0;
  editQueues = new Map;
  debouncer;
  options;
  destroyCallbacks = new Set;
  lifecycleGeneration = 0;
  rejectInitialization;
  destroyPromise;
  workerTerminationFailed = false;
  constructor(options, internalOptions = {}) {
    super();
    this.options = options;
    this.debouncer = createDebounce("tree-sitter-client");
    if (internalOptions.autoStartWorker ?? true) {
      this.startWorker();
    }
  }
  onDestroy(callback) {
    this.destroyCallbacks.add(callback);
    return () => {
      this.destroyCallbacks.delete(callback);
    };
  }
  emitError(error, bufferId) {
    if (this.listenerCount("error") > 0) {
      this.emit("error", error, bufferId);
    }
  }
  emitWarning(warning, bufferId) {
    if (this.listenerCount("warning") > 0) {
      this.emit("warning", warning, bufferId);
    }
  }
  startWorker() {
    if (this.worker) {
      return;
    }
    const workerPath = this.resolveWorkerPath();
    const worker = new Worker(workerPath);
    this.worker = worker;
    worker.onmessage = (event) => {
      if (this.worker !== worker) {
        return;
      }
      this.handleWorkerMessage(event);
    };
    worker.onerror = (error) => {
      if (this.worker !== worker) {
        return;
      }
      console.error("TreeSitter worker error:", error.message);
      const workerError = new Error(`Worker error: ${error.message}`, { cause: error.error });
      this.handleWorkerFailure(worker, workerError);
      this.emitError(`Worker error: ${error.message}`);
    };
  }
  sendWorkerMessage(message) {
    if (!this.worker) {
      throw new Error("TreeSitter worker is not available");
    }
    this.worker.postMessage(message);
  }
  rejectPendingRequests(error) {
    const requests = Array.from(this.messageCallbacks.values());
    this.messageCallbacks.clear();
    for (const request of requests) {
      request.reject(error);
    }
  }
  rejectActiveInitialization(error) {
    if (this.initializeResolvers) {
      clearTimeout(this.initializeResolvers.timeoutId);
      this.initializeResolvers.reject(error);
      this.initializeResolvers = undefined;
    }
    this.rejectInitialization?.(error);
    this.rejectInitialization = undefined;
  }
  handleWorkerFailure(worker, error) {
    if (this.worker !== worker) {
      return;
    }
    worker.onmessage = null;
    worker.onerror = null;
    this.worker = undefined;
    this.lifecycleGeneration++;
    this.initialized = false;
    this.initializePromise = undefined;
    this.rejectActiveInitialization(error);
    this.rejectPendingRequests(error);
    this.editQueues.clear();
    this.buffers.clear();
    this.debouncer.clear();
    try {
      Promise.resolve(worker.terminate()).catch(() => {});
    } catch {}
  }
  resolveWorkerPath() {
    if (this.options.workerPath) {
      return this.options.workerPath;
    }
    if (env2.OTUI_TREE_SITTER_WORKER_PATH) {
      return env2.OTUI_TREE_SITTER_WORKER_PATH;
    }
    if (typeof OTUI_TREE_SITTER_WORKER_PATH !== "undefined") {
      return OTUI_TREE_SITTER_WORKER_PATH;
    }
    let workerPath = resolveDefaultTreeSitterWorkerPath(new URL("./parser.worker.js", import.meta.url));
    if (!process.env.OTUI_ASSET_ROOT && !existsSync(workerPath)) {
      workerPath = new URL("./parser.worker.ts", import.meta.url).href;
    }
    return workerPath;
  }
  async stopWorker() {
    const worker = this.worker;
    if (!worker) {
      return;
    }
    const onmessage = worker.onmessage;
    const onerror = worker.onerror;
    worker.onmessage = null;
    worker.onerror = null;
    this.worker = undefined;
    try {
      const termination = worker.terminate();
      if (termination && typeof termination.then === "function") {
        await termination;
      }
    } catch (error) {
      if (!this.worker) {
        worker.onmessage = onmessage;
        worker.onerror = onerror;
        this.worker = worker;
      }
      throw error;
    }
  }
  async handleReset() {
    this.buffers.clear();
    await this.stopWorker();
    this.startWorker();
    this.initialized = false;
    this.initializePromise = undefined;
    this.initializeResolvers = undefined;
    return this.initialize();
  }
  async initialize() {
    if (this.destroyPromise) {
      throw new Error("Cannot initialize while client is being destroyed");
    }
    if (this.workerTerminationFailed) {
      throw new Error("Cannot initialize after worker termination failed; retry destroy()");
    }
    if (this.initializePromise) {
      return this.initializePromise;
    }
    if (!this.worker) {
      this.startWorker();
    }
    const worker = this.worker;
    const generation = this.lifecycleGeneration;
    let rejectCancellation;
    const cancellation = new Promise((_, reject) => {
      rejectCancellation = reject;
    });
    const initialization = Promise.race([this.initializeClient(generation, worker), cancellation]);
    this.rejectInitialization = rejectCancellation;
    this.initializePromise = initialization;
    initialization.then(() => {
      if (this.initializePromise === initialization) {
        this.rejectInitialization = undefined;
      }
    }, () => {
      if (this.initializePromise === initialization) {
        this.rejectInitialization = undefined;
      }
    });
    return this.initializePromise;
  }
  assertCurrentInitialization(generation, worker) {
    if (this.lifecycleGeneration !== generation || this.worker !== worker || this.destroyPromise) {
      throw new Error("TreeSitter initialization was invalidated");
    }
  }
  async initializeClient(generation, worker) {
    const treeSitterWasmPath = await resolveTreeSitterWasm();
    this.assertCurrentInitialization(generation, worker);
    await new Promise((resolve, reject) => {
      const timeoutMs = this.options.initTimeout ?? 1e4;
      const timeoutId = setTimeout(() => {
        const error = new Error("Worker initialization timed out");
        console.error("TreeSitter client:", error.message);
        this.initializeResolvers = undefined;
        reject(error);
      }, timeoutMs);
      this.initializeResolvers = { resolve, reject, timeoutId };
      this.sendWorkerMessage({
        type: "INIT",
        dataPath: this.options.dataPath,
        treeSitterWasmPath
      });
    });
    this.assertCurrentInitialization(generation, worker);
    await this.registerDefaultParsers(generation, worker);
    this.assertCurrentInitialization(generation, worker);
    this.initialized = true;
  }
  async registerDefaultParsers(generation = this.lifecycleGeneration, worker = this.worker) {
    const defaultParsers = await getParsers();
    this.assertCurrentInitialization(generation, worker);
    const overriddenFiletypes = new Set(DEFAULT_PARSER_OVERRIDES.map((parser) => parser.filetype));
    for (const parser of [
      ...defaultParsers.filter((parser) => !overriddenFiletypes.has(parser.filetype)),
      ...DEFAULT_PARSER_OVERRIDES
    ]) {
      worker.postMessage({ type: "ADD_FILETYPE_PARSER", filetypeParser: this.resolveFiletypeParser(parser) });
    }
  }
  resolvePath(path) {
    if (isUrl(path)) {
      return path;
    }
    if (isBunfsPath(path)) {
      return normalizeBunfsPath(parse(path).base);
    }
    if (!isAbsolute(path)) {
      return resolve(path);
    }
    return path;
  }
  addFiletypeParser(filetypeParser) {
    this.sendWorkerMessage({ type: "ADD_FILETYPE_PARSER", filetypeParser: this.resolveFiletypeParser(filetypeParser) });
  }
  resolveFiletypeParser(filetypeParser) {
    return {
      ...filetypeParser,
      aliases: filetypeParser.aliases ? [...new Set(filetypeParser.aliases.filter((alias) => alias !== filetypeParser.filetype))] : undefined,
      wasm: this.resolvePath(filetypeParser.wasm),
      queries: {
        highlights: filetypeParser.queries.highlights.map((path) => this.resolvePath(path)),
        injections: filetypeParser.queries.injections?.map((path) => this.resolvePath(path))
      }
    };
  }
  async getPerformance() {
    const messageId = `performance_${this.messageIdCounter++}`;
    return new Promise((resolve, reject) => {
      this.messageCallbacks.set(messageId, { resolve, reject });
      try {
        this.sendWorkerMessage({ type: "GET_PERFORMANCE", messageId });
      } catch (error) {
        this.messageCallbacks.delete(messageId);
        reject(error instanceof Error ? error : new Error(String(error)));
      }
    });
  }
  async highlightOnce(content, filetype) {
    if (!this.initialized) {
      try {
        await this.initialize();
      } catch (error) {
        return { error: "Could not highlight because of initialization error" };
      }
    }
    const messageId = `oneshot_${this.messageIdCounter++}`;
    return new Promise((resolve, reject) => {
      this.messageCallbacks.set(messageId, { resolve, reject });
      try {
        this.sendWorkerMessage({
          type: "ONESHOT_HIGHLIGHT",
          content,
          filetype,
          messageId
        });
      } catch (error) {
        this.messageCallbacks.delete(messageId);
        reject(error instanceof Error ? error : new Error(String(error)));
      }
    });
  }
  handleWorkerMessage(event) {
    const message = event.data;
    switch (message.type) {
      case "HIGHLIGHT_RESPONSE": {
        const buffer = this.buffers.get(message.bufferId);
        if (!buffer || !buffer.hasParser) {
          return;
        }
        if (buffer.version !== message.version) {
          this.resetBuffer(message.bufferId, buffer.version, buffer.content);
          return;
        }
        this.emit("highlights:response", message.bufferId, message.version, message.highlights);
        return;
      }
      case "INIT_RESPONSE": {
        if (!this.initializeResolvers) {
          return;
        }
        clearTimeout(this.initializeResolvers.timeoutId);
        if (message.error) {
          console.error("TreeSitter client initialization failed:", message.error);
          this.initializeResolvers.reject(new Error(message.error));
        } else {
          this.initializeResolvers.resolve();
        }
        this.initializeResolvers = undefined;
        return;
      }
      case "PARSER_INIT_RESPONSE": {
        const callback = this.messageCallbacks.get(message.messageId);
        if (callback) {
          this.messageCallbacks.delete(message.messageId);
          callback.resolve({ hasParser: message.hasParser, warning: message.warning, error: message.error });
        }
        return;
      }
      case "PRELOAD_PARSER_RESPONSE": {
        const callback = this.messageCallbacks.get(message.messageId);
        if (callback) {
          this.messageCallbacks.delete(message.messageId);
          callback.resolve({ hasParser: message.hasParser });
        }
        return;
      }
      case "BUFFER_DISPOSED": {
        const callback = this.messageCallbacks.get(`dispose_${message.bufferId}`);
        if (callback) {
          this.messageCallbacks.delete(`dispose_${message.bufferId}`);
          callback.resolve(true);
        }
        this.emit("buffer:disposed", message.bufferId);
        return;
      }
      case "PERFORMANCE_RESPONSE": {
        const callback = this.messageCallbacks.get(message.messageId);
        if (callback) {
          this.messageCallbacks.delete(message.messageId);
          callback.resolve(message.performance);
        }
        return;
      }
      case "ONESHOT_HIGHLIGHT_RESPONSE": {
        const callback = this.messageCallbacks.get(message.messageId);
        if (callback) {
          this.messageCallbacks.delete(message.messageId);
          callback.resolve({ highlights: message.highlights, warning: message.warning, error: message.error });
        }
        return;
      }
      case "UPDATE_DATA_PATH_RESPONSE": {
        const callback = this.messageCallbacks.get(message.messageId);
        if (callback) {
          this.messageCallbacks.delete(message.messageId);
          callback.resolve({ error: message.error });
        }
        return;
      }
      case "CLEAR_CACHE_RESPONSE": {
        const callback = this.messageCallbacks.get(message.messageId);
        if (callback) {
          this.messageCallbacks.delete(message.messageId);
          callback.resolve({ error: message.error });
        }
        return;
      }
      case "WARNING": {
        this.emitWarning(message.warning, message.bufferId);
        return;
      }
      case "ERROR": {
        if (message.messageId) {
          const callback = this.messageCallbacks.get(message.messageId);
          if (callback) {
            this.messageCallbacks.delete(message.messageId);
            callback.reject(new Error(message.error));
          }
        }
        this.emitError(message.error, message.bufferId);
        return;
      }
      case "WORKER_LOG": {
        this.emit("worker:log", message.logType, message.data.join(" "));
        return;
      }
    }
  }
  async preloadParser(filetype) {
    const messageId = `has_parser_${this.messageIdCounter++}`;
    const response = await new Promise((resolve, reject) => {
      this.messageCallbacks.set(messageId, { resolve, reject });
      try {
        this.sendWorkerMessage({
          type: "PRELOAD_PARSER",
          filetype,
          messageId
        });
      } catch (error) {
        this.messageCallbacks.delete(messageId);
        reject(error instanceof Error ? error : new Error(String(error)));
      }
    });
    return response.hasParser;
  }
  async createBuffer(id, content, filetype, version = 1, autoInitialize = true) {
    if (!this.initialized) {
      if (!autoInitialize) {
        this.emitError("Could not create buffer because client is not initialized");
        return false;
      }
      try {
        await this.initialize();
      } catch (error) {
        this.emitError("Could not create buffer because of initialization error");
        return false;
      }
    }
    if (this.buffers.has(id)) {
      throw new Error(`Buffer with id ${id} already exists`);
    }
    this.buffers.set(id, { id, content, filetype, version, hasParser: false });
    const messageId = `init_${this.messageIdCounter++}`;
    const response = await new Promise((resolve, reject) => {
      this.messageCallbacks.set(messageId, { resolve, reject });
      try {
        this.sendWorkerMessage({
          type: "INITIALIZE_PARSER",
          bufferId: id,
          version,
          content,
          filetype,
          messageId
        });
      } catch (error) {
        this.messageCallbacks.delete(messageId);
        reject(error instanceof Error ? error : new Error(String(error)));
      }
    });
    if (!response.hasParser) {
      this.emit("buffer:initialized", id, false);
      if (filetype !== "plaintext") {
        this.emitWarning(response.warning || response.error || "Buffer has no parser", id);
      }
      return false;
    }
    const bufferState = { id, content, filetype, version, hasParser: true };
    this.buffers.set(id, bufferState);
    this.emit("buffer:initialized", id, true);
    return true;
  }
  async updateBuffer(id, edits, newContent, version) {
    if (!this.initialized) {
      return;
    }
    const buffer = this.buffers.get(id);
    if (!buffer || !buffer.hasParser) {
      return;
    }
    this.buffers.set(id, { ...buffer, content: newContent, version });
    if (!this.editQueues.has(id)) {
      this.editQueues.set(id, new ProcessQueue((item) => this.processEdit(id, item.edits, item.newContent, item.version, item.isReset)));
    }
    const bufferQueue = this.editQueues.get(id);
    bufferQueue.enqueue({ edits, newContent, version });
  }
  async processEdit(bufferId, edits, newContent, version, isReset = false) {
    this.sendWorkerMessage({
      type: isReset ? "RESET_BUFFER" : "HANDLE_EDITS",
      bufferId,
      version,
      content: newContent,
      edits
    });
  }
  async removeBuffer(bufferId) {
    if (!this.initialized) {
      return;
    }
    this.buffers.delete(bufferId);
    if (this.editQueues.has(bufferId)) {
      this.editQueues.get(bufferId)?.clear();
      this.editQueues.delete(bufferId);
    }
    if (this.worker) {
      await new Promise((resolve, reject) => {
        const messageId = `dispose_${bufferId}`;
        this.messageCallbacks.set(messageId, { resolve, reject });
        try {
          this.sendWorkerMessage({
            type: "DISPOSE_BUFFER",
            bufferId
          });
        } catch (error) {
          console.error("Error disposing buffer", error);
          this.messageCallbacks.delete(messageId);
          resolve(false);
        }
        setTimeout(() => {
          if (this.messageCallbacks.has(messageId)) {
            this.messageCallbacks.delete(messageId);
            console.warn({ bufferId }, "Timed out waiting for buffer to be disposed");
            resolve(false);
          }
        }, 3000);
      });
    }
    this.debouncer.clearDebounce(`reset-${bufferId}`);
  }
  destroy() {
    if (this.destroyPromise) {
      return this.destroyPromise;
    }
    let resolveDestroy;
    let rejectDestroy;
    const destroyPromise = new Promise((resolve, reject) => {
      resolveDestroy = resolve;
      rejectDestroy = reject;
    });
    this.destroyPromise = destroyPromise;
    const destroyError = new Error("Client destroyed during initialization");
    this.lifecycleGeneration++;
    this.initialized = false;
    this.initializePromise = undefined;
    this.rejectActiveInitialization(destroyError);
    this.rejectPendingRequests(new Error("TreeSitter client destroyed"));
    for (const callback of this.destroyCallbacks) {
      try {
        callback();
      } catch (error) {
        console.error("TreeSitter client destroy callback failed:", error);
      }
    }
    this.destroyCallbacks.clear();
    clearDebounceScope("tree-sitter-client");
    this.debouncer.clear();
    this.editQueues.clear();
    this.buffers.clear();
    this.stopWorker().then(() => {
      this.workerTerminationFailed = false;
      if (this.destroyPromise === destroyPromise) {
        this.destroyPromise = undefined;
      }
      resolveDestroy();
    }, (error) => {
      this.workerTerminationFailed = true;
      if (this.destroyPromise === destroyPromise) {
        this.destroyPromise = undefined;
      }
      rejectDestroy(error);
    });
    return destroyPromise;
  }
  async resetBuffer(bufferId, version, content) {
    if (!this.initialized) {
      return;
    }
    const buffer = this.buffers.get(bufferId);
    if (!buffer || !buffer.hasParser) {
      this.emitError("Cannot reset buffer with no parser", bufferId);
      return;
    }
    this.buffers.set(bufferId, { ...buffer, content, version });
    this.debouncer.debounce(`reset-${bufferId}`, 10, () => this.processEdit(bufferId, [], content, version, true));
  }
  getBuffer(bufferId) {
    return this.buffers.get(bufferId);
  }
  getAllBuffers() {
    return Array.from(this.buffers.values());
  }
  isInitialized() {
    return this.initialized;
  }
  async setDataPath(dataPath) {
    if (this.options.dataPath === dataPath) {
      return;
    }
    this.options.dataPath = dataPath;
    if (this.initialized && this.worker) {
      const messageId = `update_datapath_${this.messageIdCounter++}`;
      return new Promise((resolve, reject) => {
        this.messageCallbacks.set(messageId, {
          resolve: (response) => {
            if (response.error) {
              reject(new Error(response.error));
            } else {
              resolve();
            }
          },
          reject
        });
        try {
          this.sendWorkerMessage({
            type: "UPDATE_DATA_PATH",
            dataPath,
            messageId
          });
        } catch (error) {
          this.messageCallbacks.delete(messageId);
          reject(error instanceof Error ? error : new Error(String(error)));
        }
      });
    }
  }
  async clearCache() {
    if (!this.initialized || !this.worker) {
      throw new Error("Cannot clear cache: client is not initialized");
    }
    const messageId = `clear_cache_${this.messageIdCounter++}`;
    return new Promise((resolve, reject) => {
      this.messageCallbacks.set(messageId, {
        resolve: (response) => {
          if (response.error) {
            reject(new Error(response.error));
          } else {
            resolve();
          }
        },
        reject
      });
      try {
        this.sendWorkerMessage({
          type: "CLEAR_CACHE",
          messageId
        });
      } catch (error) {
        this.messageCallbacks.delete(messageId);
        reject(error instanceof Error ? error : new Error(String(error)));
      }
    });
  }
}

// src/lib/data-paths.ts
import os from "os";
import path from "path";
import { EventEmitter as EventEmitter3 } from "events";

// src/lib/validate-dir-name.ts
function isValidDirectoryName(name) {
  if (!name || typeof name !== "string") {
    return false;
  }
  if (name.trim().length === 0) {
    return false;
  }
  const reservedNames = [
    "CON",
    "PRN",
    "AUX",
    "NUL",
    "COM1",
    "COM2",
    "COM3",
    "COM4",
    "COM5",
    "COM6",
    "COM7",
    "COM8",
    "COM9",
    "LPT1",
    "LPT2",
    "LPT3",
    "LPT4",
    "LPT5",
    "LPT6",
    "LPT7",
    "LPT8",
    "LPT9"
  ];
  if (reservedNames.includes(name.toUpperCase())) {
    return false;
  }
  const invalidChars = /[<>:"|?*/\\\x00-\x1f]/;
  if (invalidChars.test(name)) {
    return false;
  }
  if (name.endsWith(".") || name.endsWith(" ")) {
    return false;
  }
  if (name === "." || name === "..") {
    return false;
  }
  return true;
}

// src/lib/data-paths.ts
registerEnvVar2({
  name: "XDG_CONFIG_HOME",
  description: "Base directory for user-specific configuration files",
  type: "string",
  default: ""
});
registerEnvVar2({
  name: "XDG_DATA_HOME",
  description: "Base directory for user-specific data files",
  type: "string",
  default: ""
});

class DataPathsManager2 extends EventEmitter3 {
  _appName;
  _globalConfigPath;
  _globalConfigFile;
  _localConfigFile;
  _globalDataPath;
  constructor() {
    super();
    this._appName = "opentui";
  }
  get appName() {
    return this._appName;
  }
  set appName(value) {
    if (!isValidDirectoryName(value)) {
      throw new Error(`Invalid app name "${value}": must be a valid directory name`);
    }
    if (this._appName !== value) {
      this._appName = value;
      this._globalConfigPath = undefined;
      this._globalConfigFile = undefined;
      this._localConfigFile = undefined;
      this._globalDataPath = undefined;
      this.emit("paths:changed", this.toObject());
    }
  }
  get globalConfigPath() {
    if (this._globalConfigPath === undefined) {
      const homeDir = os.homedir();
      const xdgConfigHome = env2.XDG_CONFIG_HOME;
      const baseConfigDir = xdgConfigHome || path.join(homeDir, ".config");
      this._globalConfigPath = path.join(baseConfigDir, this._appName);
    }
    return this._globalConfigPath;
  }
  get globalConfigFile() {
    if (this._globalConfigFile === undefined) {
      this._globalConfigFile = path.join(this.globalConfigPath, "init.ts");
    }
    return this._globalConfigFile;
  }
  get localConfigFile() {
    if (this._localConfigFile === undefined) {
      this._localConfigFile = path.join(process.cwd(), `.${this._appName}.ts`);
    }
    return this._localConfigFile;
  }
  get globalDataPath() {
    if (this._globalDataPath === undefined) {
      const homeDir = os.homedir();
      const xdgDataHome = env2.XDG_DATA_HOME;
      const baseDataDir = xdgDataHome || path.join(homeDir, ".local/share");
      this._globalDataPath = path.join(baseDataDir, this._appName);
    }
    return this._globalDataPath;
  }
  toObject() {
    return {
      globalConfigPath: this.globalConfigPath,
      globalConfigFile: this.globalConfigFile,
      localConfigFile: this.localConfigFile,
      globalDataPath: this.globalDataPath
    };
  }
}
function getDataPaths2() {
  return singleton("data-paths-opentui", () => new DataPathsManager2);
}
// src/lib/tree-sitter/resolve-ft.ts
import path2 from "path";
var extensionToFiletype2 = new Map([
  ["astro", "astro"],
  ["bash", "bash"],
  ["c", "c"],
  ["cc", "cpp"],
  ["cjs", "javascript"],
  ["clj", "clojure"],
  ["cljs", "clojure"],
  ["cljc", "clojure"],
  ["cpp", "cpp"],
  ["cxx", "cpp"],
  ["cs", "csharp"],
  ["cts", "typescript"],
  ["ctsx", "typescriptreact"],
  ["dart", "dart"],
  ["diff", "diff"],
  ["edn", "clojure"],
  ["go", "go"],
  ["gemspec", "ruby"],
  ["groovy", "groovy"],
  ["h", "c"],
  ["handlebars", "handlebars"],
  ["hbs", "handlebars"],
  ["hpp", "cpp"],
  ["hxx", "cpp"],
  ["h++", "cpp"],
  ["hh", "cpp"],
  ["hrl", "erlang"],
  ["hs", "haskell"],
  ["htm", "html"],
  ["html", "html"],
  ["ini", "ini"],
  ["js", "javascript"],
  ["jsx", "javascriptreact"],
  ["jl", "julia"],
  ["json", "json"],
  ["ksh", "bash"],
  ["kt", "kotlin"],
  ["kts", "kotlin"],
  ["latex", "latex"],
  ["less", "less"],
  ["lua", "lua"],
  ["markdown", "markdown"],
  ["md", "markdown"],
  ["mdown", "markdown"],
  ["mkd", "markdown"],
  ["mjs", "javascript"],
  ["ml", "ocaml"],
  ["mli", "ocaml"],
  ["mts", "typescript"],
  ["mtsx", "typescriptreact"],
  ["patch", "diff"],
  ["php", "php"],
  ["pl", "perl"],
  ["pm", "perl"],
  ["ps1", "powershell"],
  ["psm1", "powershell"],
  ["py", "python"],
  ["pyi", "python"],
  ["r", "r"],
  ["rb", "ruby"],
  ["rake", "ruby"],
  ["rs", "rust"],
  ["ru", "ruby"],
  ["sass", "sass"],
  ["sc", "scala"],
  ["scala", "scala"],
  ["scss", "scss"],
  ["sh", "bash"],
  ["sql", "sql"],
  ["svelte", "svelte"],
  ["swift", "swift"],
  ["ts", "typescript"],
  ["tsx", "typescriptreact"],
  ["tex", "latex"],
  ["toml", "toml"],
  ["vue", "vue"],
  ["vim", "vim"],
  ["xml", "xml"],
  ["xsl", "xsl"],
  ["yaml", "yaml"],
  ["yml", "yaml"],
  ["zig", "zig"],
  ["zon", "zig"],
  ["zsh", "bash"],
  ["c++", "cpp"],
  ["erl", "erlang"],
  ["exs", "elixir"],
  ["ex", "elixir"],
  ["elm", "elm"],
  ["fsharp", "fsharp"],
  ["fs", "fsharp"],
  ["fsx", "fsharp"],
  ["fsscript", "fsharp"],
  ["fsi", "fsharp"],
  ["java", "java"],
  ["css", "css"]
]);
var basenameToFiletype2 = new Map([
  [".bash_aliases", "bash"],
  [".bash_logout", "bash"],
  [".bash_profile", "bash"],
  [".bashrc", "bash"],
  [".kshrc", "bash"],
  [".profile", "bash"],
  [".vimrc", "vim"],
  [".zlogin", "bash"],
  [".zlogout", "bash"],
  [".zprofile", "bash"],
  [".zshenv", "bash"],
  [".zshrc", "bash"],
  ["appfile", "ruby"],
  ["berksfile", "ruby"],
  ["brewfile", "ruby"],
  ["cheffile", "ruby"],
  ["containerfile", "dockerfile"],
  ["dockerfile", "dockerfile"],
  ["fastfile", "ruby"],
  ["gemfile", "ruby"],
  ["gnumakefile", "make"],
  ["gvimrc", "vim"],
  ["guardfile", "ruby"],
  ["makefile", "make"],
  ["podfile", "ruby"],
  ["rakefile", "ruby"],
  ["thorfile", "ruby"],
  ["vagrantfile", "ruby"]
]);
function normalizeFiletypeToken(value) {
  const normalizedValue = value.trim().replace(/^\./, "").toLowerCase();
  return normalizedValue || undefined;
}
function getBasename(value) {
  const normalizedValue = value.trim().replaceAll("\\", "/");
  if (!normalizedValue)
    return;
  const basename = path2.posix.basename(normalizedValue).toLowerCase();
  return basename || undefined;
}
function extToFiletype2(extension) {
  const normalizedExtension = normalizeFiletypeToken(extension);
  if (!normalizedExtension)
    return;
  return extensionToFiletype2.get(normalizedExtension);
}
function pathToFiletype2(path) {
  if (typeof path !== "string")
    return;
  const basename = getBasename(path);
  if (!basename)
    return;
  const basenameFiletype = basenameToFiletype2.get(basename);
  if (basenameFiletype) {
    return basenameFiletype;
  }
  const lastDot = basename.lastIndexOf(".");
  if (lastDot === -1 || lastDot === basename.length - 1) {
    return;
  }
  const extension = basename.substring(lastDot + 1);
  return extToFiletype2(extension);
}
function infoStringToFiletype2(infoString) {
  if (typeof infoString !== "string")
    return;
  const token = infoString.trim().split(/\s+/, 1)[0];
  const directBasenameMatch = basenameToFiletype2.get(token.toLowerCase());
  if (directBasenameMatch)
    return directBasenameMatch;
  const normalizedToken = normalizeFiletypeToken(token);
  if (!normalizedToken)
    return;
  return basenameToFiletype2.get(normalizedToken) ?? pathToFiletype2(normalizedToken) ?? extToFiletype2(normalizedToken) ?? normalizedToken;
}

// src/lib/tree-sitter/index.ts
var TREE_SITTER_CLIENT_KEY = "tree-sitter-client";
var TREE_SITTER_CLIENT_LISTENER_STATE_KEY = "tree-sitter-client-listener-state";
function getTreeSitterClientListenerState() {
  return singleton(TREE_SITTER_CLIENT_LISTENER_STATE_KEY, () => ({}));
}
function getTreeSitterClient2() {
  const existingClient = getSingleton(TREE_SITTER_CLIENT_KEY);
  if (existingClient) {
    return existingClient;
  }
  const dataPathsManager = getDataPaths2();
  const defaultOptions = {
    dataPath: dataPathsManager.globalDataPath
  };
  return singleton(TREE_SITTER_CLIENT_KEY, () => {
    const client2 = new TreeSitterClient2(defaultOptions);
    const listenerState = getTreeSitterClientListenerState();
    const handlePathsChanged = (paths) => {
      client2.setDataPath(paths.globalDataPath).catch((error) => {
        console.warn("Failed to update tree-sitter data path:", error);
      });
    };
    const removeListener = () => {
      dataPathsManager.off("paths:changed", handlePathsChanged);
      if (listenerState.removeListener === removeListener) {
        listenerState.removeListener = undefined;
      }
      if (getSingleton(TREE_SITTER_CLIENT_KEY) === client2) {
        destroySingleton(TREE_SITTER_CLIENT_KEY);
      }
    };
    listenerState.removeListener = removeListener;
    client2.onDestroy(removeListener);
    dataPathsManager.on("paths:changed", handlePathsChanged);
    return client2;
  });
}
async function destroyTreeSitterClient2() {
  const client2 = getSingleton(TREE_SITTER_CLIENT_KEY);
  if (!client2) {
    const listenerState = getSingleton(TREE_SITTER_CLIENT_LISTENER_STATE_KEY);
    listenerState?.removeListener?.();
    if (listenerState) {
      listenerState.removeListener = undefined;
    }
    return;
  }
  destroySingleton(TREE_SITTER_CLIENT_KEY);
  await client2.destroy();
}
// src/lib/extmarks-history.ts
class ExtmarksHistory {
  undoStack = [];
  redoStack = [];
  saveSnapshot(extmarks, nextId) {
    const snapshot = {
      extmarks: new Map(Array.from(extmarks.entries()).map(([id, extmark]) => [id, { ...extmark }])),
      nextId
    };
    this.undoStack.push(snapshot);
    this.redoStack = [];
  }
  undo() {
    if (this.undoStack.length === 0)
      return null;
    return this.undoStack.pop();
  }
  redo() {
    if (this.redoStack.length === 0)
      return null;
    return this.redoStack.pop();
  }
  pushRedo(snapshot) {
    this.redoStack.push(snapshot);
  }
  pushUndo(snapshot) {
    this.undoStack.push(snapshot);
  }
  clear() {
    this.undoStack = [];
    this.redoStack = [];
  }
  canUndo() {
    return this.undoStack.length > 0;
  }
  canRedo() {
    return this.redoStack.length > 0;
  }
}

// src/lib/extmarks.ts
class ExtmarksController2 {
  editBuffer;
  editorView;
  extmarks = new Map;
  extmarksByTypeId = new Map;
  metadata = new Map;
  nextId = 1;
  destroyed = false;
  history = new ExtmarksHistory;
  typeNameToId = new Map;
  typeIdToName = new Map;
  nextTypeId = 1;
  originalMoveCursorLeft;
  originalMoveCursorRight;
  originalSetCursorByOffset;
  originalMoveUpVisual;
  originalMoveDownVisual;
  originalDeleteCharBackward;
  originalDeleteChar;
  originalInsertText;
  originalInsertChar;
  originalDeleteRange;
  originalSetText;
  originalReplaceText;
  originalClear;
  originalNewLine;
  originalDeleteLine;
  originalEditorViewDeleteSelectedText;
  originalEditorViewReplaceSelectedText;
  originalUndo;
  originalRedo;
  contentChangeListener = () => {
    if (!this.destroyed)
      this.updateHighlights();
  };
  constructor(editBuffer, editorView) {
    this.editBuffer = editBuffer;
    this.editorView = editorView;
    this.originalMoveCursorLeft = editBuffer.moveCursorLeft.bind(editBuffer);
    this.originalMoveCursorRight = editBuffer.moveCursorRight.bind(editBuffer);
    this.originalSetCursorByOffset = editBuffer.setCursorByOffset.bind(editBuffer);
    this.originalMoveUpVisual = editorView.moveUpVisual.bind(editorView);
    this.originalMoveDownVisual = editorView.moveDownVisual.bind(editorView);
    this.originalDeleteCharBackward = editBuffer.deleteCharBackward.bind(editBuffer);
    this.originalDeleteChar = editBuffer.deleteChar.bind(editBuffer);
    this.originalInsertText = editBuffer.insertText.bind(editBuffer);
    this.originalInsertChar = editBuffer.insertChar.bind(editBuffer);
    this.originalDeleteRange = editBuffer.deleteRange.bind(editBuffer);
    this.originalSetText = editBuffer.setText.bind(editBuffer);
    this.originalReplaceText = editBuffer.replaceText.bind(editBuffer);
    this.originalClear = editBuffer.clear.bind(editBuffer);
    this.originalNewLine = editBuffer.newLine.bind(editBuffer);
    this.originalDeleteLine = editBuffer.deleteLine.bind(editBuffer);
    this.originalEditorViewDeleteSelectedText = editorView.deleteSelectedText.bind(editorView);
    this.originalEditorViewReplaceSelectedText = editorView._replaceSelectedText.bind(editorView);
    this.originalUndo = editBuffer.undo.bind(editBuffer);
    this.originalRedo = editBuffer.redo.bind(editBuffer);
    this.wrapCursorMovement();
    this.wrapDeletion();
    this.wrapInsertion();
    this.wrapEditorViewDeleteSelectedText();
    this.wrapUndoRedo();
    this.setupContentChangeListener();
  }
  wrapCursorMovement() {
    this.editBuffer.moveCursorLeft = () => {
      if (this.destroyed) {
        this.originalMoveCursorLeft();
        return;
      }
      const currentOffset = this.editorView.getVisualCursor().offset;
      const hasSelection = this.editorView.hasSelection();
      if (hasSelection) {
        this.originalMoveCursorLeft();
        return;
      }
      const targetOffset = currentOffset - 1;
      if (targetOffset < 0) {
        this.originalMoveCursorLeft();
        return;
      }
      const virtualExtmark = this.findVirtualExtmarkContaining(targetOffset);
      if (virtualExtmark && currentOffset >= virtualExtmark.end) {
        this.editBuffer.setCursorByOffset(Math.max(0, virtualExtmark.start - 1));
        return;
      }
      this.originalMoveCursorLeft();
    };
    this.editBuffer.moveCursorRight = () => {
      if (this.destroyed) {
        this.originalMoveCursorRight();
        return;
      }
      const currentOffset = this.editorView.getVisualCursor().offset;
      const hasSelection = this.editorView.hasSelection();
      if (hasSelection) {
        this.originalMoveCursorRight();
        return;
      }
      const targetOffset = currentOffset + 1;
      if (this.editBuffer.offsetToPosition(targetOffset) === null) {
        this.originalMoveCursorRight();
        return;
      }
      const virtualExtmark = this.findVirtualExtmarkContaining(targetOffset);
      if (virtualExtmark && currentOffset <= virtualExtmark.start) {
        this.editBuffer.setCursorByOffset(virtualExtmark.end);
        return;
      }
      this.originalMoveCursorRight();
    };
    this.editorView.moveUpVisual = () => {
      if (this.destroyed) {
        this.originalMoveUpVisual();
        return;
      }
      const hasSelection = this.editorView.hasSelection();
      if (hasSelection) {
        this.originalMoveUpVisual();
        return;
      }
      const currentOffset = this.editorView.getVisualCursor().offset;
      this.originalMoveUpVisual();
      const newOffset = this.editorView.getVisualCursor().offset;
      const virtualExtmark = this.findVirtualExtmarkContaining(newOffset);
      if (virtualExtmark) {
        const distanceToStart = newOffset - virtualExtmark.start;
        const distanceToEnd = virtualExtmark.end - newOffset;
        if (distanceToStart < distanceToEnd) {
          this.editorView.setCursorByOffset(Math.max(0, virtualExtmark.start - 1));
        } else {
          this.editorView.setCursorByOffset(virtualExtmark.end);
        }
      }
    };
    this.editorView.moveDownVisual = () => {
      if (this.destroyed) {
        this.originalMoveDownVisual();
        return;
      }
      const hasSelection = this.editorView.hasSelection();
      if (hasSelection) {
        this.originalMoveDownVisual();
        return;
      }
      const currentOffset = this.editorView.getVisualCursor().offset;
      this.originalMoveDownVisual();
      const newOffset = this.editorView.getVisualCursor().offset;
      const virtualExtmark = this.findVirtualExtmarkContaining(newOffset);
      if (virtualExtmark) {
        const distanceToStart = newOffset - virtualExtmark.start;
        const distanceToEnd = virtualExtmark.end - newOffset;
        if (distanceToStart < distanceToEnd) {
          const adjustedOffset = virtualExtmark.start - 1;
          const targetOffset = adjustedOffset <= currentOffset ? virtualExtmark.end : adjustedOffset;
          this.editorView.setCursorByOffset(targetOffset);
        } else {
          this.editorView.setCursorByOffset(virtualExtmark.end);
        }
      }
    };
    this.editBuffer.setCursorByOffset = (offset) => {
      if (this.destroyed) {
        this.originalSetCursorByOffset(offset);
        return;
      }
      const currentOffset = this.editorView.getVisualCursor().offset;
      const hasSelection = this.editorView.hasSelection();
      if (hasSelection) {
        this.originalSetCursorByOffset(offset);
        return;
      }
      const movingForward = offset > currentOffset;
      if (movingForward) {
        const virtualExtmark = this.findVirtualExtmarkContaining(offset);
        if (virtualExtmark && currentOffset <= virtualExtmark.start) {
          this.originalSetCursorByOffset(virtualExtmark.end);
          return;
        }
      } else {
        for (const extmark of this.extmarks.values()) {
          if (extmark.virtual && currentOffset >= extmark.end && offset < extmark.end && offset >= extmark.start) {
            this.originalSetCursorByOffset(Math.max(0, extmark.start - 1));
            return;
          }
        }
      }
      this.originalSetCursorByOffset(offset);
    };
  }
  wrapDeletion() {
    this.editBuffer.deleteCharBackward = () => this.editBuffer.runMutation(() => {
      if (this.destroyed) {
        this.originalDeleteCharBackward();
        return;
      }
      const currentOffset = this.editorView.getVisualCursor().offset;
      const hadSelection = this.editorView.hasSelection();
      if (currentOffset === 0 || hadSelection) {
        this.originalDeleteCharBackward();
        this.saveSnapshot();
        return;
      }
      const targetOffset = currentOffset - 1;
      const virtualExtmark = this.findVirtualExtmarkContaining(targetOffset);
      if (virtualExtmark && currentOffset === virtualExtmark.end) {
        const startCursor = this.offsetToPosition(virtualExtmark.start);
        const endCursor = this.offsetToPosition(virtualExtmark.end);
        const deleteOffset = virtualExtmark.start;
        const deleteLength = virtualExtmark.end - virtualExtmark.start;
        this.originalDeleteRange(startCursor.row, startCursor.col, endCursor.row, endCursor.col);
        this.saveSnapshot();
        this.deleteExtmarkById(virtualExtmark.id);
        this.adjustExtmarksAfterDeletion(deleteOffset, deleteLength);
        return;
      }
      this.originalDeleteCharBackward();
      this.saveSnapshot();
      const deleteOffset = this.editBuffer.getCursorPosition().offset;
      const deleteLength = currentOffset - deleteOffset;
      if (deleteLength > 0) {
        this.adjustExtmarksAfterDeletion(deleteOffset, deleteLength);
      }
    });
    this.editBuffer.deleteChar = () => this.editBuffer.runMutation(() => {
      if (this.destroyed) {
        this.originalDeleteChar();
        return;
      }
      const currentOffset = this.editorView.getVisualCursor().offset;
      const hadSelection = this.editorView.hasSelection();
      if (hadSelection) {
        this.originalDeleteChar();
        this.saveSnapshot();
        return;
      }
      const targetOffset = currentOffset;
      const virtualExtmark = this.findVirtualExtmarkContaining(targetOffset);
      if (virtualExtmark && currentOffset === virtualExtmark.start) {
        const startCursor = this.offsetToPosition(virtualExtmark.start);
        const endCursor = this.offsetToPosition(virtualExtmark.end);
        const deleteOffset = virtualExtmark.start;
        const deleteLength = virtualExtmark.end - virtualExtmark.start;
        this.originalDeleteRange(startCursor.row, startCursor.col, endCursor.row, endCursor.col);
        this.saveSnapshot();
        this.deleteExtmarkById(virtualExtmark.id);
        this.adjustExtmarksAfterDeletion(deleteOffset, deleteLength);
        return;
      }
      const deleteEndOffset = this.getNextCursorOffset(currentOffset);
      const deleteLength = deleteEndOffset - currentOffset;
      this.originalDeleteChar();
      this.saveSnapshot();
      if (deleteLength > 0) {
        this.adjustExtmarksAfterDeletion(currentOffset, deleteLength);
      }
    });
    this.editBuffer.deleteRange = (startLine, startCol, endLine, endCol) => this.editBuffer.runMutation(() => {
      if (this.destroyed) {
        this.originalDeleteRange(startLine, startCol, endLine, endCol);
        return;
      }
      const startOffset = this.positionToOffset(startLine, startCol);
      const endOffset = this.positionToOffset(endLine, endCol);
      const length = endOffset - startOffset;
      this.originalDeleteRange(startLine, startCol, endLine, endCol);
      this.saveSnapshot();
      this.adjustExtmarksAfterDeletion(startOffset, length);
    });
    this.editBuffer.deleteLine = () => this.editBuffer.runMutation(() => {
      if (this.destroyed) {
        this.originalDeleteLine();
        return;
      }
      const row = this.editBuffer.getCursorPosition().row;
      const lineStart = this.editBuffer.getLineStartOffset(row);
      const [start, end] = row + 1 < this.editBuffer.getLineCount() ? [lineStart, this.editBuffer.getLineStartOffset(row + 1)] : [Math.max(0, lineStart - 1), this.editBuffer.getEOL().offset];
      this.originalDeleteLine();
      this.saveSnapshot();
      this.adjustExtmarksAfterDeletion(start, end - start);
    });
  }
  wrapInsertion() {
    this.editBuffer.insertText = (text) => this.editBuffer.runMutation(() => {
      if (this.destroyed) {
        this.originalInsertText(text);
        return;
      }
      const currentOffset = this.editorView.getVisualCursor().offset;
      this.originalInsertText(text);
      this.saveSnapshot();
      const insertLength = this.editBuffer.getCursorPosition().offset - currentOffset;
      if (insertLength > 0) {
        this.adjustExtmarksAfterInsertion(currentOffset, insertLength);
      }
    });
    this.editBuffer.insertChar = (char) => this.editBuffer.runMutation(() => {
      if (this.destroyed) {
        this.originalInsertChar(char);
        return;
      }
      const currentOffset = this.editorView.getVisualCursor().offset;
      this.originalInsertChar(char);
      this.saveSnapshot();
      const insertLength = this.editBuffer.getCursorPosition().offset - currentOffset;
      if (insertLength > 0) {
        this.adjustExtmarksAfterInsertion(currentOffset, insertLength);
      }
    });
    this.editBuffer.setText = (text) => {
      if (this.destroyed) {
        this.originalSetText(text);
        return;
      }
      this.editBuffer.runMutation(() => {
        this.originalSetText(text);
        this.clear();
      });
    };
    this.editBuffer.replaceText = (text) => {
      if (this.destroyed) {
        this.originalReplaceText(text);
        return;
      }
      this.editBuffer.runMutation(() => {
        this.originalReplaceText(text);
        this.saveSnapshot();
        this.clear();
      });
    };
    this.editBuffer.clear = () => this.editBuffer.runMutation(() => {
      if (this.destroyed) {
        this.originalClear();
        return;
      }
      this.originalClear();
      this.saveSnapshot();
      this.clear();
    });
    this.editBuffer.newLine = () => this.editBuffer.runMutation(() => {
      if (this.destroyed) {
        this.originalNewLine();
        return;
      }
      const currentOffset = this.editorView.getVisualCursor().offset;
      this.originalNewLine();
      this.saveSnapshot();
      this.adjustExtmarksAfterInsertion(currentOffset, 1);
    });
  }
  wrapEditorViewDeleteSelectedText() {
    this.editorView._replaceSelectedText = (text) => this.editBuffer.runMutation(() => {
      if (this.destroyed)
        return this.originalEditorViewReplaceSelectedText(text);
      const selection = this.editorView.getSelection();
      const deleteOffset = selection ? Math.min(selection.start, selection.end) : 0;
      const deleteLength = selection ? Math.abs(selection.end - selection.start) : 0;
      const cursorOffset = this.editBuffer.getCursorPosition().offset;
      const result = this.originalEditorViewReplaceSelectedText(text);
      const insertOffset = result.deleted ? deleteOffset : cursorOffset;
      if (result.deleted) {
        this.saveSnapshot();
        if (deleteLength > 0)
          this.adjustExtmarksAfterDeletion(deleteOffset, deleteLength, false);
      }
      if (result.inserted)
        this.saveSnapshot();
      const insertLength = this.editBuffer.getCursorPosition().offset - insertOffset;
      if (insertLength > 0)
        this.adjustExtmarksAfterInsertion(insertOffset, insertLength, false);
      if (deleteLength > 0 || insertLength > 0)
        this.updateHighlights();
      return result;
    });
    this.editorView.deleteSelectedText = () => this.editBuffer.runMutation(() => {
      if (this.destroyed) {
        this.originalEditorViewDeleteSelectedText();
        return;
      }
      const selection = this.editorView.getSelection();
      if (!selection) {
        this.originalEditorViewDeleteSelectedText();
        this.saveSnapshot();
        return;
      }
      const deleteOffset = Math.min(selection.start, selection.end);
      const deleteLength = Math.abs(selection.end - selection.start);
      this.originalEditorViewDeleteSelectedText();
      this.saveSnapshot();
      if (deleteLength > 0) {
        this.adjustExtmarksAfterDeletion(deleteOffset, deleteLength);
      }
    });
  }
  setupContentChangeListener() {
    this.editBuffer.on("content-changed", this.contentChangeListener);
  }
  deleteExtmarkById(id) {
    const extmark = this.extmarks.get(id);
    if (extmark) {
      this.extmarks.delete(id);
      this.extmarksByTypeId.get(extmark.typeId)?.delete(id);
      this.metadata.delete(id);
    }
  }
  findVirtualExtmarkContaining(offset) {
    for (const extmark of this.extmarks.values()) {
      if (extmark.virtual && offset >= extmark.start && offset < extmark.end) {
        return extmark;
      }
    }
    return null;
  }
  adjustExtmarksAfterInsertion(insertOffset, length, updateHighlights = true) {
    for (const extmark of this.extmarks.values()) {
      if (extmark.start >= insertOffset) {
        extmark.start += length;
        extmark.end += length;
      } else if (extmark.end > insertOffset) {
        extmark.end += length;
      }
    }
    if (updateHighlights)
      this.updateHighlights();
  }
  adjustExtmarksAfterDeletion(deleteOffset, length, updateHighlights = true) {
    const toDelete = [];
    for (const extmark of this.extmarks.values()) {
      if (extmark.end <= deleteOffset) {
        continue;
      }
      if (extmark.start >= deleteOffset + length) {
        extmark.start -= length;
        extmark.end -= length;
      } else if (extmark.start >= deleteOffset && extmark.end <= deleteOffset + length) {
        toDelete.push(extmark.id);
      } else if (extmark.start < deleteOffset && extmark.end > deleteOffset + length) {
        extmark.end -= length;
      } else if (extmark.start < deleteOffset && extmark.end > deleteOffset) {
        extmark.end -= Math.min(extmark.end, deleteOffset + length) - deleteOffset;
      } else if (extmark.start < deleteOffset + length && extmark.end > deleteOffset + length) {
        const overlap = deleteOffset + length - extmark.start;
        extmark.start = deleteOffset;
        extmark.end -= length;
      }
    }
    for (const id of toDelete) {
      this.deleteExtmarkById(id);
    }
    if (updateHighlights)
      this.updateHighlights();
  }
  offsetToPosition(offset) {
    const result = this.editBuffer.offsetToPosition(offset);
    if (!result) {
      return { row: 0, col: 0 };
    }
    return result;
  }
  positionToOffset(row, col) {
    return this.editBuffer.positionToOffset(row, col);
  }
  getNextCursorOffset(currentOffset) {
    this.originalMoveCursorRight();
    const nextOffset = this.editorView.getVisualCursor().offset;
    this.originalSetCursorByOffset(currentOffset);
    return nextOffset;
  }
  updateHighlights() {
    this.editBuffer.clearAllHighlights();
    for (const extmark of this.extmarks.values()) {
      if (extmark.styleId !== undefined) {
        this.editBuffer.addHighlightByCharRange({
          start: this.offsetExcludingNewlines(extmark.start),
          end: this.offsetExcludingNewlines(extmark.end),
          styleId: extmark.styleId,
          priority: extmark.priority ?? 0,
          hlRef: extmark.id & 65535
        });
      }
    }
  }
  offsetExcludingNewlines(offset) {
    return offset - (this.editBuffer.offsetToPosition(offset)?.row ?? 0);
  }
  create(options) {
    if (this.destroyed) {
      throw new Error("ExtmarksController is destroyed");
    }
    const id = this.nextId++;
    const typeId = options.typeId ?? 0;
    const extmark = {
      id,
      start: options.start,
      end: options.end,
      virtual: options.virtual ?? false,
      styleId: options.styleId,
      priority: options.priority,
      data: options.data,
      typeId
    };
    this.extmarks.set(id, extmark);
    if (!this.extmarksByTypeId.has(typeId)) {
      this.extmarksByTypeId.set(typeId, new Set);
    }
    this.extmarksByTypeId.get(typeId).add(id);
    if (options.metadata !== undefined) {
      this.metadata.set(id, options.metadata);
    }
    try {
      this.updateHighlights();
    } catch (error) {
      this.deleteExtmarkById(id);
      this.updateHighlights();
      throw error;
    }
    return id;
  }
  delete(id) {
    if (this.destroyed) {
      throw new Error("ExtmarksController is destroyed");
    }
    const extmark = this.extmarks.get(id);
    if (!extmark)
      return false;
    this.deleteExtmarkById(id);
    this.updateHighlights();
    return true;
  }
  get(id) {
    if (this.destroyed)
      return null;
    return this.extmarks.get(id) ?? null;
  }
  getAll() {
    if (this.destroyed)
      return [];
    return Array.from(this.extmarks.values());
  }
  getVirtual() {
    if (this.destroyed)
      return [];
    return Array.from(this.extmarks.values()).filter((e) => e.virtual);
  }
  getAtOffset(offset) {
    if (this.destroyed)
      return [];
    return Array.from(this.extmarks.values()).filter((e) => offset >= e.start && offset < e.end);
  }
  getAllForTypeId(typeId) {
    if (this.destroyed)
      return [];
    const ids = this.extmarksByTypeId.get(typeId);
    if (!ids)
      return [];
    return Array.from(ids).map((id) => this.extmarks.get(id)).filter((e) => e !== undefined);
  }
  clear() {
    if (this.destroyed)
      return;
    this.extmarks.clear();
    this.extmarksByTypeId.clear();
    this.metadata.clear();
    this.updateHighlights();
  }
  saveSnapshot() {
    this.history.saveSnapshot(this.snapshotExtmarks(), this.nextId);
  }
  snapshotExtmarks() {
    return new Map(Array.from(this.extmarks, ([id, extmark]) => [id, { ...extmark, metadata: this.metadata.get(id) }]));
  }
  restoreSnapshot(snapshot) {
    this.extmarks.clear();
    this.extmarksByTypeId.clear();
    this.metadata.clear();
    for (const [id, saved] of snapshot.extmarks) {
      const { metadata, ...extmark } = saved;
      this.extmarks.set(id, extmark);
      if (!this.extmarksByTypeId.has(extmark.typeId)) {
        this.extmarksByTypeId.set(extmark.typeId, new Set);
      }
      this.extmarksByTypeId.get(extmark.typeId).add(id);
      if (metadata !== undefined)
        this.metadata.set(id, metadata);
    }
    this.nextId = snapshot.nextId;
    this.updateHighlights();
  }
  wrapUndoRedo() {
    this.editBuffer.undo = () => this.editBuffer.runMutation(() => {
      if (this.destroyed || !this.history.canUndo()) {
        return this.originalUndo();
      }
      const result = this.originalUndo();
      const currentSnapshot = {
        extmarks: this.snapshotExtmarks(),
        nextId: this.nextId
      };
      this.history.pushRedo(currentSnapshot);
      const snapshot = this.history.undo();
      this.restoreSnapshot(snapshot);
      return result;
    });
    this.editBuffer.redo = () => this.editBuffer.runMutation(() => {
      if (this.destroyed || !this.history.canRedo()) {
        return this.originalRedo();
      }
      const result = this.originalRedo();
      const currentSnapshot = {
        extmarks: this.snapshotExtmarks(),
        nextId: this.nextId
      };
      this.history.pushUndo(currentSnapshot);
      const snapshot = this.history.redo();
      this.restoreSnapshot(snapshot);
      return result;
    });
  }
  registerType(typeName) {
    if (this.destroyed) {
      throw new Error("ExtmarksController is destroyed");
    }
    const existing = this.typeNameToId.get(typeName);
    if (existing !== undefined) {
      return existing;
    }
    const typeId = this.nextTypeId++;
    this.typeNameToId.set(typeName, typeId);
    this.typeIdToName.set(typeId, typeName);
    return typeId;
  }
  getTypeId(typeName) {
    if (this.destroyed)
      return null;
    return this.typeNameToId.get(typeName) ?? null;
  }
  getTypeName(typeId) {
    if (this.destroyed)
      return null;
    return this.typeIdToName.get(typeId) ?? null;
  }
  getMetadataFor(extmarkId) {
    if (this.destroyed)
      return;
    return this.metadata.get(extmarkId);
  }
  destroy() {
    if (this.destroyed)
      return;
    this.editBuffer.off("content-changed", this.contentChangeListener);
    this.editBuffer.moveCursorLeft = this.originalMoveCursorLeft;
    this.editBuffer.moveCursorRight = this.originalMoveCursorRight;
    this.editBuffer.setCursorByOffset = this.originalSetCursorByOffset;
    this.editorView.moveUpVisual = this.originalMoveUpVisual;
    this.editorView.moveDownVisual = this.originalMoveDownVisual;
    this.editBuffer.deleteCharBackward = this.originalDeleteCharBackward;
    this.editBuffer.deleteChar = this.originalDeleteChar;
    this.editBuffer.insertText = this.originalInsertText;
    this.editBuffer.insertChar = this.originalInsertChar;
    this.editBuffer.deleteRange = this.originalDeleteRange;
    this.editBuffer.setText = this.originalSetText;
    this.editBuffer.replaceText = this.originalReplaceText;
    this.editBuffer.clear = this.originalClear;
    this.editBuffer.newLine = this.originalNewLine;
    this.editBuffer.deleteLine = this.originalDeleteLine;
    this.editorView.deleteSelectedText = this.originalEditorViewDeleteSelectedText;
    this.editorView._replaceSelectedText = this.originalEditorViewReplaceSelectedText;
    this.editBuffer.undo = this.originalUndo;
    this.editBuffer.redo = this.originalRedo;
    this.extmarks.clear();
    this.extmarksByTypeId.clear();
    this.metadata.clear();
    this.typeNameToId.clear();
    this.typeIdToName.clear();
    this.history.clear();
    this.destroyed = true;
  }
}
function createExtmarksController2(editBuffer, editorView) {
  return new ExtmarksController2(editBuffer, editorView);
}
// src/lib/terminal-palette.ts
var SYSTEM_CLOCK2 = new SystemClock2;
registerEnvVar2({
  name: "OTUI_PALETTE_IDLE_TIMEOUT_MS",
  description: "Milliseconds of silence after palette queries before using fallback colors.",
  type: "number",
  default: 300
});
var OSC4_RESPONSE = /\x1b]4;(\d+);(?:(?:rgb:)([0-9a-fA-F]+)\/([0-9a-fA-F]+)\/([0-9a-fA-F]+)|#([0-9a-fA-F]{6}))(?:\x07|\x1b\\)/g;
var OSC_SPECIAL_RESPONSE = /\x1b](\d+);(?:(?:rgb:)([0-9a-fA-F]+)\/([0-9a-fA-F]+)\/([0-9a-fA-F]+)|#([0-9a-fA-F]{6}))(?:\x07|\x1b\\)/g;
function scaleComponent(comp) {
  const val = parseInt(comp, 16);
  const maxIn = (1 << 4 * comp.length) - 1;
  return Math.round(val / maxIn * 255).toString(16).padStart(2, "0");
}
function toHex(r, g, b, hex6) {
  if (hex6)
    return `#${hex6.toLowerCase()}`;
  if (r && g && b)
    return `#${scaleComponent(r)}${scaleComponent(g)}${scaleComponent(b)}`;
  return "#000000";
}
function wrapForTmux(osc) {
  const escaped = osc.replace(/\x1b/g, "\x1B\x1B");
  return `\x1BPtmux;${escaped}\x1B\\`;
}

class TerminalPalette2 {
  stdin;
  stdout;
  writeFn;
  activeQuerySessions = [];
  inLegacyTmux;
  inTmux;
  oscSource;
  clock;
  constructor(options) {
    const { stdin, stdout, writeFn, isLegacyTmux, isTmux, oscSource, clock } = options;
    this.stdin = stdin;
    this.stdout = stdout;
    this.writeFn = writeFn || ((data) => stdout.write(data));
    this.inLegacyTmux = isLegacyTmux ?? false;
    this.inTmux = isTmux ?? this.inLegacyTmux;
    this.oscSource = oscSource;
    this.clock = clock ?? SYSTEM_CLOCK2;
  }
  writeOsc(osc, wrapForLegacyTmux = false) {
    const data = wrapForLegacyTmux && this.inLegacyTmux ? wrapForTmux(osc) : osc;
    return this.writeFn(data);
  }
  cleanup() {
    for (const cleanupSession of [...this.activeQuerySessions]) {
      cleanupSession();
    }
    this.activeQuerySessions = [];
  }
  subscribeInput(handler) {
    if (this.oscSource) {
      return this.oscSource.subscribeOsc((sequence) => {
        handler(sequence);
      });
    }
    this.stdin.on("data", handler);
    return () => {
      this.stdin.removeListener("data", handler);
    };
  }
  createQuerySession() {
    const timers = new Set;
    const subscriptions = new Set;
    let closed = false;
    const cleanup = () => {
      if (closed)
        return;
      closed = true;
      for (const timer of timers) {
        this.clock.clearTimeout(timer);
      }
      timers.clear();
      for (const unsubscribe of subscriptions) {
        unsubscribe();
      }
      subscriptions.clear();
      const idx = this.activeQuerySessions.indexOf(cleanup);
      if (idx !== -1)
        this.activeQuerySessions.splice(idx, 1);
    };
    this.activeQuerySessions.push(cleanup);
    return {
      setTimer: (fn, ms) => {
        const timer = this.clock.setTimeout(fn, ms);
        timers.add(timer);
        return timer;
      },
      resetTimer: (existing, fn, ms) => {
        if (existing) {
          this.clock.clearTimeout(existing);
          timers.delete(existing);
        }
        const timer = this.clock.setTimeout(fn, ms);
        timers.add(timer);
        return timer;
      },
      subscribeInput: (handler) => {
        const unsubscribe = this.subscribeInput(handler);
        subscriptions.add(unsubscribe);
        return () => {
          if (!subscriptions.has(unsubscribe))
            return;
          subscriptions.delete(unsubscribe);
          unsubscribe();
        };
      },
      cleanup
    };
  }
  async detectOSCSupport(timeoutMs = 300) {
    const out = this.stdout;
    if (!out.isTTY || !this.stdin.isTTY)
      return false;
    return new Promise((resolve) => {
      const session = this.createQuerySession();
      let buffer = "";
      let settled = false;
      const finish = (supported) => {
        if (settled)
          return;
        settled = true;
        session.cleanup();
        resolve(supported);
      };
      const onData = (chunk) => {
        buffer += chunk.toString();
        OSC4_RESPONSE.lastIndex = 0;
        if (OSC4_RESPONSE.test(buffer)) {
          finish(true);
        }
      };
      session.setTimer(() => {
        finish(false);
      }, timeoutMs);
      session.subscribeInput(onData);
      this.writeOsc("\x1B]4;0;?\x07", true);
    });
  }
  async queryPalette(indices, timeoutMs = 1200, idleTimeoutMs = env2.OTUI_PALETTE_IDLE_TIMEOUT_MS) {
    const out = this.stdout;
    const results = new Map;
    indices.forEach((i) => results.set(i, null));
    if (!out.isTTY || !this.stdin.isTTY) {
      return results;
    }
    return new Promise((resolve) => {
      const session = this.createQuerySession();
      let buffer = "";
      let idleTimer = null;
      let settled = false;
      const finish = () => {
        if (settled)
          return;
        settled = true;
        session.cleanup();
        resolve(results);
      };
      const onData = (chunk) => {
        buffer += chunk.toString();
        let m;
        OSC4_RESPONSE.lastIndex = 0;
        while (m = OSC4_RESPONSE.exec(buffer)) {
          const idx = parseInt(m[1], 10);
          if (results.has(idx))
            results.set(idx, toHex(m[2], m[3], m[4], m[5]));
        }
        if (buffer.length > 8192)
          buffer = buffer.slice(-4096);
        const done = [...results.values()].filter((v) => v !== null).length;
        if (done === results.size) {
          finish();
          return;
        }
        idleTimer = session.resetTimer(idleTimer, finish, idleTimeoutMs);
      };
      session.setTimer(finish, timeoutMs);
      session.subscribeInput(onData);
      this.writeOsc(indices.map((i) => `\x1B]4;${i};?\x07`).join(""), true);
      idleTimer = session.resetTimer(idleTimer, finish, idleTimeoutMs);
    });
  }
  async querySpecialColors(timeoutMs = 1200, idleTimeoutMs = env2.OTUI_PALETTE_IDLE_TIMEOUT_MS) {
    const out = this.stdout;
    const results = {
      10: null,
      11: null,
      12: null,
      13: null,
      14: null,
      15: null,
      16: null,
      17: null,
      19: null
    };
    const queries = this.inTmux ? [10, 11, 12] : [10, 11, 12, 13, 14, 15, 16, 17, 19];
    if (!out.isTTY || !this.stdin.isTTY) {
      return results;
    }
    return new Promise((resolve) => {
      const session = this.createQuerySession();
      let buffer = "";
      let idleTimer = null;
      let settled = false;
      const finish = () => {
        if (settled)
          return;
        settled = true;
        session.cleanup();
        resolve(results);
      };
      const onData = (chunk) => {
        buffer += chunk.toString();
        let updated = false;
        let m;
        OSC_SPECIAL_RESPONSE.lastIndex = 0;
        while (m = OSC_SPECIAL_RESPONSE.exec(buffer)) {
          const idx = parseInt(m[1], 10);
          if (idx in results) {
            results[idx] = toHex(m[2], m[3], m[4], m[5]);
            updated = true;
          }
        }
        if (buffer.length > 8192)
          buffer = buffer.slice(-4096);
        if (queries.every((idx) => results[idx] !== null)) {
          finish();
          return;
        }
        if (!updated)
          return;
        idleTimer = session.resetTimer(idleTimer, finish, idleTimeoutMs);
      };
      session.setTimer(finish, timeoutMs);
      session.subscribeInput(onData);
      this.writeOsc(queries.map((idx) => `\x1B]${idx};?\x07`).join(""));
      idleTimer = session.resetTimer(idleTimer, finish, idleTimeoutMs);
    });
  }
  async detect(options) {
    const { timeout = 5000, size = 16 } = options || {};
    const supported = await this.detectOSCSupport();
    if (!supported) {
      return {
        palette: Array(size).fill(null),
        defaultForeground: null,
        defaultBackground: null,
        cursorColor: null,
        mouseForeground: null,
        mouseBackground: null,
        tekForeground: null,
        tekBackground: null,
        highlightBackground: null,
        highlightForeground: null
      };
    }
    const indicesToQuery = [...Array(size).keys()];
    const idleTimeout = env2.OTUI_PALETTE_IDLE_TIMEOUT_MS;
    const [paletteResults, specialColors] = await Promise.all([
      this.queryPalette(indicesToQuery, timeout, idleTimeout),
      this.querySpecialColors(timeout, idleTimeout)
    ]);
    return {
      palette: [...Array(size).keys()].map((i) => paletteResults.get(i) ?? null),
      defaultForeground: specialColors[10],
      defaultBackground: specialColors[11],
      cursorColor: specialColors[12],
      mouseForeground: specialColors[13],
      mouseBackground: specialColors[14],
      tekForeground: specialColors[15],
      tekBackground: specialColors[16],
      highlightBackground: specialColors[17],
      highlightForeground: specialColors[19]
    };
  }
}
function createTerminalPalette2(options) {
  return new TerminalPalette2(options);
}
var DEFAULT_FOREGROUND_FALLBACK = RGBA2.fromInts(...DEFAULT_FOREGROUND_RGB2);
var DEFAULT_BACKGROUND_FALLBACK = RGBA2.fromInts(...DEFAULT_BACKGROUND_RGB2);
var fallbackAnsi256Palette = null;
function getFallbackAnsi256Palette() {
  if (!fallbackAnsi256Palette) {
    fallbackAnsi256Palette = Array.from({ length: 256 }, (_, index) => {
      const [r, g, b] = ansi256IndexToRgb2(index);
      return RGBA2.fromInts(r, g, b);
    });
  }
  return fallbackAnsi256Palette;
}
function normalizeTerminalPalette2(colors) {
  const fallbackPalette = getFallbackAnsi256Palette();
  return {
    palette: Array.from({ length: 256 }, (_, index) => {
      const detected = colors?.palette[index];
      return detected ? RGBA2.fromHex(detected) : RGBA2.clone(fallbackPalette[index]);
    }),
    defaultForeground: colors?.defaultForeground ? RGBA2.fromHex(colors.defaultForeground) : RGBA2.clone(DEFAULT_FOREGROUND_FALLBACK),
    defaultBackground: colors?.defaultBackground ? RGBA2.fromHex(colors.defaultBackground) : RGBA2.clone(DEFAULT_BACKGROUND_FALLBACK)
  };
}
function buildTerminalPaletteSignature2(colors) {
  const normalized = normalizeTerminalPalette2(colors);
  const paletteSignature = normalized.palette.map((color) => color.toInts().join(",")).join(";");
  return [
    paletteSignature,
    normalized.defaultForeground.toInts().join(","),
    normalized.defaultBackground.toInts().join(",")
  ].join("|");
}
// src/lib/paste.ts
var PASTE_TEXT_DECODER = new TextDecoder;
var ANSI_SEQUENCES = /(?:\x1b\[|\x9b)[\x30-\x3f]*[\x20-\x2f]*[\x40-\x7e]?|(?:\x1b[P\]X^_]|[\x90\x98\x9d-\x9f])[^\x07\x1b\x9c]*(?:\x07|\x1b\\|\x9c)?|\x1b[\x20-\x2f]*[\x30-\x7e]?/g;
function decodePasteBytes2(bytes) {
  return PASTE_TEXT_DECODER.decode(bytes);
}
function stripAnsiSequences2(text) {
  return text.replace(ANSI_SEQUENCES, "");
}
// src/lib/host-clipboard.internal.ts
var DEFAULT_CLIPBOARD_TIMEOUT_MS = 1000;
var DEFAULT_CLIPBOARD_MAX_BYTES = 8 * 1024 * 1024;
var DEFAULT_CLIPBOARD_MAX_IMAGE_PIXELS = 64 * 1024 * 1024;
var DEFAULT_CLIPBOARD_MAX_CONVERSION_BYTES = 512 * 1024 * 1024;
var DEFAULT_CLIPBOARD_MAX_CONCURRENT_OPERATIONS = 16;
var DEFAULT_CLIPBOARD_MAX_PROVIDER_TRANSFERS = 16;
var MAX_U32 = 4294967295;
var MIME_ESSENCE_PATTERN = /^[a-z0-9!#$%&'*+.^_`|~-]+\/[a-z0-9!#$%&'*+.^_`|~-]+$/i;
var HOST_CLIPBOARD_MIME_PREFERENCE_COUNT_MAX = 64;
var HOST_CLIPBOARD_MIME_ESSENCE_BYTES_MAX = 255;
var validateU32 = (name, value) => {
  if (!Number.isInteger(value) || value < 0 || value > MAX_U32) {
    throw new RangeError(`${name} must be an integer from 0 through ${MAX_U32}`);
  }
  return value;
};
var validatePositiveU32 = (name, value) => {
  const validated = validateU32(name, value);
  if (validated === 0)
    throw new RangeError(`${name} must be greater than zero`);
  return validated;
};
var normalizeOptions = (options) => {
  const waylandSeat = options.waylandSeat;
  if (waylandSeat !== undefined && (typeof waylandSeat !== "string" || waylandSeat.length === 0 || waylandSeat.includes("\x00"))) {
    throw new TypeError("waylandSeat must be a non-empty string without NUL characters");
  }
  return {
    timeoutMs: validateU32("timeoutMs", options.timeoutMs ?? DEFAULT_CLIPBOARD_TIMEOUT_MS),
    maxReadBytes: validateU32("maxReadBytes", options.maxReadBytes ?? DEFAULT_CLIPBOARD_MAX_BYTES),
    maxWriteBytes: validateU32("maxWriteBytes", options.maxWriteBytes ?? DEFAULT_CLIPBOARD_MAX_BYTES),
    maxImagePixels: validateU32("maxImagePixels", options.maxImagePixels ?? DEFAULT_CLIPBOARD_MAX_IMAGE_PIXELS),
    maxConversionBytes: validateU32("maxConversionBytes", options.maxConversionBytes ?? DEFAULT_CLIPBOARD_MAX_CONVERSION_BYTES),
    maxConcurrentOperations: validatePositiveU32("maxConcurrentOperations", options.maxConcurrentOperations ?? DEFAULT_CLIPBOARD_MAX_CONCURRENT_OPERATIONS),
    maxProviderTransfers: validatePositiveU32("maxProviderTransfers", options.maxProviderTransfers ?? DEFAULT_CLIPBOARD_MAX_PROVIDER_TRANSFERS),
    waylandSeat
  };
};
var normalizePreferredTypes = (preferredTypes) => {
  if (!Array.isArray(preferredTypes) || preferredTypes.length === 0) {
    throw new TypeError("preferredTypes must contain at least one MIME essence type");
  }
  if (preferredTypes.length > HOST_CLIPBOARD_MIME_PREFERENCE_COUNT_MAX) {
    throw new RangeError(`preferredTypes must contain at most ${HOST_CLIPBOARD_MIME_PREFERENCE_COUNT_MAX} MIME essence types`);
  }
  const normalized = preferredTypes.map((mimeType) => {
    if (typeof mimeType !== "string") {
      throw new TypeError("preferredTypes must contain valid MIME essence types without parameters");
    }
    if (mimeType.length > HOST_CLIPBOARD_MIME_ESSENCE_BYTES_MAX) {
      throw new RangeError(`preferredTypes MIME essences must be at most ${HOST_CLIPBOARD_MIME_ESSENCE_BYTES_MAX} ASCII bytes`);
    }
    if (!MIME_ESSENCE_PATTERN.test(mimeType)) {
      throw new TypeError("preferredTypes must contain valid MIME essence types without parameters");
    }
    return mimeType.toLowerCase();
  });
  return normalized;
};
var normalizeSelection = (selection) => {
  const normalized = selection ?? "clipboard";
  if (normalized !== "clipboard" && normalized !== "primary") {
    throw new TypeError("selection must be clipboard or primary");
  }
  return normalized;
};
var validateClipboardText = (text, maxWriteBytes) => {
  if (typeof text !== "string" || text.length === 0)
    throw new TypeError("writeText requires non-empty text");
  if (text.includes("\x00"))
    throw new TypeError("writeText does not support NUL characters");
  const byteLimit = Math.min(maxWriteBytes, MAX_U32);
  let byteLength = 0;
  for (const character of text) {
    const codePoint = character.codePointAt(0);
    if (codePoint >= 55296 && codePoint <= 57343) {
      throw new TypeError("writeText does not support unpaired UTF-16 surrogates");
    }
    if (codePoint <= 127) {
      byteLength += 1;
    } else if (codePoint <= 2047) {
      byteLength += 2;
    } else if (codePoint <= 65535) {
      byteLength += 3;
    } else {
      byteLength += 4;
    }
    if (byteLength > byteLimit) {
      throw new RangeError(`writeText exceeds the configured ${maxWriteBytes} byte limit`);
    }
  }
};
var createActiveOperation = (callerSignal) => {
  const controller = new AbortController;
  let settle = () => {};
  const settled = new Promise((resolve) => {
    settle = resolve;
  });
  if (callerSignal) {
    callerSignal.addEventListener("abort", () => controller.abort(callerSignal.reason), {
      once: true,
      signal: controller.signal
    });
  }
  return { controller, settled, settle };
};
var runTrackedOperation = (active, callerSignal, operation) => {
  const state = createActiveOperation(callerSignal);
  active.add(state);
  let result;
  try {
    result = operation(state.controller.signal);
  } catch (error) {
    result = Promise.reject(error);
  }
  return result.finally(() => {
    active.delete(state);
    state.controller.abort();
    state.settle();
  });
};
var createHostClipboardWithBackend = (options, createBackend) => {
  const config = normalizeOptions(options);
  const backend = createBackend(config);
  const active = new Set;
  let disposed = false;
  let disposePromise;
  const assertUsable = () => {
    if (disposed)
      throw new Error("Host clipboard service is disposed");
  };
  return {
    maxWriteBytes: config.maxWriteBytes,
    read(readOptions) {
      try {
        assertUsable();
        const preferredTypes = normalizePreferredTypes(readOptions.preferredTypes);
        const selection = normalizeSelection(readOptions.selection);
        if (readOptions.signal?.aborted)
          return Promise.resolve({ status: "cancelled" });
        if (config.timeoutMs === 0)
          return Promise.resolve({ status: "timed-out" });
        return runTrackedOperation(active, readOptions.signal, async (signal) => {
          const result = await backend.read({
            preferredTypes,
            selection,
            maxBytes: config.maxReadBytes,
            timeoutMs: config.timeoutMs,
            signal
          });
          if (result.status !== "read")
            return result;
          if (result.representation.bytes.byteLength > config.maxReadBytes)
            return { status: "limit-exceeded" };
          return { status: "read", representation: result.representation };
        });
      } catch (error) {
        return Promise.reject(error);
      }
    },
    writeText(text, operationOptions = {}) {
      try {
        assertUsable();
        validateClipboardText(text, config.maxWriteBytes);
        const selection = normalizeSelection(operationOptions.selection);
        if (operationOptions.signal?.aborted)
          return Promise.resolve({ status: "cancelled" });
        if (config.timeoutMs === 0)
          return Promise.resolve({ status: "timed-out" });
        return runTrackedOperation(active, operationOptions.signal, (signal) => backend.writeText(text, { selection, timeoutMs: config.timeoutMs, signal }));
      } catch (error) {
        return Promise.reject(error);
      }
    },
    clear(operationOptions = {}) {
      try {
        assertUsable();
        const selection = normalizeSelection(operationOptions.selection);
        if (operationOptions.signal?.aborted)
          return Promise.resolve({ status: "cancelled" });
        if (config.timeoutMs === 0)
          return Promise.resolve({ status: "timed-out" });
        return runTrackedOperation(active, operationOptions.signal, (signal) => backend.clear({ selection, timeoutMs: config.timeoutMs, signal }));
      } catch (error) {
        return Promise.reject(error);
      }
    },
    dispose() {
      if (disposePromise)
        return disposePromise;
      disposed = true;
      for (const operation of active)
        operation.controller.abort();
      disposePromise = (async () => {
        await Promise.all([...active].map((operation) => operation.settled));
        await backend.dispose();
      })();
      return disposePromise;
    }
  };
};

// src/lib/host-clipboard.native.ts
var SHUTDOWN_POLL_INTERVAL_MS = 1;
var OPERATION_POLL_INTERVAL_MS = 1;
var PROVIDER_POLL_INTERVAL_MS = 8;
var MAX_WORK_UNITS_PER_DRAIN = 64;
var selectionValue = (selection) => selection === "clipboard" ? 0 : 1;
var encodeReadRequest = (preferredTypes) => {
  const encoder = new TextEncoder;
  const encoded = preferredTypes.map((mimeType) => encoder.encode(mimeType));
  const size = encoded.reduce((total, mimeType) => total + 4 + mimeType.byteLength, 4);
  const request = new Uint8Array(size);
  const view = new DataView(request.buffer);
  view.setUint32(0, encoded.length, true);
  let offset = 4;
  for (const mimeType of encoded) {
    view.setUint32(offset, mimeType.byteLength, true);
    offset += 4;
    request.set(mimeType, offset);
    offset += mimeType.byteLength;
  }
  return request;
};
var startFailure = (status) => ({
  status: "failed",
  error: new Error(`Native clipboard operation failed to start (${NativeClipboardStartStatus2[status]})`)
});

class NativeClipboardBackend {
  maxImagePixels;
  maxConversionBytes;
  library;
  service;
  pending = new Map;
  pollTimer;
  pollTimerForOperation = false;
  providerActive = false;
  disposed = false;
  disposePromise;
  constructor(maxImagePixels, maxConversionBytes, maxConcurrentOperations, maxProviderTransfers, waylandSeat) {
    this.maxImagePixels = maxImagePixels;
    this.maxConversionBytes = maxConversionBytes;
    this.library = resolveRenderLib2();
    const service = this.library.clipboardServiceCreate(maxConcurrentOperations, maxProviderTransfers, waylandSeat);
    if (!service)
      throw new Error("Failed to create native clipboard service");
    this.service = service;
  }
  read(options) {
    const request = encodeReadRequest(options.preferredTypes);
    const started = this.library.clipboardReadOperationStart(this.service, request, selectionValue(options.selection), options.maxBytes, this.maxImagePixels, this.maxConversionBytes, options.timeoutMs);
    return this.track(started, options.signal, "read");
  }
  writeText(text, options) {
    const started = this.library.clipboardWriteOperationStart(this.service, new TextEncoder().encode(text), selectionValue(options.selection), options.timeoutMs);
    return this.track(started, options.signal, "write");
  }
  clear(options) {
    const started = this.library.clipboardClearOperationStart(this.service, selectionValue(options.selection), options.timeoutMs);
    return this.track(started, options.signal, "clear");
  }
  dispose() {
    if (this.disposePromise)
      return this.disposePromise;
    this.disposed = true;
    this.disposePromise = this.shutdown();
    return this.disposePromise;
  }
  track(started, signal, kind) {
    if (this.disposed)
      return Promise.reject(new Error("Native clipboard backend is disposed"));
    if (started.status !== NativeClipboardStartStatus2.Ok || !started.operation) {
      return Promise.resolve(startFailure(started.status));
    }
    return new Promise((resolve, reject) => {
      const operation = { handle: started.operation, kind, signal, resolve, reject };
      this.pending.set(operation.handle, operation);
      signal.addEventListener("abort", () => this.requestCancel(operation), { once: true });
      this.ensureScheduled();
      this.drain();
    });
  }
  requestCancel(operation) {
    if (!this.pending.has(operation.handle))
      return;
    try {
      this.library.clipboardOperationCancel(operation.handle);
    } catch (error) {
      operation.cleanupError ??= error;
    }
    this.ensureScheduled();
  }
  ensureScheduled() {
    const hasPendingOperation = this.pending.size > 0;
    if (!hasPendingOperation && !this.providerActive) {
      this.clearPollTimer();
      return;
    }
    if (this.pollTimer !== undefined) {
      if (hasPendingOperation && !this.pollTimerForOperation)
        this.clearPollTimer();
      else {
        if (hasPendingOperation)
          this.pollTimer.ref();
        else
          this.pollTimer.unref();
        return;
      }
    }
    this.pollTimerForOperation = hasPendingOperation;
    this.pollTimer = setTimeout(() => {
      this.pollTimer = undefined;
      this.pollTimerForOperation = false;
      this.drain();
    }, hasPendingOperation ? OPERATION_POLL_INTERVAL_MS : PROVIDER_POLL_INTERVAL_MS);
    if (!hasPendingOperation)
      this.pollTimer.unref();
  }
  clearPollTimer() {
    if (this.pollTimer === undefined)
      return;
    clearTimeout(this.pollTimer);
    this.pollTimer = undefined;
    this.pollTimerForOperation = false;
  }
  drain() {
    this.providerActive = false;
    try {
      this.providerActive = this.library.clipboardServiceDrain(this.service) === 1;
    } catch (error) {
      for (const operation of this.pending.values()) {
        operation.cleanupError ??= error;
        try {
          this.library.clipboardOperationCancel(operation.handle);
        } catch {}
      }
    }
    let workUnits = 0;
    while (workUnits < MAX_WORK_UNITS_PER_DRAIN && this.pending.size > 0) {
      const operation = this.pending.values().next().value;
      if (!operation)
        break;
      workUnits += 1;
      try {
        if (operation.cleanupError !== undefined) {
          try {
            this.library.clipboardOperationCancel(operation.handle);
          } catch {}
          const status = this.library.clipboardOperationPoll(operation.handle);
          if (status === NativeClipboardOperationStatus2.Pending) {
            this.rotate(operation);
            continue;
          }
          this.providerActive = true;
          const destroyed = this.library.clipboardOperationDestroy(operation.handle);
          if (destroyed === NativeClipboardDestroyStatus2.NotReady) {
            this.rotate(operation);
            continue;
          }
          this.pending.delete(operation.handle);
          operation.reject(operation.cleanupError);
          continue;
        }
        if (operation.signal.aborted)
          this.library.clipboardOperationCancel(operation.handle);
        const status = this.library.clipboardOperationPoll(operation.handle);
        if (status === NativeClipboardOperationStatus2.Pending) {
          this.rotate(operation);
          continue;
        }
        this.providerActive = true;
        const result = this.readResult(operation.handle, operation.kind, status);
        const destroyed = this.library.clipboardOperationDestroy(operation.handle);
        if (destroyed === NativeClipboardDestroyStatus2.NotReady) {
          this.rotate(operation);
          continue;
        }
        this.pending.delete(operation.handle);
        operation.resolve(destroyed === NativeClipboardDestroyStatus2.Destroyed ? result : { status: "failed", error: new Error("Native clipboard operation became invalid before destruction") });
      } catch (error) {
        operation.cleanupError ??= error;
        try {
          this.library.clipboardOperationCancel(operation.handle);
        } catch {}
        this.rotate(operation);
      }
    }
    this.ensureScheduled();
  }
  rotate(operation) {
    this.pending.delete(operation.handle);
    this.pending.set(operation.handle, operation);
  }
  readResult(handle, kind, status) {
    switch (status) {
      case NativeClipboardOperationStatus2.Read:
        return kind === "read" ? this.readRepresentation(handle) : this.invalidResult(kind, status);
      case NativeClipboardOperationStatus2.Empty:
        return kind === "read" ? { status: "empty" } : this.invalidResult(kind, status);
      case NativeClipboardOperationStatus2.Written:
        return kind === "write" ? { status: "written" } : this.invalidResult(kind, status);
      case NativeClipboardOperationStatus2.Cleared:
        return kind === "clear" ? { status: "cleared" } : this.invalidResult(kind, status);
      case NativeClipboardOperationStatus2.Unsupported:
        return { status: "unsupported" };
      case NativeClipboardOperationStatus2.Cancelled:
        return { status: "cancelled" };
      case NativeClipboardOperationStatus2.TimedOut:
        return { status: "timed-out" };
      case NativeClipboardOperationStatus2.LimitExceeded:
        return kind === "read" ? { status: "limit-exceeded" } : this.invalidResult(kind, status);
      case NativeClipboardOperationStatus2.Failed:
        return { status: "failed", error: this.readError(handle) };
      default:
        return { status: "failed", error: new Error("Native clipboard operation returned an invalid status") };
    }
  }
  invalidResult(kind, status) {
    return {
      status: "failed",
      error: new Error(`Native clipboard ${kind} returned inapplicable status ${NativeClipboardOperationStatus2[status]}`)
    };
  }
  readRepresentation(handle) {
    const mimeLength = this.library.clipboardOperationResultMimeLength(handle);
    const dataLength = this.library.clipboardOperationResultDataLength(handle);
    if (mimeLength.status !== NativeClipboardCopyStatus2.Ok || dataLength.status !== NativeClipboardCopyStatus2.Ok) {
      return { status: "failed", error: new Error("Failed to read native clipboard result lengths") };
    }
    const mime = new Uint8Array(mimeLength.length);
    const bytes = new Uint8Array(dataLength.length);
    if (this.library.clipboardOperationResultMimeCopy(handle, mime) !== NativeClipboardCopyStatus2.Ok || this.library.clipboardOperationResultDataCopy(handle, bytes) !== NativeClipboardCopyStatus2.Ok) {
      return { status: "failed", error: new Error("Failed to copy native clipboard result") };
    }
    return { status: "read", representation: { mimeType: new TextDecoder().decode(mime), bytes } };
  }
  readError(handle) {
    const code = this.library.clipboardOperationResultErrorCode(handle);
    const length = this.library.clipboardOperationResultDiagnosticLength(handle);
    if (code.status !== NativeClipboardCopyStatus2.Ok || length.status !== NativeClipboardCopyStatus2.Ok) {
      return new Error("Native clipboard operation failed without a readable diagnostic");
    }
    const diagnostic = new Uint8Array(length.length);
    if (this.library.clipboardOperationResultDiagnosticCopy(handle, diagnostic) !== NativeClipboardCopyStatus2.Ok) {
      return new Error("Native clipboard operation failed without a readable diagnostic");
    }
    return Object.assign(new Error(new TextDecoder().decode(diagnostic)), { code: code.errorCode });
  }
  async shutdown() {
    this.clearPollTimer();
    let status = this.library.clipboardServiceBeginShutdown(this.service);
    while (status === NativeClipboardShutdownStatus2.Pending) {
      await new Promise((resolve) => setTimeout(resolve, SHUTDOWN_POLL_INTERVAL_MS));
      status = this.library.clipboardServicePollShutdown(this.service);
    }
    if (status !== NativeClipboardShutdownStatus2.Ready)
      throw new Error("Native clipboard service became invalid");
    if (this.library.clipboardServiceDestroy(this.service) !== NativeClipboardDestroyStatus2.Destroyed) {
      throw new Error("Failed to destroy native clipboard service");
    }
  }
}
var createNativeHostClipboardBackend = (options) => new NativeClipboardBackend(options.maxImagePixels, options.maxConversionBytes, options.maxConcurrentOperations, options.maxProviderTransfers, options.waylandSeat);

// src/lib/clipboard.ts
var NOT_ATTEMPTED_TERMINAL = {
  status: "not-attempted",
  capability: "unknown"
};
var validateSelection = (selection) => {
  const normalized = selection ?? "clipboard";
  if (normalized !== "clipboard" && normalized !== "primary") {
    throw new TypeError("selection must be clipboard or primary");
  }
  return normalized;
};
var createHostClipboard2 = (options = {}) => createHostClipboardWithBackend(options, createNativeHostClipboardBackend);
var validateDestination = (destination) => {
  if (destination !== "terminal-only" && destination !== "host-only" && destination !== "best-available" && destination !== "all-available") {
    throw new TypeError("destination is not a supported clipboard policy");
  }
};
var createClipboard2 = ({ host, terminal }) => {
  const active = new Set;
  let disposed = false;
  let disposePromise;
  const assertUsable = () => {
    if (disposed)
      throw new Error("Clipboard service is disposed");
  };
  const canUseRemoteHost = (options) => !terminal.remote || options.allowRemoteHost === true;
  const composeMutation = async (options, signal, hostOperation, terminalOperation) => {
    if (options.destination === "terminal-only") {
      return { host: { status: "not-attempted" }, terminal: terminalOperation() };
    }
    if (options.destination === "host-only") {
      const hostResult = canUseRemoteHost(options) ? await hostOperation() : { status: "not-attempted" };
      return { host: hostResult, terminal: NOT_ATTEMPTED_TERMINAL };
    }
    if (options.destination === "best-available") {
      if (terminal.remote) {
        return { host: { status: "not-attempted" }, terminal: terminalOperation() };
      }
      const hostResult = await hostOperation();
      const terminalResult = !signal.aborted && (hostResult.status === "unsupported" || hostResult.status === "failed") ? terminalOperation() : NOT_ATTEMPTED_TERMINAL;
      return { host: hostResult, terminal: terminalResult };
    }
    const hostPromise = canUseRemoteHost(options) ? hostOperation() : Promise.resolve({ status: "not-attempted" });
    const terminalResult = terminalOperation();
    return { host: await hostPromise, terminal: terminalResult };
  };
  return {
    read(options) {
      try {
        assertUsable();
        return host.read(options);
      } catch (error) {
        return Promise.reject(error);
      }
    },
    writeText(text, options) {
      try {
        assertUsable();
        validateDestination(options.destination);
        validateClipboardText(text, host.maxWriteBytes);
        const selection = validateSelection(options.selection);
        if (options.signal?.aborted) {
          return Promise.resolve({ host: { status: "not-attempted" }, terminal: NOT_ATTEMPTED_TERMINAL });
        }
        return runTrackedOperation(active, options.signal, (signal) => {
          const operationOptions = { selection, signal };
          return composeMutation(options, signal, () => host.writeText(text, operationOptions), () => terminal.writeText(text, selection));
        });
      } catch (error) {
        return Promise.reject(error);
      }
    },
    clear(options) {
      try {
        assertUsable();
        validateDestination(options.destination);
        const selection = validateSelection(options.selection);
        if (options.signal?.aborted) {
          return Promise.resolve({ host: { status: "not-attempted" }, terminal: NOT_ATTEMPTED_TERMINAL });
        }
        return runTrackedOperation(active, options.signal, (signal) => {
          const operationOptions = { selection, signal };
          return composeMutation(options, signal, () => host.clear(operationOptions), () => terminal.clear(selection));
        });
      } catch (error) {
        return Promise.reject(error);
      }
    },
    dispose() {
      if (disposePromise)
        return disposePromise;
      disposed = true;
      for (const operation of active)
        operation.controller.abort();
      disposePromise = (async () => {
        await Promise.all([...active].map((operation) => operation.settled));
        await host.dispose();
      })();
      return disposePromise;
    }
  };
};
var ClipboardTarget2;
((ClipboardTarget) => {
  ClipboardTarget[ClipboardTarget["Clipboard"] = 0] = "Clipboard";
  ClipboardTarget[ClipboardTarget["Primary"] = 1] = "Primary";
  ClipboardTarget[ClipboardTarget["Select"] = 2] = "Select";
  ClipboardTarget[ClipboardTarget["Secondary"] = 3] = "Secondary";
})(ClipboardTarget2 ||= {});
var createRendererClipboardAdapter2 = (renderer) => {
  const targetFor = (selection) => selection === "primary" ? 1 /* Primary */ : 0 /* Clipboard */;
  const capability = () => renderer.capabilities?.osc52_support ?? "unknown";
  return {
    get remote() {
      return renderer.capabilities?.remote ?? true;
    },
    writeText(text, selection) {
      const currentCapability = capability();
      if (currentCapability === "unsupported")
        return { status: "not-attempted", capability: currentCapability };
      return {
        status: renderer.copyToClipboardOSC52(text, targetFor(selection)) ? "attempted" : "local-failure",
        capability: currentCapability
      };
    },
    clear(selection) {
      const currentCapability = capability();
      if (currentCapability === "unsupported")
        return { status: "not-attempted", capability: currentCapability };
      return {
        status: renderer.clearClipboardOSC52(targetFor(selection)) ? "attempted" : "local-failure",
        capability: currentCapability
      };
    }
  };
};
// src/lib/detect-links.ts
var URL_SCOPES = ["markup.link.url", "string.special.url"];
var HTTP_URL_PREFIX = /https?:\/\//i;
var BARE_URL = /https?:\/\/[^\s<>"`]+/gi;
function normalizeMarkdownLinkTarget(destination) {
  return destination.replace(/\\([!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~])/g, "$1");
}
function detectLinks2(chunks, context) {
  const content = context.content;
  const highlights = context.highlights;
  const hasBareUrl = HTTP_URL_PREFIX.test(content);
  if (!hasBareUrl && !highlights.some(([, , group]) => URL_SCOPES.includes(group)))
    return chunks;
  const ranges = [];
  const rawRanges = [];
  const labels = new Map;
  const concealedDelimiters = new Map;
  for (let i = 0;i < highlights.length; i++) {
    const [start, end, group, meta] = highlights[i];
    if (group === "conceal" && meta?.conceal === "" && /^[*_~]+$/.test(content.slice(start, end))) {
      concealedDelimiters.set(end, start);
    }
    if (group === "markup.raw" || group.startsWith("markup.raw.")) {
      rawRanges.push({ start, end });
    }
    if (group === "markup.link.label") {
      const existing = labels.get(end);
      if (!existing || start < existing.start)
        labels.set(end, { start, end });
    }
    if (!URL_SCOPES.includes(group))
      continue;
    const url = content.slice(start, end);
    if (!url)
      continue;
    ranges.push({ start, end, url });
  }
  const highlightedCount = ranges.length;
  for (let index = 0;index < highlightedCount; index++) {
    const range = ranges[index];
    let labelEnd = range.start;
    if (content[labelEnd - 1] === "<")
      labelEnd--;
    while (labelEnd > 0 && /\s/.test(content[labelEnd - 1]))
      labelEnd--;
    if (content[labelEnd - 1] !== "(" || content[labelEnd - 2] !== "]")
      continue;
    const label = labels.get(labelEnd - 2);
    if (!label)
      continue;
    range.url = normalizeMarkdownLinkTarget(range.url);
    ranges.push({ ...label, url: range.url, label: true });
  }
  if (hasBareUrl) {
    rawRanges.sort((a, b) => a.start - b.start || b.end - a.end);
    ranges.sort((a, b) => a.start - b.start || b.end - a.end);
    let rawIndex = 0;
    let highlightedIndex = 0;
    for (const match of content.matchAll(BARE_URL)) {
      const start = match.index;
      let url = match[0];
      let openParens = 0;
      let closeParens = 0;
      for (const character of url) {
        if (character === "(")
          openParens++;
        if (character === ")")
          closeParens++;
      }
      while (url.length > 0) {
        const delimiterStart = concealedDelimiters.get(start + url.length);
        if (delimiterStart !== undefined && delimiterStart >= start) {
          url = url.slice(0, delimiterStart - start);
          continue;
        }
        const last = url[url.length - 1];
        if (last === ")" && closeParens > openParens) {
          closeParens--;
        } else if (!".,!?;:]}'".includes(last)) {
          break;
        }
        url = url.slice(0, -1);
      }
      const end = start + url.length;
      if (!url)
        continue;
      while (rawIndex < rawRanges.length && rawRanges[rawIndex].end <= start)
        rawIndex++;
      if (rawIndex < rawRanges.length && rawRanges[rawIndex].start < end)
        continue;
      while (highlightedIndex < ranges.length && ranges[highlightedIndex].end <= start)
        highlightedIndex++;
      if (highlightedIndex < ranges.length && ranges[highlightedIndex].start < end)
        continue;
      ranges.push({ start, end, url });
    }
  }
  if (ranges.length === 0)
    return chunks;
  ranges.sort((a, b) => a.start - b.start || b.end - a.end || Number(b.label ?? false) - Number(a.label ?? false));
  const linkedChunks = [];
  let contentPos = 0;
  let rangeIndex = 0;
  for (let index = 0;index < chunks.length; index++) {
    const chunk = chunks[index];
    if (!chunk.text || chunk.link) {
      linkedChunks.push(chunk);
      continue;
    }
    const providedRange = context.sourceRanges?.[index];
    const start = providedRange?.start ?? content.indexOf(chunk.text, contentPos);
    if (start < 0) {
      linkedChunks.push(chunk);
      continue;
    }
    const end = providedRange?.end ?? start + chunk.text.length;
    contentPos = end;
    while (rangeIndex < ranges.length && ranges[rangeIndex].end <= start)
      rangeIndex++;
    if (content.slice(start, end) !== chunk.text) {
      const range = ranges[rangeIndex];
      if (range?.label && range.start < end)
        chunk.link = { url: range.url };
      linkedChunks.push(chunk);
      continue;
    }
    let position = start;
    for (;rangeIndex < ranges.length; rangeIndex++) {
      const range = ranges[rangeIndex];
      if (range.end <= position)
        continue;
      if (range.start >= end)
        break;
      const linkStart = Math.max(position, range.start);
      const linkEnd = Math.min(end, range.end);
      if (linkStart > position) {
        linkedChunks.push({ ...chunk, text: chunk.text.slice(position - start, linkStart - start) });
      }
      if (linkStart === start && linkEnd === end) {
        chunk.link = { url: range.url };
        linkedChunks.push(chunk);
      } else {
        linkedChunks.push({
          ...chunk,
          text: chunk.text.slice(linkStart - start, linkEnd - start),
          link: { url: range.url }
        });
      }
      position = linkEnd;
      if (position === end)
        break;
    }
    if (position === start) {
      linkedChunks.push(chunk);
    } else if (position < end) {
      linkedChunks.push({ ...chunk, text: chunk.text.slice(position - start) });
    }
  }
  return linkedChunks;
}
// src/lib/buffer-access.ts
function withBufferAccess(lib, context, lease, callback) {
  try {
    return withLazyBufferAccess(lease, (getCells) => callback(getCells()), () => lib.contextValidateBufferLease(context, lease.handle));
  } finally {
    lib.contextReleaseBufferLease(context, lease.handle);
  }
}
function withLazyBufferAccess(snapshot, callback, validate) {
  let active = true;
  let cells;
  const getCells = () => {
    if (!active)
      throw new Error("Buffer access scope has ended");
    if (cells)
      return cells;
    const value = typeof snapshot === "function" ? snapshot() : snapshot;
    let char;
    let fg;
    let bg;
    let attributes;
    const guard = () => {
      if (!active)
        throw new Error("Buffer access scope has ended");
    };
    cells = {
      width: value.width,
      height: value.height,
      generation: value.generation,
      get char() {
        guard();
        return char ??= new Uint32Array(toArrayBuffer(value.char, 0, value.width * value.height * 4));
      },
      get fg() {
        guard();
        return fg ??= new Uint16Array(toArrayBuffer(value.fg, 0, value.width * value.height * 8));
      },
      get bg() {
        guard();
        return bg ??= new Uint16Array(toArrayBuffer(value.bg, 0, value.width * value.height * 8));
      },
      get attributes() {
        guard();
        return attributes ??= new Uint32Array(toArrayBuffer(value.attributes, 0, value.width * value.height * 4));
      }
    };
    return cells;
  };
  try {
    const result = callback(getCells);
    if (result !== null && (typeof result === "object" || typeof result === "function") && "then" in result && typeof result.then === "function") {
      Promise.resolve(result).catch(() => {});
      throw new TypeError("Buffer access callbacks must be synchronous");
    }
    validate();
    return result;
  } finally {
    active = false;
  }
}

// src/session-buffer.ts
function acquireSessionBufferLease2(lib, context, session, which, frame = null) {
  return frame ? lib.sceneFrameAcquireBufferLease(context, session, frame, which) : lib.sessionAcquireBufferLease(context, session, which);
}

// src/buffer.ts
function requireInteger(value, name, min, max) {
  if (!Number.isSafeInteger(value) || value < min || value > max) {
    throw new RangeError(`${name} must be an integer from ${min} to ${max}`);
  }
}
function packDrawOptions(border, shouldFill, titleAlignment, bottomTitleAlignment) {
  let packed = 0;
  if (border === true) {
    packed |= 15;
  } else if (Array.isArray(border)) {
    if (border.includes("top"))
      packed |= 8;
    if (border.includes("right"))
      packed |= 4;
    if (border.includes("bottom"))
      packed |= 2;
    if (border.includes("left"))
      packed |= 1;
  }
  if (shouldFill) {
    packed |= 1 << 4;
  }
  const alignmentMap = {
    left: 0,
    center: 1,
    right: 2
  };
  const alignment = alignmentMap[titleAlignment];
  const bottomAlignment = alignmentMap[bottomTitleAlignment];
  packed |= alignment << 5;
  packed |= bottomAlignment << 7;
  return packed;
}
var recordedFrameAccess = "Paint hooks record drawing and cannot read the frame. Draw into an owned buffer and compose it instead.";

class ResourceContext2 {
  renderLib = resolveRenderLib2();
  context;
  _disposed = false;
  constructor(options) {
    this.context = this.renderLib.createContext(options);
  }
  get disposed() {
    return this._disposed;
  }
  get resourceContext() {
    return this;
  }
  assertAlive() {
    if (this._disposed)
      throw new Error("Resource Context is destroyed");
  }
  destroy() {
    if (this._disposed)
      return;
    this.renderLib.getYogaHost().runMutation(() => {
      this.renderLib.destroyContext(this.context);
      this._disposed = true;
    });
  }
}
var contextUnicode = new WeakMap;
var contextUnicodeChars = new WeakMap;
var nextUnicodeChar = 4294967296;

class OptimizedBuffer2 {
  static fbIdCounter = 0;
  id;
  lib;
  source;
  _width;
  _height;
  _widthMethod;
  respectAlpha = false;
  _destroyed = false;
  _nativePaintAccess = null;
  _bufferTarget;
  guard() {
    if (this._destroyed)
      throw new Error(`Buffer ${this.id} is destroyed`);
    if ("buffer" in this.source)
      this.source.owner.assertAlive();
  }
  get recorder() {
    return "recorder" in this.source ? this.source.recorder : null;
  }
  checkedTarget() {
    const source = this.source;
    if ("buffer" in source) {
      return this._bufferTarget ??= Object.freeze({ context: source.context, target: source.buffer, frame: null });
    }
    if ("recorder" in source)
      throw new Error(recordedFrameAccess);
    const frame = source.getFrame?.();
    if (source.which !== "next" || !frame)
      throw new Error("Session scene drawing requires an active next frame");
    return { context: source.context, target: source.session, frame };
  }
  _getSceneHandle(scene) {
    this.guard();
    const source = this.source;
    if (!("buffer" in source) || source.owner !== scene.resourceContext || this.lib !== scene.resourceContext.renderLib) {
      throw new Error("Scene binding requires a buffer owned by the same Context");
    }
    return source.buffer;
  }
  _getSceneDrawTarget(scene) {
    this.guard();
    scene.assertAlive();
    const target = this.checkedTarget();
    if (target.context !== scene.driver.context || this.lib !== scene.driver.renderLib) {
      throw new Error("Scene drawing requires a buffer owned by the same Context");
    }
    return target;
  }
  drawChecked(options) {
    const recorder = this.recorder;
    if (recorder)
      return recorder.draw(options);
    this.lib.contextDrawBuffer(this.checkedTarget(), options);
  }
  _drawSceneText(scene, node, x, y) {
    this.guard();
    const recorder = this.recorder;
    if (recorder)
      return recorder.view("scene", node, x, y);
    this.lib.contextDrawSceneText(this._getSceneDrawTarget(scene), node, x, y);
  }
  get buffers() {
    this.guard();
    if (this._nativePaintAccess !== null)
      return this._nativePaintAccess();
    if (this.recorder)
      throw new Error(recordedFrameAccess);
    throw new Error("Use withBuffers() for Context-owned framebuffer access");
  }
  withBuffers(callback) {
    this.guard();
    const lib = this.lib;
    const source = this.source;
    if ("recorder" in source)
      throw new Error(recordedFrameAccess);
    const lease = "session" in source ? acquireSessionBufferLease2(lib, source.context, source.session, source.which, source.getFrame?.()) : lib.contextAcquireBufferLease(source.context, source.buffer);
    return withBufferAccess(lib, source.context, lease, callback);
  }
  _withNativePaint(callback) {
    const source = this.source;
    if ("recorder" in source)
      throw new Error(recordedFrameAccess);
    const lib = this.lib;
    let lease;
    const previous = this._nativePaintAccess;
    try {
      withLazyBufferAccess(() => lease ??= ("session" in source) ? acquireSessionBufferLease2(lib, source.context, source.session, source.which, source.getFrame?.()) : lib.contextAcquireBufferLease(source.context, source.buffer), (getCells) => {
        this._nativePaintAccess = getCells;
        callback();
      }, () => {
        if (lease)
          lib.contextValidateBufferLease(source.context, lease.handle);
      });
    } finally {
      this._nativePaintAccess = previous;
      if (lease)
        lib.contextReleaseBufferLease(source.context, lease.handle);
    }
  }
  constructor(lib, source, width, height, options) {
    this.id = options.id || `fb_${OptimizedBuffer2.fbIdCounter++}`;
    this.lib = lib;
    this.respectAlpha = options.respectAlpha || false;
    this._width = width;
    this._height = height;
    this._widthMethod = options.widthMethod || "unicode";
    this.source = source;
  }
  static fromRecorder(lib, context, session, recorder) {
    const { width, height } = lib.sessionGetRendererState(context, session);
    return new OptimizedBuffer2(lib, { context, session, recorder }, width, height, { id: "scene-recording" });
  }
  static fromSession(lib, context, session, which, getFrame) {
    const { width, height } = lib.sessionGetRendererState(context, session);
    return new OptimizedBuffer2(lib, { context, session, which, getFrame }, width, height, { id: `scene-${which}` });
  }
  static create(width, height, widthMethod, options) {
    const owner = options?.owner?.resourceContext;
    if (!owner)
      throw new Error("OptimizedBuffer requires an explicit resource owner: pass { owner: renderer.nativeScene }, or a ResourceContext when there is no renderer");
    owner.assertAlive();
    const { renderLib: lib, context } = owner;
    const buffer = lib.createContextBuffer(context, {
      width,
      height,
      widthMethod,
      respectAlpha: options.respectAlpha
    });
    try {
      return new OptimizedBuffer2(lib, { context, buffer, owner }, width, height, { ...options, widthMethod });
    } catch (error) {
      try {
        lib.destroyContextBuffer(context, buffer);
      } catch {}
      throw error;
    }
  }
  get widthMethod() {
    if ("session" in this.source) {
      this.guard();
      this._widthMethod = this.lib.sessionGetCapabilities(this.source.context, this.source.session).unicode;
    }
    return this._widthMethod;
  }
  get width() {
    this.guard();
    if ("session" in this.source)
      return this.lib.sessionGetRendererState(this.source.context, this.source.session).width;
    return this._width;
  }
  get height() {
    this.guard();
    if ("session" in this.source)
      return this.lib.sessionGetRendererState(this.source.context, this.source.session).height;
    return this._height;
  }
  setRespectAlpha(respectAlpha) {
    this.guard();
    this.drawChecked({ operation: "respectAlpha", enabled: respectAlpha });
    this.respectAlpha = respectAlpha;
  }
  getRealCharBytes(addLineBreaks = false) {
    return this.withResolvedChars({ addLineBreaks }, (bytes) => bytes);
  }
  withResolvedChars({ addLineBreaks, cellLengths }, callback) {
    this.guard();
    const lib = this.lib;
    const source = this.source;
    if ("recorder" in source)
      throw new Error(recordedFrameAccess);
    const lease = "session" in source ? acquireSessionBufferLease2(lib, source.context, source.session, source.which, source.getFrame?.()) : lib.contextAcquireBufferLease(source.context, source.buffer);
    return withBufferAccess(lib, source.context, lease, (cells) => {
      const size = lib.contextBufferLeaseGetRealCharSize(source.context, lease.handle, addLineBreaks);
      const output = new Uint8Array(size);
      const lengths = cellLengths ? new Uint8Array(cells.width * cells.height) : undefined;
      const written = lib.contextBufferLeaseWriteResolvedChars(source.context, lease.handle, output, addLineBreaks, lengths);
      return callback(output.subarray(0, written), cells, lengths);
    });
  }
  getSpanLines() {
    return this.withResolvedChars({ addLineBreaks: false, cellLengths: true }, (bytes, cells, lengths) => {
      const { fg, bg, attributes, width, height } = cells;
      const lines = [];
      const decoder = new TextDecoder("utf-8", { ignoreBOM: true });
      let offset = 0;
      for (let y = 0;y < height; y++) {
        const spans = [];
        let currentSpan = null;
        for (let x = 0;x < width; x++) {
          const i = y * width + x;
          const cellFg = RGBA2.fromArray(fg.subarray(i * 4, i * 4 + 4));
          const cellBg = RGBA2.fromArray(bg.subarray(i * 4, i * 4 + 4));
          const cellAttrs = attributes[i] & 255;
          const end = offset + lengths[i];
          const cellChar = decoder.decode(bytes.subarray(offset, end));
          offset = end;
          if (currentSpan && currentSpan.fg.equals(cellFg) && currentSpan.bg.equals(cellBg) && currentSpan.attributes === cellAttrs) {
            currentSpan.text += cellChar;
            currentSpan.width += 1;
          } else {
            if (currentSpan) {
              spans.push(currentSpan);
            }
            currentSpan = {
              text: cellChar,
              fg: cellFg,
              bg: cellBg,
              attributes: cellAttrs,
              width: 1
            };
          }
        }
        if (currentSpan) {
          spans.push(currentSpan);
        }
        lines.push({ spans });
      }
      return lines;
    });
  }
  clear(bg = RGBA2.fromValues(0, 0, 0, 1)) {
    this.guard();
    this.drawChecked({ operation: "clear", background: bg });
  }
  setCell(x, y, char, fg, bg, attributes = 0) {
    this.guard();
    this.drawChecked({
      operation: "cell",
      x,
      y,
      char: char.codePointAt(0) ?? 32,
      foreground: fg,
      background: bg,
      attributes
    });
  }
  setCellWithAlphaBlending(x, y, char, fg, bg, attributes = 0) {
    this.guard();
    this.drawChecked({
      operation: "cellBlend",
      x,
      y,
      char: char.codePointAt(0) ?? 32,
      foreground: fg,
      background: bg,
      attributes
    });
  }
  drawText(text, x, y, fg, bg, attributes = 0, selection) {
    this.guard();
    if (!selection) {
      this.drawChecked({ operation: "text", text, x, y, foreground: fg, background: bg, attributes });
      return;
    }
    const { start, end } = selection;
    let selectionBg;
    let selectionFg;
    if (selection.bgColor) {
      selectionBg = selection.bgColor;
      selectionFg = selection.fgColor || fg;
    } else {
      const defaultBg = bg || RGBA2.fromValues(0, 0, 0, 0);
      selectionFg = defaultBg.a > 0 ? defaultBg : RGBA2.fromValues(0, 0, 0, 1);
      selectionBg = fg;
    }
    if (start > 0) {
      const beforeText = text.slice(0, start);
      this.drawText(beforeText, x, y, fg, bg, attributes);
    }
    if (end > start) {
      const selectedText = text.slice(start, end);
      this.drawText(selectedText, x + start, y, selectionFg, selectionBg, attributes);
    }
    if (end < text.length) {
      const afterText = text.slice(end);
      this.drawText(afterText, x + end, y, fg, bg, attributes);
    }
  }
  fillRect(x, y, width, height, bg) {
    this.guard();
    if (width <= 0 || height <= 0)
      return;
    this.drawChecked({ operation: "fill", x, y, width, height, background: bg });
  }
  colorMatrix(matrix, cellMask, strength = 1, target = 3 /* Both */) {
    this.guard();
    if (matrix.length !== 16)
      throw new RangeError(`colorMatrix matrix must have length 16, got ${matrix.length}`);
    const recorder = this.recorder;
    if (recorder)
      return recorder.colorMatrix(matrix, cellMask, strength, target);
    const destination = this.checkedTarget();
    this.lib.contextColorMatrixBuffer(destination, matrix, cellMask, strength, target);
  }
  colorMatrixUniform(matrix, strength = 1, target = 3 /* Both */) {
    this.guard();
    if (matrix.length !== 16)
      throw new RangeError(`colorMatrixUniform matrix must have length 16, got ${matrix.length}`);
    const recorder = this.recorder;
    if (recorder)
      return recorder.colorMatrix(matrix, null, strength, target);
    const destination = this.checkedTarget();
    this.lib.contextColorMatrixBuffer(destination, matrix, null, strength, target);
  }
  drawFrameBuffer(destX, destY, frameBuffer, sourceX, sourceY, sourceWidth, sourceHeight) {
    this.guard();
    frameBuffer.guard();
    const destination = this.source;
    const source = frameBuffer.source;
    if (!("buffer" in source) || source.context !== destination.context || frameBuffer.lib !== this.lib) {
      throw new Error("Scene composition requires a buffer owned by the same Context");
    }
    this.drawChecked({
      operation: "compose",
      source: source.buffer,
      x: destX,
      y: destY,
      sourceX,
      sourceY,
      sourceWidth,
      sourceHeight
    });
  }
  destroy() {
    if (this._destroyed)
      return;
    const source = this.source;
    if ("buffer" in source && !source.owner.disposed) {
      const release = () => {
        if (!source.owner.disposed)
          this.lib.destroyContextBuffer(source.context, source.buffer);
      };
      this.lib.releaseAfterPaint(source.context, release);
    }
    this._destroyed = true;
  }
  drawTextBuffer(textBufferView, x, y) {
    this.guard();
    const owner = textBufferView._getOwner();
    if (owner.renderLib !== this.lib || owner.context !== this.source.context) {
      throw new Error("Text drawing requires a view owned by the same Context");
    }
    const view = textBufferView._getSceneHandle(owner);
    const recorder = this.recorder;
    if (recorder)
      return recorder.view("text", view, x, y);
    this.lib.contextDrawTextBufferView(this.checkedTarget(), view, x, y);
  }
  drawEditorView(editorView, x, y) {
    this.guard();
    const owner = editorView._getOwner();
    if (owner.renderLib !== this.lib || owner.context !== this.source.context) {
      throw new Error("Editor drawing requires a view owned by the same Context");
    }
    const view = editorView._getSceneHandle(owner);
    const recorder = this.recorder;
    if (recorder)
      return recorder.view("editor", view, x, y);
    this.lib.contextDrawEditorView(this.checkedTarget(), view, x, y);
  }
  drawSuperSampleBuffer(x, y, pixelData, pixelDataLength, format, alignedBytesPerRow) {
    this.guard();
    const recorder = this.recorder;
    if (recorder)
      return recorder.supersample(pixelData, pixelDataLength, x, y, format, alignedBytesPerRow);
    const target = this.checkedTarget();
    this.lib.contextDrawSuperSampleBuffer(target, pixelData, pixelDataLength, x, y, format, alignedBytesPerRow);
  }
  drawImage(image, x, y, width, height, pixelWidth = 0, pixelHeight = 0, sourceX = 0, sourceY = 0, sourceWidth = image.width, sourceHeight = image.height, protocol = "auto") {
    this.guard();
    requireInteger(x, "x", -2147483648, 2147483647);
    requireInteger(y, "y", -2147483648, 2147483647);
    requireInteger(width, "width", 1, 2147483647);
    requireInteger(height, "height", 1, 2147483647);
    requireInteger(pixelWidth, "pixelWidth", 0, 2147483647);
    requireInteger(pixelHeight, "pixelHeight", 0, 2147483647);
    requireInteger(sourceX, "sourceX", 0, 4294967295);
    requireInteger(sourceY, "sourceY", 0, 4294967295);
    requireInteger(sourceWidth, "sourceWidth", 1, 4294967295);
    requireInteger(sourceHeight, "sourceHeight", 1, 4294967295);
    if (x + width > 2147483647 || y + height > 2147483647) {
      throw new RangeError("image destination coordinates and dimensions exceed i32 bounds");
    }
    const options = {
      x,
      y,
      width,
      height,
      pixelWidth,
      pixelHeight,
      sourceX,
      sourceY,
      sourceWidth,
      sourceHeight,
      protocol
    };
    const handle = image._getContextHandle(this.lib, this.source.context);
    const recorder = this.recorder;
    if (recorder) {
      recorder.image(handle, options);
      return true;
    }
    return this.lib.contextDrawImage(this.checkedTarget(), handle, options);
  }
  drawPackedBuffer(data, dataLen, posX, posY, terminalWidthCells, terminalHeightCells) {
    this.guard();
    if (dataLen <= 0 || terminalWidthCells <= 0 || terminalHeightCells <= 0)
      return;
    const recorder = this.recorder;
    if (recorder)
      return recorder.packed(data, dataLen, posX, posY, terminalWidthCells, terminalHeightCells);
    const target = this.checkedTarget();
    this.lib.contextDrawPackedBuffer(target, data, dataLen, posX, posY, terminalWidthCells, terminalHeightCells);
  }
  drawGrayscaleBuffer(posX, posY, intensities, srcWidth, srcHeight, fg = null, bg = null) {
    this.guard();
    const recorder = this.recorder;
    if (recorder)
      return recorder.grayscale(intensities, posX, posY, srcWidth, srcHeight, fg, bg, false);
    const target = this.checkedTarget();
    this.lib.contextDrawGrayscaleBuffer(target, intensities, posX, posY, srcWidth, srcHeight, fg, bg, false);
  }
  drawGrayscaleBufferSupersampled(posX, posY, intensities, srcWidth, srcHeight, fg = null, bg = null) {
    this.guard();
    const recorder = this.recorder;
    if (recorder)
      return recorder.grayscale(intensities, posX, posY, srcWidth, srcHeight, fg, bg, true);
    const target = this.checkedTarget();
    this.lib.contextDrawGrayscaleBuffer(target, intensities, posX, posY, srcWidth, srcHeight, fg, bg, true);
  }
  resize(width, height) {
    this.guard();
    const source = this.source;
    if (!("buffer" in source)) {
      throw new Error("Resizing a Session scene framebuffer is unsupported");
    }
    if (this._width === width && this._height === height)
      return;
    this.lib.contextResizeBuffer(source.context, source.buffer, width, height);
    this._width = width;
    this._height = height;
  }
  drawBox(options) {
    this.guard();
    if (options.width <= 0 || options.height <= 0)
      return;
    const style = parseBorderStyle2(options.borderStyle, "single");
    const borderChars = options.customBorderChars ?? BorderCharArrays2[style];
    const packedOptions = packDrawOptions(options.border, options.shouldFill ?? false, options.titleAlignment || "left", options.bottomTitleAlignment || "left");
    this.drawChecked({
      operation: "box",
      x: options.x,
      y: options.y,
      width: options.width,
      height: options.height,
      borderChars,
      packedOptions,
      foreground: options.borderColor,
      background: options.backgroundColor,
      titleColor: options.titleColor ?? options.borderColor,
      text: options.title,
      bottomTitle: options.bottomTitle
    });
  }
  pushScissorRect(x, y, width, height) {
    this.guard();
    this.stackChecked({ operation: "pushScissor", x, y, width: Math.max(0, width), height: Math.max(0, height) });
  }
  popScissorRect() {
    this.guard();
    this.stackChecked({ operation: "popScissor" });
  }
  clearScissorRects() {
    this.guard();
    this.stackChecked({ operation: "clearScissors" });
  }
  pushOpacity(opacity) {
    this.guard();
    this.stackChecked({ operation: "pushOpacity", opacity });
  }
  popOpacity() {
    this.guard();
    this.stackChecked({ operation: "popOpacity" });
  }
  getCurrentOpacity() {
    this.guard();
    return this.stackChecked({ operation: "getOpacity" });
  }
  clearOpacity() {
    this.guard();
    this.stackChecked({ operation: "clearOpacity" });
  }
  stackChecked(options) {
    const recorder = this.recorder;
    if (recorder)
      return recorder.stack(options);
    return this.lib.contextBufferStack(this.checkedTarget(), options);
  }
  encodeUnicode(text) {
    this.guard();
    const context = this.source.context;
    const handle = this.lib.createContextUnicode(context, text, this.widthMethod);
    const owner = { lib: this.lib, handle, tokens: [] };
    let chars = contextUnicodeChars.get(context);
    if (!chars)
      contextUnicodeChars.set(context, chars = new Map);
    try {
      const data = this.lib.getContextUnicode(context, handle);
      if (data.length > Number.MAX_SAFE_INTEGER - nextUnicodeChar)
        throw new RangeError("Unicode token limit reached");
      data.forEach((glyph, index) => {
        if (glyph.char <= 1114111)
          return;
        glyph.char = nextUnicodeChar++;
        owner.tokens.push(glyph.char);
        chars.set(glyph.char, { owner, index });
      });
      const encoded = { data };
      contextUnicode.set(encoded, owner);
      return encoded;
    } catch (error) {
      for (const token of owner.tokens)
        chars.delete(token);
      try {
        this.lib.destroyContextUnicode(context, handle);
      } catch {}
      throw error;
    }
  }
  freeUnicode(encoded) {
    this.guard();
    const native = contextUnicode.get(encoded);
    if (!native || native.lib !== this.lib || native.handle.context !== this.source.context) {
      throw new Error("Encoded Unicode must be live and owned by the same Context");
    }
    const context = this.source.context;
    const release = () => this.lib.destroyContextUnicode(context, native.handle);
    this.lib.releaseAfterPaint(context, release);
    const chars = contextUnicodeChars.get(this.source.context);
    for (const token of native.tokens)
      chars.delete(token);
    contextUnicode.delete(encoded);
  }
  drawGrid(options) {
    this.guard();
    const recorder = this.recorder;
    if (recorder)
      return recorder.grid(options);
    const target = this.checkedTarget();
    this.lib.contextDrawGrid(target, options);
  }
  drawChar(char, x, y, fg, bg, attributes = 0) {
    this.guard();
    if (char > 4294967295) {
      const glyph = contextUnicodeChars.get(this.source.context)?.get(char);
      if (!glyph || glyph.owner.lib !== this.lib) {
        throw new Error("Encoded Unicode must be live and owned by the same Context");
      }
      const recorder = this.recorder;
      if (recorder)
        return recorder.unicode(glyph.owner.handle, glyph.index, x, y, fg, bg, attributes);
      this.lib.contextBufferDrawUnicode(this.checkedTarget(), glyph.owner.handle, glyph.index, x, y, fg, bg, attributes);
      return;
    }
    this.drawChecked({ operation: "char", char, x, y, foreground: fg, background: bg, attributes });
  }
}

// src/renderables/composition/vnode.ts
import util from "util";
var BrandedVNode = Symbol.for("@opentui/core/VNode");
function isRenderableConstructor(value) {
  return typeof value === "function" && value.prototype && Renderable2.prototype.isPrototypeOf(value.prototype);
}
function flattenChildren(children) {
  const result = [];
  for (const child of children) {
    if (Array.isArray(child)) {
      result.push(...flattenChildren(child));
    } else if (child !== null && child !== undefined && child !== false) {
      result.push(child);
    }
  }
  return result;
}
function h2(type, props, ...children) {
  if (typeof type !== "function") {
    throw new TypeError("h() received an invalid vnode type");
  }
  const vnode = {
    [BrandedVNode]: true,
    type,
    props,
    children: flattenChildren(children),
    __pendingCalls: []
  };
  if (isRenderableConstructor(type)) {
    return new Proxy(vnode, {
      get(target, prop, receiver) {
        if (prop in target) {
          return Reflect.get(target, prop, receiver);
        }
        if (typeof prop === "string") {
          const prototype = type.prototype;
          const hasMethod = prototype && (typeof prototype[prop] === "function" || Object.getOwnPropertyDescriptor(prototype, prop) || Object.getOwnPropertyDescriptor(Object.getPrototypeOf(prototype), prop));
          if (hasMethod) {
            return (...args) => {
              target.__pendingCalls = target.__pendingCalls || [];
              target.__pendingCalls.push({ method: prop, args });
              return target;
            };
          }
        }
        return Reflect.get(target, prop, receiver);
      },
      set(target, prop, value, receiver) {
        if (typeof prop === "string" && isRenderableConstructor(type)) {
          const prototype = type.prototype;
          const descriptor = Object.getOwnPropertyDescriptor(prototype, prop) || Object.getOwnPropertyDescriptor(Object.getPrototypeOf(prototype), prop);
          if (descriptor && descriptor.set) {
            target.__pendingCalls = target.__pendingCalls || [];
            target.__pendingCalls.push({ method: prop, args: [value], isProperty: true });
            return true;
          }
        }
        return Reflect.set(target, prop, value, receiver);
      }
    });
  }
  return vnode;
}
function isVNode2(node) {
  return node && node[BrandedVNode];
}
function maybeMakeRenderable2(ctx, node) {
  if (isRenderable2(node))
    return node;
  if (isVNode2(node))
    return instantiate2(ctx, node);
  if (true) {
    console.warn("maybeMakeRenderable received an invalid node", util.inspect(node, { depth: 2 }));
  }
  return null;
}
function wrapWithDelegates2(instance, delegateMap) {
  if (!delegateMap || Object.keys(delegateMap).length === 0)
    return instance;
  instance.refreshHooks();
  const getDescendant = (id) => {
    return instance.findDescendantById(id);
  };
  const proxy = new Proxy(instance, {
    get(target, prop, receiver) {
      if (typeof prop === "string" && delegateMap[prop]) {
        const host = getDescendant(delegateMap[prop]);
        if (host) {
          const value = host[prop];
          if (typeof value === "function") {
            return value.bind(host);
          }
          return value;
        }
      }
      return Reflect.get(target, prop, receiver);
    },
    set(target, prop, value, receiver) {
      if (typeof prop === "string" && delegateMap[prop]) {
        const host = getDescendant(delegateMap[prop]);
        if (host) {
          return Reflect.set(host, prop, value);
        }
      }
      return Reflect.set(target, prop, value, receiver);
    }
  });
  return proxy;
}
function instantiate2(ctx, node) {
  if (isRenderable2(node))
    return node;
  if (!node || typeof node !== "object") {
    throw new TypeError("mount() received an invalid vnode");
  }
  const vnode = node;
  const { type, props } = vnode;
  const children = flattenChildren(vnode.children || []);
  const delegateMap = vnode.__delegateMap;
  if (isRenderableConstructor(type)) {
    const instance = new type(ctx, props || {});
    for (const child of children) {
      if (isRenderable2(child)) {
        instance.add(child);
      } else {
        const mounted = instantiate2(ctx, child);
        instance.add(mounted);
      }
    }
    const delegatedInstance = wrapWithDelegates2(instance, delegateMap);
    const pendingCalls = vnode.__pendingCalls;
    if (pendingCalls) {
      for (const call of pendingCalls) {
        if (call.isProperty) {
          delegatedInstance[call.method] = call.args[0];
        } else {
          delegatedInstance[call.method].apply(delegatedInstance, call.args);
        }
      }
    }
    return delegatedInstance;
  }
  const resolved = type(props || {}, children);
  const inst = instantiate2(ctx, resolved);
  return wrapWithDelegates2(inst, delegateMap);
}
function delegate2(mapping, vnode) {
  if (isRenderable2(vnode)) {
    return wrapWithDelegates2(vnode, mapping);
  }
  if (!vnode || typeof vnode !== "object")
    return vnode;
  vnode.__delegateMap = { ...vnode.__delegateMap || {}, ...mapping };
  return vnode;
}

// src/lib/renderable.validations.ts
function validateOptions(id, options) {
  if (typeof options.width === "number") {
    if (options.width < 0) {
      throw new TypeError(`Invalid width for Renderable ${id}: ${options.width}`);
    }
  }
  if (typeof options.height === "number") {
    if (options.height < 0) {
      throw new TypeError(`Invalid height for Renderable ${id}: ${options.height}`);
    }
  }
}
function isValidPercentage(value) {
  if (typeof value === "string" && value.endsWith("%")) {
    const numPart = value.slice(0, -1);
    const num = parseFloat(numPart);
    return !Number.isNaN(num);
  }
  return false;
}
function isMarginType(value) {
  if (typeof value === "number" && !Number.isNaN(value)) {
    return true;
  }
  if (value === "auto") {
    return true;
  }
  return isValidPercentage(value);
}
function isPaddingType(value) {
  if (typeof value === "number" && !Number.isNaN(value)) {
    return true;
  }
  return isValidPercentage(value);
}
function isPositionType(value) {
  if (typeof value === "number" && !Number.isNaN(value)) {
    return true;
  }
  if (value === "auto") {
    return true;
  }
  return isValidPercentage(value);
}
function isPositionTypeType(value) {
  return value === "relative" || value === "absolute";
}
function isOverflowType(value) {
  return value === "visible" || value === "hidden" || value === "scroll";
}
function isDimensionType(value) {
  return isPositionType(value);
}
function isFlexBasisType(value) {
  if (value === undefined || value === "auto") {
    return true;
  }
  if (typeof value === "number" && !Number.isNaN(value)) {
    return true;
  }
  return false;
}
function isSizeType(value) {
  if (value === undefined) {
    return true;
  }
  if (typeof value === "number" && !Number.isNaN(value)) {
    return true;
  }
  return isValidPercentage(value);
}

// src/Renderable.ts
var BrandedRenderable = Symbol.for("@opentui/core/Renderable");
var nativeSceneMethodNames = [
  "renderSelf",
  "onResize",
  "onLayoutResize",
  "onUpdate",
  "renderBefore",
  "renderAfter",
  "onLifecyclePass",
  "selectable"
];
var nativeSceneMethodDefaults = {
  selectable: false,
  onLifecyclePass: null,
  renderBefore: undefined,
  renderAfter: undefined
};
var nativeSceneHookUpdates = nativeConstants.OT_SCENE_HOOK_UPDATE | nativeConstants.OT_SCENE_HOOK_IDLE_UPDATE;
var nativeSceneHookListeners = nativeConstants.OT_SCENE_HOOK_RESIZE | nativeConstants.OT_SCENE_HOOK_LAYOUT_CHANGED;
var nativeSceneHookBeforeAfter = nativeConstants.OT_SCENE_HOOK_RENDER_BEFORE | nativeConstants.OT_SCENE_HOOK_RENDER_AFTER;
var nativeSceneHookHostMethods = nativeConstants.OT_SCENE_HOOK_UPDATE | nativeSceneHookBeforeAfter | nativeConstants.OT_SCENE_HOOK_RENDER_SELF;
function isRowFlexDirection(direction) {
  return direction === FlexDirection2.Row || direction === FlexDirection2.RowReverse;
}
function clampOpacity(value) {
  return value === undefined ? 1 : Math.max(0, Math.min(1, value));
}
var LayoutEvents2;
((LayoutEvents) => {
  LayoutEvents["LAYOUT_CHANGED"] = "layout-changed";
  LayoutEvents["RESIZED"] = "resized";
})(LayoutEvents2 ||= {});
var RenderableEvents2;
((RenderableEvents) => {
  RenderableEvents["FOCUSED"] = "focused";
  RenderableEvents["BLURRED"] = "blurred";
  RenderableEvents["DESTROYED"] = "destroyed";
})(RenderableEvents2 ||= {});
var positionKeys = ["left", "top", "right", "bottom"];
function isRenderable2(obj) {
  return !!obj?.[BrandedRenderable];
}

class BaseRenderable2 extends EventEmitter4 {
  [BrandedRenderable] = true;
  static renderableNumber = 1;
  _id;
  num;
  _dirty = false;
  parent = null;
  _visible = true;
  constructor(options) {
    super();
    this.num = BaseRenderable2.renderableNumber++;
    this._id = options.id ?? `renderable-${this.num}`;
  }
  get id() {
    return this._id;
  }
  set id(value) {
    this._id = value;
  }
  get isDirty() {
    return this._dirty;
  }
  markClean() {
    this._dirty = false;
  }
  markDirty() {
    this._dirty = true;
  }
  destroy() {}
  destroyRecursively() {}
  get visible() {
    return this._visible;
  }
  set visible(value) {
    this._visible = value;
  }
}

class Renderable2 extends BaseRenderable2 {
  static defaultFocusable = false;
  static renderablesByNumber = new Map;
  static nativeIntegration = {
    kind: "custom",
    body: { native: this.prototype.renderSelf }
  };
  nativeIntegration;
  _isDestroyed = false;
  _cleanupInProgress = false;
  _childCleanupInProgress = false;
  _deferredCleanup;
  _ctx;
  _sceneHandle;
  _yogaFreed = false;
  _translateX = 0;
  _translateY = 0;
  _width;
  _height;
  _destroyedLayout;
  _zIndex;
  buffered;
  frameBuffer = null;
  _focusable = this.constructor.defaultFocusable;
  _focused = false;
  _hasFocusedDescendant = false;
  keypressHandler = null;
  pasteHandler = null;
  _live = false;
  _liveCount = 0;
  _sizeChangeListener = undefined;
  _nativeSceneHookFlags = 0;
  _nativeSceneHookGeneration = 0n;
  _nativeSceneHooksRegistered = false;
  _nativeSceneResize = false;
  _nativeSceneResizeCallbacks;
  _nativeSceneHookLayout;
  _observedLayout;
  _observedLayoutRevision = -1;
  _computedLayout;
  _computedLayoutRevision = -1;
  _nativeSceneMethods;
  _nativeSceneMethodsPending = false;
  _mouseListener = null;
  _mouseListeners = {};
  _pasteListener = undefined;
  _keyListeners = {};
  _positionType = "relative";
  _overflow = "visible";
  _position = {};
  _opacity = 1;
  _flexShrink = 1;
  _childrenInLayoutOrder = [];
  parent = null;
  constructor(ctx, options) {
    super(options);
    this._ctx = ctx;
    this.nativeIntegration = new.target.nativeIntegration;
    Renderable2.renderablesByNumber.set(this.num, this);
    try {
      validateOptions(this.id, options);
      this._width = options.width ?? "auto";
      this._height = options.height ?? "auto";
      this._zIndex = options.zIndex ?? 0;
      this._visible = options.visible !== false;
      this.buffered = options.buffered ?? false;
      this._live = options.live ?? false;
      this._liveCount = this._live && this._visible ? 1 : 0;
      this._opacity = clampOpacity(options.opacity);
      ctx.nativeScene.createNode(this, options);
      if (options.renderBefore !== undefined)
        this.renderBefore = options.renderBefore;
      if (options.renderAfter !== undefined)
        this.renderAfter = options.renderAfter;
      if (this.nativeSceneNeedsHookPublish())
        this.setNativeSceneHooks(this._nativeSceneHookFlags);
      this.setDisplay(this._visible ? 0 /* Flex */ : 1 /* None */);
      this.setupYogaProperties(options);
      if (this.nativeIntegration.measure)
        this.setMeasureFunc(this.nativeIntegration.measure.bind(this));
      if (this._zIndex !== 0 || this._opacity !== 1 || this._focusable) {
        ctx.nativeScene.setPaint(this, Renderable2.prototype.getNativeScenePaint.call(this));
      }
      this.applyEventOptions(options);
      if (this.buffered) {
        this.createFrameBuffer();
      }
      if (!Object.hasOwn(new.target, "nativeIntegration") || this.nativeIntegration.construction !== "prototype") {
        ctx.nativeScene.scheduleHookScan(this);
      }
    } catch (error) {
      try {
        this.destroyLayoutBacking();
      } catch {}
      Renderable2.renderablesByNumber.delete(this.num);
      throw error;
    }
  }
  abortConstruction(error, cleanup) {
    try {
      this.destroyLayoutBacking((run) => {
        this._isDestroyed = true;
        Renderable2.renderablesByNumber.delete(this.num);
        if (cleanup)
          run(() => cleanup(run));
        if (this.frameBuffer) {
          const frameBuffer = this.frameBuffer;
          this.frameBuffer = null;
          run(() => frameBuffer.destroy());
        }
      });
    } catch {}
    throw error;
  }
  rollbackConstruction(error) {
    try {
      Renderable2.prototype.destroy.call(this);
    } catch {}
    throw error;
  }
  runCleanup(steps) {
    let failure;
    const run = (step) => {
      try {
        step();
      } catch (error) {
        failure ??= { error };
      }
    };
    try {
      steps(run);
    } catch (error) {
      if (!failure)
        throw error;
    }
    if (failure)
      throw failure.error;
  }
  assignOptions(target, options) {
    if (options == null || this._isDestroyed || target._isDestroyed)
      return;
    this.assertMutable();
    for (const key of Reflect.ownKeys(options)) {
      if (!Object.getOwnPropertyDescriptor(options, key)?.enumerable)
        continue;
      const value = Reflect.get(options, key);
      if (this._isDestroyed || target._isDestroyed)
        return;
      target[key] = value;
    }
  }
  get focusable() {
    return this._focusable;
  }
  set focusable(value) {
    value ??= this.constructor.defaultFocusable;
    if (this._focusable === value)
      return;
    this.setNativeScenePaint({ focusable: value });
    this._focusable = value;
    this.runCleanup((run) => {
      if (!value)
        run(() => this.blur());
      run(() => this.requestRender());
    });
  }
  get ctx() {
    return this._ctx;
  }
  get visible() {
    return this._visible;
  }
  get primaryAxis() {
    return isRowFlexDirection(this.getFlexDirection()) ? "row" : "column";
  }
  set visible(value) {
    value ??= true;
    if (this._visible === value)
      return;
    this.runMutation(() => {
      const wasVisible = this._visible;
      this.setDisplay(value ? 0 /* Flex */ : 1 /* None */);
      this._visible = value;
      if (this._live) {
        if (!wasVisible && value) {
          this.propagateLiveCount(1);
        } else if (wasVisible && !value) {
          this.propagateLiveCount(-1);
        }
      }
      if (this._focused) {
        this.blur();
      }
      this.requestRender();
    });
  }
  get opacity() {
    return this._opacity;
  }
  set opacity(value) {
    const clamped = clampOpacity(value);
    if (this._opacity !== clamped) {
      this.setNativeScenePaint({ opacity: clamped });
      this._opacity = clamped;
      this.requestRender();
    }
  }
  hasSelection() {
    return false;
  }
  onSelectionChanged(selection) {
    return false;
  }
  getSelectedText() {
    return "";
  }
  shouldStartSelection(x, y) {
    return false;
  }
  focus() {
    if (this._isDestroyed || this._focused || !this._focusable)
      return;
    this._ctx.nativeScene.setFocus(this, true);
    this._focused = true;
    this.runCleanup((run) => {
      run(() => this._ctx.focusRenderable(this));
      run(() => this.requestRender());
      if (this._isDestroyed || !this._focused || this._ctx.currentFocusedRenderable !== this)
        return;
      if (this.keypressHandler)
        return;
      this.keypressHandler = (key) => {
        if (this._isDestroyed || !this._focused || this._ctx.currentFocusedRenderable !== this)
          return;
        this._keyListeners["down"]?.(key);
        if (this._isDestroyed)
          return;
        if (!key.defaultPrevented && this.handleKeyPress) {
          this.handleKeyPress(key);
        }
      };
      this.pasteHandler = (event) => {
        if (this._isDestroyed || !this._focused || this._ctx.currentFocusedRenderable !== this)
          return;
        this._pasteListener?.call(this, event);
        if (this._isDestroyed)
          return;
        if (!event.defaultPrevented && this.handlePaste) {
          this.handlePaste(event);
        }
      };
      this.ctx._internalKeyInput.onInternal("keypress", this.keypressHandler);
      this.ctx._internalKeyInput.onInternal("paste", this.pasteHandler);
      run(() => this.propagateFocusChange(true));
      run(() => this.emit("focused" /* FOCUSED */));
    });
  }
  propagateFocusChange(hasFocus) {
    let parent = this.parent;
    while (parent) {
      if (!hasFocus) {
        hasFocus = parent._childrenInLayoutOrder.some((child) => !child._isDestroyed && (child._focused || child._hasFocusedDescendant));
      }
      if (parent._hasFocusedDescendant !== hasFocus) {
        parent._hasFocusedDescendant = hasFocus;
        parent.markDirty();
      }
      hasFocus ||= parent._focused;
      parent = parent.parent;
    }
    this.requestRender();
  }
  blur() {
    if (!this._focused)
      return;
    this._focused = false;
    const keypress = this.keypressHandler;
    const paste = this.pasteHandler;
    this.keypressHandler = null;
    this.pasteHandler = null;
    this.runCleanup((run) => {
      run(() => this._ctx.nativeScene.setFocus(this, false));
      if (keypress)
        run(() => this.ctx._internalKeyInput.offInternal("keypress", keypress));
      if (paste)
        run(() => this.ctx._internalKeyInput.offInternal("paste", paste));
      run(() => this.propagateFocusChange(false));
      if (!this._focused)
        run(() => this._ctx.blurRenderable(this));
      if (!this._focused)
        run(() => this.emit("blurred" /* BLURRED */));
    });
  }
  get focused() {
    return this._focused;
  }
  get hasFocusedDescendant() {
    return this._hasFocusedDescendant;
  }
  get live() {
    return this._live;
  }
  get liveCount() {
    return this._liveCount;
  }
  set live(value) {
    value ??= false;
    if (this._live === value)
      return;
    this._live = value;
    if (this._visible) {
      const delta = value ? 1 : -1;
      this.propagateLiveCount(delta);
    }
  }
  propagateLiveCount(delta) {
    this._liveCount += delta;
    this.parent?.propagateLiveCount(delta);
  }
  onLiveCountChanged(previous) {}
  findDescendantById(id) {
    for (const child of this._childrenInLayoutOrder) {
      if (child.id === id)
        return child;
      if (isRenderable2(child)) {
        const found = child.findDescendantById(id);
        if (found)
          return found;
      }
    }
    return;
  }
  requestRender() {
    this.markDirty();
    this._ctx.requestRender();
  }
  _needsLifecyclePass() {
    return this.onLifecyclePass !== null;
  }
  get translateX() {
    return this._translateX;
  }
  set translateX(value) {
    value ??= 0;
    if (this._translateX === value)
      return;
    this.setNativeScenePaint({ translateX: value });
    this._translateX = value;
    this.requestRender();
  }
  get translateY() {
    return this._translateY;
  }
  set translateY(value) {
    value ??= 0;
    if (this._translateY === value)
      return;
    this.setNativeScenePaint({ translateY: value });
    this._translateY = value;
    this.requestRender();
  }
  get screenX() {
    return this.isFreed() ? this._destroyedLayout?.screenX ?? 0 : this.getNativeSceneLayout().screenX;
  }
  get screenY() {
    return this.isFreed() ? this._destroyedLayout?.screenY ?? 0 : this.getNativeSceneLayout().screenY;
  }
  get _screenX() {
    return this.getNativeScenePaintLayout()?.screenX ?? this.screenX;
  }
  get _screenY() {
    return this.getNativeScenePaintLayout()?.screenY ?? this.screenY;
  }
  getNativeScenePaintLayout() {
    const cached = this._nativeSceneHookLayout;
    if (!cached)
      return;
    const scene = this._ctx.nativeScene;
    const revision = scene.currentGeometryRevision;
    if (!this._isDestroyed && cached.paintRevision !== revision) {
      cached.paintLayout = scene.getLayout(this, "paint");
      cached.paintRevision = revision;
    }
    return cached.paintLayout;
  }
  get x() {
    if (!this.isFreed())
      return this.getNativeSceneLayout().screenX;
    const left = this._destroyedLayout?.x ?? 0;
    if (this.parent) {
      return this.parent.x + left + this._translateX;
    }
    return left + this._translateX;
  }
  set x(value) {
    this.left = value;
  }
  get top() {
    return this._position.top;
  }
  set top(value) {
    if (isPositionType(value) || value == null) {
      this.setPosition({ top: value ?? undefined });
    }
  }
  get right() {
    return this._position.right;
  }
  set right(value) {
    if (isPositionType(value) || value == null) {
      this.setPosition({ right: value ?? undefined });
    }
  }
  get bottom() {
    return this._position.bottom;
  }
  set bottom(value) {
    if (isPositionType(value) || value == null) {
      this.setPosition({ bottom: value ?? undefined });
    }
  }
  get left() {
    return this._position.left;
  }
  set left(value) {
    if (isPositionType(value) || value == null) {
      this.setPosition({ left: value ?? undefined });
    }
  }
  get y() {
    if (!this.isFreed())
      return this.getNativeSceneLayout().screenY;
    const top = this._destroyedLayout?.y ?? 0;
    if (this.parent) {
      return this.parent.y + top + this._translateY;
    }
    return top + this._translateY;
  }
  set y(value) {
    this.top = value;
  }
  get width() {
    if (!this.isFreed()) {
      const layout = this.getNativeSceneLayout();
      return layout.width === 0 ? this.styledDimension("width") : layout.width;
    }
    return this._destroyedLayout?.width ?? this.styledDimension("width");
  }
  set width(value) {
    this.setDimension("width", value);
  }
  get height() {
    if (!this.isFreed()) {
      const layout = this.getNativeSceneLayout();
      return layout.height === 0 ? this.styledDimension("height") : layout.height;
    }
    return this._destroyedLayout?.height ?? this.styledDimension("height");
  }
  defaultDimension(_kind) {
    return "auto";
  }
  styledDimension(kind) {
    const value = kind === "width" ? this._width : this._height;
    return typeof value === "number" ? value : 0;
  }
  getNativeSceneLayout() {
    const scene = this._ctx.nativeScene;
    const cached = this._nativeSceneHookLayout;
    const revision = scene.currentGeometryRevision;
    if (cached?.layout && cached.revision === revision)
      return cached.layout;
    const layoutRevision = scene.observedLayoutRevision;
    if (layoutRevision !== undefined && this._observedLayoutRevision === layoutRevision)
      return this._observedLayout;
    const layout = scene.getLayout(this);
    if (cached) {
      cached.revision = revision;
      cached.layout = layout;
    }
    if (layoutRevision !== undefined) {
      this._observedLayout = layout;
      this._observedLayoutRevision = layoutRevision;
    }
    return layout;
  }
  set height(value) {
    this.setDimension("height", value);
  }
  setDimension(kind, input) {
    if (this.isFreed())
      return;
    const value = input ?? this.defaultDimension(kind);
    const key = kind === "width" ? "_width" : "_height";
    if (!isDimensionType(value) || this[key] === value)
      return;
    this.runMutation(() => {
      const disableShrink = typeof value === "number" && this._flexShrink === 1;
      const dimension = kind === "width" ? Dimension2.Width : Dimension2.Height;
      sceneSetDimension(this._ctx.nativeScene, this, dimension, value, disableShrink);
      this[key] = value;
      if (disableShrink)
        this._flexShrink = 0;
      this.requestRender();
    });
  }
  get zIndex() {
    return this._zIndex;
  }
  set zIndex(value) {
    value = value ?? 0;
    if (this._zIndex !== value) {
      this.setNativeScenePaint({ zIndex: value });
      this._zIndex = value;
      this.requestRender();
    }
  }
  getChildrenSortedByPrimaryAxis() {
    const axis = isRowFlexDirection(this.getFlexDirection()) ? "screenX" : "screenY";
    if (this._childrenInLayoutOrder.length < 2)
      return [...this._childrenInLayoutOrder];
    const children = this._childrenInLayoutOrder.map((child) => ({ child, coordinate: child[axis] }));
    children.sort((a, b) => a.coordinate - b.coordinate);
    return children.map(({ child }) => child);
  }
  _bindSceneHandle(handle) {
    this._sceneHandle = handle;
    this._yogaFreed = false;
  }
  _getSceneHandle(owner) {
    if (this._ctx.nativeScene !== owner)
      throw new Error("Yoga node belongs to a different native scene");
    owner.assertAlive();
    if (this._yogaFreed || !this._sceneHandle)
      throw new Error("Native scene Yoga node is freed");
    return this._sceneHandle;
  }
  _releaseSceneHandle() {
    this._yogaFreed = true;
    this._sceneHandle = undefined;
  }
  isFreed() {
    return this._yogaFreed || !this._sceneHandle;
  }
  assertMutable() {
    this._ctx.nativeScene.driver.renderLib.getYogaHost().assertMutable();
    this._getSceneHandle(this._ctx.nativeScene);
  }
  runMutation(operation) {
    if (this.isFreed())
      return;
    this.assertMutable();
    return this._ctx.nativeScene.driver.renderLib.getYogaHost().runMutation(operation);
  }
  yogaSetEnum(kind, value) {
    if (this.isFreed())
      return;
    sceneSetEnum(this._ctx.nativeScene, this, kind, value);
  }
  yogaGetEnum(kind, fallback) {
    return this.isFreed() ? fallback : sceneGetEnum(this._ctx.nativeScene, this, kind);
  }
  yogaGetFloat(kind) {
    return this.isFreed() ? NaN : sceneGetFloat(this._ctx.nativeScene, this, kind);
  }
  yogaSetFloat(kind, value) {
    if (this.isFreed())
      return;
    sceneSetFloat(this._ctx.nativeScene, this, kind, value);
  }
  yogaSetValue(kind, edge, valueInput) {
    if (this.isFreed())
      return;
    sceneSetValue(this._ctx.nativeScene, this, kind, edge, valueInput);
  }
  yogaGetValue(kind, edge) {
    return this.isFreed() ? UNDEFINED_VALUE : sceneGetValue(this._ctx.nativeScene, this, kind, edge);
  }
  setDisplay(display) {
    this.yogaSetEnum(YogaEnumKind.Display, display);
  }
  getFlexDirection() {
    return this.yogaGetEnum(YogaEnumKind.FlexDirection, FlexDirection2.Column);
  }
  setFlexDirection(flexDirection) {
    this.yogaSetEnum(YogaEnumKind.FlexDirection, flexDirection);
  }
  setFlexWrap(flexWrap) {
    this.yogaSetEnum(YogaEnumKind.FlexWrap, flexWrap);
  }
  setAlignItems(alignItems) {
    this.yogaSetEnum(YogaEnumKind.AlignItems, alignItems);
  }
  setJustifyContent(justifyContent) {
    this.yogaSetEnum(YogaEnumKind.JustifyContent, justifyContent);
  }
  setAlignSelf(alignSelf) {
    this.yogaSetEnum(YogaEnumKind.AlignSelf, alignSelf);
  }
  setPositionType(positionType) {
    this.yogaSetEnum(YogaEnumKind.PositionType, positionType);
  }
  setOverflow(overflow) {
    this.yogaSetEnum(YogaEnumKind.Overflow, overflow);
  }
  setFlexGrow(flexGrow) {
    this.yogaSetFloat(YogaFloatKind.FlexGrow, flexGrow);
  }
  setFlexShrink(flexShrink) {
    this.yogaSetFloat(YogaFloatKind.FlexShrink, flexShrink);
  }
  setFlexBasis(flexBasis) {
    this.yogaSetValue(YogaValueKind.FlexBasis, NATIVE_EDGE_NONE2, flexBasis);
  }
  setWidth(width) {
    this.yogaSetValue(YogaValueKind.Width, NATIVE_EDGE_NONE2, width);
  }
  setHeight(height) {
    this.yogaSetValue(YogaValueKind.Height, NATIVE_EDGE_NONE2, height);
  }
  setMinWidth(minWidth) {
    this.yogaSetValue(YogaValueKind.MinWidth, NATIVE_EDGE_NONE2, minWidth);
  }
  setMaxWidth(maxWidth) {
    this.yogaSetValue(YogaValueKind.MaxWidth, NATIVE_EDGE_NONE2, maxWidth);
  }
  setMinHeight(minHeight) {
    this.yogaSetValue(YogaValueKind.MinHeight, NATIVE_EDGE_NONE2, minHeight);
  }
  setMaxHeight(maxHeight) {
    this.yogaSetValue(YogaValueKind.MaxHeight, NATIVE_EDGE_NONE2, maxHeight);
  }
  setMargin(edge, margin) {
    this.yogaSetValue(YogaValueKind.Margin, edge, margin);
  }
  getMargin(edge) {
    return this.yogaGetValue(YogaValueKind.Margin, edge);
  }
  setPadding(edge, padding) {
    this.yogaSetValue(YogaValueKind.Padding, edge, padding);
  }
  setGap(gutter, gap) {
    this.yogaSetValue(YogaValueKind.Gap, gutter, gap);
  }
  getWidth() {
    return this.yogaGetValue(YogaValueKind.Width, NATIVE_EDGE_NONE2);
  }
  getFlexWrap() {
    return this.yogaGetEnum(YogaEnumKind.FlexWrap, Wrap2.NoWrap);
  }
  getAlignItems() {
    return this.yogaGetEnum(YogaEnumKind.AlignItems, Align2.Stretch);
  }
  getJustifyContent() {
    return this.yogaGetEnum(YogaEnumKind.JustifyContent, Justify2.FlexStart);
  }
  getAlignSelf() {
    return this.yogaGetEnum(YogaEnumKind.AlignSelf, Align2.Auto);
  }
  getPositionType() {
    return this.yogaGetEnum(YogaEnumKind.PositionType, PositionType2.Relative);
  }
  getFlexGrow() {
    return this.yogaGetFloat(YogaFloatKind.FlexGrow);
  }
  getFlexShrink() {
    return this.yogaGetFloat(YogaFloatKind.FlexShrink);
  }
  getFlexBasis() {
    return this.yogaGetValue(YogaValueKind.FlexBasis, NATIVE_EDGE_NONE2);
  }
  getHeight() {
    return this.yogaGetValue(YogaValueKind.Height, NATIVE_EDGE_NONE2);
  }
  getMinWidth() {
    return this.yogaGetValue(YogaValueKind.MinWidth, NATIVE_EDGE_NONE2);
  }
  getMinHeight() {
    return this.yogaGetValue(YogaValueKind.MinHeight, NATIVE_EDGE_NONE2);
  }
  getMaxWidth() {
    return this.yogaGetValue(YogaValueKind.MaxWidth, NATIVE_EDGE_NONE2);
  }
  getMaxHeight() {
    return this.yogaGetValue(YogaValueKind.MaxHeight, NATIVE_EDGE_NONE2);
  }
  getPadding(edge) {
    return this.yogaGetValue(YogaValueKind.Padding, edge);
  }
  getGap(gutter) {
    return this.yogaGetValue(YogaValueKind.Gap, gutter);
  }
  getComputedLayout() {
    const scene = this._ctx.nativeScene;
    const revision = scene.observedLayoutRevision;
    let layout = this._computedLayout;
    if (revision === undefined || this._computedLayoutRevision !== revision || layout === undefined || this._yogaFreed) {
      layout = scene.getLayout(this, true);
      if (revision !== undefined) {
        this._computedLayout = layout;
        this._computedLayoutRevision = revision;
      }
    }
    const { left, top, right, bottom, width, height } = layout;
    return { left, top, right, bottom, width, height };
  }
  setMeasureFunc(measure) {
    this.assertMutable();
    this._ctx.nativeScene.setMeasureFunc(this, measure);
  }
  hasMeasureFunc() {
    return this._ctx.nativeScene.hasMeasureFunc(this);
  }
  setupYogaProperties(options) {
    const node = this;
    if (isFlexBasisType(options.flexBasis)) {
      node.setFlexBasis(options.flexBasis);
    }
    if (isSizeType(options.minWidth)) {
      node.setMinWidth(options.minWidth);
    }
    if (isSizeType(options.minHeight)) {
      node.setMinHeight(options.minHeight);
    }
    if (options.flexGrow !== undefined) {
      node.setFlexGrow(options.flexGrow);
    } else {
      node.setFlexGrow(0);
    }
    if (options.flexShrink !== undefined) {
      this._flexShrink = options.flexShrink;
      node.setFlexShrink(options.flexShrink);
    } else {
      const hasExplicitWidth = typeof options.width === "number";
      const hasExplicitHeight = typeof options.height === "number";
      this._flexShrink = hasExplicitWidth || hasExplicitHeight ? 0 : 1;
      node.setFlexShrink(this._flexShrink);
    }
    node.setFlexDirection(parseFlexDirection2(options.flexDirection));
    node.setFlexWrap(parseWrap2(options.flexWrap));
    node.setAlignItems(parseAlignItems2(options.alignItems));
    node.setJustifyContent(parseJustify2(options.justifyContent));
    node.setAlignSelf(parseAlign2(options.alignSelf));
    if (isDimensionType(options.width)) {
      this._width = options.width;
      node.setWidth(options.width);
    }
    if (isDimensionType(options.height)) {
      this._height = options.height;
      node.setHeight(options.height);
    }
    this._positionType = options.position === "absolute" ? "absolute" : "relative";
    if (this._positionType !== "relative") {
      node.setPositionType(parsePositionType2(this._positionType));
    }
    this._overflow = options.overflow === "hidden" ? "hidden" : options.overflow === "scroll" ? "scroll" : "visible";
    if (this._overflow !== "visible") {
      node.setOverflow(parseOverflow2(this._overflow));
    }
    const hasPositionProps = options.top !== undefined || options.right !== undefined || options.bottom !== undefined || options.left !== undefined;
    if (hasPositionProps) {
      this._position = {
        top: options.top,
        right: options.right,
        bottom: options.bottom,
        left: options.left
      };
      this.updateYogaPosition(this._position);
      this.requestRender();
    }
    if (isSizeType(options.maxWidth)) {
      node.setMaxWidth(options.maxWidth);
    }
    if (isSizeType(options.maxHeight)) {
      node.setMaxHeight(options.maxHeight);
    }
    this.setupMarginAndPadding(options);
  }
  setupMarginAndPadding(options) {
    const node = this;
    if (isMarginType(options.margin)) {
      node.setMargin(Edge2.All, options.margin);
    }
    if (isMarginType(options.marginX)) {
      node.setMargin(Edge2.Horizontal, options.marginX);
    }
    if (isMarginType(options.marginY)) {
      node.setMargin(Edge2.Vertical, options.marginY);
    }
    if (isMarginType(options.marginTop)) {
      node.setMargin(Edge2.Top, options.marginTop);
    }
    if (isMarginType(options.marginRight)) {
      node.setMargin(Edge2.Right, options.marginRight);
    }
    if (isMarginType(options.marginBottom)) {
      node.setMargin(Edge2.Bottom, options.marginBottom);
    }
    if (isMarginType(options.marginLeft)) {
      node.setMargin(Edge2.Left, options.marginLeft);
    }
    if (isPaddingType(options.padding)) {
      node.setPadding(Edge2.All, options.padding);
    }
    if (isPaddingType(options.paddingX)) {
      node.setPadding(Edge2.Horizontal, options.paddingX);
    }
    if (isPaddingType(options.paddingY)) {
      node.setPadding(Edge2.Vertical, options.paddingY);
    }
    if (isPaddingType(options.paddingTop)) {
      node.setPadding(Edge2.Top, options.paddingTop);
    }
    if (isPaddingType(options.paddingRight)) {
      node.setPadding(Edge2.Right, options.paddingRight);
    }
    if (isPaddingType(options.paddingBottom)) {
      node.setPadding(Edge2.Bottom, options.paddingBottom);
    }
    if (isPaddingType(options.paddingLeft)) {
      node.setPadding(Edge2.Left, options.paddingLeft);
    }
  }
  set position(positionType) {
    positionType ??= "relative";
    if (!isPositionTypeType(positionType) || this._positionType === positionType)
      return;
    this.runMutation(() => {
      this.setPositionType(parsePositionType2(positionType));
      this._positionType = positionType;
      this.requestRender();
    });
  }
  get overflow() {
    return this._overflow;
  }
  set overflow(overflow) {
    overflow ??= "visible";
    if (!isOverflowType(overflow) || this._overflow === overflow)
      return;
    this.runMutation(() => {
      this.setOverflow(parseOverflow2(overflow));
      this._overflow = overflow;
      this.requestRender();
    });
  }
  setPosition(position) {
    this.runMutation(() => {
      this.updateYogaPosition(position);
      this._position = { ...this._position, ...position };
      this.requestRender();
    });
  }
  updateYogaPosition(position) {
    const units = new Uint32Array(positionKeys.length);
    const values = new Float32Array(positionKeys.length);
    let mask = 0;
    for (let edge = 0;edge < positionKeys.length; edge++) {
      const key = positionKeys[edge];
      const input = position[key] ?? undefined;
      if (!(key in position) || input !== undefined && !isPositionType(input))
        continue;
      const value = parseYogaValue(input);
      mask |= 1 << edge;
      units[edge] = value.unit;
      values[edge] = value.value;
    }
    this._ctx.nativeScene.setPositions(this, mask, units, values);
  }
  set flexGrow(grow) {
    if (grow == null) {
      this.setFlexGrow(0);
    } else {
      this.setFlexGrow(grow);
    }
    this.requestRender();
  }
  set flexShrink(shrink) {
    const value = shrink == null ? 1 : shrink;
    this.runMutation(() => {
      this.setFlexShrink(value);
      this._flexShrink = value;
      this.requestRender();
    });
  }
  set flexDirection(direction) {
    this.setFlexDirection(parseFlexDirection2(direction));
    this.requestRender();
  }
  set flexWrap(wrap) {
    this.setFlexWrap(parseWrap2(wrap));
    this.requestRender();
  }
  set alignItems(alignItems) {
    this.setAlignItems(parseAlignItems2(alignItems));
    this.requestRender();
  }
  set justifyContent(justifyContent) {
    this.setJustifyContent(parseJustify2(justifyContent));
    this.requestRender();
  }
  set alignSelf(alignSelf) {
    this.setAlignSelf(parseAlign2(alignSelf));
    this.requestRender();
  }
  set flexBasis(basis) {
    this.setStyleValue(YogaValueKind.FlexBasis, NATIVE_EDGE_NONE2, basis, isFlexBasisType);
  }
  set minWidth(minWidth) {
    this.setStyleValue(YogaValueKind.MinWidth, NATIVE_EDGE_NONE2, minWidth, isSizeType);
  }
  set maxWidth(maxWidth) {
    this.setStyleValue(YogaValueKind.MaxWidth, NATIVE_EDGE_NONE2, maxWidth, isSizeType);
  }
  set minHeight(minHeight) {
    this.setStyleValue(YogaValueKind.MinHeight, NATIVE_EDGE_NONE2, minHeight, isSizeType);
  }
  set maxHeight(maxHeight) {
    this.setStyleValue(YogaValueKind.MaxHeight, NATIVE_EDGE_NONE2, maxHeight, isSizeType);
  }
  set margin(margin) {
    this.setStyleValue(YogaValueKind.Margin, Edge2.All, margin, isMarginType);
  }
  set marginX(marginX) {
    this.setStyleValue(YogaValueKind.Margin, Edge2.Horizontal, marginX, isMarginType);
  }
  set marginY(marginY) {
    this.setStyleValue(YogaValueKind.Margin, Edge2.Vertical, marginY, isMarginType);
  }
  set marginTop(margin) {
    this.setStyleValue(YogaValueKind.Margin, Edge2.Top, margin, isMarginType);
  }
  get marginTop() {
    return this.getMargin(Edge2.Top).value;
  }
  set marginRight(margin) {
    this.setStyleValue(YogaValueKind.Margin, Edge2.Right, margin, isMarginType);
  }
  set marginBottom(margin) {
    this.setStyleValue(YogaValueKind.Margin, Edge2.Bottom, margin, isMarginType);
  }
  set marginLeft(margin) {
    this.setStyleValue(YogaValueKind.Margin, Edge2.Left, margin, isMarginType);
  }
  set padding(padding) {
    this.setStyleValue(YogaValueKind.Padding, Edge2.All, padding, isPaddingType);
  }
  set paddingX(paddingX) {
    this.setStyleValue(YogaValueKind.Padding, Edge2.Horizontal, paddingX, isPaddingType);
  }
  set paddingY(paddingY) {
    this.setStyleValue(YogaValueKind.Padding, Edge2.Vertical, paddingY, isPaddingType);
  }
  set paddingTop(padding) {
    this.setStyleValue(YogaValueKind.Padding, Edge2.Top, padding, isPaddingType);
  }
  set paddingRight(padding) {
    this.setStyleValue(YogaValueKind.Padding, Edge2.Right, padding, isPaddingType);
  }
  set paddingBottom(padding) {
    this.setStyleValue(YogaValueKind.Padding, Edge2.Bottom, padding, isPaddingType);
  }
  set paddingLeft(padding) {
    this.setStyleValue(YogaValueKind.Padding, Edge2.Left, padding, isPaddingType);
  }
  setStyleValue(kind, edge, value, isValid) {
    if (value != null && !isValid(value))
      return;
    this.yogaSetValue(kind, edge, value ?? undefined);
    this.requestRender();
  }
  setMeasureProvider(provider) {
    if (this.isFreed())
      return;
    const node = this;
    node.runMutation(() => {
      node.setMeasureFunc(provider);
      this.requestRender();
    });
  }
  invalidateIntrinsicSize() {
    if (this.isFreed())
      return;
    const node = this;
    node.assertMutable();
    if (node.hasMeasureFunc())
      this._ctx.nativeScene.markDirty(this);
  }
  getLayout() {
    if (this.isFreed())
      throw new Error("Renderable is destroyed");
    return this.getComputedLayout();
  }
  onLayoutResize(width, height) {
    if (this._visible) {
      this.handleFrameBufferResize(width, height);
      this.onResize(width, height);
      this.requestRender();
    }
  }
  handleFrameBufferResize(width, height) {
    if (!this.buffered)
      return;
    if (width <= 0 || height <= 0) {
      return;
    }
    if (this.frameBuffer) {
      this.frameBuffer.resize(width, height);
    } else {
      this.createFrameBuffer();
    }
  }
  createFrameBuffer() {
    const w = this.width;
    const h = this.height;
    if (w <= 0 || h <= 0) {
      return;
    }
    this.frameBuffer = OptimizedBuffer2.create(w, h, this._ctx.widthMethod, {
      respectAlpha: true,
      id: `framebuffer-${this.id}`,
      owner: this._ctx.nativeScene
    });
  }
  onResize(width, height) {
    this.onSizeChange?.();
    this.emit("resize");
  }
  placeChild(child, anchor) {
    return this.runMutation(() => {
      if (this._ctx.nativeScene !== child._ctx.nativeScene) {
        throw new Error("Cannot move renderables between native scenes");
      }
      if (!child.isDestroyed)
        this._ctx.nativeScene.refreshPendingHooks(child);
      let previous = child.parent;
      if (previous && previous !== this && previous.remove !== Renderable2.prototype.remove) {
        previous.remove(child);
        previous = child.parent;
      }
      if (this._isDestroyed || child.isDestroyed || anchor?.isDestroyed)
        return -1;
      const target = this;
      const childNode = child;
      const previousIndex = previous?._childrenInLayoutOrder.indexOf(child) ?? -1;
      const anchorIndex = anchor ? target._childrenInLayoutOrder.indexOf(anchor) : target._childrenInLayoutOrder.length;
      if (anchorIndex === -1)
        return -1;
      const index = anchorIndex - (previous === target && previousIndex !== -1 && previousIndex < anchorIndex ? 1 : 0);
      let counts;
      let lifecycle;
      let focus;
      let focusPaths;
      if (previous !== target) {
        if (child._focused || child._hasFocusedDescendant) {
          focus = new Map;
          focusPaths = [];
          for (const start of [previous, target]) {
            const path = [];
            for (let parent = start;parent; parent = parent.parent) {
              focus.set(parent, parent._hasFocusedDescendant);
              path.push(parent);
            }
            focusPaths.push(path);
          }
        }
        if (child._liveCount > 0) {
          counts = new Map;
          for (const [start, delta] of [
            [previous, -child._liveCount],
            [target, child._liveCount]
          ]) {
            for (let parent = start;parent; parent = parent.parent) {
              const count = counts.get(parent) ?? { before: parent._liveCount, after: parent._liveCount };
              count.after += delta;
              counts.set(parent, count);
            }
          }
        }
        if (previous) {
          const passes = previous._ctx.getLifecyclePasses();
          lifecycle = new Map([[passes, false]]);
        }
        if (typeof child.onLifecyclePass === "function") {
          const passes = target._ctx.getLifecyclePasses();
          lifecycle ??= new Map;
          lifecycle.set(passes, true);
        }
      }
      this._ctx.nativeScene.moveNode(childNode, this, index);
      if (previous && previousIndex !== -1)
        previous._childrenInLayoutOrder.splice(previousIndex, 1);
      target._childrenInLayoutOrder.splice(index, 0, child);
      child.parent = target;
      if (counts)
        for (const [parent, count] of counts)
          parent._liveCount = count.after;
      if (focusPaths)
        for (const path of focusPaths) {
          for (const parent of path) {
            parent._hasFocusedDescendant = parent._childrenInLayoutOrder.some((node) => node._focused || node._hasFocusedDescendant);
          }
        }
      if (lifecycle)
        for (const [passes, active] of lifecycle) {
          if (active)
            passes.add(child);
          else
            passes.delete(child);
        }
      this.runCleanup((run) => {
        if (focus)
          for (const [parent, focused] of focus) {
            if (parent._hasFocusedDescendant !== focused)
              parent.markDirty();
          }
        if (counts)
          for (const [parent, count] of counts)
            run(() => parent.onLiveCountChanged(count.before));
        if (previous && previous !== target)
          run(() => child.onRemove());
        if (previous && previous !== target)
          run(() => previous.requestRender());
        run(() => target.requestRender());
      });
      return index;
    });
  }
  add(obj, index) {
    if (!obj) {
      return -1;
    }
    if (isVNode2(obj))
      this.assertMutable();
    const renderable = maybeMakeRenderable2(this._ctx, obj);
    if (!renderable) {
      return -1;
    }
    if (this._isDestroyed) {
      if (true) {
        console.warn(`Renderable with id ${this.id} was already destroyed, skipping add`);
      }
      return -1;
    }
    if (renderable.isDestroyed) {
      if (true) {
        console.warn(`Renderable with id ${renderable.id} was already destroyed, skipping add`);
      }
      return -1;
    }
    const anchorRenderable = index !== undefined ? this._childrenInLayoutOrder[index] : undefined;
    if (anchorRenderable) {
      return this.insertBefore(renderable, anchorRenderable);
    }
    return this.placeChild(renderable);
  }
  insertBefore(obj, anchor) {
    if (!anchor) {
      return this.add(obj);
    }
    if (!obj) {
      return -1;
    }
    if (isVNode2(obj))
      this.assertMutable();
    const renderable = maybeMakeRenderable2(this._ctx, obj);
    if (!renderable) {
      return -1;
    }
    if (this._isDestroyed) {
      if (true) {
        console.warn(`Renderable with id ${this.id} was already destroyed, skipping insertBefore`);
      }
      return -1;
    }
    if (renderable.isDestroyed) {
      if (true) {
        console.warn(`Renderable with id ${renderable.id} was already destroyed, skipping insertBefore`);
      }
      return -1;
    }
    if (!isRenderable2(anchor)) {
      throw new Error("Anchor must be a Renderable");
    }
    if (anchor.isDestroyed) {
      if (true) {
        console.warn(`Anchor with id ${anchor.id} was already destroyed, skipping insertBefore`);
      }
      return -1;
    }
    if (this._childrenInLayoutOrder.indexOf(anchor) === -1) {
      if (true) {
        console.warn(`Anchor with id ${anchor.id} does not exist within the parent ${this.id}, skipping insertBefore`);
      }
      return -1;
    }
    if (renderable === anchor) {
      if (true) {
        console.warn(`Anchor is the same as the node ${renderable.id} being inserted, skipping insertBefore`);
      }
      return -1;
    }
    return this.placeChild(renderable, anchor);
  }
  getRenderable(id) {
    return this._childrenInLayoutOrder.find((child) => child.id === id);
  }
  remove(child) {
    if (!(child instanceof BaseRenderable2)) {
      throw new Error("remove expects a renderable child object");
    }
    const index = this._childrenInLayoutOrder.indexOf(child);
    if (index === -1) {
      if (true) {
        console.warn(`Renderable with id ${child.id} is not a child of ${this.id}, skipping remove`);
      }
      return;
    }
    const renderable = this._childrenInLayoutOrder[index];
    this.runMutation(() => {
      this._ctx.nativeScene.moveNode(renderable, null, 0);
      this.removeLayoutChildAt(index);
      this.runCleanup((run) => {
        if (renderable._focused || renderable._hasFocusedDescendant) {
          run(() => renderable.propagateFocusChange(false));
        }
        if (renderable._liveCount > 0)
          run(() => this.propagateLiveCount(-renderable._liveCount));
        run(() => this.requestRender());
        run(() => renderable.onRemove());
        renderable.parent = null;
        run(() => this._ctx.unregisterLifecyclePass(renderable));
      });
    });
  }
  onRemove() {}
  getChildren() {
    return [...this._childrenInLayoutOrder];
  }
  getChildrenCount() {
    return this._childrenInLayoutOrder.length;
  }
  onUpdate(deltaTime) {}
  renderSelf(buffer, deltaTime) {}
  getNativeScenePaint() {
    return {
      zIndex: this._zIndex,
      opacity: this._opacity,
      translateX: this._translateX,
      translateY: this._translateY,
      border: NativeBorder2.None,
      shouldFill: false,
      backgroundColor: RGBA2.fromValues(0, 0, 0, 0),
      borderColor: RGBA2.fromValues(1, 1, 1, 1),
      focusable: this._focusable,
      focusedBorderColor: RGBA2.fromValues(0, 170 / 255, 1, 1),
      borderStyle: "single"
    };
  }
  setNativeScenePaint(paint = this.getNativeScenePaint()) {
    if (this.isFreed())
      return;
    this._ctx.nativeScene.setPaint(this, paint);
  }
  static nativeSceneMethods = nativeSceneMethodNames.map((name) => {
    const normalize = (value) => {
      if (name === "selectable")
        return value;
      if (name === "onLifecyclePass")
        value ??= null;
      else if (name === "renderBefore" || name === "renderAfter")
        value ??= undefined;
      else if (name === "onUpdate")
        value ??= nativeSceneMethodDefaults.onUpdate;
      if (typeof value !== "function" && !((name === "renderBefore" || name === "renderAfter" || name === "onLifecyclePass") && value == null))
        throw new TypeError(`Invalid ${name} hook`);
      return value;
    };
    return {
      name,
      normalize,
      descriptor: {
        configurable: true,
        get() {
          const methods = this._nativeSceneMethods;
          if (methods && name in methods)
            return methods[name];
          return nativeSceneMethodDefaults[name];
        },
        set(value) {
          if (name === "selectable") {
            if (this.isFreed())
              return;
            this.assertMutable();
            this.ensureNativeSceneMethods()[name] = value;
            return;
          }
          value = normalize(value);
          if (value === this[name])
            return;
          this.setNativeSceneHooks(this._nativeSceneHookFlags, { [name]: value });
          this.ensureNativeSceneMethods()[name] = value;
          if (name === "onLifecyclePass") {
            if (!value)
              this._ctx.unregisterLifecyclePass(this);
            else if (this.parent)
              this._ctx.registerLifecyclePass(this);
            else
              this._ctx.nativeScene.lifecyclePasses.refresh(this);
          }
        }
      }
    };
  });
  static {
    const prototype = this.prototype;
    nativeSceneMethodDefaults.renderSelf = prototype.renderSelf;
    nativeSceneMethodDefaults.onResize = prototype.onResize;
    nativeSceneMethodDefaults.onLayoutResize = prototype.onLayoutResize;
    nativeSceneMethodDefaults.onUpdate = prototype.onUpdate;
    for (const method of this.nativeSceneMethods) {
      if (method.name === "renderSelf" || method.name === "onResize" || method.name === "onLayoutResize" || method.name === "onUpdate") {
        this.installNativeSceneMethod(prototype, method, nativeSceneMethodDefaults[method.name]);
      } else {
        Object.defineProperty(prototype, method.name, method.descriptor);
      }
    }
  }
  static defineNativeIntegration(integration) {
    for (const method of Renderable2.nativeSceneMethods) {
      let prototype = this.prototype;
      while (prototype) {
        const descriptor = Object.getOwnPropertyDescriptor(prototype, method.name);
        if (descriptor) {
          if ("value" in descriptor)
            this.installNativeSceneMethod(this.prototype, method, descriptor.value);
          break;
        }
        prototype = Object.getPrototypeOf(prototype);
      }
    }
    return integration;
  }
  static installNativeSceneMethod(prototype, method, handler) {
    const instance = {
      ...method.descriptor,
      get() {
        const methods = this._nativeSceneMethods;
        return methods && method.name in methods ? methods[method.name] : handler;
      }
    };
    Object.defineProperty(prototype, method.name, {
      configurable: true,
      get() {
        return handler;
      },
      set(value) {
        Object.defineProperty(this, method.name, instance);
        method.descriptor.set.call(this, value);
      }
    });
  }
  refreshHooks() {
    if (this._isDestroyed)
      return;
    this.assertMutable();
    try {
      this._scanNativeSceneHooks();
    } catch (error) {
      this._ctx.nativeScene.scheduleHookScan(this);
      throw error;
    }
    this.requestRender();
  }
  _scanNativeSceneHooks() {
    if (!this._isDestroyed)
      this.refreshNativeSceneMethods();
  }
  ensureNativeSceneMethods() {
    return this._nativeSceneMethods ??= {};
  }
  nativeSceneNeedsHookPublish() {
    if (this.buffered)
      return true;
    if (!this.usesNativeDrawing(this.renderSelf))
      return true;
    if (this.hostUpdateFlags(this.onUpdate) !== 0)
      return true;
    const onResize = this.onResize;
    const onLayoutResize = this.onLayoutResize;
    if (onLayoutResize !== nativeSceneMethodDefaults.onLayoutResize)
      return true;
    if (!this._nativeSceneHooksRegistered && this.nativeIntegration.beforeAfter !== false && (this.renderBefore || this.renderAfter))
      return true;
    return this.needsHostResize(onResize);
  }
  usesNativeDrawing(renderSelf) {
    const body = this.nativeIntegration.body;
    return typeof body === "object" && "native" in body && (!this.buffered || body.buffered === true) && renderSelf === body.native;
  }
  needsHostResize(onResize) {
    const resize = this.nativeIntegration.lifecycle?.resize;
    return onResize !== nativeSceneMethodDefaults.onResize && onResize !== resize?.native;
  }
  hostUpdateFlags(onUpdate) {
    const update = this.nativeIntegration.lifecycle?.update;
    if (update && onUpdate === update.idle) {
      return update.active(this) ? NativeSceneHook2.Update : NativeSceneHook2.IdleUpdate;
    }
    return onUpdate === nativeSceneMethodDefaults.onUpdate ? 0 : NativeSceneHook2.Update;
  }
  refreshNativeSceneMethods() {
    this._refreshNativeSceneSurface();
    const methods = Renderable2.nativeSceneMethods;
    for (let index = 0;index < methods.length; index++) {
      const method = methods[index];
      const name = method.name;
      const own = Object.getOwnPropertyDescriptor(this, name);
      if (own?.set === method.descriptor.set)
        continue;
      const handler = method.normalize(this[name]);
      if (!own && handler === nativeSceneMethodDefaults[name])
        continue;
      this.ensureNativeSceneMethods()[name] = handler;
      Object.defineProperty(this, name, method.descriptor);
      if (own)
        this._nativeSceneMethodsPending = true;
    }
    if (this._nativeSceneMethodsPending) {
      this.setNativeSceneHooks(this._nativeSceneHookFlags, {
        onResize: this.onResize,
        onLayoutResize: this.onLayoutResize
      });
      if (!this.onLifecyclePass)
        this._ctx.unregisterLifecyclePass(this);
      else if (this.parent)
        this._ctx.registerLifecyclePass(this);
      else
        this._ctx.nativeScene.lifecyclePasses.refresh(this);
      this._nativeSceneMethodsPending = false;
    }
  }
  refreshNativeSceneHooks() {
    this.setNativeSceneHooks(this._nativeSceneHookFlags);
  }
  _refreshNativeSceneSurface() {}
  setNativeSceneHooks(flags, overrides = {}, lineInfo) {
    if (this.isFreed())
      return;
    const scene = this._ctx.nativeScene;
    const previousFlags = this._nativeSceneHookFlags;
    const previousGeneration = this._nativeSceneHookGeneration;
    const method = (name) => (name in overrides) ? overrides[name] : this[name];
    const onUpdate = method("onUpdate");
    flags = flags & ~nativeSceneHookHostMethods | (method("renderBefore") ? NativeSceneHook2.RenderBefore : 0) | (method("renderAfter") ? NativeSceneHook2.RenderAfter : 0);
    const renderSelf = method("renderSelf");
    if (!this.usesNativeDrawing(renderSelf))
      flags |= NativeSceneHook2.RenderSelf;
    const overridden = ("onUpdate" in overrides ? nativeSceneHookUpdates : 0) | ("onResize" in overrides || "onLayoutResize" in overrides ? NativeSceneHook2.Resize : 0) | ("renderBefore" in overrides ? NativeSceneHook2.RenderBefore : 0) | ("renderAfter" in overrides ? NativeSceneHook2.RenderAfter : 0) | ("renderSelf" in overrides ? NativeSceneHook2.RenderSelf : 0);
    const changed = (previousFlags ^ this._nativeSceneHookFlags) & ~overridden;
    flags = flags & ~changed | this._nativeSceneHookFlags & changed;
    const resizeCallbacks = {
      onResize: "onResize" in overrides ? overrides.onResize : this._nativeSceneResizeCallbacks?.onResize ?? this.onResize,
      onLayoutResize: "onLayoutResize" in overrides ? overrides.onLayoutResize : this._nativeSceneResizeCallbacks?.onLayoutResize ?? this.onLayoutResize
    };
    const resize = this.buffered || resizeCallbacks.onLayoutResize !== Renderable2.prototype.onLayoutResize || this.needsHostResize(resizeCallbacks.onResize);
    if (this._nativeSceneResize !== resize)
      flags = flags & ~NativeSceneHook2.Resize | (this._sizeChangeListener || this.listenerCount("resize") ? NativeSceneHook2.Resize : 0);
    if (resize)
      flags |= NativeSceneHook2.Resize;
    lineInfo ??= !!this.nativeIntegration.lineInfo && this.listenerCount("line-info-change") > 0;
    const update = "onUpdate" in overrides || previousGeneration === this._nativeSceneHookGeneration ? this.hostUpdateFlags(onUpdate) : this._nativeSceneHookFlags & nativeSceneHookUpdates;
    flags = flags & ~nativeSceneHookUpdates | update;
    const generation = this._nativeSceneHookGeneration + 1n;
    if (flags !== 0 || lineInfo || this._nativeSceneHooksRegistered) {
      let nativeFlags = flags;
      if (this.nativeIntegration.beforeAfter === false) {
        nativeFlags &= ~nativeSceneHookBeforeAfter;
      }
      const nativeResize = this.nativeIntegration.lifecycle?.resize;
      if (!resize && nativeResize) {
        nativeFlags = nativeFlags & ~NativeSceneHook2.Resize | (lineInfo && this.nativeIntegration.lineInfo ? NativeSceneHook2.Resize : 0);
      }
      if (nativeFlags & NativeSceneHook2.RenderSelf)
        nativeFlags |= NativeSceneHook2.RenderAfter;
      scene.setHooks(this, nativeFlags, generation, this.styledDimension("width"), this.styledDimension("height"));
      this._nativeSceneHooksRegistered = true;
    }
    this._nativeSceneResizeCallbacks = resize ? resizeCallbacks : undefined;
    this._nativeSceneResize = resize;
    this._nativeSceneHookFlags = flags;
    this._nativeSceneHookGeneration = generation;
  }
  _runNativeSceneHook(request, deltaTime) {
    if (this._isDestroyed || request.hookGeneration !== this._nativeSceneHookGeneration)
      return;
    const previousLayout = this._nativeSceneHookLayout;
    const revision = this._ctx.nativeScene.currentGeometryRevision;
    const currentGeometry = request.geometryRevision === revision;
    this._nativeSceneHookLayout = { revision, layout: currentGeometry ? request.publicLayout : undefined };
    try {
      switch (request.kind) {
        case NativeSceneFrame2.Update:
          this.onUpdate(deltaTime);
          break;
        case NativeSceneFrame2.Resize:
          if (this._nativeSceneResize) {
            this._nativeSceneHookLayout.paintLayout = currentGeometry && request.paintLayout || this._ctx.nativeScene.getLayout(this, "paint");
            this._nativeSceneHookLayout.paintRevision = revision;
            this.onLayoutResize(request.width, request.height);
          } else {
            const resize = this.nativeIntegration.lifecycle?.resize;
            if (!resize) {
              this.onSizeChange?.call(this);
              if (!this._isDestroyed)
                this.emit("resize");
            }
            if (!this._isDestroyed && this.nativeIntegration.lineInfo)
              this.emit("line-info-change");
          }
          break;
        case NativeSceneFrame2.LayoutChanged:
          this.emit("layout-changed" /* LAYOUT_CHANGED */);
          break;
      }
    } finally {
      this._nativeSceneHookLayout = previousLayout;
    }
  }
  _recordNativeScenePaint(slot, index, deltaTime, frame, recorder, geometryRevision) {
    if (this._isDestroyed)
      return;
    const previousLayout = this._nativeSceneHookLayout;
    const revision = this._ctx.nativeScene.currentGeometryRevision;
    this._nativeSceneHookLayout = {
      revision,
      layout: geometryRevision === revision ? slot.publicLayout : undefined,
      paintLayout: slot.paintLayout,
      paintRevision: revision
    };
    const buffer = this.nativeIntegration.paintBuffer !== "destination" && this.nativeIntegration.bufferComposition !== "native" && this.buffered && this.frameBuffer ? this.frameBuffer : frame;
    try {
      if (slot.hooks & NativeSceneHook2.RenderBefore) {
        recorder.slot(index, NativeScenePaintPhase2.Before, slot.opacity);
        this.renderBefore?.call(this, buffer, deltaTime);
        if (this._isDestroyed)
          return;
      }
      if (slot.hooks & NativeSceneHook2.RenderSelf) {
        recorder.slot(index, NativeScenePaintPhase2.Self, slot.opacity);
        if (this.nativeIntegration.beforeAfter === false)
          this.markClean();
        this._invokeNativePaint(buffer, deltaTime);
        if (this._isDestroyed)
          return;
      }
      if (slot.hooks & NativeSceneHook2.RenderAfter) {
        recorder.slot(index, NativeScenePaintPhase2.After, slot.opacity);
        if (this.nativeIntegration.beforeAfter !== false) {
          this.renderAfter?.call(this, buffer, deltaTime);
          this.markClean();
        }
        if (!this._isDestroyed && this.nativeIntegration.bufferComposition !== "native" && this.buffered && this.frameBuffer)
          frame.drawFrameBuffer(Math.trunc(this._screenX), Math.trunc(this._screenY), this.frameBuffer);
      }
    } finally {
      this._nativeSceneHookLayout = previousLayout;
    }
  }
  _invokeNativePaint(buffer, deltaTime) {
    this.renderSelf(buffer, deltaTime);
  }
  get isDestroyed() {
    return this._isDestroyed;
  }
  destroy() {
    if (this._isDestroyed || this._cleanupInProgress || this._childCleanupInProgress) {
      return;
    }
    this.assertMutable();
    this.destroyLayoutBacking((run) => {
      run(() => this.destroyOwnedResources());
      this._isDestroyed = true;
      run(() => this.emit("destroyed" /* DESTROYED */));
      if (this._focused || this._hasFocusedDescendant) {
        run(() => {
          const current = this._ctx.currentFocusedRenderable;
          let focused = current;
          while (focused && focused !== this)
            focused = focused.parent;
          if (!current || focused === this)
            this.propagateFocusChange(false);
        });
      }
      if (this.parent) {
        const parent = this.parent;
        run(() => parent.remove(this));
        if (this.parent === parent) {
          run(() => this.detachFromParent());
        }
      }
      if (this.frameBuffer) {
        const frameBuffer = this.frameBuffer;
        this.frameBuffer = null;
        run(() => frameBuffer.destroy());
      }
      for (const child of [...this._childrenInLayoutOrder]) {
        run(() => this.remove(child));
      }
      this._childrenInLayoutOrder = [];
      Renderable2.renderablesByNumber.delete(this.num);
      run(() => this.blur());
      run(() => this.removeAllListeners());
      run(() => this.destroySelf());
    });
  }
  destroyRecursively() {
    if (this._isDestroyed || this._cleanupInProgress || this._childCleanupInProgress)
      return;
    this.assertMutable();
    const children = [...this._childrenInLayoutOrder];
    let index = 0;
    this._childCleanupInProgress = true;
    const cleanupOwners = this._ctx.nativeScene.cleanupOwners;
    const ownsCompletion = !cleanupOwners.has(this);
    cleanupOwners.add(this);
    const resume = () => this.runCleanup((run) => {
      while (index < children.length) {
        const child = children[index++];
        run(() => child.destroyRecursively());
        if (child._cleanupInProgress || child._childCleanupInProgress) {
          (child._deferredCleanup ??= []).push(resume);
          return;
        }
      }
      this._childCleanupInProgress = false;
      run(() => this.destroy());
      if (ownsCompletion)
        this.completeCleanup(run);
    });
    resume();
  }
  _deferUntilCleanupComplete(resume) {
    const pending = [this];
    while (pending.length > 0) {
      const node = pending.pop();
      if (node._cleanupInProgress || node._childCleanupInProgress) {
        (node._deferredCleanup ??= []).push(resume);
        return true;
      }
      for (const child of node._childrenInLayoutOrder)
        pending.push(child);
    }
    for (const node of this._ctx.nativeScene.cleanupOwners) {
      (node._deferredCleanup ??= []).push(resume);
      return true;
    }
    return false;
  }
  destroyOwnedResources() {}
  destroySelf() {}
  destroyLayoutBacking(cleanup) {
    const scene = this._ctx.nativeScene;
    const hasHandle = !!this._sceneHandle && !this._yogaFreed;
    this._cleanupInProgress = true;
    const cleanupOwners = scene.cleanupOwners;
    const ownsCompletion = !cleanupOwners.has(this);
    cleanupOwners.add(this);
    this.runCleanup((run) => {
      if (hasHandle && this.selectable) {
        run(() => {
          const layout = scene.getLayout(this);
          this._destroyedLayout = {
            x: layout.left,
            y: layout.top,
            screenX: layout.screenX,
            screenY: layout.screenY,
            width: layout.width === 0 ? this.styledDimension("width") : layout.width,
            height: layout.height === 0 ? this.styledDimension("height") : layout.height
          };
        });
      }
      if (cleanup)
        run(() => cleanup(run));
      this._isDestroyed = true;
      if (hasHandle)
        run(() => scene.destroyNode(this));
      this._cleanupInProgress = false;
      if (ownsCompletion)
        this.completeCleanup(run);
    });
  }
  completeCleanup(run) {
    this._ctx.nativeScene.cleanupOwners.delete(this);
    const deferred = this._deferredCleanup;
    this._deferredCleanup = undefined;
    if (deferred)
      for (const resume of deferred)
        run(resume);
  }
  removeLayoutChildAt(index) {
    const children = this._childrenInLayoutOrder;
    if (index === children.length - 1)
      children.pop();
    else
      children.splice(index, 1);
  }
  detachFromParent() {
    const parent = this.parent;
    if (!parent)
      return;
    const layoutIndex = parent._childrenInLayoutOrder.indexOf(this);
    if (layoutIndex !== -1) {
      this._ctx.nativeScene.moveNode(this, null, 0);
      parent.removeLayoutChildAt(layoutIndex);
      if (this._liveCount > 0) {
        parent.propagateLiveCount(-this._liveCount);
      }
    }
    parent._ctx.unregisterLifecyclePass(this);
    this.parent = null;
  }
  processMouseEvent(event) {
    event.currentTarget = this;
    this._mouseListener?.call(this, event);
    if (this._isDestroyed)
      return;
    this._mouseListeners[event.type]?.call(this, event);
    if (this._isDestroyed)
      return;
    this.onMouseEvent(event);
    if (this.parent && !event.propagationStopped) {
      this.parent.processMouseEvent(event);
    }
  }
  assertSupportedEvent(event) {
    if ((event === "resized" /* RESIZED */ || event === "layout-changed" /* LAYOUT_CHANGED */) && !(this instanceof RootRenderable2)) {
      throw new Error(`Native scene does not support ${event} hooks`);
    }
  }
  on(event, listener) {
    return this.changeSceneListeners("add", event, listener);
  }
  addListener(event, listener) {
    return this.changeSceneListeners("add", event, listener);
  }
  prependListener(event, listener) {
    return this.changeSceneListeners("prepend", event, listener);
  }
  off(event, listener) {
    return this.changeSceneListeners("remove", event, listener);
  }
  removeListener(event, listener) {
    return this.changeSceneListeners("remove", event, listener);
  }
  removeAllListeners(event) {
    if (arguments.length > 0 && event === undefined)
      return super.removeAllListeners(event);
    return this.changeSceneListeners("clear", event);
  }
  changeSceneListeners(operation, event, listener) {
    if (operation === "add" || operation === "prepend")
      this.assertSupportedEvent(event);
    const change = () => {
      switch (operation) {
        case "add":
          return super.addListener(event, listener);
        case "prepend":
          return super.prependListener(event, listener);
        case "remove":
          return super.removeListener(event, listener);
        case "clear":
          return event === undefined ? super.removeAllListeners() : super.removeAllListeners(event);
      }
    };
    if (this._isDestroyed || event === "line-info-change" && !this.nativeIntegration.lineInfo || (operation !== "clear" || event !== undefined) && event !== "resize" && event !== "line-info-change" && event !== "layout-changed" /* LAYOUT_CHANGED */ || operation !== "clear" && typeof listener !== "function") {
      return change();
    }
    let resize = this.listenerCount("resize");
    const initialLineInfo = this.nativeIntegration.lineInfo ? this.listenerCount("line-info-change") : 0;
    let lineInfo = initialLineInfo;
    let layout = this.listenerCount("layout-changed" /* LAYOUT_CHANGED */);
    if (operation === "clear") {
      if (event === undefined || event === "resize")
        resize = 0;
      if (event === undefined || event === "line-info-change")
        lineInfo = 0;
      if (event === undefined || event === "layout-changed" /* LAYOUT_CHANGED */)
        layout = 0;
      const changed = resize !== this.listenerCount("resize") || lineInfo !== initialLineInfo || layout !== this.listenerCount("layout-changed" /* LAYOUT_CHANGED */);
      if (!changed)
        return change();
    } else {
      if (operation === "remove" && !this.rawListeners(event).some((entry) => entry === listener || entry.listener === listener)) {
        return change();
      }
      const delta = operation === "remove" ? -1 : 1;
      if (event === "resize")
        resize += delta;
      else if (event === "line-info-change")
        lineInfo += delta;
      else
        layout += delta;
    }
    this.setNativeSceneHooks(this._nativeSceneHookFlags & ~nativeSceneHookListeners | (resize > 0 || this._sizeChangeListener ? NativeSceneHook2.Resize : 0) | (layout > 0 ? NativeSceneHook2.LayoutChanged : 0), {}, lineInfo > 0);
    this.runCleanup((run) => {
      run(change);
      run(() => {
        if (!this._isDestroyed) {
          const flags = this._nativeSceneHookFlags & ~nativeSceneHookListeners | (this.listenerCount("resize") > 0 || this._sizeChangeListener ? NativeSceneHook2.Resize : 0) | (this.listenerCount("layout-changed" /* LAYOUT_CHANGED */) > 0 ? NativeSceneHook2.LayoutChanged : 0);
          this.setNativeSceneHooks(flags);
        }
      });
    });
    return this;
  }
  onMouseEvent(event) {}
  set onMouse(handler) {
    if (handler)
      this._mouseListener = handler;
    else
      this._mouseListener = null;
  }
  set onMouseDown(handler) {
    if (handler)
      this._mouseListeners["down"] = handler;
    else
      delete this._mouseListeners["down"];
  }
  set onMouseUp(handler) {
    if (handler)
      this._mouseListeners["up"] = handler;
    else
      delete this._mouseListeners["up"];
  }
  set onMouseMove(handler) {
    if (handler)
      this._mouseListeners["move"] = handler;
    else
      delete this._mouseListeners["move"];
  }
  set onMouseDrag(handler) {
    if (handler)
      this._mouseListeners["drag"] = handler;
    else
      delete this._mouseListeners["drag"];
  }
  set onMouseDragEnd(handler) {
    if (handler)
      this._mouseListeners["drag-end"] = handler;
    else
      delete this._mouseListeners["drag-end"];
  }
  set onMouseDrop(handler) {
    if (handler)
      this._mouseListeners["drop"] = handler;
    else
      delete this._mouseListeners["drop"];
  }
  set onMouseOver(handler) {
    if (handler)
      this._mouseListeners["over"] = handler;
    else
      delete this._mouseListeners["over"];
  }
  set onMouseOut(handler) {
    if (handler)
      this._mouseListeners["out"] = handler;
    else
      delete this._mouseListeners["out"];
  }
  set onMouseScroll(handler) {
    if (handler)
      this._mouseListeners["scroll"] = handler;
    else
      delete this._mouseListeners["scroll"];
  }
  set onPaste(handler) {
    this._pasteListener = handler;
  }
  get onPaste() {
    return this._pasteListener;
  }
  set onKeyDown(handler) {
    if (handler)
      this._keyListeners["down"] = handler;
    else
      delete this._keyListeners["down"];
  }
  get onKeyDown() {
    return this._keyListeners["down"];
  }
  set onSizeChange(handler) {
    if (handler !== this._sizeChangeListener) {
      if (handler != null && typeof handler !== "function")
        throw new TypeError("Invalid size change hook");
      const flags = this._nativeSceneHookFlags & ~NativeSceneHook2.Resize;
      this.setNativeSceneHooks(flags | (handler || this.listenerCount("resize") > 0 ? NativeSceneHook2.Resize : 0));
    }
    this._sizeChangeListener = handler;
  }
  get onSizeChange() {
    return this._sizeChangeListener;
  }
  applyEventOptions(options) {
    this.onMouse = options.onMouse;
    this.onMouseDown = options.onMouseDown;
    this.onMouseUp = options.onMouseUp;
    this.onMouseMove = options.onMouseMove;
    this.onMouseDrag = options.onMouseDrag;
    this.onMouseDragEnd = options.onMouseDragEnd;
    this.onMouseDrop = options.onMouseDrop;
    this.onMouseOver = options.onMouseOver;
    this.onMouseOut = options.onMouseOut;
    this.onMouseScroll = options.onMouseScroll;
    this.onPaste = options.onPaste;
    this.onKeyDown = options.onKeyDown;
    this.onSizeChange = options.onSizeChange;
  }
}

class RootRenderable2 extends Renderable2 {
  static nativeIntegration = this.defineNativeIntegration({
    ...Renderable2.nativeIntegration,
    kind: "root",
    construction: "prototype"
  });
  _currentRenderable;
  constructor(ctx) {
    super(ctx, {
      id: "__root__",
      zIndex: 0,
      visible: true,
      width: ctx.width,
      height: ctx.height,
      enableLayout: true
    });
    try {
      this.setNativeScenePaint();
    } catch (error) {
      this.abortConstruction(error);
    }
  }
  get currentRenderable() {
    return this._currentRenderable;
  }
  _setCurrentRenderable(renderable) {
    this._currentRenderable = renderable;
  }
  takeCurrentRenderable() {
    const renderable = this._currentRenderable;
    this._currentRenderable = undefined;
    return renderable;
  }
  propagateLiveCount(delta) {
    const oldCount = this._liveCount;
    this._liveCount += delta;
    this.onLiveCountChanged(oldCount);
  }
  onLiveCountChanged(previous) {
    if (previous === 0 && this._liveCount > 0) {
      this._ctx.requestLive();
    } else if (previous > 0 && this._liveCount === 0) {
      this._ctx.dropLive();
    }
  }
  resize(width, height) {
    this.width = width;
    this.height = height;
    this.emit("resized" /* RESIZED */, { width, height });
  }
}

// src/text-buffer.ts
import { readFileSync } from "fs";
class TextBuffer2 {
  lib;
  native;
  _length = 0;
  _byteSize = 0;
  _destroyed = false;
  _syntaxStyle;
  constructor(lib, handle, source) {
    const owner = source?.resourceContext;
    if (!owner)
      throw new Error("TextBuffer requires an explicit resource owner");
    owner.assertAlive();
    if (owner.renderLib !== lib || !handle || typeof handle !== "object" || handle.context !== owner.context) {
      throw new Error("TextBuffer Context owner mismatch");
    }
    this.lib = lib;
    this.native = { owner, handle };
    this.updateLengths();
  }
  static create(widthMethod, source) {
    const owner = source?.resourceContext;
    if (!owner)
      throw new Error("TextBuffer requires an explicit resource owner: pass renderer.nativeScene, or a ResourceContext when there is no renderer");
    owner.assertAlive();
    const lib = owner.renderLib;
    const handle = lib.createContextTextBuffer(owner.context, { widthMethod });
    try {
      return new TextBuffer2(lib, handle, owner);
    } catch (error) {
      lib.destroyContextTextBuffer(owner.context, handle);
      throw error;
    }
  }
  guard() {
    if (this._destroyed)
      throw new Error("TextBuffer is destroyed");
    this.native.owner.assertAlive();
  }
  _getOwner() {
    this.guard();
    return this.native.owner;
  }
  _getSceneHandle(scene) {
    this.guard();
    if (this.native.owner !== scene.resourceContext)
      throw new Error("TextBuffer Context owner mismatch");
    return this.native.handle;
  }
  updateLengths() {
    const info = this.lib.contextTextBufferGetInfo(this.native.handle.context, this.native.handle);
    this._length = info.textLength;
    this._byteSize = info.byteLength;
  }
  setText(text) {
    this.guard();
    this.lib.getYogaHost().runMutation(() => {
      const textBytes = this.lib.encoder.encode(text);
      this.lib.contextTextBufferSetText(this.native.handle.context, this.native.handle, textBytes);
      this.updateLengths();
    });
  }
  append(text) {
    this.guard();
    this.lib.getYogaHost().runMutation(() => {
      const textBytes = this.lib.encoder.encode(text);
      this.lib.contextTextBufferAppend(this.native.handle.context, this.native.handle, textBytes);
      this.updateLengths();
    });
  }
  loadFile(path) {
    this.guard();
    this.lib.getYogaHost().runMutation(() => {
      let bytes;
      try {
        bytes = readFileSync(path);
      } catch (cause) {
        throw new Error(`Failed to load file: ${path}`, { cause });
      }
      this.lib.contextTextBufferSetText(this.native.handle.context, this.native.handle, bytes);
      this.updateLengths();
    });
  }
  setStyledText(text) {
    this.guard();
    this.lib.getYogaHost().runMutation(() => {
      const chunks = text.chunks;
      if (Array.isArray(chunks) && chunks.length === 0) {
        this.lib.contextTextBufferClear(this.native.handle.context, this.native.handle);
      } else {
        this.lib.contextTextBufferSetStyledText(this.native.handle.context, this.native.handle, new StyledText2(chunks));
      }
      this.updateLengths();
    });
  }
  _setEncodedStyledText(text) {
    this.guard();
    this.lib.getYogaHost().runMutation(() => {
      this.lib.contextTextBufferSetEncodedStyledText(this.native.handle.context, this.native.handle, text);
      this.updateLengths();
    });
  }
  static _replaceStyledTextBatch(replacements, beforeNative) {
    if (replacements.length === 0) {
      beforeNative();
      return true;
    }
    const owner = replacements[0].textBuffer._getOwner();
    const lib = owner.renderLib;
    const entries = replacements.map(({ textBuffer, textBufferView, text }) => ({
      buffer: textBuffer._getSceneHandle(owner),
      view: textBufferView._getSceneHandle(owner),
      text
    }));
    return lib.getYogaHost().runMutation(() => {
      const info = lib.contextTextBufferReplaceStyledBatch(owner.context, entries, beforeNative);
      if (info === null)
        return false;
      for (let index = 0;index < replacements.length; index++) {
        replacements[index].textBuffer._length = info[index * 2];
        replacements[index].textBuffer._byteSize = info[index * 2 + 1];
      }
      return true;
    });
  }
  setDefaults(mask, style) {
    this.guard();
    this.lib.contextTextBufferSetDefaults(this.native.handle.context, this.native.handle, mask, style);
  }
  _setDefaults(fg, bg, attributes) {
    this.setDefaults(7 /* All */, { fg, bg, attributes });
  }
  setDefaultFg(fg) {
    this.setDefaults(1 /* Foreground */, { fg });
  }
  setDefaultBg(bg) {
    this.setDefaults(2 /* Background */, { bg });
  }
  setDefaultAttributes(attributes) {
    this.setDefaults(4 /* Attributes */, { attributes });
  }
  resetDefaults() {
    this.setDefaults(7 /* All */, {});
  }
  getLineCount() {
    this.guard();
    return this.lib.contextTextBufferGetInfo(this.native.handle.context, this.native.handle).lineCount;
  }
  get length() {
    this.guard();
    return this._length;
  }
  get byteSize() {
    this.guard();
    return this._byteSize;
  }
  getPlainText() {
    this.guard();
    return this.lib.contextTextBufferGetText(this.native.handle.context, this.native.handle);
  }
  getTextRange(startOffset, endOffset) {
    this.guard();
    if (startOffset >= endOffset)
      return "";
    return this.lib.contextTextBufferGetRange(this.native.handle.context, this.native.handle, startOffset, endOffset);
  }
  highlight(operation, argument, highlight) {
    this.guard();
    this.lib.contextTextBufferHighlight(this.native.handle.context, this.native.handle, operation, argument, highlight);
  }
  addHighlightByCharRange(highlight) {
    this.highlight(1 /* AddRange */, 0, highlight);
  }
  addHighlight(lineIdx, highlight) {
    this.highlight(0 /* AddLine */, lineIdx, highlight);
  }
  removeHighlightsByRef(hlRef) {
    this.highlight(2 /* RemoveRef */, hlRef);
  }
  clearLineHighlights(lineIdx) {
    this.highlight(3 /* ClearLine */, lineIdx);
  }
  clearAllHighlights() {
    this.highlight(4 /* ClearAll */);
  }
  getLineHighlights(lineIdx) {
    this.guard();
    return this.lib.contextTextBufferGetHighlights(this.native.handle.context, this.native.handle, lineIdx);
  }
  getHighlightCount() {
    this.guard();
    return this.lib.contextTextBufferGetInfo(this.native.handle.context, this.native.handle).highlightCount;
  }
  setSyntaxStyle(style) {
    this.guard();
    this.lib.getYogaHost().runMutation(() => {
      this.lib.contextTextBufferSetSyntaxStyle(this.native.handle.context, this.native.handle, style?._getSceneHandle(this.native.owner) ?? null);
      this._syntaxStyle = style ?? undefined;
    });
  }
  getSyntaxStyle() {
    this.guard();
    return this._syntaxStyle ?? null;
  }
  setTabWidth(width) {
    this.guard();
    this.lib.getYogaHost().runMutation(() => {
      this.lib.contextTextBufferSetTabWidth(this.native.handle.context, this.native.handle, width);
      this.updateLengths();
    });
  }
  getTabWidth() {
    this.guard();
    return this.lib.contextTextBufferGetInfo(this.native.handle.context, this.native.handle).tabWidth;
  }
  clear() {
    this.guard();
    this.lib.getYogaHost().runMutation(() => {
      this.lib.contextTextBufferClear(this.native.handle.context, this.native.handle);
      this._length = 0;
      this._byteSize = 0;
    });
  }
  reset() {
    this.guard();
    this.lib.getYogaHost().runMutation(() => {
      this.lib.contextTextBufferClear(this.native.handle.context, this.native.handle, true);
      this._length = 0;
      this._byteSize = 0;
    });
  }
  destroy() {
    if (this._destroyed)
      return;
    this.lib.getYogaHost().runMutation(() => {
      if (!this.native.owner.disposed) {
        try {
          this.lib.releaseAfterPaint(this.native.handle.context, () => this.lib.destroyContextTextBuffer(this.native.handle.context, this.native.handle));
        } catch (error) {
          if (!(error instanceof NativeError2) || error.status !== -9 /* StaleHandle */)
            throw error;
        }
      }
      this._destroyed = true;
      this._syntaxStyle = undefined;
    });
  }
}

// src/text-buffer-view.ts
class TextBufferView2 {
  lib;
  native;
  textBuffer;
  _destroyed = false;
  selectionClear = true;
  constructor(lib, handle, textBuffer, source) {
    const owner = source?.resourceContext;
    if (!owner)
      throw new Error("TextBufferView requires an explicit resource owner");
    owner.assertAlive();
    if (owner.renderLib !== lib)
      throw new Error("TextBufferView library owner mismatch");
    if (textBuffer._getOwner() !== owner || !handle || typeof handle !== "object" || handle.context !== owner.context) {
      throw new Error("TextBufferView Context owner mismatch");
    }
    this.lib = lib;
    this.native = { owner, handle };
    this.textBuffer = textBuffer;
  }
  static create(textBuffer) {
    const owner = textBuffer._getOwner();
    const lib = owner.renderLib;
    const handle = lib.createContextTextBufferView(owner.context, textBuffer._getSceneHandle(owner));
    try {
      return new TextBufferView2(lib, handle, textBuffer, owner);
    } catch (error) {
      lib.destroyContextTextBufferView(owner.context, handle);
      throw error;
    }
  }
  guard() {
    if (this._destroyed)
      throw new Error("TextBufferView is destroyed");
    this.native.owner.assertAlive();
    this.textBuffer._getSceneHandle(this.native.owner);
  }
  _getOwner() {
    this.guard();
    return this.native.owner;
  }
  _getSceneHandle(scene) {
    this.guard();
    if (this.native.owner !== scene.resourceContext)
      throw new Error("TextBufferView Context owner mismatch");
    return this.native.handle;
  }
  select(selection) {
    this.guard();
    this.selectionClear = false;
    return this.lib.contextTextBufferViewSelect(this.native.handle.context, this.native.handle, selection);
  }
  reset(local) {
    this.guard();
    const { context } = this.native.handle;
    this.lib.contextTextBufferViewResetSelection(context, this.native.handle, local, this.selectionClear);
    this.selectionClear = true;
  }
  setSelection(start, end, bgColor, fgColor) {
    this.select({ operation: 0 /* Set */, start, end, bg: bgColor, fg: fgColor });
  }
  updateSelection(end, bgColor, fgColor) {
    this.select({ operation: 1 /* Update */, end, bg: bgColor, fg: fgColor });
  }
  resetSelection() {
    this.reset(false);
  }
  getSelection() {
    this.guard();
    return this.lib.contextTextBufferViewGetInfo(this.native.handle.context, this.native.handle).selection;
  }
  hasSelection() {
    this.guard();
    return this.getSelection() !== null;
  }
  setLocalSelection(anchorX, anchorY, focusX, focusY, bgColor, fgColor, behavior = "cell") {
    return this.select({
      operation: 3 /* Local */,
      anchorX,
      anchorY,
      focusX,
      focusY,
      bg: bgColor,
      fg: fgColor,
      behavior: behavior === "cell" ? 0 : behavior === "word" ? 1 : 2
    });
  }
  updateLocalSelection(anchorX, anchorY, focusX, focusY, bgColor, fgColor, behavior = "cell") {
    return this.select({
      operation: 4 /* LocalUpdate */,
      anchorX,
      anchorY,
      focusX,
      focusY,
      bg: bgColor,
      fg: fgColor,
      behavior: behavior === "cell" ? 0 : behavior === "word" ? 1 : 2
    });
  }
  resetLocalSelection() {
    this.reset(true);
  }
  setSelectionOccupancy(occupancy) {
    this.guard();
    this.lib.contextTextBufferViewSelect(this.native.handle.context, this.native.handle, {
      operation: 7 /* Occupancy */,
      behavior: occupancy === "boundary" ? 1 : 0
    });
  }
  getSelectionOccupancy() {
    this.guard();
    return this.lib.contextTextBufferViewGetInfo(this.native.handle.context, this.native.handle).selectionOccupancy;
  }
  command(command, argument) {
    this.guard();
    this.lib.contextTextBufferViewCommand(this.native.handle.context, this.native.handle, command, argument);
  }
  setWrapWidth(width) {
    this.command(0 /* WrapWidth */, width ?? 0);
  }
  setWrapMode(mode) {
    this.command(1 /* WrapMode */, mode === "none" ? 0 : mode === "char" ? 1 : 2);
  }
  setTextAlign(alignment) {
    this.command(5 /* TextAlign */, alignment === "left" ? 0 : alignment === "center" ? 1 : 2);
  }
  setFirstLineOffset(offset) {
    this.command(2 /* FirstLineOffset */, offset);
  }
  setViewportSize(width, height) {
    this.guard();
    return this.lib.contextTextBufferViewSetViewport(this.native.handle.context, this.native.handle, { x: 0, y: 0, width, height }, true);
  }
  setViewport(x, y, width, height) {
    this.guard();
    return this.lib.contextTextBufferViewSetViewport(this.native.handle.context, this.native.handle, {
      x,
      y,
      width,
      height
    });
  }
  get lineInfo() {
    this.guard();
    return this.lib.contextTextBufferViewGetLines(this.native.handle.context, this.native.handle);
  }
  get logicalLineInfo() {
    this.guard();
    return this.lib.contextTextBufferViewGetLines(this.native.handle.context, this.native.handle, true);
  }
  getLineSources(startLine, lineCount) {
    this.guard();
    const { context } = this.native.handle;
    return this.lib.contextTextBufferViewGetLines(context, this.native.handle, true, startLine, lineCount).lineSources;
  }
  getSelectedText() {
    this.guard();
    return this.lib.contextTextBufferViewGetSelectedText(this.native.handle.context, this.native.handle);
  }
  getPlainText() {
    this.guard();
    return this.textBuffer.getPlainText();
  }
  setTabIndicator(indicator) {
    const codePoint = typeof indicator === "string" ? indicator.codePointAt(0) ?? 0 : indicator;
    this.command(3 /* TabIndicator */, codePoint);
  }
  setTabIndicatorColor(color) {
    this.guard();
    return this.lib.contextTextBufferViewSetTabColor(this.native.handle.context, this.native.handle, color);
  }
  setTruncate(truncate) {
    this.command(4 /* Truncate */, truncate ? 1 : 0);
  }
  measureForDimensions(width, height) {
    this.guard();
    return this.lib.contextTextBufferViewMeasure(this.native.handle.context, this.native.handle, width, height);
  }
  getVirtualLineCount() {
    this.guard();
    return this.lib.contextTextBufferViewGetInfo(this.native.handle.context, this.native.handle).virtualLineCount;
  }
  destroy() {
    if (this._destroyed)
      return;
    this.lib.getYogaHost().runMutation(() => {
      if (!this.native.owner.disposed) {
        try {
          this.lib.releaseAfterPaint(this.native.handle.context, () => this.lib.destroyContextTextBufferView(this.native.handle.context, this.native.handle));
        } catch (error) {
          if (!(error instanceof NativeError2) || error.status !== -9 /* StaleHandle */)
            throw error;
        }
      }
      this._destroyed = true;
    });
  }
}

// src/edit-buffer.ts
import { EventEmitter as EventEmitter5 } from "events";

class EditBuffer2 extends EventEmitter5 {
  lib;
  native;
  unsubscribe;
  id;
  _destroyed = false;
  _syntaxStyle;
  constructor(lib, handle, source) {
    super();
    const owner = source?.resourceContext;
    if (!owner)
      throw new Error("EditBuffer requires an explicit resource owner");
    owner.assertAlive();
    if (owner.renderLib !== lib || !handle || typeof handle !== "object" || handle.context !== owner.context) {
      throw new Error("EditBuffer Context owner mismatch");
    }
    this.lib = lib;
    this.native = { owner, handle };
    this.id = handle.slot;
    this.unsubscribe = lib.onContextEditEvent(handle.context, handle, (name) => {
      if (!this._destroyed && !owner.disposed)
        this.emit(name);
    });
  }
  static create(widthMethod, source) {
    const owner = source?.resourceContext;
    if (!owner)
      throw new Error("EditBuffer requires an explicit resource owner: pass renderer.nativeScene, or a ResourceContext when there is no renderer");
    owner.assertAlive();
    const lib = owner.renderLib;
    const handle = lib.createContextEditBuffer(owner.context, { widthMethod });
    try {
      return new EditBuffer2(lib, handle, owner);
    } catch (error) {
      lib.destroyContextEditBuffer(owner.context, handle);
      throw error;
    }
  }
  guard() {
    if (this._destroyed)
      throw new Error("EditBuffer is destroyed");
    this.native.owner.assertAlive();
  }
  _getOwner() {
    this.guard();
    return this.native.owner;
  }
  _getSceneHandle(scene) {
    this.guard();
    if (this.native.owner !== scene.resourceContext)
      throw new Error("EditBuffer Context owner mismatch");
    return this.native.handle;
  }
  runMutation(operation) {
    this.guard();
    return this.lib.getYogaHost().runMutation(operation);
  }
  command(command, argument) {
    this.guard();
    this.lib.contextEditBufferCommand(this.native.handle.context, this.native.handle, command, argument);
  }
  position(query, a, b) {
    this.guard();
    return this.lib.contextEditBufferGetPosition(this.native.handle.context, this.native.handle, query, a, b);
  }
  highlight(operation, argument, highlight) {
    this.guard();
    this.lib.contextEditBufferHighlight(this.native.handle.context, this.native.handle, operation, argument, highlight);
  }
  setDefaults(mask, style) {
    this.guard();
    this.lib.contextEditBufferSetDefaults(this.native.handle.context, this.native.handle, mask, style);
  }
  setNativeText(text, preserveHistory = false) {
    const textBytes = this.lib.encoder.encode(text);
    this.lib.contextEditBufferSetText(this.native.handle.context, this.native.handle, textBytes, preserveHistory);
  }
  setText(text) {
    this.runMutation(() => this.setNativeText(text));
  }
  setTextOwned(text) {
    this.guard();
    this.setNativeText(text);
  }
  replaceText(text) {
    this.runMutation(() => this.setNativeText(text, true));
  }
  replaceTextOwned(text) {
    this.guard();
    this.setNativeText(text, true);
  }
  getLineCount() {
    this.guard();
    return this.lib.contextEditBufferGetInfo(this.native.handle.context, this.native.handle).lineCount;
  }
  setTabWidth(width) {
    this.runMutation(() => {
      this.lib.contextEditBufferSetTabWidth(this.native.handle.context, this.native.handle, width);
    });
  }
  getTabWidth() {
    this.guard();
    return this.lib.contextEditBufferGetInfo(this.native.handle.context, this.native.handle).tabWidth;
  }
  getText() {
    this.guard();
    return this.lib.contextEditBufferGetText(this.native.handle.context, this.native.handle);
  }
  insertChar(char) {
    this.guard();
    return this.lib.contextEditBufferInsertText(this.native.handle.context, this.native.handle, this.lib.encoder.encode(char));
  }
  insertText(text) {
    this.guard();
    return this.lib.contextEditBufferInsertText(this.native.handle.context, this.native.handle, this.lib.encoder.encode(text));
  }
  deleteChar() {
    this.command(0 /* DeleteForward */);
  }
  deleteCharBackward() {
    this.command(1 /* Backspace */);
  }
  deleteRange(startLine, startCol, endLine, endCol) {
    this.guard();
    return this.lib.contextEditBufferDeleteRange(this.native.handle.context, this.native.handle, startLine, startCol, endLine, endCol);
  }
  newLine() {
    this.command(2 /* NewLine */);
  }
  deleteLine() {
    this.command(3 /* DeleteLine */);
  }
  moveCursorLeft() {
    this.command(4 /* MoveLeft */);
  }
  moveCursorRight() {
    this.command(5 /* MoveRight */);
  }
  moveCursorUp() {
    this.command(6 /* MoveUp */);
  }
  moveCursorDown() {
    this.command(7 /* MoveDown */);
  }
  gotoLine(line) {
    this.command(8 /* GotoLine */, line);
  }
  setCursor(line, col) {
    this.guard();
    return this.lib.contextEditBufferSetCursor(this.native.handle.context, this.native.handle, line, col);
  }
  setCursorToLineCol(line, col) {
    this.guard();
    return this.lib.contextEditBufferSetCursor(this.native.handle.context, this.native.handle, line, col);
  }
  setCursorByOffset(offset) {
    this.command(9 /* CursorOffset */, offset);
  }
  getCursorPosition() {
    this.guard();
    return this.lib.contextEditBufferGetInfo(this.native.handle.context, this.native.handle).cursor;
  }
  getNextWordBoundary() {
    return this.position(1 /* NextWord */);
  }
  getPrevWordBoundary() {
    return this.position(2 /* PrevWord */);
  }
  getEOL() {
    return this.position(3 /* Eol */);
  }
  offsetToPosition(offset) {
    const result = this.position(4 /* Offset */, offset);
    return result && { row: result.row, col: result.col };
  }
  positionToOffset(row, col) {
    return this.position(5 /* Coords */, row, col)?.offset ?? 0;
  }
  getLineStartOffset(row) {
    return this.position(6 /* LineStart */, row)?.offset ?? 0;
  }
  measureText(text) {
    this.guard();
    return this.lib.contextEditBufferMeasureText(this.native.handle.context, this.native.handle, this.lib.encoder.encode(text));
  }
  getTextRange(startOffset, endOffset) {
    this.guard();
    if (startOffset >= endOffset)
      return "";
    return this.lib.contextEditBufferGetRange(this.native.handle.context, this.native.handle, false, 0, startOffset, 0, endOffset);
  }
  getTextRangeByCoords(startRow, startCol, endRow, endCol) {
    this.guard();
    return this.lib.contextEditBufferGetRange(this.native.handle.context, this.native.handle, true, startRow, startCol, endRow, endCol);
  }
  debugLogRope() {
    this.command(12 /* DebugRope */);
    this.lib.logContextDiagnostics(this.native.handle.context);
  }
  undo() {
    this.guard();
    return this.lib.contextEditBufferHistory(this.native.handle.context, this.native.handle, false);
  }
  redo() {
    this.guard();
    return this.lib.contextEditBufferHistory(this.native.handle.context, this.native.handle, true);
  }
  canUndo() {
    this.guard();
    return this.lib.contextEditBufferGetInfo(this.native.handle.context, this.native.handle).canUndo;
  }
  canRedo() {
    this.guard();
    return this.lib.contextEditBufferGetInfo(this.native.handle.context, this.native.handle).canRedo;
  }
  clearHistory() {
    this.command(11 /* ClearHistory */);
  }
  setDefaultFg(fg) {
    this.setDefaults(1 /* Foreground */, { fg });
  }
  setDefaultBg(bg) {
    this.setDefaults(2 /* Background */, { bg });
  }
  setDefaultAttributes(attributes) {
    this.setDefaults(4 /* Attributes */, { attributes });
  }
  resetDefaults() {
    this.setDefaults(7 /* All */, {});
  }
  setSyntaxStyle(style) {
    this.runMutation(() => {
      this.lib.contextEditBufferSetSyntaxStyle(this.native.handle.context, this.native.handle, style?._getSceneHandle(this.native.owner) ?? null);
      this._syntaxStyle = style ?? undefined;
    });
  }
  getSyntaxStyle() {
    this.guard();
    return this._syntaxStyle ?? null;
  }
  addHighlight(lineIdx, highlight) {
    this.highlight(0 /* AddLine */, lineIdx, highlight);
  }
  addHighlightByCharRange(highlight) {
    this.highlight(1 /* AddRange */, 0, highlight);
  }
  removeHighlightsByRef(hlRef) {
    this.highlight(2 /* RemoveRef */, hlRef);
  }
  clearLineHighlights(lineIdx) {
    this.highlight(3 /* ClearLine */, lineIdx);
  }
  clearAllHighlights() {
    this.highlight(4 /* ClearAll */);
  }
  getLineHighlights(lineIdx) {
    this.guard();
    return this.lib.contextEditBufferGetHighlights(this.native.handle.context, this.native.handle, lineIdx);
  }
  clear() {
    this.command(10 /* Clear */);
  }
  destroy() {
    if (this._destroyed)
      return;
    this.lib.getYogaHost().runMutation(() => {
      if (!this.native.owner.disposed)
        this.lib.releaseAfterPaint(this.native.handle.context, () => this.lib.destroyContextEditBuffer(this.native.handle.context, this.native.handle));
      this._destroyed = true;
      this.unsubscribe?.();
      this.unsubscribe = undefined;
      this.removeAllListeners();
      this._syntaxStyle = undefined;
    });
  }
}
function measureEditText2(text, options) {
  const lib = resolveRenderLib2();
  return lib.editMeasureText(lib.encoder.encode(text), options.widthMethod, options.tabWidth ?? 0);
}

// src/editor-view.ts
class EditorView2 {
  lib;
  native;
  editBuffer;
  _destroyed = false;
  _extmarksController;
  constructor(lib, handle, editBuffer, source) {
    const owner = source?.resourceContext;
    if (!owner)
      throw new Error("EditorView requires an explicit resource owner");
    owner.assertAlive();
    if (owner.renderLib !== lib)
      throw new Error("EditorView library owner mismatch");
    if (editBuffer._getOwner() !== owner || !handle || typeof handle !== "object" || handle.context !== owner.context) {
      throw new Error("EditorView Context owner mismatch");
    }
    this.lib = lib;
    this.native = { owner, handle };
    this.editBuffer = editBuffer;
  }
  static create(editBuffer, viewportWidth, viewportHeight) {
    const owner = editBuffer._getOwner();
    const lib = owner.renderLib;
    const handle = lib.createContextEditorView(owner.context, editBuffer._getSceneHandle(owner), viewportWidth, viewportHeight);
    try {
      return new EditorView2(lib, handle, editBuffer, owner);
    } catch (error) {
      lib.destroyContextEditorView(owner.context, handle);
      throw error;
    }
  }
  get isDestroyed() {
    return this._destroyed;
  }
  guard() {
    if (this._destroyed)
      throw new Error("EditorView is destroyed");
    this.native.owner.assertAlive();
    this.editBuffer._getOwner();
  }
  _getOwner() {
    this.guard();
    return this.native.owner;
  }
  _getSceneHandle(scene) {
    this.guard();
    if (this.native.owner !== scene.resourceContext)
      throw new Error("EditorView Context owner mismatch");
    return this.native.handle;
  }
  command(command, argument) {
    this.guard();
    this.lib.contextEditorViewCommand(this.native.handle.context, this.native.handle, command, argument);
  }
  position(query) {
    this.guard();
    return this.lib.contextEditorViewGetPosition(this.native.handle.context, this.native.handle, query);
  }
  select(selection) {
    this.guard();
    return this.lib.contextEditorViewSelect(this.native.handle.context, this.native.handle, selection);
  }
  setViewportSize(width, height) {
    this.guard();
    return this.lib.contextEditorViewSetViewport(this.native.handle.context, this.native.handle, { x: 0, y: 0, width, height }, true);
  }
  setViewport(x, y, width, height, moveCursor = true) {
    this.guard();
    return this.lib.contextEditorViewSetViewport(this.native.handle.context, this.native.handle, { x, y, width, height }, false, moveCursor);
  }
  getViewport() {
    this.guard();
    const { x, y, width, height } = this.lib.contextEditorViewGetViewport(this.native.handle.context, this.native.handle);
    return { offsetX: x, offsetY: y, width, height };
  }
  setScrollMargin(margin) {
    this.guard();
    return this.lib.contextEditorViewSetScrollMargin(this.native.handle.context, this.native.handle, margin);
  }
  setWrapMode(mode) {
    this.command(5 /* WrapMode */, mode === "none" ? 0 : mode === "char" ? 1 : 2);
  }
  getVirtualLineCount() {
    this.guard();
    return this.lib.contextEditorViewGetInfo(this.native.handle.context, this.native.handle, true).virtualLineCount;
  }
  getTotalVirtualLineCount() {
    this.guard();
    return this.lib.contextEditorViewGetInfo(this.native.handle.context, this.native.handle).totalVirtualLineCount;
  }
  setSelection(start, end, bgColor, fgColor) {
    this.select({ operation: 0 /* Set */, start, end, bg: bgColor, fg: fgColor });
  }
  updateSelection(end, bgColor, fgColor) {
    this.select({ operation: 1 /* Update */, end, bg: bgColor, fg: fgColor });
  }
  resetSelection() {
    this.select({ operation: 2 /* Reset */ });
  }
  getSelection() {
    this.guard();
    return this.lib.contextEditorViewGetSelection(this.native.handle.context, this.native.handle).selection;
  }
  hasSelection() {
    return this.getSelection() !== null;
  }
  setLocalSelection(anchorX, anchorY, focusX, focusY, bgColor, fgColor, updateCursor, followCursor, behavior = "cell") {
    return this.select({
      operation: 3 /* Local */,
      anchorX,
      anchorY,
      focusX,
      focusY,
      bg: bgColor,
      fg: fgColor,
      updateCursor,
      followCursor,
      behavior: behavior === "cell" ? 0 : behavior === "word" ? 1 : 2
    });
  }
  updateLocalSelection(anchorX, anchorY, focusX, focusY, bgColor, fgColor, updateCursor, followCursor, behavior = "cell") {
    return this.select({
      operation: 4 /* LocalUpdate */,
      anchorX,
      anchorY,
      focusX,
      focusY,
      bg: bgColor,
      fg: fgColor,
      updateCursor,
      followCursor,
      behavior: behavior === "cell" ? 0 : behavior === "word" ? 1 : 2
    });
  }
  resetLocalSelection() {
    this.select({ operation: 5 /* LocalReset */ });
  }
  convertSelectionToCell() {
    return this.select({ operation: 6 /* Cell */ });
  }
  setSelectionOccupancy(occupancy) {
    this.select({
      operation: 7 /* Occupancy */,
      behavior: occupancy === "boundary" ? 1 : 0
    });
  }
  getSelectionOccupancy() {
    this.guard();
    return this.lib.contextEditorViewGetSelection(this.native.handle.context, this.native.handle).selectionOccupancy;
  }
  setSelectionInclusive(start, end, bgColor, fgColor) {
    this.select({ operation: 8 /* Inclusive */, start, end, bg: bgColor, fg: fgColor });
  }
  setSelectionColors(bgColor, fgColor) {
    this.select({ operation: 9 /* Colors */, bg: bgColor, fg: fgColor });
  }
  getSelectedText() {
    this.guard();
    return this.lib.contextEditorViewGetSelectedText(this.native.handle.context, this.native.handle);
  }
  getCursor() {
    this.guard();
    const { row, col } = this.editBuffer.getCursorPosition();
    return { row, col };
  }
  getText() {
    this.guard();
    return this.editBuffer.getText();
  }
  getVisualCursor() {
    return this.position(0 /* Cursor */);
  }
  moveUpVisual() {
    this.command(0 /* MoveUp */);
  }
  moveDownVisual() {
    this.command(1 /* MoveDown */);
  }
  deleteSelectedText() {
    this.command(3 /* DeleteSelection */);
  }
  _replaceSelectedText(text) {
    this.guard();
    return this.lib.contextEditorViewReplaceSelection(this.native.handle.context, this.native.handle, this.lib.encoder.encode(text));
  }
  setCursorByOffset(offset) {
    this.command(4 /* CursorOffset */, offset);
  }
  getNextWordBoundary() {
    return this.position(1 /* NextWord */);
  }
  getPrevWordBoundary() {
    return this.position(2 /* PrevWord */);
  }
  getEOL() {
    return this.position(3 /* Eol */);
  }
  getVisualSOL() {
    return this.position(4 /* VisualSol */);
  }
  getVisualEOL() {
    return this.position(5 /* VisualEol */);
  }
  gotoVisualLineEnd() {
    this.command(2 /* GotoLineEnd */);
  }
  getLineInfo() {
    this.guard();
    return this.lib.contextEditorViewGetLines(this.native.handle.context, this.native.handle, false);
  }
  getLogicalLineInfo() {
    this.guard();
    return this.lib.contextEditorViewGetLines(this.native.handle.context, this.native.handle, true);
  }
  get extmarks() {
    this.guard();
    if (!this._extmarksController) {
      this._extmarksController = createExtmarksController2(this.editBuffer, this);
    }
    return this._extmarksController;
  }
  setPlaceholderStyledText(chunks) {
    this.guard();
    return this.lib.contextEditorViewSetPlaceholder(this.native.handle.context, this.native.handle, new StyledText2(chunks.map((chunk) => ({ ...chunk, __isChunk: true }))));
  }
  setTabIndicator(indicator) {
    const codePoint = typeof indicator === "string" ? indicator.codePointAt(0) ?? 0 : indicator;
    this.command(6 /* TabIndicator */, codePoint);
  }
  setTabIndicatorColor(color) {
    this.guard();
    return this.lib.contextEditorViewSetTabColor(this.native.handle.context, this.native.handle, color);
  }
  measureForDimensions(width, height) {
    this.guard();
    return this.lib.contextEditorViewMeasure(this.native.handle.context, this.native.handle, width, height);
  }
  destroy() {
    if (this._destroyed)
      return;
    this.lib.getYogaHost().runMutation(() => {
      if (!this.native.owner.disposed) {
        try {
          this.lib.releaseAfterPaint(this.native.handle.context, () => this.lib.destroyContextEditorView(this.native.handle.context, this.native.handle));
        } catch (error) {
          if (!(error instanceof NativeError2) || error.status !== -9 /* StaleHandle */)
            throw error;
        }
      }
      this._destroyed = true;
      this._extmarksController?.destroy();
      this._extmarksController = undefined;
    });
  }
}

// src/syntax-style.ts
function cloneStyle(style) {
  return {
    ...style,
    fg: style.fg ? RGBA2.clone(style.fg) : undefined,
    bg: style.bg ? RGBA2.clone(style.bg) : undefined
  };
}
function convertThemeToStyles2(theme) {
  const flatStyles = {};
  for (const tokenStyle of theme) {
    const styleDefinition = {};
    if (tokenStyle.style.foreground) {
      styleDefinition.fg = parseColor2(tokenStyle.style.foreground);
    }
    if (tokenStyle.style.background) {
      styleDefinition.bg = parseColor2(tokenStyle.style.background);
    }
    if (tokenStyle.style.bold !== undefined) {
      styleDefinition.bold = tokenStyle.style.bold;
    }
    if (tokenStyle.style.italic !== undefined) {
      styleDefinition.italic = tokenStyle.style.italic;
    }
    if (tokenStyle.style.underline !== undefined) {
      styleDefinition.underline = tokenStyle.style.underline;
    }
    if (tokenStyle.style.dim !== undefined) {
      styleDefinition.dim = tokenStyle.style.dim;
    }
    for (const scope of tokenStyle.scope) {
      flatStyles[scope] = cloneStyle(styleDefinition);
    }
  }
  return flatStyles;
}

class SyntaxStyle2 {
  lib;
  native;
  _destroyed = false;
  nameCache = new Map;
  styleDefs = new Map;
  mergedCache = new Map;
  constructor(lib, handle, source) {
    const owner = source?.resourceContext;
    if (!owner)
      throw new Error("SyntaxStyle requires an explicit resource owner");
    owner.assertAlive();
    if (owner.renderLib !== lib || !handle || typeof handle !== "object" || handle.context !== owner.context) {
      throw new Error("SyntaxStyle Context owner mismatch");
    }
    this.lib = lib;
    this.native = { owner, handle };
  }
  static create(source) {
    const owner = source?.resourceContext;
    if (!owner)
      throw new Error("SyntaxStyle requires an explicit resource owner: pass renderer.nativeScene, or a ResourceContext when there is no renderer");
    owner.assertAlive();
    const lib = owner.renderLib;
    const handle = lib.createContextSyntaxStyle(owner.context);
    try {
      return new SyntaxStyle2(lib, handle, owner);
    } catch (error) {
      lib.destroyContextSyntaxStyle(owner.context, handle);
      throw error;
    }
  }
  static fromTheme(theme, owner) {
    return SyntaxStyle2.fromStyles(convertThemeToStyles2(theme), owner);
  }
  static fromStyles(styles, owner) {
    const style = SyntaxStyle2.create(owner);
    try {
      for (const [name, styleDef] of styles instanceof Map ? styles : Object.entries(styles)) {
        style.registerStyle(name, styleDef);
      }
      return style;
    } catch (error) {
      style.destroy();
      throw error;
    }
  }
  guard() {
    if (this._destroyed)
      throw new Error("NativeSyntaxStyle is destroyed");
    this.native.owner.assertAlive();
  }
  _getSceneHandle(scene) {
    this.guard();
    if (this.native.owner !== scene.resourceContext)
      throw new Error("SyntaxStyle owner mismatch: bind definitions in the destination Context");
    return this.native.handle;
  }
  registerStyle(name, style) {
    this.guard();
    const { bold, italic, underline, dim, fg: foreground, bg: background } = style;
    const definition = {
      bold,
      italic,
      underline,
      dim,
      fg: foreground ? RGBA2.clone(parseColor2(foreground)) : undefined,
      bg: background ? RGBA2.clone(parseColor2(background)) : undefined
    };
    const attributes = createTextAttributes2(definition);
    const fg = definition.fg ?? null;
    const bg = definition.bg ?? null;
    return this.lib.getYogaHost().runMutation(() => {
      const id = this.lib.contextSyntaxStyleRegister(this.native.handle.context, this.native.handle, name, {
        fg,
        bg,
        attributes
      });
      this.nameCache.set(name, id);
      this.styleDefs.set(name, definition);
      this.mergedCache.clear();
      return id;
    });
  }
  resolveStyleId(name) {
    this.guard();
    const cached = this.nameCache.get(name);
    if (cached !== undefined)
      return cached;
    const id = this.lib.contextSyntaxStyleResolveByName(this.native.handle.context, this.native.handle, name);
    if (id !== null) {
      this.nameCache.set(name, id);
    }
    return id;
  }
  getStyleId(name) {
    this.guard();
    const id = this.resolveStyleId(name);
    if (id !== null)
      return id;
    if (name.includes(".")) {
      const baseName = name.split(".")[0];
      return this.resolveStyleId(baseName);
    }
    return null;
  }
  getStyleCount() {
    this.guard();
    return this.lib.contextSyntaxStyleGetStyleCount(this.native.handle.context, this.native.handle);
  }
  clearNameCache() {
    this.guard();
    this.nameCache.clear();
  }
  getStyle(name) {
    this.guard();
    const style = this.styleDefs.get(name);
    if (style)
      return cloneStyle(style);
    if (name.includes(".")) {
      const baseName = name.split(".")[0];
      const base = this.styleDefs.get(baseName);
      return base ? cloneStyle(base) : undefined;
    }
    return;
  }
  mergeStyles(...styleNames) {
    this.guard();
    const cacheKey = styleNames.join(":");
    const cached = this.mergedCache.get(cacheKey);
    if (cached)
      return cloneStyle(cached);
    const styleDefinition = {};
    for (const name of styleNames) {
      const style = this.getStyle(name);
      if (!style)
        continue;
      if (style.fg)
        styleDefinition.fg = style.fg;
      if (style.bg)
        styleDefinition.bg = style.bg;
      if (style.bold !== undefined)
        styleDefinition.bold = style.bold;
      if (style.italic !== undefined)
        styleDefinition.italic = style.italic;
      if (style.underline !== undefined)
        styleDefinition.underline = style.underline;
      if (style.dim !== undefined)
        styleDefinition.dim = style.dim;
    }
    const attributes = createTextAttributes2({
      bold: styleDefinition.bold,
      italic: styleDefinition.italic,
      underline: styleDefinition.underline,
      dim: styleDefinition.dim
    });
    const merged = {
      fg: styleDefinition.fg,
      bg: styleDefinition.bg,
      attributes
    };
    this.mergedCache.set(cacheKey, merged);
    return cloneStyle(merged);
  }
  clearCache() {
    this.guard();
    this.mergedCache.clear();
  }
  getCacheSize() {
    this.guard();
    return this.mergedCache.size;
  }
  getAllStyles() {
    this.guard();
    return new Map(Array.from(this.styleDefs, ([name, style]) => [name, cloneStyle(style)]));
  }
  getRegisteredNames() {
    this.guard();
    return Array.from(this.styleDefs.keys());
  }
  destroy() {
    if (this._destroyed)
      return;
    this.lib.getYogaHost().runMutation(() => {
      if (!this.native.owner.disposed)
        this.lib.destroyContextSyntaxStyle(this.native.handle.context, this.native.handle);
      this._destroyed = true;
      this.nameCache.clear();
      this.styleDefs.clear();
      this.mergedCache.clear();
    });
  }
}

// src/animation/Timeline.ts
var easingFunctions = {
  linear: (t) => t,
  inQuad: (t) => t * t,
  outQuad: (t) => t * (2 - t),
  inOutQuad: (t) => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t,
  inExpo: (t) => t === 0 ? 0 : Math.pow(2, 10 * (t - 1)),
  outExpo: (t) => t === 1 ? 1 : 1 - Math.pow(2, -10 * t),
  inOutSine: (t) => -(Math.cos(Math.PI * t) - 1) / 2,
  outBounce: (t) => {
    const n1 = 7.5625;
    const d1 = 2.75;
    if (t < 1 / d1) {
      return n1 * t * t;
    } else if (t < 2 / d1) {
      return n1 * (t -= 1.5 / d1) * t + 0.75;
    } else if (t < 2.5 / d1) {
      return n1 * (t -= 2.25 / d1) * t + 0.9375;
    } else {
      return n1 * (t -= 2.625 / d1) * t + 0.984375;
    }
  },
  outElastic: (t) => {
    const c4 = 2 * Math.PI / 3;
    return t === 0 ? 0 : t === 1 ? 1 : Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * c4) + 1;
  },
  inBounce: (t) => 1 - easingFunctions.outBounce(1 - t),
  inCirc: (t) => 1 - Math.sqrt(1 - t * t),
  outCirc: (t) => Math.sqrt(1 - Math.pow(t - 1, 2)),
  inOutCirc: (t) => {
    if ((t *= 2) < 1)
      return -0.5 * (Math.sqrt(1 - t * t) - 1);
    return 0.5 * (Math.sqrt(1 - (t -= 2) * t) + 1);
  },
  inBack: (t, s = 1.70158) => t * t * ((s + 1) * t - s),
  outBack: (t, s = 1.70158) => --t * t * ((s + 1) * t + s) + 1,
  inOutBack: (t, s = 1.70158) => {
    s *= 1.525;
    if ((t *= 2) < 1)
      return 0.5 * (t * t * ((s + 1) * t - s));
    return 0.5 * ((t -= 2) * t * ((s + 1) * t + s) + 2);
  }
};
function captureInitialValues(item) {
  if (!item.properties)
    return;
  if (!item.initialValues || item.initialValues.length === 0) {
    const initialValues = [];
    for (let i = 0;i < item.target.length; i++) {
      const target = item.target[i];
      const targetInitialValues = {};
      for (const key of Object.keys(item.properties)) {
        if (typeof target[key] === "number") {
          targetInitialValues[key] = target[key];
        }
      }
      initialValues.push(targetInitialValues);
    }
    item.initialValues = initialValues;
  }
}
function applyAnimationAtProgress(item, progress, reversed, timelineTime, deltaTime = 0) {
  if (!item.properties || !item.initialValues)
    return;
  const easingFn = easingFunctions[item.ease || "linear"] || easingFunctions.linear;
  const easedProgress = easingFn(Math.max(0, Math.min(1, progress)));
  const finalProgress = reversed ? 1 - easedProgress : easedProgress;
  for (let i = 0;i < item.target.length; i++) {
    const target = item.target[i];
    const targetInitialValues = item.initialValues[i];
    if (!targetInitialValues)
      continue;
    for (const [key, endValue] of Object.entries(item.properties)) {
      const startValue = targetInitialValues[key];
      const newValue = startValue + (endValue - startValue) * finalProgress;
      target[key] = newValue;
    }
  }
  if (item.onUpdate) {
    const animation = {
      targets: item.target,
      progress: easedProgress,
      currentTime: timelineTime,
      deltaTime
    };
    item.onUpdate(animation);
  }
}
function evaluateAnimation(item, timelineTime, deltaTime = 0) {
  if (timelineTime < item.startTime) {
    return;
  }
  const animationTime = timelineTime - item.startTime;
  const duration = item.duration || 0;
  if (timelineTime >= item.startTime && !item.started) {
    captureInitialValues(item);
    if (item.onStart) {
      item.onStart();
    }
    item.started = true;
  }
  if (duration === 0) {
    if (!item.completed) {
      applyAnimationAtProgress(item, 1, false, timelineTime, deltaTime);
      if (item.onComplete) {
        item.onComplete();
      }
      item.completed = true;
    }
    return;
  }
  const maxLoops = !item.loop || item.loop === 1 ? 1 : typeof item.loop === "number" ? item.loop : Infinity;
  const loopDelay = item.loopDelay || 0;
  const cycleTime = duration + loopDelay;
  let currentCycle = Math.floor(animationTime / cycleTime);
  let timeInCycle = animationTime % cycleTime;
  if (item.onLoop && item.currentLoop !== undefined && currentCycle > item.currentLoop && currentCycle < maxLoops) {
    item.onLoop();
  }
  item.currentLoop = currentCycle;
  if (item.onComplete && !item.completed && currentCycle === maxLoops - 1 && timeInCycle >= duration) {
    const finalLoopReversed = (item.alternate || false) && currentCycle % 2 === 1;
    applyAnimationAtProgress(item, 1, finalLoopReversed, timelineTime, deltaTime);
    item.onComplete();
    item.completed = true;
    return;
  }
  if (currentCycle >= maxLoops) {
    if (!item.completed) {
      const finalReversed = (item.alternate || false) && (maxLoops - 1) % 2 === 1;
      applyAnimationAtProgress(item, 1, finalReversed, timelineTime, deltaTime);
      if (item.onComplete) {
        item.onComplete();
      }
      item.completed = true;
    }
    return;
  }
  if (timeInCycle === 0 && animationTime > 0 && currentCycle < maxLoops) {
    currentCycle = currentCycle - 1;
    timeInCycle = cycleTime;
  }
  if (timeInCycle >= duration) {
    const isReversed = (item.alternate || false) && currentCycle % 2 === 1;
    applyAnimationAtProgress(item, 1, isReversed, timelineTime, deltaTime);
    return;
  }
  const progress = timeInCycle / duration;
  const isReversed = (item.alternate || false) && currentCycle % 2 === 1;
  applyAnimationAtProgress(item, progress, isReversed, timelineTime, deltaTime);
}
function evaluateCallback(item, timelineTime) {
  if (!item.executed && timelineTime >= item.startTime && item.callback) {
    item.callback();
    item.executed = true;
  }
}
function evaluateTimelineSync(item, timelineTime, deltaTime = 0) {
  if (!item.timeline)
    return;
  if (timelineTime < item.startTime) {
    return;
  }
  if (!item.timelineStarted) {
    item.timelineStarted = true;
    item.timeline.play();
    const overshoot = timelineTime - item.startTime;
    item.timeline.update(overshoot);
    return;
  }
  item.timeline.update(deltaTime);
}
function evaluateItem(item, timelineTime, deltaTime = 0) {
  if (item.type === "animation") {
    evaluateAnimation(item, timelineTime, deltaTime);
  } else if (item.type === "callback") {
    evaluateCallback(item, timelineTime);
  }
}

class Timeline2 {
  items = [];
  subTimelines = [];
  currentTime = 0;
  isPlaying = false;
  isComplete = false;
  duration;
  loop;
  synced = false;
  autoplay;
  onComplete;
  onPause;
  stateChangeListeners = [];
  constructor(options = {}) {
    this.duration = options.duration || 1000;
    this.loop = options.loop === true;
    this.autoplay = options.autoplay !== false;
    this.onComplete = options.onComplete;
    this.onPause = options.onPause;
  }
  addStateChangeListener(listener) {
    this.stateChangeListeners.push(listener);
  }
  removeStateChangeListener(listener) {
    this.stateChangeListeners = this.stateChangeListeners.filter((l) => l !== listener);
  }
  notifyStateChange() {
    for (const listener of this.stateChangeListeners) {
      listener(this);
    }
  }
  add(target, properties, startTime = 0) {
    const resolvedStartTime = typeof startTime === "string" ? 0 : startTime;
    const animationProperties = {};
    for (const key in properties) {
      if (!["duration", "ease", "onUpdate", "onComplete", "onStart", "onLoop", "loop", "loopDelay", "alternate"].includes(key)) {
        if (typeof properties[key] === "number") {
          animationProperties[key] = properties[key];
        }
      }
    }
    this.items.push({
      type: "animation",
      startTime: resolvedStartTime,
      target: Array.isArray(target) ? target : [target],
      properties: animationProperties,
      initialValues: [],
      duration: properties.duration !== undefined ? properties.duration : 1000,
      ease: properties.ease || "linear",
      loop: properties.loop,
      loopDelay: properties.loopDelay || 0,
      alternate: properties.alternate || false,
      onUpdate: properties.onUpdate,
      onComplete: properties.onComplete,
      onStart: properties.onStart,
      onLoop: properties.onLoop,
      completed: false,
      started: false,
      currentLoop: 0,
      once: properties.once ?? false
    });
    return this;
  }
  once(target, properties) {
    this.add(target, {
      ...properties,
      once: true
    }, this.currentTime);
    return this;
  }
  call(callback, startTime = 0) {
    const resolvedStartTime = typeof startTime === "string" ? 0 : startTime;
    this.items.push({
      type: "callback",
      startTime: resolvedStartTime,
      callback,
      executed: false
    });
    return this;
  }
  sync(timeline, startTime = 0) {
    if (timeline.synced) {
      throw new Error("Timeline already synced");
    }
    this.subTimelines.push({
      type: "timeline",
      startTime,
      timeline
    });
    timeline.synced = true;
    return this;
  }
  play() {
    if (this.isComplete) {
      return this.restart();
    }
    this.subTimelines.forEach((subTimeline) => {
      if (subTimeline.timelineStarted) {
        subTimeline.timeline.play();
      }
    });
    this.isPlaying = true;
    this.notifyStateChange();
    return this;
  }
  pause() {
    this.subTimelines.forEach((subTimeline) => {
      subTimeline.timeline.pause();
    });
    this.isPlaying = false;
    try {
      this.onPause?.();
    } finally {
      this.notifyStateChange();
    }
    return this;
  }
  resetItems() {
    this.items.forEach((item) => {
      if (item.type === "callback") {
        item.executed = false;
      } else if (item.type === "animation") {
        item.completed = false;
        item.started = false;
        item.currentLoop = 0;
      }
    });
    this.subTimelines.forEach((subTimeline) => {
      subTimeline.timelineStarted = false;
      if (subTimeline.timeline) {
        subTimeline.timeline.restart();
        subTimeline.timeline.pause();
      }
    });
  }
  restart() {
    this.isComplete = false;
    this.currentTime = 0;
    this.isPlaying = true;
    this.resetItems();
    this.notifyStateChange();
    return this;
  }
  update(deltaTime) {
    for (const subTimeline of this.subTimelines) {
      evaluateTimelineSync(subTimeline, this.currentTime + deltaTime, deltaTime);
    }
    if (!this.isPlaying)
      return;
    this.currentTime += deltaTime;
    for (const item of this.items) {
      evaluateItem(item, this.currentTime, deltaTime);
    }
    for (let i = this.items.length - 1;i >= 0; i--) {
      const item = this.items[i];
      if (item.type === "animation" && item.once && item.completed) {
        this.items.splice(i, 1);
      }
    }
    if (this.loop && this.currentTime >= this.duration) {
      const overshoot = this.currentTime % this.duration;
      this.resetItems();
      this.currentTime = 0;
      if (overshoot > 0) {
        this.update(overshoot);
      }
    } else if (!this.loop && this.currentTime >= this.duration) {
      this.currentTime = this.duration;
      this.isPlaying = false;
      this.isComplete = true;
      try {
        this.onComplete?.();
      } finally {
        this.notifyStateChange();
      }
    }
  }
}
var rendererEngines = new WeakMap;
var timelineOwners = new WeakMap;

class TimelineEngine {
  timelines = new Set;
  renderer = null;
  frameCallback = async (deltaTime) => {
    this.update(deltaTime);
  };
  isLive = false;
  defaults = {
    frameRate: 60
  };
  attach(renderer) {
    if (renderer.isDestroyed)
      throw new Error("Cannot attach timelines to a destroyed renderer");
    if (this.renderer === renderer) {
      if (!renderer.hasFrameCallback(this.frameCallback))
        renderer.setFrameCallback(this.frameCallback);
      return;
    }
    if (this === engine2)
      this.detach();
    else if (this.renderer)
      throw new Error("Timeline engine is already attached; use getTimelineEngine(renderer) for another renderer");
    else if (rendererEngines.has(renderer))
      throw new Error("Renderer already has a timeline engine; use getTimelineEngine(renderer)");
    else
      rendererEngines.set(renderer, this);
    this.renderer = renderer;
    renderer.setFrameCallback(this.frameCallback);
    this.updateLiveState();
  }
  detach() {
    if (this.renderer) {
      if (this !== engine2)
        rendererEngines.delete(this.renderer);
      this.renderer.removeFrameCallback(this.frameCallback);
      if (this.isLive) {
        this.renderer.dropLive();
        this.isLive = false;
      }
    }
    this.renderer = null;
  }
  updateLiveState() {
    if (!this.renderer)
      return;
    const hasRunningTimelines = Array.from(this.timelines).some((timeline) => !timeline.synced && timeline.isPlaying && !timeline.isComplete);
    if (hasRunningTimelines && !this.isLive) {
      this.renderer.requestLive();
      this.isLive = true;
    } else if (!hasRunningTimelines && this.isLive) {
      this.renderer.dropLive();
      this.isLive = false;
    }
  }
  onTimelineStateChange = (timeline) => {
    this.updateLiveState();
  };
  register(timeline) {
    const owner = timelineOwners.get(timeline);
    if (owner && owner !== this)
      throw new Error("Timeline belongs to another timeline engine; unregister it first");
    if (!this.timelines.has(timeline)) {
      timelineOwners.set(timeline, this);
      this.timelines.add(timeline);
      timeline.addStateChangeListener(this.onTimelineStateChange);
      this.updateLiveState();
    }
  }
  unregister(timeline) {
    if (this.timelines.has(timeline)) {
      this.timelines.delete(timeline);
      timelineOwners.delete(timeline);
      timeline.removeStateChangeListener(this.onTimelineStateChange);
      this.updateLiveState();
    }
  }
  clear() {
    for (const timeline of this.timelines) {
      timelineOwners.delete(timeline);
      timeline.removeStateChangeListener(this.onTimelineStateChange);
    }
    this.timelines.clear();
    this.updateLiveState();
  }
  update(deltaTime) {
    for (const timeline of this.timelines) {
      if (this.renderer?.isDestroyed)
        break;
      if (!timeline.synced) {
        timeline.update(deltaTime);
      }
    }
  }
}
var engine2 = new TimelineEngine;
function getTimelineEngine2(renderer) {
  const owner = rendererEngines.get(renderer) ?? new TimelineEngine;
  owner.attach(renderer);
  return owner;
}
function destroyTimelineEngine(renderer) {
  const owner = rendererEngines.get(renderer);
  owner?.clear();
  owner?.detach();
  if (engine2["renderer"] === renderer)
    engine2.detach();
}
function createTimeline2(options = {}, renderer) {
  const owner = renderer ? getTimelineEngine2(renderer) : engine2;
  const timeline = new Timeline2(options);
  if (options.autoplay !== false) {
    timeline.play();
  }
  owner.register(timeline);
  return timeline;
}

// src/renderer.ts
import { appendFileSync, writeFileSync } from "fs";
import { Writable as Writable3 } from "stream";

// src/ansi.ts
var ANSI = {
  switchToAlternateScreen: "\x1B[?1049h",
  switchToMainScreen: "\x1B[?1049l",
  reset: "\x1B[0m",
  resetScrollRegion: "\x1B[r",
  home: "\x1B[H",
  clearScreen: "\x1B[2J",
  clearSavedLines: "\x1B[3J",
  scrollDown: (lines) => `\x1B[${lines}T`,
  scrollUp: (lines) => `\x1B[${lines}S`,
  moveCursor: (row, col) => `\x1B[${row};${col}H`,
  moveCursorAndClear: (row, col) => `\x1B[${row};${col}H\x1B[J`,
  setRgbBackground: (r, g, b) => `\x1B[48;2;${r};${g};${b}m`,
  resetBackground: "\x1B[49m",
  bracketedPasteStart: "\x1B[200~",
  bracketedPasteEnd: "\x1B[201~"
};

// src/renderables/Box.ts
function isGapType(value) {
  if (value === undefined) {
    return true;
  }
  if (typeof value === "number" && !Number.isNaN(value)) {
    return true;
  }
  return isValidPercentage(value);
}
function borderMask(sides) {
  return (sides.left ? 1 : 0) | (sides.bottom ? 2 : 0) | (sides.right ? 4 : 0) | (sides.top ? 8 : 0);
}

class BoxRenderable2 extends Renderable2 {
  static nativeIntegration = this.defineNativeIntegration({
    kind: "box",
    body: { native: this.prototype.renderSelf },
    construction: "prototype"
  });
  _backgroundColor;
  _border;
  _borderStyle;
  _borderColor;
  _focusedBorderColor;
  _customBorderCharsObj;
  _customBorderChars;
  borderSides;
  _shouldFill;
  _title;
  _titleColor;
  _titleAlignment;
  _bottomTitle;
  _bottomTitleAlignment;
  _defaultOptions = {
    backgroundColor: "transparent",
    borderStyle: "single",
    border: false,
    borderColor: "#FFFFFF",
    shouldFill: true,
    titleAlignment: "left",
    bottomTitleAlignment: "left",
    focusedBorderColor: "#00AAFF"
  };
  constructor(ctx, options) {
    super(ctx, options);
    try {
      if (options.focusable === true) {
        this._focusable = true;
      }
      this._backgroundColor = RGBA2.clone(parseColor2(options.backgroundColor || this._defaultOptions.backgroundColor));
      this._border = options.border ?? this._defaultOptions.border;
      if (!options.border && (options.borderStyle || options.borderColor || options.focusedBorderColor || options.customBorderChars)) {
        this._border = true;
      }
      this._borderStyle = parseBorderStyle2(options.borderStyle, this._defaultOptions.borderStyle);
      this._borderColor = RGBA2.clone(parseColor2(options.borderColor || this._defaultOptions.borderColor));
      if (Array.isArray(this._border))
        this._border = [...this._border];
      this._focusedBorderColor = RGBA2.clone(parseColor2(options.focusedBorderColor || this._defaultOptions.focusedBorderColor));
      this._customBorderCharsObj = options.customBorderChars;
      this._customBorderChars = this._customBorderCharsObj ? borderCharsToArray2(this._customBorderCharsObj) : undefined;
      this.borderSides = getBorderSides2(this._border);
      this._shouldFill = options.shouldFill ?? this._defaultOptions.shouldFill;
      this._title = options.title;
      this._titleColor = options.titleColor ? RGBA2.clone(parseColor2(options.titleColor)) : undefined;
      this._titleAlignment = options.titleAlignment || this._defaultOptions.titleAlignment;
      this._bottomTitle = options.bottomTitle;
      this._bottomTitleAlignment = options.bottomTitleAlignment || this._defaultOptions.bottomTitleAlignment;
      this.setNativeScenePaint();
      this.requestRender();
      if (this._title || this._bottomTitle || this._titleColor || this._customBorderChars || this._titleAlignment !== "left" || this._bottomTitleAlignment !== "left") {
        this.setNativeBoxDetails();
      }
      const hasInitialGapProps = options.gap !== undefined || options.rowGap !== undefined || options.columnGap !== undefined;
      if (hasInitialGapProps) {
        this.applyYogaGap(options);
      }
    } catch (error) {
      this.abortConstruction(error);
    }
  }
  initializeBorder() {
    if (this._border === false) {
      this._border = true;
      this.borderSides = getBorderSides2(this._border);
    }
  }
  get customBorderChars() {
    return this._customBorderCharsObj;
  }
  set customBorderChars(value) {
    const chars = value ? borderCharsToArray2(value) : undefined;
    this.setNativeBoxDetails({ customBorderChars: chars });
    this._customBorderCharsObj = value;
    this._customBorderChars = chars;
    this.requestRender();
  }
  get backgroundColor() {
    return RGBA2.clone(this._backgroundColor);
  }
  set backgroundColor(value) {
    if (this.isFreed())
      return;
    const newColor = RGBA2.clone(parseColor2(value ?? this._defaultOptions.backgroundColor));
    this._ctx.nativeScene.setBackground(this, newColor);
    this._backgroundColor = newColor;
    this.requestRender();
  }
  get border() {
    if (Array.isArray(this._border))
      return [...this._border];
    return this._border;
  }
  set border(value) {
    if (this._border !== value) {
      const sides = getBorderSides2(value);
      this.setNativeScenePaint({ border: borderMask(sides) });
      this._border = Array.isArray(value) ? [...value] : value;
      this.borderSides = sides;
      this.requestRender();
    }
  }
  get borderStyle() {
    return this._borderStyle;
  }
  set borderStyle(value) {
    const _value = parseBorderStyle2(value, this._defaultOptions.borderStyle);
    if (this._borderStyle !== _value || !this._border) {
      this.runMutation(() => {
        this._ctx.nativeScene.setBoxBorderStyle(this, _value, this._border === false ? 15 : borderMask(this.borderSides));
        this._borderStyle = _value;
        this._customBorderChars = undefined;
        this._customBorderCharsObj = undefined;
        this.initializeBorder();
        this.requestRender();
      });
    }
  }
  get borderColor() {
    return RGBA2.clone(this._borderColor);
  }
  set borderColor(value) {
    const newColor = RGBA2.clone(parseColor2(value ?? this._defaultOptions.borderColor));
    this.setNativeScenePaint({
      borderColor: newColor,
      border: this._border === false ? 15 : borderMask(this.borderSides)
    });
    this._borderColor = newColor;
    this.initializeBorder();
    this.requestRender();
  }
  get focusedBorderColor() {
    return RGBA2.clone(this._focusedBorderColor);
  }
  set focusedBorderColor(value) {
    const newColor = RGBA2.clone(parseColor2(value ?? this._defaultOptions.focusedBorderColor));
    this.setNativeScenePaint({
      focusedBorderColor: newColor,
      border: this._border === false ? 15 : borderMask(this.borderSides)
    });
    this._focusedBorderColor = newColor;
    this.initializeBorder();
    this.requestRender();
  }
  get title() {
    return this._title;
  }
  set title(value) {
    if (this._title !== value) {
      this.setNativeBoxDetails({ title: value });
      this._title = value;
      this.requestRender();
    }
  }
  get titleColor() {
    return this._titleColor ? RGBA2.clone(this._titleColor) : undefined;
  }
  set titleColor(value) {
    const newColor = value ? RGBA2.clone(parseColor2(value)) : undefined;
    if (this._titleColor !== newColor) {
      this.setNativeBoxDetails({ titleColor: newColor });
      this._titleColor = newColor;
      this.requestRender();
    }
  }
  get titleAlignment() {
    return this._titleAlignment;
  }
  set titleAlignment(value) {
    value ??= this._defaultOptions.titleAlignment;
    if (this._titleAlignment !== value) {
      this.setNativeBoxDetails({ titleAlignment: value });
      this._titleAlignment = value;
      this.requestRender();
    }
  }
  get bottomTitle() {
    return this._bottomTitle;
  }
  set bottomTitle(value) {
    if (this._bottomTitle !== value) {
      this.setNativeBoxDetails({ bottomTitle: value });
      this._bottomTitle = value;
      this.requestRender();
    }
  }
  get bottomTitleAlignment() {
    return this._bottomTitleAlignment;
  }
  set bottomTitleAlignment(value) {
    value ??= this._defaultOptions.bottomTitleAlignment;
    if (this._bottomTitleAlignment !== value) {
      this.setNativeBoxDetails({ bottomTitleAlignment: value });
      this._bottomTitleAlignment = value;
      this.requestRender();
    }
  }
  setNativeBoxDetails(details = {}) {
    if (this.isFreed())
      return;
    this._ctx.nativeScene.setBoxDetails(this, {
      title: this._title,
      bottomTitle: this._bottomTitle,
      titleAlignment: this._titleAlignment,
      bottomTitleAlignment: this._bottomTitleAlignment,
      titleColor: this._titleColor,
      customBorderChars: this._customBorderChars,
      ...details
    });
  }
  renderSelf(buffer) {
    const hasBorder = this.borderSides.top || this.borderSides.right || this.borderSides.bottom || this.borderSides.left;
    const hasVisibleFill = this.shouldFill && this._backgroundColor.a > 0;
    if (!hasBorder && !hasVisibleFill) {
      return;
    }
    const hasFocusWithin = this._focusable && (this._focused || this._hasFocusedDescendant);
    const currentBorderColor = hasFocusWithin ? this._focusedBorderColor : this._borderColor;
    const screenX = Math.trunc(this._screenX);
    const screenY = Math.trunc(this._screenY);
    buffer.drawBox({
      x: screenX,
      y: screenY,
      width: this.width,
      height: this.height,
      borderStyle: this._borderStyle,
      customBorderChars: this._customBorderChars,
      border: this._border,
      borderColor: currentBorderColor,
      backgroundColor: this._backgroundColor,
      shouldFill: this.shouldFill,
      title: this._title,
      titleColor: this._titleColor ?? currentBorderColor,
      titleAlignment: this._titleAlignment,
      bottomTitle: this._bottomTitle,
      bottomTitleAlignment: this._bottomTitleAlignment
    });
  }
  get shouldFill() {
    return this._shouldFill;
  }
  set shouldFill(value) {
    value ??= this._defaultOptions.shouldFill;
    if (this._shouldFill === value)
      return;
    this.setNativeScenePaint({ shouldFill: value });
    this._shouldFill = value;
    this.requestRender();
  }
  getNativeScenePaint() {
    return {
      zIndex: this._zIndex,
      opacity: this._opacity,
      translateX: this._translateX,
      translateY: this._translateY,
      focusable: this._focusable,
      border: borderMask(this.borderSides),
      shouldFill: this._shouldFill,
      backgroundColor: this._backgroundColor,
      borderColor: this._borderColor,
      focusedBorderColor: this._focusedBorderColor,
      borderStyle: this._borderStyle
    };
  }
  applyYogaGap(options) {
    if (isGapType(options.gap)) {
      this.setGap(Gutter2.All, options.gap);
    }
    if (isGapType(options.rowGap)) {
      this.setGap(Gutter2.Row, options.rowGap);
    }
    if (isGapType(options.columnGap)) {
      this.setGap(Gutter2.Column, options.columnGap);
    }
  }
  set gap(gap) {
    this.setGapStyle(Gutter2.All, gap);
  }
  set rowGap(rowGap) {
    this.setGapStyle(Gutter2.Row, rowGap);
  }
  set columnGap(columnGap) {
    this.setGapStyle(Gutter2.Column, columnGap);
  }
  setGapStyle(gutter, gap) {
    if (gap != null && !isGapType(gap))
      return;
    this.setGap(gutter, gap ?? undefined);
    this.requestRender();
  }
}

// src/renderables/TextBufferRenderable.ts
class TextBufferRenderable2 extends Renderable2 {
  static nativeIntegration = this.defineNativeIntegration({
    kind: "text",
    body: { native: this.prototype.renderSelf },
    lifecycle: { resize: { native: this.prototype.onResize } },
    beforeAfter: false,
    paintBuffer: "destination",
    construction: "prototype"
  });
  _defaultFg;
  _defaultBg;
  _defaultAttributes;
  _selectionBg;
  _selectionFg;
  _wrapMode = "word";
  _textAlign = "left";
  lastLocalSelection = null;
  _tabIndicator;
  _tabIndicatorColor;
  _scrollX = 0;
  _scrollY = 0;
  _truncate = false;
  _firstLineOffset = 0;
  textBuffer;
  textBufferView;
  _textBufferSyntaxStyle;
  nativeTextScene;
  _defaultOptions = {
    fg: RGBA2.fromValues(1, 1, 1, 1),
    bg: RGBA2.fromValues(0, 0, 0, 0),
    selectionBg: undefined,
    selectionFg: undefined,
    selectable: true,
    attributes: 0,
    wrapMode: "word",
    textAlign: "left",
    tabIndicator: undefined,
    tabIndicatorColor: undefined,
    truncate: false
  };
  constructor(ctx, options, sharedText = false) {
    super(ctx, options);
    this.nativeTextScene = sharedText ? undefined : ctx.nativeScene;
    let textBuffer;
    let textBufferView;
    let syntaxStyle;
    try {
      this._defaultFg = RGBA2.clone(parseColor2(options.fg ?? this._defaultOptions.fg));
      this._defaultBg = RGBA2.clone(parseColor2(options.bg ?? this._defaultOptions.bg));
      this._defaultAttributes = options.attributes ?? this._defaultOptions.attributes;
      this._selectionBg = options.selectionBg ? RGBA2.clone(parseColor2(options.selectionBg)) : undefined;
      this._selectionFg = options.selectionFg ? RGBA2.clone(parseColor2(options.selectionFg)) : undefined;
      this.selectable = options.selectable ?? this._defaultOptions.selectable;
      this._wrapMode = options.wrapMode ?? this._defaultOptions.wrapMode;
      this._textAlign = options.textAlign ?? this._defaultOptions.textAlign;
      this._tabIndicator = options.tabIndicator ?? this._defaultOptions.tabIndicator;
      this._tabIndicatorColor = options.tabIndicatorColor ? RGBA2.clone(parseColor2(options.tabIndicatorColor)) : this._defaultOptions.tabIndicatorColor;
      this._truncate = options.truncate ?? this._defaultOptions.truncate;
      if (this.nativeTextScene) {
        this._firstLineOffset = ctx.claimFirstLineOffset?.(this) ?? 0;
        this.setNativeScenePaint();
        this.setNativeSceneTextOptions();
        return;
      }
      textBuffer = TextBuffer2.create(this._ctx.widthMethod, ctx.nativeScene);
      this.textBuffer = textBuffer;
      textBufferView = TextBufferView2.create(textBuffer);
      this.textBufferView = textBufferView;
      this._firstLineOffset = ctx.claimFirstLineOffset?.(this) ?? 0;
      syntaxStyle = SyntaxStyle2.create(ctx.nativeScene);
      this._textBufferSyntaxStyle = syntaxStyle;
      textBuffer.setSyntaxStyle(syntaxStyle);
      this.textBufferView.setWrapMode(this._wrapMode);
      this.textBufferView.setTextAlign(this._textAlign);
      this.textBufferView.setFirstLineOffset(this._firstLineOffset);
      ctx.nativeScene.setTextView(this, textBufferView._getSceneHandle(ctx.nativeScene));
      this.textBuffer._setDefaults(this._defaultFg, this._defaultBg, this._defaultAttributes);
      if (this._tabIndicator !== undefined) {
        this.textBufferView.setTabIndicator(this._tabIndicator);
      }
      if (this._tabIndicatorColor !== undefined) {
        this.textBufferView.setTabIndicatorColor(this._tabIndicatorColor);
      }
      const width = this.width;
      if (width > 0 && this.height > 0)
        this.updateViewportOffset();
      else if (this._wrapMode !== "none" && width > 0)
        this.textBufferView.setWrapWidth(Math.trunc(width));
      this.textBufferView.setTruncate(this._truncate);
      this.updateTextInfo();
    } catch (error) {
      this.abortConstruction(error, (run) => {
        run(() => textBuffer?.setSyntaxStyle(null));
        run(() => syntaxStyle?.destroy());
        run(() => textBufferView?.destroy());
        run(() => textBuffer?.destroy());
      });
    }
  }
  onMouseEvent(event) {
    if (event.type === "scroll") {
      this.handleScroll(event);
    }
  }
  handleScroll(event) {
    if (!event.scroll)
      return;
    const { direction, delta } = event.scroll;
    if (direction === "up") {
      this.scrollY -= delta;
    } else if (direction === "down") {
      this.scrollY += delta;
    }
    if (this._wrapMode === "none") {
      if (direction === "left") {
        this.scrollX -= delta;
      } else if (direction === "right") {
        this.scrollX += delta;
      }
    }
  }
  get lineInfo() {
    if (this.nativeTextScene)
      return this.nativeTextScene.getTextLineInfo(this);
    return this.textBufferView.logicalLineInfo;
  }
  getLineSources(startLine, lineCount) {
    if (this.needsLineInfoFallback(TextBufferRenderable2.prototype)) {
      return this.lineInfo.lineSources.slice(startLine, startLine + lineCount);
    }
    if (this.nativeTextScene) {
      return this.nativeTextScene.getTextLineInfo(this, startLine, lineCount).lineSources;
    }
    return this.textBufferView.getLineSources(startLine, lineCount);
  }
  needsLineInfoFallback(owner) {
    let prototype = this;
    while (prototype && prototype !== owner) {
      if (Object.hasOwn(prototype, "getLineSources"))
        return false;
      if (Object.hasOwn(prototype, "lineInfo"))
        return true;
      prototype = Object.getPrototypeOf(prototype);
    }
    return false;
  }
  get lineCount() {
    if (this.nativeTextScene)
      return this.nativeTextScene.getTextMetrics(this).lineCount;
    return this.textBuffer.getLineCount();
  }
  get virtualLineCount() {
    if (this.nativeTextScene)
      return this.nativeTextScene.getTextMetrics(this).virtualLineCount;
    return this.textBufferView.getVirtualLineCount();
  }
  get scrollY() {
    return this._scrollY;
  }
  set scrollY(value) {
    const maxScrollY = Math.max(0, this.scrollHeight - this.height);
    const clamped = Math.max(0, Math.min(value ?? 0, maxScrollY));
    if (this._scrollY !== clamped) {
      this.runMutation(() => {
        this.setNativeSceneTextOptions({ scrollY: clamped });
        if (!this.nativeTextScene)
          this.updateViewportOffset(this._scrollX, clamped);
        this._scrollY = clamped;
        this.requestRender();
      });
    }
  }
  get scrollX() {
    return this._scrollX;
  }
  set scrollX(value) {
    const maxScrollX = Math.max(0, this.scrollWidth - this.width);
    const clamped = Math.max(0, Math.min(value ?? 0, maxScrollX));
    if (this._scrollX !== clamped) {
      this.runMutation(() => {
        this.setNativeSceneTextOptions({ scrollX: clamped });
        if (!this.nativeTextScene)
          this.updateViewportOffset(clamped, this._scrollY);
        this._scrollX = clamped;
        this.requestRender();
      });
    }
  }
  get scrollWidth() {
    if (this.nativeTextScene)
      return this.nativeTextScene.getTextMetrics(this).widthColsMax;
    return this.lineInfo.lineWidthColsMax;
  }
  get scrollHeight() {
    if (this.nativeTextScene)
      return this.nativeTextScene.getTextMetrics(this).virtualLineCount;
    return this.virtualLineCount;
  }
  get maxScrollY() {
    return Math.max(0, this.scrollHeight - this.height);
  }
  get maxScrollX() {
    return Math.max(0, this.scrollWidth - this.width);
  }
  updateViewportOffset(scrollX = this._scrollX, scrollY = this._scrollY) {
    const width = this.width;
    const height = this.height;
    if (width > 0 && height > 0) {
      this.textBufferView.setViewport(Math.trunc(scrollX), Math.trunc(scrollY), Math.trunc(width), Math.trunc(height));
    }
  }
  get plainText() {
    if (this.nativeTextScene)
      return this.nativeTextScene.getText(this);
    return this.textBuffer.getPlainText();
  }
  get textLength() {
    if (this.nativeTextScene)
      return this.nativeTextScene.getTextMetrics(this).textLength;
    return this.textBuffer.length;
  }
  get fg() {
    return RGBA2.clone(this._defaultFg);
  }
  set fg(value) {
    const newColor = RGBA2.clone(parseColor2(value ?? this._defaultOptions.fg));
    this.runMutation(() => {
      this.setNativeSceneTextOptions({ fg: newColor });
      if (!this.nativeTextScene)
        this.textBuffer.setDefaultFg(newColor);
      this._defaultFg = newColor;
      this.onFgChanged(newColor);
      this.requestRender();
    });
  }
  get selectionBg() {
    return this._selectionBg ? RGBA2.clone(this._selectionBg) : undefined;
  }
  set selectionBg(value) {
    const newColor = value ? RGBA2.clone(parseColor2(value)) : undefined;
    if (this._selectionBg !== newColor) {
      this.runMutation(() => {
        if (this.nativeTextScene || this.lastLocalSelection) {
          this.updateLocalSelection(this.lastLocalSelection, true, { bg: newColor, fg: this._selectionFg });
        }
        this._selectionBg = newColor;
        this.requestRender();
      });
    }
  }
  get selectionFg() {
    return this._selectionFg ? RGBA2.clone(this._selectionFg) : undefined;
  }
  set selectionFg(value) {
    const newColor = value ? RGBA2.clone(parseColor2(value)) : undefined;
    if (this._selectionFg !== newColor) {
      this.runMutation(() => {
        if (this.nativeTextScene || this.lastLocalSelection) {
          this.updateLocalSelection(this.lastLocalSelection, true, { bg: this._selectionBg, fg: newColor });
        }
        this._selectionFg = newColor;
        this.requestRender();
      });
    }
  }
  get bg() {
    return RGBA2.clone(this._defaultBg);
  }
  set bg(value) {
    const newColor = RGBA2.clone(parseColor2(value ?? this._defaultOptions.bg));
    this.runMutation(() => {
      this.setNativeSceneTextOptions({ bg: newColor });
      if (!this.nativeTextScene)
        this.textBuffer.setDefaultBg(newColor);
      this._defaultBg = newColor;
      this.onBgChanged(newColor);
      this.requestRender();
    });
  }
  get attributes() {
    return this._defaultAttributes;
  }
  set attributes(value) {
    const attributes = value ?? this._defaultOptions.attributes;
    if (this._defaultAttributes !== attributes) {
      this.runMutation(() => {
        this.setNativeSceneTextOptions({ attributes });
        if (!this.nativeTextScene)
          this.textBuffer.setDefaultAttributes(attributes);
        this._defaultAttributes = attributes;
        this.onAttributesChanged(attributes);
        this.requestRender();
      });
    }
  }
  get wrapMode() {
    return this._wrapMode;
  }
  set wrapMode(value) {
    value ??= this._defaultOptions.wrapMode;
    if (this._wrapMode !== value) {
      this.runMutation(() => {
        this.setNativeSceneTextOptions({ wrapMode: value });
        if (!this.nativeTextScene)
          this.textBufferView.setWrapMode(value);
        this._wrapMode = value;
        if (!this.nativeTextScene && value !== "none") {
          const width = this.width;
          if (width > 0)
            this.textBufferView.setWrapWidth(Math.trunc(width));
        }
        this.requestRender();
      });
    }
  }
  get textAlign() {
    return this._textAlign;
  }
  set textAlign(value) {
    value ??= this._defaultOptions.textAlign;
    if (this._textAlign !== value) {
      this.runMutation(() => {
        this.setNativeSceneTextOptions({ textAlign: value });
        if (!this.nativeTextScene)
          this.textBufferView.setTextAlign(value);
        this._textAlign = value;
        this.requestRender();
      });
    }
  }
  get tabIndicator() {
    return this._tabIndicator;
  }
  set tabIndicator(value) {
    if (this._tabIndicator !== value) {
      this.runMutation(() => {
        this.setNativeSceneTextOptions({ tabIndicator: value });
        if (!this.nativeTextScene)
          this.textBufferView.setTabIndicator(value ?? 0);
        this._tabIndicator = value;
        this.requestRender();
      });
    }
  }
  get tabIndicatorColor() {
    return this._tabIndicatorColor ? RGBA2.clone(this._tabIndicatorColor) : undefined;
  }
  set tabIndicatorColor(value) {
    const newColor = value ? RGBA2.clone(parseColor2(value)) : undefined;
    if (this._tabIndicatorColor !== newColor) {
      this.runMutation(() => {
        this.setNativeSceneTextOptions({ tabIndicatorColor: newColor });
        if (!this.nativeTextScene && newColor !== undefined)
          this.textBufferView.setTabIndicatorColor(newColor);
        this._tabIndicatorColor = newColor;
        this.requestRender();
      });
    }
  }
  get truncate() {
    return this._truncate;
  }
  set truncate(value) {
    value ??= this._defaultOptions.truncate;
    if (this._truncate !== value) {
      this.runMutation(() => {
        this.setNativeSceneTextOptions({ truncate: value });
        if (!this.nativeTextScene)
          this.textBufferView.setTruncate(value);
        this._truncate = value;
        this.requestRender();
      });
    }
  }
  onResize(width, height) {
    if (!this.nativeTextScene) {
      this.textBufferView.setViewport(Math.trunc(this._scrollX), Math.trunc(this._scrollY), width, height);
    }
    this.requestRender();
    this.emit("line-info-change");
  }
  refreshLocalSelection() {
    if (this.lastLocalSelection) {
      return this.updateLocalSelection(this.lastLocalSelection);
    }
    return false;
  }
  updateLocalSelection(localSelection, isStart = true, colors) {
    const bg = colors ? colors.bg : this._selectionBg;
    const fg = colors ? colors.fg : this._selectionFg;
    if (this.nativeTextScene) {
      return this.nativeTextScene.setTextSelection(this, !localSelection?.isActive ? "reset" : isStart ? "set" : "update", localSelection, bg, fg);
    }
    if (!localSelection?.isActive) {
      this.textBufferView.resetLocalSelection();
      return true;
    }
    return this.textBufferView[isStart ? "setLocalSelection" : "updateLocalSelection"](localSelection.anchorX, localSelection.anchorY, localSelection.focusX, localSelection.focusY, bg, fg, localSelection.behavior);
  }
  updateTextInfo() {
    if (this.lastLocalSelection) {
      this.updateLocalSelection(this.lastLocalSelection);
    }
    this.requestRender();
    this.emit("line-info-change");
  }
  shouldStartSelection(x, y) {
    if (!this.selectable)
      return false;
    const localX = x - this.x;
    const localY = y - this.y;
    return localX >= 0 && localX < this.width && localY >= 0 && localY < this.height;
  }
  onSelectionChanged(selection) {
    const localSelection = convertGlobalToLocalSelection2(selection, Math.trunc(this.x), Math.trunc(this.y));
    const changed = this.updateLocalSelection(localSelection, selection?.isStart ?? false);
    this.lastLocalSelection = localSelection;
    if (changed) {
      this.requestRender();
    }
    return this.hasSelection();
  }
  getSelectedText() {
    if (this.nativeTextScene)
      return this.nativeTextScene.getSelectedText(this);
    return this.textBufferView.getSelectedText();
  }
  hasSelection() {
    if (this.nativeTextScene)
      return this.nativeTextScene.getTextSelection(this) !== null;
    return this.textBufferView.hasSelection();
  }
  getSelection() {
    if (this.nativeTextScene)
      return this.nativeTextScene.getTextSelection(this);
    return this.textBufferView.getSelection();
  }
  renderSelf(buffer) {
    this.drawToBuffer(buffer, this._screenX, this._screenY);
  }
  drawToBuffer(buffer, x, y) {
    if (this.isDestroyed)
      throw new Error("Cannot draw destroyed text");
    if (this.nativeTextScene) {
      this.nativeTextScene.drawText(this, buffer, Math.trunc(x), Math.trunc(y));
      return;
    }
    buffer.drawTextBuffer(this.textBufferView, Math.trunc(x), Math.trunc(y));
  }
  destroyOwnedResources() {
    if (this.nativeTextScene)
      return;
    this.runCleanup((run) => {
      run(() => this.textBuffer.setSyntaxStyle(null));
      run(() => this._textBufferSyntaxStyle.destroy());
      run(() => this.textBufferView.destroy());
      run(() => this.textBuffer.destroy());
    });
  }
  setNativeSceneTextOptions(options = {}) {
    this.nativeTextScene?.setTextOptions(this, {
      fg: this._defaultFg,
      bg: this._defaultBg,
      attributes: this._defaultAttributes,
      wrapMode: this._wrapMode,
      textAlign: this._textAlign,
      truncate: this._truncate,
      scrollX: this._scrollX,
      scrollY: this._scrollY,
      firstLineOffset: this._firstLineOffset,
      tabIndicator: this._tabIndicator,
      tabIndicatorColor: this._tabIndicatorColor,
      ...options
    });
  }
  onFgChanged(newColor) {}
  onBgChanged(newColor) {}
  onAttributesChanged(newAttributes) {}
}

// src/renderables/Code.ts
class CodeRenderable2 extends TextBufferRenderable2 {
  static nativeIntegration = this.defineNativeIntegration({
    ...TextBufferRenderable2.nativeIntegration,
    kind: "text_view",
    body: { native: this.prototype.renderSelf },
    lifecycle: {
      ...TextBufferRenderable2.nativeIntegration.lifecycle,
      update: {
        idle: this.prototype.onUpdate,
        active: (renderable) => renderable._highlightsDirty
      }
    }
  });
  _content;
  _filetype;
  _syntaxStyle;
  _isHighlighting = false;
  _treeSitterClient;
  _highlightsDirty = false;
  _highlightSnapshotId = 0;
  _highlightLoopActive = false;
  _highlightPromise;
  _highlightRerun = false;
  _conceal;
  _drawUnstyledText;
  _shouldRenderTextBuffer = true;
  _streaming;
  _initialStyledText;
  _hadInitialContent = false;
  _baseHighlight;
  _onHighlight;
  _onChunks;
  _highlightingPromise = Promise.resolve();
  _renderedLineSources;
  _mappedLineInfo;
  _contentDefaultOptions = {
    content: "",
    conceal: true,
    drawUnstyledText: true,
    streaming: false
  };
  constructor(ctx, options) {
    super(ctx, options, true);
    try {
      this._content = options.content ?? this._contentDefaultOptions.content;
      this._filetype = options.filetype;
      this._syntaxStyle = options.syntaxStyle;
      this._treeSitterClient = options.treeSitterClient ?? getTreeSitterClient2();
      this._conceal = options.conceal ?? this._contentDefaultOptions.conceal;
      this._drawUnstyledText = options.drawUnstyledText ?? this._contentDefaultOptions.drawUnstyledText;
      this._streaming = options.streaming ?? this._contentDefaultOptions.streaming;
      this._initialStyledText = options.initialStyledText;
      this._baseHighlight = options.baseHighlight;
      this._onHighlight = options.onHighlight;
      this._onChunks = options.onChunks;
      if (this._content.length > 0) {
        if (this._initialStyledText && this._drawUnstyledText) {
          this.textBuffer.setStyledText(this._initialStyledText);
        } else {
          this.textBuffer.setText(this._content);
        }
        this.updateTextInfo();
        this.setShouldRenderTextBuffer(this._drawUnstyledText || !this._filetype);
      }
      this.setHighlightsDirty(this._content.length > 0);
    } catch (error) {
      this.rollbackConstruction(error);
    }
  }
  get content() {
    return this._content;
  }
  invalidateHighlights() {
    this.setHighlightsDirty(true);
    this._highlightSnapshotId++;
  }
  setHighlightsDirty(value) {
    if (this._highlightsDirty === value)
      return;
    this._highlightsDirty = value;
    if (!this.isDestroyed)
      this.refreshNativeSceneHooks();
  }
  setShouldRenderTextBuffer(value) {
    if (this._shouldRenderTextBuffer === value)
      return;
    this._shouldRenderTextBuffer = value;
    if (!this.isDestroyed)
      this._ctx.nativeScene.setTextViewPaint(this, value);
  }
  set content(value) {
    if (this._content === value)
      return;
    this.runMutation(() => {
      if (this._streaming && this._filetype && !this._drawUnstyledText) {
        this._content = value;
        this.invalidateHighlights();
        this.requestRender();
        return;
      }
      if (value && this._initialStyledText && this._drawUnstyledText) {
        this.textBuffer.setStyledText(this._initialStyledText);
      } else {
        this.textBuffer.setText(value);
      }
      this._content = value;
      this.invalidateHighlights();
      this.setRenderedLineSources(undefined);
      this.updateTextInfo();
    });
  }
  updateStreamingPreview(content, initialStyledText) {
    this._content = content;
    this._initialStyledText = initialStyledText;
    this.invalidateHighlights();
    this.textBuffer.setStyledText(initialStyledText);
    this.setRenderedLineSources(undefined);
    this.updateTextInfo();
  }
  get lineInfo() {
    if (!this._renderedLineSources)
      return super.lineInfo;
    if (this._mappedLineInfo)
      return this._mappedLineInfo;
    const lineInfo = super.lineInfo;
    const renderedLineSources = this._renderedLineSources;
    this._mappedLineInfo = {
      ...lineInfo,
      lineSources: lineInfo.lineSources.map((line) => renderedLineSources[line] ?? line)
    };
    return this._mappedLineInfo;
  }
  getLineSources(startLine, lineCount) {
    if (this.needsLineInfoFallback(CodeRenderable2.prototype)) {
      return this.lineInfo.lineSources.slice(startLine, startLine + lineCount);
    }
    const sources = this.textBufferView.getLineSources(startLine, lineCount);
    const renderedLineSources = this._renderedLineSources;
    return renderedLineSources ? sources.map((line) => renderedLineSources[line] ?? line) : sources;
  }
  get wrapMode() {
    return super.wrapMode;
  }
  set wrapMode(value) {
    if (super.wrapMode !== value) {
      this._mappedLineInfo = undefined;
      super.wrapMode = value;
    }
  }
  onResize(width, height) {
    this._mappedLineInfo = undefined;
    super.onResize(width, height);
  }
  updateTextInfo() {
    this._mappedLineInfo = undefined;
    super.updateTextInfo();
  }
  get filetype() {
    return this._filetype;
  }
  set filetype(value) {
    if (this._filetype !== value) {
      this._filetype = value;
      this.invalidateHighlights();
    }
  }
  get syntaxStyle() {
    return this._syntaxStyle;
  }
  set syntaxStyle(value) {
    if (this._syntaxStyle !== value) {
      this._syntaxStyle = value;
      this.invalidateHighlights();
    }
  }
  get conceal() {
    return this._conceal;
  }
  set conceal(value) {
    if (this._conceal !== value) {
      this._conceal = value;
      this.invalidateHighlights();
    }
  }
  get drawUnstyledText() {
    return this._drawUnstyledText;
  }
  set drawUnstyledText(value) {
    if (this._drawUnstyledText !== value) {
      this._drawUnstyledText = value;
      this.invalidateHighlights();
    }
  }
  get streaming() {
    return this._streaming;
  }
  set initialStyledText(value) {
    if (this._initialStyledText !== value) {
      if (value && this._streaming && this._drawUnstyledText && this._isHighlighting) {
        this.updateStreamingPreview(this._content, value);
        return;
      }
      this._initialStyledText = value;
      this.invalidateHighlights();
    }
  }
  set streaming(value) {
    if (this._streaming !== value) {
      this._streaming = value;
      this._hadInitialContent = false;
      this.invalidateHighlights();
    }
  }
  get treeSitterClient() {
    return this._treeSitterClient;
  }
  set treeSitterClient(value) {
    if (this._treeSitterClient !== value) {
      this._treeSitterClient = value;
      this.invalidateHighlights();
    }
  }
  get onHighlight() {
    return this._onHighlight;
  }
  get baseHighlight() {
    return this._baseHighlight;
  }
  set baseHighlight(value) {
    if (this._baseHighlight !== value) {
      this._baseHighlight = value;
      this.invalidateHighlights();
    }
  }
  set onHighlight(value) {
    if (this._onHighlight !== value) {
      this._onHighlight = value;
      this.invalidateHighlights();
    }
  }
  get onChunks() {
    return this._onChunks;
  }
  set onChunks(value) {
    if (this._onChunks !== value) {
      this._onChunks = value;
      this.invalidateHighlights();
    }
  }
  get isHighlighting() {
    return this._isHighlighting || this._highlightRerun;
  }
  get highlightingDone() {
    return this._highlightingPromise;
  }
  async transformChunks(chunks, context) {
    if (!this._onChunks)
      return chunks;
    const modified = await this._onChunks(chunks, context);
    return modified ?? chunks;
  }
  ensureVisibleTextBeforeHighlight() {
    const content = this._content;
    const isInitialContent = this._streaming && !this._hadInitialContent;
    const shouldDrawUnstyledNow = this._streaming ? isInitialContent && this._drawUnstyledText : this._drawUnstyledText;
    if (this._streaming && !isInitialContent) {
      this.setShouldRenderTextBuffer(true);
    } else if (shouldDrawUnstyledNow) {
      if (this._initialStyledText) {
        this.textBuffer.setStyledText(this._initialStyledText);
      } else {
        this.textBuffer.setText(content);
      }
      this.setRenderedLineSources(undefined);
      this.setShouldRenderTextBuffer(true);
    } else {
      this.setShouldRenderTextBuffer(false);
    }
  }
  async startHighlight() {
    const content = this._content;
    const filetype = this._filetype;
    const snapshotId = ++this._highlightSnapshotId;
    if (!filetype)
      return;
    const isInitialContent = this._streaming && !this._hadInitialContent;
    if (isInitialContent) {
      this._hadInitialContent = true;
    }
    this._isHighlighting = true;
    try {
      const result = await this._treeSitterClient.highlightOnce(content, filetype);
      if (snapshotId !== this._highlightSnapshotId) {
        this.requestRender();
        return;
      }
      if (this.isDestroyed)
        return;
      let highlights = result.highlights ?? [];
      if (this._onHighlight && highlights.length >= 0) {
        const context = {
          content,
          filetype,
          syntaxStyle: this._syntaxStyle
        };
        const modified = await this._onHighlight(highlights, context);
        if (modified !== undefined) {
          highlights = modified;
        }
      }
      if (snapshotId !== this._highlightSnapshotId) {
        this.requestRender();
        return;
      }
      if (this.isDestroyed)
        return;
      if (highlights.length > 0 || this._onChunks || this._baseHighlight) {
        const sourceRanges = this._onChunks ? [] : undefined;
        const context = {
          content,
          filetype,
          syntaxStyle: this._syntaxStyle,
          highlights,
          sourceRanges
        };
        let chunks = treeSitterToTextChunks2(content, highlights, this._syntaxStyle, {
          enabled: this._conceal,
          baseHighlight: this._baseHighlight,
          ranges: sourceRanges
        });
        const renderedLineSources = this._onChunks ? undefined : this.getConcealLinesSourceMap(content, highlights);
        chunks = await this.transformChunks(chunks, context);
        if (snapshotId !== this._highlightSnapshotId) {
          this.requestRender();
          return;
        }
        if (this.isDestroyed)
          return;
        const styledText = new StyledText2(chunks);
        this.textBuffer.setStyledText(styledText);
        this.setRenderedLineSources(renderedLineSources);
      } else {
        this.textBuffer.setText(content);
        this.setRenderedLineSources(undefined);
      }
      this.setShouldRenderTextBuffer(true);
      this._isHighlighting = false;
      this.setHighlightsDirty(false);
      this.updateTextInfo();
      this.requestRender();
    } catch (error) {
      if (snapshotId !== this._highlightSnapshotId) {
        this.requestRender();
        return;
      }
      console.warn("Code highlighting failed, falling back to plain text:", error);
      if (this.isDestroyed)
        return;
      this.textBuffer.setText(content);
      this.setRenderedLineSources(undefined);
      this.setShouldRenderTextBuffer(true);
      this._isHighlighting = false;
      this.setHighlightsDirty(false);
      this.updateTextInfo();
      this.requestRender();
    }
  }
  async runHighlights() {
    try {
      do {
        this._highlightRerun = false;
        await this.startHighlight();
      } while (this._highlightRerun && !this.isDestroyed && this._content.length > 0 && this._filetype);
    } finally {
      this._isHighlighting = false;
      this._highlightLoopActive = false;
      this._highlightRerun = false;
    }
  }
  clearPendingHighlight() {
    this._highlightSnapshotId++;
    this._isHighlighting = false;
    this._highlightRerun = false;
    this._highlightingPromise = Promise.resolve();
  }
  setRenderedLineSources(lineSources) {
    this._renderedLineSources = lineSources;
    this._mappedLineInfo = undefined;
  }
  static isIdentityLineSources(lineSources) {
    for (let i = 0;i < lineSources.length; i++) {
      if (lineSources[i] !== i)
        return false;
    }
    return true;
  }
  static getMergedConcealLineRanges(highlights) {
    const ranges = [];
    for (const highlight of highlights) {
      const meta = highlight[3];
      if (meta?.concealLines === undefined)
        continue;
      const group = highlight[2];
      const isEmptyConceal = meta.conceal === "" || meta.conceal === undefined && (group === "conceal" || group.startsWith("conceal."));
      if (isEmptyConceal) {
        ranges.push([highlight[0], highlight[1]]);
      }
    }
    if (ranges.length <= 1)
      return ranges;
    ranges.sort((a, b) => a[0] - b[0]);
    let writeIndex = 0;
    for (let i = 1;i < ranges.length; i++) {
      const current = ranges[writeIndex];
      const next = ranges[i];
      if (next[0] <= current[1]) {
        current[1] = Math.max(current[1], next[1]);
      } else {
        writeIndex++;
        ranges[writeIndex] = next;
      }
    }
    ranges.length = writeIndex + 1;
    return ranges;
  }
  getConcealLinesSourceMap(content, highlights) {
    if (!this._conceal || content.length === 0)
      return;
    const concealLineRanges = CodeRenderable2.getMergedConcealLineRanges(highlights);
    if (concealLineRanges.length === 0)
      return;
    const lineSources = [];
    let sourceLine = 0;
    let lineStart = 0;
    let rangeIndex = 0;
    let currentRenderedLineHasText = false;
    const setCurrentRenderedLineSource = (line, hasText) => {
      if (lineSources.length === 0) {
        lineSources.push(line);
      } else if (!currentRenderedLineHasText) {
        lineSources[lineSources.length - 1] = line;
      }
      if (hasText)
        currentRenderedLineHasText = true;
    };
    while (lineStart <= content.length) {
      const newlineOffset = content.indexOf(`
`, lineStart);
      const lineEnd = newlineOffset === -1 ? content.length : newlineOffset;
      while (rangeIndex < concealLineRanges.length && concealLineRanges[rangeIndex][1] <= lineStart) {
        rangeIndex++;
      }
      const range = concealLineRanges[rangeIndex];
      const fullyConcealed = !!range && lineEnd > lineStart && range[0] <= lineStart && range[1] >= lineEnd;
      const lineBreakConcealed = newlineOffset !== -1 && !!range && range[0] <= newlineOffset && range[1] >= newlineOffset;
      if (!fullyConcealed || !lineBreakConcealed) {
        const hasText = lineEnd > lineStart && !fullyConcealed;
        if (hasText || newlineOffset !== -1 || !fullyConcealed) {
          setCurrentRenderedLineSource(sourceLine, hasText);
        }
        if (newlineOffset !== -1 && !lineBreakConcealed) {
          lineSources.push(sourceLine + 1);
          currentRenderedLineHasText = false;
        }
      }
      sourceLine++;
      if (newlineOffset === -1)
        break;
      lineStart = newlineOffset + 1;
    }
    if (lineSources.length === 0 || CodeRenderable2.isIdentityLineSources(lineSources))
      return;
    return lineSources;
  }
  getLineHighlights(lineIdx) {
    return this.textBuffer.getLineHighlights(lineIdx);
  }
  onUpdate(deltaTime) {
    super.onUpdate(deltaTime);
    this.scheduleHighlights();
  }
  scheduleHighlights() {
    if (!this._highlightsDirty || this.isDestroyed)
      return;
    const hasContent = this._content.length > 0;
    if (!hasContent || !this._filetype) {
      this.setShouldRenderTextBuffer(hasContent);
      this.setHighlightsDirty(false);
      this.clearPendingHighlight();
      if (hasContent) {
        this.textBuffer.setText(this._content);
        this.setRenderedLineSources(undefined);
        this.updateTextInfo();
      }
      return;
    }
    this.ensureVisibleTextBeforeHighlight();
    this.setHighlightsDirty(false);
    if (this._highlightLoopActive) {
      this._isHighlighting = true;
      this._highlightRerun = true;
      this._highlightingPromise = this._highlightPromise;
      return;
    }
    this._highlightLoopActive = true;
    this._highlightPromise = this.runHighlights();
    this._highlightingPromise = this._highlightPromise;
  }
  renderSelf(buffer) {
    if (!this._shouldRenderTextBuffer)
      return;
    super.renderSelf(buffer);
  }
  destroyOwnedResources() {
    this.runCleanup((run) => {
      run(() => this.clearPendingHighlight());
      run(() => super.destroyOwnedResources());
    });
  }
}

// src/image.ts
import { open, stat } from "fs/promises";
class ImageLoadError2 extends Error {
  code;
  source;
  status;
  constructor(code, source, message, options) {
    super(message, { cause: options?.cause });
    this.name = "ImageLoadError";
    this.code = code;
    this.source = source;
    this.status = options?.status;
  }
}

class OwnedRawImageImpl {
  data;
  width;
  height;
  stride;
  lib;
  owner;
  handle;
  format = "rgba8";
  colorSpace = "srgb";
  alpha = "straight";
  constructor(data, width, height, stride, lib, handle, owner) {
    this.data = data;
    this.width = width;
    this.height = height;
    this.stride = stride;
    this.lib = lib;
    this.owner = owner;
    this.handle = handle;
  }
  dispose() {
    if (!this.handle)
      return;
    this.lib.imageReleasePixels(this.handle);
    this.handle = null;
    this.owner.release();
  }
}

class ImageOwner {
  resources;
  automatic;
  static automaticOwner;
  references = 0;
  constructor(resources, automatic) {
    this.resources = resources;
    this.automatic = automatic;
  }
  static acquire(options) {
    resolveRenderLib2().getYogaHost().assertMutable();
    const owner = options.owner;
    let result;
    if (owner !== undefined) {
      owner.assertAlive();
      result = new ImageOwner(owner, false);
    } else {
      result = this.automaticOwner ??= new ImageOwner(new ResourceContext2({ objectCapacity: 4096, renderCellsMax: 1 }), true);
    }
    result.retain();
    return result;
  }
  retain() {
    this.references++;
  }
  release() {
    this.references--;
    if (this.references === 0 && this.automatic) {
      this.resources.destroy();
      ImageOwner.automaticOwner = undefined;
    }
  }
}
var STATUS_MESSAGES = [
  "ok",
  "invalid image handle",
  "unsupported image format",
  "unsupported image color space",
  "malformed image data",
  "image dimensions exceed limits",
  "image memory limit exceeded",
  "invalid image argument",
  "out of memory",
  "image output buffer is too small",
  "internal image error",
  "unsupported image feature",
  "image is retained"
];
var STATUS_CODES = [
  "internal-error",
  "invalid-handle",
  "unsupported-format",
  "unsupported-color-space",
  "malformed-data",
  "dimension-limit",
  "memory-limit",
  "invalid-argument",
  "out-of-memory",
  "output-too-small",
  "internal-error",
  "unsupported-feature",
  "busy"
];
var BUSY_STATUS = 12;

class ImageError2 extends Error {
  code;
  status;
  constructor(status) {
    super(`Native image operation failed: ${STATUS_MESSAGES[status] ?? `unknown status ${status}`}`);
    this.name = "ImageError";
    this.status = status;
    this.code = STATUS_CODES[status] ?? "internal-error";
  }
}
var FILTER_IDS = {
  default: 0,
  area: 1,
  triangle: 2,
  "cubic-bspline": 3,
  "catmull-rom": 4,
  mitchell: 5,
  nearest: 6
};
var BLEND_IDS = {
  "source-over": 0,
  source: 1,
  "destination-over": 2
};
var PIXEL_FORMAT_BGRA = {
  rgba8: false,
  bgra8: true
};
var PIXEL_ALPHA_IDS = { straight: 0, opaque: 1 };
var MAX_ENCODED_BYTES = 64 * 1024 * 1024;
function imageError(status) {
  return new ImageError2(status);
}
function checkStatus(status) {
  if (status !== 0)
    throw imageError(status);
}
function requireMappedOption(mapping, value, name) {
  if (!Object.prototype.hasOwnProperty.call(mapping, value))
    throw new TypeError(`Unsupported ${name}: ${String(value)}`);
  return mapping[value];
}
function requireU32(value, name, allowZero = false) {
  if (!Number.isSafeInteger(value) || value < (allowZero ? 0 : 1) || value > 4294967295) {
    throw new RangeError(`${name} must be ${allowZero ? "a non-negative" : "a positive"} u32 integer`);
  }
  return value;
}
function pixelImportOptions(width, options) {
  const stride = requireU32(options.stride ?? width * 4, "stride");
  const bgra = requireMappedOption(PIXEL_FORMAT_BGRA, options.format ?? "rgba8", "pixel format");
  const alpha = requireMappedOption(PIXEL_ALPHA_IDS, options.alpha ?? "straight", "pixel alpha");
  if (options.colorSpace !== undefined && options.colorSpace !== "srgb") {
    throw new TypeError(`Unsupported pixel color space: ${String(options.colorSpace)}`);
  }
  return { stride, format: Number(bgra), alpha };
}
function requireI32(value, name) {
  if (!Number.isSafeInteger(value) || value < -2147483648 || value > 2147483647) {
    throw new RangeError(`${name} must be an i32 integer`);
  }
  return value;
}
function requireByte(value, name) {
  if (!Number.isInteger(value) || value < 0 || value > 255)
    throw new RangeError(`${name} must be an integer from 0 to 255`);
  return value;
}
function unpackInfo(info) {
  const format = ["unknown", "png", "raw-rgba", "jpeg", "webp", "gif"][info.format];
  if (!format || format === "unknown")
    throw new Error(`Unknown native image format ${info.format}`);
  return {
    width: info.width,
    height: info.height,
    sourceWidth: info.sourceWidth,
    sourceHeight: info.sourceHeight,
    format,
    colorStatus: info.colorStatus === 1 ? "explicit-srgb" : "assumed-srgb",
    orientation: info.orientation,
    hasAlpha: info.hasAlpha !== 0
  };
}
function encodedBytes(data) {
  if (data instanceof Uint8Array)
    return data;
  if (data instanceof ArrayBuffer)
    return new Uint8Array(data);
  throw new TypeError("image data must be a Uint8Array or ArrayBuffer");
}
async function readResponseBytes(response, signal) {
  const contentLength = response.headers.get("content-length");
  if (contentLength !== null) {
    const declaredLength = Number(contentLength);
    if (Number.isFinite(declaredLength) && declaredLength > MAX_ENCODED_BYTES) {
      response.body?.cancel().catch(() => {});
      throw imageError(6);
    }
  }
  if (!response.body)
    return new Uint8Array;
  const reader = response.body.getReader();
  const abort = () => void reader.cancel(signal?.reason).catch(() => {});
  signal?.addEventListener("abort", abort, { once: true });
  let data = new Uint8Array;
  let total = 0;
  try {
    while (true) {
      signal?.throwIfAborted();
      const { done, value } = await reader.read();
      if (done)
        break;
      if (value.byteLength > MAX_ENCODED_BYTES - total) {
        throw imageError(6);
      }
      if (value.byteLength === 0)
        continue;
      const required = total + value.byteLength;
      if (required > data.byteLength) {
        const capacity = Math.min(MAX_ENCODED_BYTES, Math.max(required, data.byteLength * 2));
        const grown = new Uint8Array(capacity);
        grown.set(data.subarray(0, total));
        data = grown;
      }
      data.set(value, total);
      total = required;
    }
  } catch (error) {
    reader.cancel().catch(() => {});
    throw error;
  } finally {
    signal?.removeEventListener("abort", abort);
    reader.releaseLock();
  }
  return data.byteLength === total ? data : data.slice(0, total);
}
async function readFileBytes(path, signal) {
  signal?.throwIfAborted();
  if ((await stat(path)).size > MAX_ENCODED_BYTES)
    throw imageError(6);
  const file = await open(path, "r");
  const chunks = [];
  let total = 0;
  try {
    while (true) {
      signal?.throwIfAborted();
      const chunk = new Uint8Array(Math.min(64 * 1024, MAX_ENCODED_BYTES - total + 1));
      const { bytesRead } = await file.read(chunk, 0, chunk.byteLength, null);
      if (bytesRead === 0)
        break;
      total += bytesRead;
      if (total > MAX_ENCODED_BYTES)
        throw imageError(6);
      chunks.push(chunk.subarray(0, bytesRead));
    }
  } finally {
    await file.close();
  }
  const data = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    data.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return data;
}
async function loadResponseBytes(response, source, signal) {
  try {
    signal?.throwIfAborted();
  } catch (error) {
    response.body?.cancel().catch(() => {});
    throw error;
  }
  if (!response.ok) {
    response.body?.cancel().catch(() => {});
    throw new ImageLoadError2("http-status", source, `Failed to fetch image: HTTP ${response.status}`, {
      status: response.status
    });
  }
  try {
    const data = await readResponseBytes(response, signal);
    signal?.throwIfAborted();
    return data;
  } catch (error) {
    if (signal?.aborted)
      throw signal.reason;
    if (error instanceof ImageError2)
      throw error;
    throw new ImageLoadError2("network", source, `Failed to read image response: ${source}`, { cause: error });
  }
}
function imageInfo2(data, options = {}) {
  const bytes = encodedBytes(data);
  if (bytes.byteLength === 0)
    throw new TypeError("image data must not be empty");
  const owner = ImageOwner.acquire(options);
  try {
    const result = owner.resources.renderLib.imageInfo(owner.resources.context, bytes);
    checkStatus(result.status);
    return unpackInfo(result.info);
  } finally {
    owner.release();
  }
}

class NativeImage2 {
  owner;
  lib;
  handle;
  imageInfo;
  contextImages = new Map;
  constructor(owner, handle, info) {
    this.owner = owner;
    this.lib = owner.resources.renderLib;
    this.handle = handle;
    this.imageInfo = info;
    owner.retain();
  }
  static create(options, operation) {
    const owner = ImageOwner.acquire(options);
    try {
      const result = operation(owner);
      checkStatus(result.status);
      if (!result.handle)
        throw imageError(10);
      return NativeImage2.fromHandle(owner, result.handle);
    } finally {
      owner.release();
    }
  }
  static decode(data, options = {}) {
    const bytes = encodedBytes(data);
    if (bytes.byteLength === 0)
      throw new TypeError("image data must not be empty");
    return NativeImage2.create(options, ({ resources }) => resources.renderLib.imageDecode(resources.context, bytes));
  }
  static async load(source, options = {}) {
    if (source instanceof Response) {
      return NativeImage2.decode(await loadResponseBytes(source, source.url || "Response", options.signal), options);
    }
    options.signal?.throwIfAborted();
    if (source instanceof Uint8Array || source instanceof ArrayBuffer)
      return NativeImage2.decode(source, options);
    if (source instanceof Blob) {
      if (source.size > MAX_ENCODED_BYTES)
        throw imageError(6);
      return NativeImage2.decode(await loadResponseBytes(new Response(source), "Blob", options.signal), options);
    }
    const url = source instanceof URL ? source : (/^(?:https?|file|blob|data):/i.test(source) || /^[a-z][a-z0-9+.-]*:\/\//i.test(source)) && !/^[a-z]:[\\/]/i.test(source) ? new URL(source) : null;
    if (!url || url.protocol === "file:") {
      const path = url ?? source;
      let data;
      try {
        data = await readFileBytes(path, options.signal);
      } catch (error) {
        if (options.signal?.aborted)
          throw options.signal.reason;
        if (error instanceof ImageError2)
          throw error;
        throw new ImageLoadError2("file-read", String(source), `Failed to read image: ${String(source)}`, {
          cause: error
        });
      }
      options.signal?.throwIfAborted();
      return NativeImage2.decode(data, options);
    }
    if (url.protocol !== "http:" && url.protocol !== "https:" && url.protocol !== "blob:" && url.protocol !== "data:") {
      throw new ImageLoadError2("unsupported-url-scheme", url.href, `Unsupported image URL scheme: ${url.protocol}`);
    }
    let response;
    try {
      response = await (options.fetch ?? globalThis.fetch)(url, { signal: options.signal });
    } catch (error) {
      if (options.signal?.aborted)
        throw options.signal.reason;
      throw new ImageLoadError2("network", url.href, `Failed to fetch image: ${url.href}`, { cause: error });
    }
    return NativeImage2.decode(await loadResponseBytes(response, url.href, options.signal), options);
  }
  static fromRgba(pixels, width, height, stride = width * 4, options = {}) {
    if (!(pixels instanceof Uint8Array))
      throw new TypeError("pixels must be a Uint8Array");
    requireU32(width, "width");
    requireU32(height, "height");
    requireU32(stride, "stride");
    return NativeImage2.create(options, ({ resources }) => resources.renderLib.imageCreateFromRgba(resources.context, pixels, width, height, stride));
  }
  static fromPixels(pixels, width, height, options = {}) {
    if (!(pixels instanceof Uint8Array))
      throw new TypeError("pixels must be a Uint8Array");
    requireU32(width, "width");
    requireU32(height, "height");
    const { stride, format, alpha } = pixelImportOptions(width, options);
    return NativeImage2.create(options, ({ resources }) => resources.renderLib.imageCreateFromPixels(resources.context, pixels, width, height, stride, format, alpha));
  }
  static fromHandle(owner, handle) {
    const lib = owner.resources.renderLib;
    try {
      const result = lib.imageGetInfo(handle);
      checkStatus(result.status);
      return new NativeImage2(owner, handle, unpackInfo(result.info));
    } catch (error) {
      lib.imageDestroy(handle);
      throw error;
    }
  }
  guard() {
    if (!this.handle)
      throw new Error("NativeImage is disposed");
    this.owner.resources.assertAlive();
    return this.handle;
  }
  get ptr() {
    return this.guard();
  }
  _getContextHandle(lib, context) {
    const source = this.guard();
    if (lib !== this.lib)
      throw new Error("NativeImage library owner mismatch");
    if (source.context === context)
      return source;
    for (const [owner, identity] of this.contextImages) {
      const current = owner.deref();
      if (!current)
        this.contextImages.delete(owner);
      else if (current === context)
        return { ...identity, context };
    }
    const result = lib.imageClone(source, context);
    checkStatus(result.status);
    const { context: _, ...identity } = result.handle;
    this.contextImages.set(new WeakRef(context), identity);
    return result.handle;
  }
  releaseContextImages() {
    let failure;
    for (const [owner, identity] of this.contextImages) {
      const context = owner.deref();
      try {
        if (context)
          this.lib.releaseAfterPaint(context, () => this.lib.destroyContextImage(context, { ...identity, context }));
        this.contextImages.delete(owner);
      } catch (error) {
        if (error instanceof NativeError2 && error.status === -7 /* WrongContext */) {
          this.contextImages.delete(owner);
        } else
          failure ??= { error };
      }
    }
    if (failure)
      throw failure.error;
  }
  wrap(result) {
    checkStatus(result.status);
    if (!result.handle)
      throw imageError(10);
    return NativeImage2.fromHandle(this.owner, result.handle);
  }
  info() {
    this.guard();
    return { ...this.imageInfo };
  }
  get width() {
    this.guard();
    return this.imageInfo.width;
  }
  get height() {
    this.guard();
    return this.imageInfo.height;
  }
  clone() {
    return this.wrap(this.lib.imageClone(this.guard()));
  }
  retain() {
    return this.wrap(this.lib.imageRetain(this.guard()));
  }
  resize(options) {
    if (!options || options.width === undefined && options.height === undefined) {
      throw new TypeError("resize requires width, height, or both");
    }
    let width = options.width;
    let height = options.height;
    if (width !== undefined)
      requireU32(width, "width");
    if (height !== undefined)
      requireU32(height, "height");
    if (width === undefined)
      width = Math.max(1, Math.round(this.width * height / this.height));
    if (height === undefined)
      height = Math.max(1, Math.round(this.height * width / this.width));
    requireU32(width, "width");
    requireU32(height, "height");
    const filter = requireMappedOption(FILTER_IDS, options.kernel ?? "area", "resize kernel");
    return this.wrap(this.lib.imageResize(this.guard(), width, height, filter));
  }
  extract(options) {
    return this.wrap(this.lib.imageExtract(this.guard(), requireU32(options.left, "left", true), requireU32(options.top, "top", true), requireU32(options.width, "width"), requireU32(options.height, "height")));
  }
  extend(options = {}) {
    const background = options.background ?? [0, 0, 0, 0];
    if (background.length !== 4)
      throw new TypeError("background must contain four RGBA channels");
    const color = Uint8Array.from(background.map((value, index) => requireByte(value, `background[${index}]`)));
    return this.wrap(this.lib.imageExtend(this.guard(), requireU32(options.top ?? 0, "top", true), requireU32(options.right ?? 0, "right", true), requireU32(options.bottom ?? 0, "bottom", true), requireU32(options.left ?? 0, "left", true), color));
  }
  rotate(angle) {
    const operation = angle === 90 ? 0 : angle === 180 ? 1 : angle === 270 ? 2 : -1;
    if (operation < 0)
      throw new RangeError("angle must be 90, 180, or 270");
    return this.wrap(this.lib.imageTransform(this.guard(), operation));
  }
  flip() {
    return this.wrap(this.lib.imageTransform(this.guard(), 3));
  }
  flop() {
    return this.wrap(this.lib.imageTransform(this.guard(), 4));
  }
  composite(overlay, options = {}) {
    if (!(overlay instanceof NativeImage2))
      throw new TypeError("overlay must be a NativeImage");
    const opacity = options.opacity ?? 1;
    if (!Number.isFinite(opacity) || opacity < 0 || opacity > 1)
      throw new RangeError("opacity must be between 0 and 1");
    return this.wrap(this.lib.imageComposite(this.guard(), overlay._getContextHandle(this.lib, this.guard().context), requireI32(options.left ?? 0, "left"), requireI32(options.top ?? 0, "top"), requireMappedOption(BLEND_IDS, options.blend ?? "source-over", "blend mode"), Math.round(opacity * 255)));
  }
  ensureEncodedPng() {
    checkStatus(this.lib.imageEnsureEncodedPng(this.guard()));
  }
  raw(format = "rgba8") {
    const stride = this.width * 4;
    const data = new Uint8Array(stride * this.height);
    checkStatus(this.lib.imageCopyPixels(this.guard(), data, stride, requireMappedOption(PIXEL_FORMAT_BGRA, format, "pixel format")));
    return { data, width: this.width, height: this.height, stride, format, colorSpace: "srgb", alpha: "straight" };
  }
  takeRaw() {
    const handle = this.guard();
    this.releaseContextImages();
    const result = this.lib.imageTakePixels(handle);
    if (result.status === BUSY_STATUS) {
      throw new Error("Cannot transfer image pixels while native buffers retain the image");
    }
    checkStatus(result.status);
    const width = this.imageInfo.width;
    const height = this.imageInfo.height;
    const stride = width * 4;
    this.handle = null;
    try {
      const data = new Uint8Array(toArrayBuffer(result.pointer, 0, result.byteCount));
      return new OwnedRawImageImpl(data, width, height, stride, this.lib, result.lease, this.owner);
    } catch (error) {
      this.lib.imageReleasePixels(result.lease);
      this.owner.release();
      throw error;
    }
  }
  copyTo(destination, options = {}) {
    if (!(destination instanceof Uint8Array))
      throw new TypeError("destination must be a Uint8Array");
    const stride = options.stride ?? this.width * 4;
    requireU32(stride, "stride");
    const bgra = requireMappedOption(PIXEL_FORMAT_BGRA, options.format ?? "rgba8", "pixel format");
    checkStatus(this.lib.imageCopyPixels(this.guard(), destination, stride, bgra));
  }
  dispose() {
    try {
      this.releaseContextImages();
    } finally {
      if (this.handle) {
        const handle = this.handle;
        if (!this.owner.resources.disposed)
          this.lib.releaseAfterPaint(handle.context, () => this.lib.imageDestroy(handle));
        this.handle = null;
        this.owner.release();
      }
    }
  }
}

class NativeImagePool2 {
  lib;
  owner;
  images = [];
  disposed = false;
  width;
  height;
  capacity;
  constructor(options) {
    this.owner = options.owner;
    this.width = requireU32(options.width, "width");
    this.height = requireU32(options.height, "height");
    this.capacity = requireU32(options.capacity ?? 3, "capacity");
    if (this.capacity > 8)
      throw new RangeError("capacity must be between 1 and 8");
    this.lib = resolveRenderLib2();
  }
  publishRgba(pixels, stride = this.width * 4) {
    return this.publishPixels(pixels, { stride: requireU32(stride, "stride") });
  }
  publishPixels(pixels, options = {}) {
    if (this.disposed)
      throw new Error("NativeImagePool is disposed");
    if (!(pixels instanceof Uint8Array))
      throw new TypeError("pixels must be a Uint8Array");
    const { stride, format, alpha } = pixelImportOptions(this.width, options);
    for (const image of this.images) {
      const status = this.lib.imageUpdatePixels(image.ptr, pixels, stride, format, alpha);
      if (status === BUSY_STATUS)
        continue;
      checkStatus(status);
      return image.retain();
    }
    if (this.images.length === this.capacity)
      return null;
    const image = NativeImage2.fromPixels(pixels, this.width, this.height, { ...options, owner: this.owner });
    this.images.push(image);
    return image.retain();
  }
  dispose() {
    if (this.disposed)
      return;
    for (const image of this.images)
      image.dispose();
    this.images.length = 0;
    this.disposed = true;
  }
}

// src/renderables/Image.ts
function resolveImageRenderProtocol2(requested, capabilities, hasResolution) {
  if (requested !== "auto")
    return requested === "sixel" && !hasResolution ? "blocks" : requested;
  const configured = capabilities?.image_protocol ?? "auto";
  if (configured !== "auto")
    return configured === "sixel" && !hasResolution ? "blocks" : configured;
  if (!capabilities || capabilities.multiplexer === "tmux")
    return "blocks";
  if (capabilities.kitty_graphics)
    return "kitty";
  if (capabilities.sixel && hasResolution)
    return "sixel";
  return "blocks";
}
function pixelResolution(ctx) {
  const terminalWidth = ctx.terminalWidth ?? 0;
  const terminalHeight = ctx.terminalHeight ?? 0;
  const resolution = terminalWidth > 0 && terminalHeight > 0 ? ctx.resolution : null;
  return resolution && resolution.width > 0 && resolution.height > 0 ? resolution : null;
}

class ImageRenderable2 extends Renderable2 {
  static nativeIntegration = this.defineNativeIntegration({
    kind: "image",
    body: { native: this.prototype.renderSelf, buffered: true },
    bufferComposition: "native",
    construction: "prototype"
  });
  _source;
  _image = null;
  _pendingImage = null;
  _loadError = null;
  _loadController = null;
  onLoad;
  onError;
  _fit;
  _protocol;
  loadPromise = null;
  constructor(ctx, options) {
    super(ctx, options);
    try {
      this._fit = options.fit ?? "fit";
      this._protocol = options.protocol ?? "auto";
      this.onLoad = options.onLoad;
      this.onError = options.onError;
      this.setNativeSceneImage();
      if (options.source !== undefined)
        this.source = options.source;
    } catch (error) {
      this.abortConstruction(error, () => this.destroySelf());
    }
  }
  get source() {
    return this._source;
  }
  set source(source) {
    source ??= undefined;
    if (source === this._source)
      return;
    if (source === undefined)
      this.setNativeSceneImage(null);
    this._source = source;
    const previous = this._loadController;
    previous?.abort();
    if (this.isDestroyed || this._loadController !== previous)
      return;
    this._loadController = null;
    this._pendingImage?.dispose();
    this._pendingImage = null;
    if (source === undefined) {
      this._loadError = null;
      this._image?.dispose();
      this._image = null;
      this.loadPromise = null;
      this.requestRender();
      return;
    }
    const controller = new AbortController;
    this._loadController = controller;
    this._loadError = null;
    let imagePromise;
    if (source instanceof NativeImage2) {
      try {
        const image = source.retain();
        this._pendingImage = image;
        imagePromise = Promise.resolve(image);
      } catch (error) {
        imagePromise = Promise.reject(error);
      }
    } else {
      imagePromise = NativeImage2.load(source, {
        signal: controller.signal,
        owner: this._ctx.nativeScene.resourceContext
      });
    }
    this.loadPromise = this.load(imagePromise, controller);
  }
  get image() {
    return this._image;
  }
  get fit() {
    return this._fit;
  }
  set fit(value) {
    const next = value ?? "fit";
    if (this._fit === next)
      return;
    this.setNativeSceneImage(this._image, next);
    this._fit = next;
    this.requestRender();
  }
  get protocol() {
    return this._protocol;
  }
  set protocol(value) {
    const next = value ?? "auto";
    if (this._protocol === next)
      return;
    this.setNativeSceneImage(this._image, this._fit, next);
    this._protocol = next;
    this.requestRender();
  }
  get effectiveProtocol() {
    return resolveImageRenderProtocol2(this._protocol, this._ctx.capabilities, pixelResolution(this._ctx) !== null);
  }
  get cellAspectRatio() {
    const resolution = pixelResolution(this._ctx);
    if (!resolution)
      return 2;
    const cellWidth = resolution.width / this._ctx.terminalWidth;
    const cellHeight = resolution.height / this._ctx.terminalHeight;
    return cellWidth > 0 && cellHeight > 0 ? cellHeight / cellWidth : 2;
  }
  getFittedSize(targetWidth, targetHeight, cellAspectRatio = this.cellAspectRatio, sourceWidth = this._image?.width ?? 0, sourceHeight = this._image?.height ?? 0) {
    if (sourceWidth <= 0 || sourceHeight <= 0 || targetWidth <= 0 || targetHeight <= 0)
      return { width: 0, height: 0 };
    if (this._fit === "fill")
      return { width: targetWidth, height: targetHeight };
    const displayAspect = sourceWidth / sourceHeight * cellAspectRatio;
    const scale = this._fit === "fit" ? Math.min(targetWidth / displayAspect, targetHeight) : Math.max(targetWidth / displayAspect, targetHeight);
    return {
      width: Math.max(1, Math.round(displayAspect * scale)),
      height: Math.max(1, Math.round(scale))
    };
  }
  get loading() {
    return this._loadController !== null;
  }
  get loadError() {
    return this._loadError;
  }
  createFrameBuffer() {
    const previous = this.frameBuffer;
    super.createFrameBuffer();
    if (this._fit === undefined || this.frameBuffer === previous)
      return;
    try {
      this.setNativeSceneImage();
    } catch (error) {
      const candidate = this.frameBuffer;
      this.frameBuffer = previous;
      try {
        candidate?.destroy();
      } catch {}
      throw error;
    }
  }
  renderSelf(buffer) {
    if (!this._image || this.width <= 0 || this.height <= 0)
      return;
    const fitted = this._fit === "cover" ? { width: this.width, height: this.height } : this.getFittedSize(this.width, this.height);
    if (fitted.width <= 0 || fitted.height <= 0)
      return;
    const originX = this.buffered ? 0 : this._screenX;
    const originY = this.buffered ? 0 : this._screenY;
    const x = originX + Math.floor((this.width - fitted.width) / 2);
    const y = originY + Math.floor((this.height - fitted.height) / 2);
    const resolution = pixelResolution(this._ctx);
    const pixelWidth = resolution ? Math.max(1, Math.round(fitted.width * resolution.width / this._ctx.terminalWidth)) : 0;
    const pixelHeight = resolution ? Math.max(1, Math.round(fitted.height * resolution.height / this._ctx.terminalHeight)) : 0;
    let sourceX = 0;
    let sourceY = 0;
    let sourceWidth = this._image.width;
    let sourceHeight = this._image.height;
    if (this._fit === "cover") {
      const targetAspect = this.width / (this.height * this.cellAspectRatio);
      const sourceAspect = sourceWidth / sourceHeight;
      if (sourceAspect > targetAspect) {
        sourceWidth = Math.max(1, Math.round(sourceHeight * targetAspect));
        sourceX = Math.floor((this._image.width - sourceWidth) / 2);
      } else {
        sourceHeight = Math.max(1, Math.round(sourceWidth / targetAspect));
        sourceY = Math.floor((this._image.height - sourceHeight) / 2);
      }
    }
    buffer.drawImage(this._image, x, y, fitted.width, fitted.height, pixelWidth, pixelHeight, sourceX, sourceY, sourceWidth, sourceHeight, this._protocol);
  }
  async load(imagePromise, controller) {
    let image;
    try {
      image = await imagePromise;
      if (this.isDestroyed || this._loadController !== controller) {
        image.dispose();
        return;
      }
      if (this._pendingImage === image)
        this._pendingImage = null;
      this.setNativeSceneImage(image);
    } catch (error) {
      try {
        image?.dispose();
      } catch {}
      if (controller.signal.aborted || this.isDestroyed || this._loadController !== controller)
        return;
      this._loadController = null;
      this._loadError = error;
      this.onError?.(error);
      return;
    }
    const previous = this._image;
    this._image = image;
    this._loadController = null;
    this.runCleanup((run) => {
      run(() => previous?.dispose());
      run(() => this.requestRender());
      run(() => this.onLoad?.(image));
    });
  }
  setNativeSceneImage(image = this._image, fit = this._fit, protocol = this._protocol) {
    this._ctx.nativeScene.setImage(this, image, fit, protocol, this.buffered ? this.frameBuffer : null);
  }
  destroySelf() {
    const controller = this._loadController;
    const pending = this._pendingImage;
    const image = this._image;
    this._loadController = null;
    this._pendingImage = null;
    this._image = null;
    this.runCleanup((run) => {
      run(() => controller?.abort());
      run(() => pending?.dispose());
      run(() => image?.dispose());
      run(() => super.destroySelf());
    });
  }
}

// src/renderables/TextNode.ts
var BrandedTextNodeRenderable = Symbol.for("@opentui/core/TextNodeRenderable");
function isTextNodeRenderable2(obj) {
  return !!obj?.[BrandedTextNodeRenderable];
}
function styledTextToTextNodes(styledText) {
  return styledText.chunks.map((chunk) => {
    const node = new TextNodeRenderable2({
      fg: chunk.fg,
      bg: chunk.bg,
      attributes: chunk.attributes,
      link: chunk.link
    });
    node.add(chunk.text);
    return node;
  });
}

class TextNodeRenderable2 extends BaseRenderable2 {
  [BrandedTextNodeRenderable] = true;
  _fg;
  _bg;
  _attributes;
  _link;
  _children = [];
  dirtyRevision = 0;
  parent = null;
  constructor(options) {
    super(options);
    this._fg = options.fg ? RGBA2.clone(parseColor2(options.fg)) : undefined;
    this._bg = options.bg ? RGBA2.clone(parseColor2(options.bg)) : undefined;
    this._attributes = options.attributes ?? 0;
    this._link = options.link;
  }
  get children() {
    return this._children;
  }
  set children(children) {
    for (const child of this._children) {
      if (isTextNodeRenderable2(child) && child.parent === this) {
        child.parent = null;
      }
    }
    for (const child of children) {
      if (isTextNodeRenderable2(child)) {
        if (child.parent && child.parent !== this) {
          child.parent.remove(child);
        }
        child.parent = this;
      }
    }
    this._children = children;
    this.requestRender();
  }
  requestRender() {
    this.markDirty();
    this.parent?.requestRender();
  }
  markDirty() {
    super.markDirty();
    this.dirtyRevision++;
  }
  add(obj, index) {
    if (typeof obj === "string") {
      if (index !== undefined) {
        this._children.splice(index, 0, obj);
        this.requestRender();
        return index;
      }
      const insertIndex = this._children.length;
      this._children.push(obj);
      this.requestRender();
      return insertIndex;
    }
    if (isTextNodeRenderable2(obj)) {
      const insertIndex = this.prepareChildInsert(obj, index);
      this._children.splice(insertIndex, 0, obj);
      obj.parent = this;
      this.requestRender();
      return insertIndex;
    }
    if (isStyledText2(obj)) {
      const textNodes = styledTextToTextNodes(obj);
      if (index !== undefined) {
        this._children.splice(index, 0, ...textNodes);
        textNodes.forEach((node) => node.parent = this);
        this.requestRender();
        return index;
      }
      const insertIndex = this._children.length;
      this._children.push(...textNodes);
      textNodes.forEach((node) => node.parent = this);
      this.requestRender();
      return insertIndex;
    }
    throw new Error("TextNodeRenderable only accepts strings, TextNodeRenderable instances, or StyledText instances");
  }
  prepareChildInsert(child, index) {
    let insertIndex = index ?? this._children.length;
    if (child.parent && child.parent !== this) {
      child.parent.remove(child);
    } else if (child.parent === this) {
      const currentIndex = this._children.indexOf(child);
      if (currentIndex !== -1) {
        this._children.splice(currentIndex, 1);
        if (currentIndex < insertIndex)
          insertIndex -= 1;
      }
    }
    return Math.max(0, Math.min(insertIndex, this._children.length));
  }
  replace(obj, index) {
    const existing = this._children[index];
    if (isTextNodeRenderable2(existing) && existing.parent === this) {
      existing.parent = null;
    }
    if (isTextNodeRenderable2(obj)) {
      if (obj.parent && obj.parent !== this) {
        obj.parent.remove(obj);
      } else if (obj.parent === this) {
        const currentIndex = this._children.indexOf(obj);
        if (currentIndex !== -1 && currentIndex !== index) {
          this._children.splice(currentIndex, 1);
          if (currentIndex < index)
            index -= 1;
        }
      }
      obj.parent = this;
    }
    this._children[index] = obj;
    this.requestRender();
  }
  insertBefore(child, anchorNode) {
    if (!anchorNode || !isTextNodeRenderable2(anchorNode)) {
      throw new Error("Anchor must be a TextNodeRenderable");
    }
    const anchorIndex = this._children.indexOf(anchorNode);
    if (anchorIndex === -1) {
      throw new Error("Anchor node not found in children");
    }
    if (child === anchorNode) {
      return this;
    }
    if (isTextNodeRenderable2(child)) {
      this.add(child, anchorIndex);
      return this;
    }
    if (typeof child === "string") {
      this._children.splice(anchorIndex, 0, child);
    } else if (isStyledText2(child)) {
      const textNodes = styledTextToTextNodes(child);
      this._children.splice(anchorIndex, 0, ...textNodes);
      textNodes.forEach((node) => node.parent = this);
    } else {
      throw new Error("Child must be a string, TextNodeRenderable, or StyledText instance");
    }
    this.requestRender();
    return this;
  }
  remove(child) {
    if (!isTextNodeRenderable2(child)) {
      throw new Error("remove expects a TextNodeRenderable child object");
    }
    const childIndex = this._children.indexOf(child);
    if (childIndex === -1) {
      if (true) {
        console.warn(`TextNodeRenderable with id ${child.id} is not a child of ${this.id}, skipping remove`);
      }
      return;
    }
    this._children.splice(childIndex, 1);
    child.parent = null;
    this.requestRender();
  }
  clear() {
    for (const child of this._children) {
      if (isTextNodeRenderable2(child) && child.parent === this) {
        child.parent = null;
      }
    }
    this._children = [];
    this.requestRender();
  }
  mergeStyles(parentStyle) {
    return {
      fg: this.fg ?? parentStyle.fg,
      bg: this.bg ?? parentStyle.bg,
      attributes: this._attributes | parentStyle.attributes,
      link: this._link ?? parentStyle.link
    };
  }
  gatherWithInheritedStyle(parentStyle = {
    fg: undefined,
    bg: undefined,
    attributes: 0
  }) {
    return this.gatherChunks(parentStyle);
  }
  prepareWithInheritedStyle(parentStyle) {
    const revisions = new Map;
    const chunks = this.gatherChunks(parentStyle, revisions);
    return {
      chunks,
      acknowledge: () => {
        for (const [node, revision] of revisions) {
          if (node.dirtyRevision === revision)
            node.markClean();
        }
      }
    };
  }
  gatherChunks(parentStyle, revisions) {
    revisions?.set(this, this.dirtyRevision);
    const currentStyle = this.mergeStyles(parentStyle);
    const chunks = [];
    for (const child of this._children) {
      if (typeof child === "string") {
        chunks.push({
          __isChunk: true,
          text: child,
          fg: currentStyle.fg,
          bg: currentStyle.bg,
          attributes: currentStyle.attributes,
          link: currentStyle.link
        });
      } else {
        const childChunks = revisions ? child.gatherChunks(currentStyle, revisions) : child.gatherWithInheritedStyle(currentStyle);
        chunks.push(...childChunks);
      }
    }
    if (!revisions)
      this.markClean();
    return chunks;
  }
  static fromString(text, options = {}) {
    const node = new TextNodeRenderable2(options);
    node.add(text);
    return node;
  }
  static fromNodes(nodes, options = {}) {
    const node = new TextNodeRenderable2(options);
    for (const childNode of nodes) {
      node.add(childNode);
    }
    return node;
  }
  toChunks(parentStyle = {
    fg: undefined,
    bg: undefined,
    attributes: 0
  }) {
    return this.gatherWithInheritedStyle(parentStyle);
  }
  getChildren() {
    return this._children.filter((child) => typeof child !== "string");
  }
  getChildrenCount() {
    return this._children.length;
  }
  getRenderable(id) {
    return this._children.find((child) => typeof child !== "string" && child.id === id);
  }
  getRenderableIndex(id) {
    return this._children.findIndex((child) => isTextNodeRenderable2(child) && child.id === id);
  }
  get fg() {
    return this._fg ? RGBA2.clone(this._fg) : undefined;
  }
  set fg(fg) {
    if (!fg) {
      this._fg = undefined;
      this.requestRender();
      return;
    }
    this._fg = RGBA2.clone(parseColor2(fg));
    this.requestRender();
  }
  set bg(bg) {
    if (!bg) {
      this._bg = undefined;
      this.requestRender();
      return;
    }
    this._bg = RGBA2.clone(parseColor2(bg));
    this.requestRender();
  }
  get bg() {
    return this._bg ? RGBA2.clone(this._bg) : undefined;
  }
  set attributes(attributes) {
    this._attributes = attributes;
    this.requestRender();
  }
  get attributes() {
    return this._attributes;
  }
  set link(link) {
    this._link = link;
    this.requestRender();
  }
  get link() {
    return this._link;
  }
  findDescendantById(id) {
    return;
  }
}

class RootTextNodeRenderable2 extends TextNodeRenderable2 {
  ctx;
  textParent;
  constructor(ctx, options, textParent) {
    super(options);
    this.ctx = ctx;
    this.textParent = textParent;
  }
  requestRender() {
    this.markDirty();
    this.textParent.requestRender();
  }
}

// src/renderables/Text.ts
class TextRenderable2 extends TextBufferRenderable2 {
  static nativeIntegration = this.defineNativeIntegration({
    ...TextBufferRenderable2.nativeIntegration,
    lineInfo: true
  });
  _text;
  _hasManualStyledText = false;
  rootTextNode;
  composeText = () => this.updateTextFromNodes();
  _contentDefaultOptions = {
    content: ""
  };
  constructor(ctx, options) {
    super(ctx, options);
    try {
      const initialContent = options.content;
      const content = initialContent ?? this._contentDefaultOptions.content;
      this.content = content;
      this._hasManualStyledText = initialContent !== undefined && content !== "";
      this.onLifecyclePass = this.composeText;
    } catch (error) {
      this.rollbackConstruction(error);
    }
  }
  get content() {
    if (typeof this._text === "string")
      this._text = stringToStyledText2(this._text);
    return this._text;
  }
  get chunks() {
    return this.content.chunks;
  }
  get textNode() {
    return this.rootTextNode ??= new RootTextNodeRenderable2(this._ctx, {
      id: `${this.id}-root`,
      fg: this._defaultFg,
      bg: this._defaultBg,
      attributes: this._defaultAttributes
    }, this);
  }
  set content(value) {
    if (typeof value !== "string" && this._text === value) {
      this._hasManualStyledText = true;
      this._ctx.nativeScene.lifecyclePasses.refresh(this);
      return;
    }
    this._ctx.nativeScene.setText(this, value);
    this._text = value;
    this._hasManualStyledText = true;
    this._ctx.nativeScene.lifecyclePasses.refresh(this);
    this.requestRender();
    this.refreshLocalSelection();
    this.emit("line-info-change");
  }
  updateTextFromNodes() {
    if (this.rootTextNode?.isDirty && !this._hasManualStyledText) {
      const style = {
        fg: this._defaultFg,
        bg: this._defaultBg,
        attributes: this._defaultAttributes,
        link: undefined
      };
      const prepared = this.rootTextNode.prepareWithInheritedStyle(style);
      this._ctx.nativeScene.setText(this, new StyledText2(prepared.chunks));
      prepared.acknowledge();
      this._ctx.nativeScene.lifecyclePasses.refresh(this);
      this.refreshLocalSelection();
      this.emit("line-info-change");
      return;
    }
    this._ctx.nativeScene.lifecyclePasses.refresh(this);
  }
  _needsLifecyclePass() {
    if (this.onLifecyclePass !== this.composeText)
      return super._needsLifecyclePass();
    return !this._hasManualStyledText && !!this.rootTextNode?.isDirty;
  }
  requestRender() {
    if (this.isDestroyed)
      return;
    this._ctx.nativeScene.lifecyclePasses.refresh(this);
    super.requestRender();
  }
  add(obj, index) {
    return this.textNode.add(obj, index);
  }
  remove(child) {
    this.textNode.remove(child);
  }
  insertBefore(obj, anchor) {
    this.textNode.insertBefore(obj, anchor);
    return this.textNode.children.indexOf(obj);
  }
  getTextChildren() {
    return this.rootTextNode?.getChildren() ?? [];
  }
  clear() {
    this._ctx.nativeScene.setText(this, "");
    this._text = stringToStyledText2("");
    this.rootTextNode?.clear();
    this.requestRender();
    this.refreshLocalSelection();
    this.emit("line-info-change");
  }
  onFgChanged(newColor) {
    if (this.rootTextNode)
      this.rootTextNode.fg = newColor;
  }
  onBgChanged(newColor) {
    if (this.rootTextNode)
      this.rootTextNode.bg = newColor;
  }
  onAttributesChanged(newAttributes) {
    if (this.rootTextNode)
      this.rootTextNode.attributes = newAttributes;
  }
  destroyOwnedResources() {
    this.runCleanup((run) => {
      run(() => {
        if (this.rootTextNode) {
          for (const child of this.rootTextNode.getChildren()) {
            if (child.parent === this.rootTextNode)
              child.parent = null;
          }
        }
        if (this.rootTextNode)
          this.rootTextNode.children.length = 0;
      });
      run(() => super.destroyOwnedResources());
    });
  }
}

// src/NativeSession.ts
import { Writable } from "stream";
var scheduler = {
  now: () => process.hrtime.bigint(),
  schedule(callback, delayMs) {
    if (delayMs === undefined) {
      const handle = setImmediate(callback);
      return () => clearImmediate(handle);
    }
    const handle = setTimeout(callback, delayMs);
    return () => clearTimeout(handle);
  }
};
var emptyOutput = new Uint8Array(0);

class ReadySessions {
  host;
  ready = new Set;
  pending = new Set;
  current = null;
  cancelTurn = null;
  failure = null;
  constructor(host) {
    this.host = host;
  }
  scope(onError) {
    if (this.failure)
      throw this.failure;
    const tasks = new Set;
    const scoped = {
      now: () => this.host.now(),
      schedule: (callback, delayMs) => {
        if (this.failure)
          throw this.failure;
        let cancelTimer;
        const task = {
          callback,
          active: true,
          onError,
          cancel: () => {
            task.active = false;
            tasks.delete(task);
            this.pending.delete(task);
            if (tasks.size === 0)
              this.ready.delete(tasks);
            const cancel = cancelTimer;
            cancelTimer = undefined;
            try {
              cancel?.();
            } finally {
              if (this.ready.size === 0) {
                const cancel = this.cancelTurn;
                this.cancelTurn = null;
                cancel?.();
              }
            }
          }
        };
        this.pending.add(task);
        const enqueue = () => {
          if (!task.active)
            return;
          tasks.add(task);
          this.ready.add(tasks);
          this.arm();
        };
        try {
          if (delayMs === undefined)
            enqueue();
          else
            cancelTimer = this.host.schedule(enqueue, delayMs);
        } catch (error) {
          this.fail(error);
        }
        if (this.failure)
          throw this.failure;
        return task.cancel;
      }
    };
    readyServices.set(scoped, this);
    return scoped;
  }
  arm() {
    if (this.failure || this.cancelTurn || this.ready.size === 0)
      return;
    let arming = true;
    try {
      this.cancelTurn = this.host.schedule(() => {
        if (arming)
          throw new Error("NativeSessionScheduler.schedule ran a callback inline");
        this.cancelTurn = null;
        const tasks = this.ready.values().next().value;
        if (!tasks)
          return;
        const task = this.current = tasks.values().next().value;
        this.ready.delete(tasks);
        tasks.delete(task);
        if (tasks.size > 0)
          this.ready.add(tasks);
        task.active = false;
        this.pending.delete(task);
        try {
          task.callback();
        } finally {
          try {
            this.arm();
          } finally {
            this.current = null;
          }
        }
      });
    } catch (error) {
      this.fail(error);
    } finally {
      arming = false;
    }
  }
  fail(error) {
    if (this.failure)
      return;
    this.failure = asError(error);
    const affected = new Set(this.pending);
    if (this.current)
      affected.add(this.current);
    const owners = new Set;
    let cleanupFailure;
    for (const task of affected) {
      owners.add(task.onError);
      try {
        task.cancel();
      } catch (error) {
        cleanupFailure ??= { error };
      }
    }
    this.ready.clear();
    this.pending.clear();
    for (const onError of owners) {
      try {
        onError(this.failure);
      } catch (error) {
        cleanupFailure ??= { error };
      }
    }
    if (cleanupFailure)
      throw cleanupFailure.error;
  }
}
var readyServices = new WeakMap;
function sessionScheduler(host, onError) {
  let service = readyServices.get(host);
  if (!service) {
    service = new ReadySessions(host);
    readyServices.set(host, service);
  }
  return service.scope(onError);
}
function completion() {
  const result = Promise.withResolvers();
  result.promise.catch(() => {});
  return result;
}
function asError(error) {
  return error instanceof Error ? error : new Error("NativeSession failed", { cause: error });
}

class NativeSession2 {
  sink;
  owner;
  lib = resolveRenderLib2();
  attachmentCleanup;
  resourceContext;
  nativeSession;
  buffer;
  outputBufferSize;
  sinkWrite;
  scheduler;
  maxWriteBytes;
  maxAtomicWriteBytes;
  closeTimeoutNs;
  closeWait = completion();
  idleWait = null;
  presentationWait = null;
  transition = null;
  scheduled = null;
  output = null;
  blocked = false;
  sinkErrorSeen = false;
  detached = false;
  closeDeadlineNs = null;
  closeRequested = false;
  closeInterruption = null;
  stopped = false;
  exiting = false;
  finishing = false;
  _disposed = false;
  _error = null;
  detachedSessions = new Set;
  closed = this.closeWait.promise;
  constructor(sink, options = {}, owner) {
    this.sink = sink;
    this.owner = owner;
    this.lib.getYogaHost().assertMutable();
    const size = options.outputBufferSize ?? 65536;
    const timeout = options.closeTimeoutMs ?? 1000;
    const output = options.output ?? {
      chunkSize: 65536,
      spanCapacity: 128,
      maxBytes: 8388608n,
      controlCapacity: 4096
    };
    if (!Number.isInteger(size) || size <= 0 || size > 4294967295) {
      throw new RangeError("NativeSession outputBufferSize must be a positive u32");
    }
    if (!Number.isInteger(timeout) || timeout < 0 || timeout > 2147483647) {
      throw new RangeError("NativeSession closeTimeoutMs must be an integer from 0 to 2147483647");
    }
    if (!sink.writable || sink.destroyed || sink.writableEnded)
      throw new Error("NativeSession sink is not writable");
    this.sinkWrite = sink.write;
    this.outputBufferSize = size;
    this.buffer = sink === process.stdout && process.stdout.fd === 1 ? null : new Uint8Array(size);
    this.scheduler = sessionScheduler(options.scheduler ?? scheduler, (error) => {
      if (this.stopped) {
        if (this.canDetach())
          this.detach();
      } else
        this.finish(error);
    });
    this.maxWriteBytes = output.maxBytes;
    this.closeTimeoutNs = BigInt(timeout) * 1000000n;
    owner?.checkOpen();
    this.resourceContext = owner?.resourceContext ?? new ResourceContext2(options.context ?? { objectCapacity: 65536, renderCellsMax: 1e6 });
    let session;
    try {
      session = this.lib.createSession(this.context, output);
      this.nativeSession = Object.freeze(session);
      this.maxAtomicWriteBytes = this.lib.sessionGetWriteLimit(this.context, session);
      sink.on("error", this.onError);
      sink.on("close", this.onClose);
      sink.on("finish", this.onFinish);
      sink.on("drain", this.onDrain);
      if (this._error)
        throw this._error;
      if (!sink.writable || sink.destroyed || sink.writableEnded)
        throw new Error("NativeSession sink is not writable");
      this.blocked = sink.writableNeedDrain;
      owner?.detachedSessions.add(this);
    } catch (error) {
      this.stopped = true;
      try {
        if (session)
          this.finish(asError(error));
        else if (!owner)
          this.resourceContext.destroy();
      } catch {} finally {
        this.detach();
      }
      throw error;
    }
  }
  get context() {
    return this.resourceContext.context;
  }
  get renderLib() {
    return this.lib;
  }
  get session() {
    return this.nativeSession;
  }
  get disposed() {
    return this._disposed;
  }
  get contextDisposed() {
    return this.resourceContext.disposed;
  }
  get error() {
    return this._error;
  }
  usesOutput(sink) {
    return this.sink === sink;
  }
  attachRenderer(options, beforeDispose) {
    this.checkOpen();
    this.lib.sessionAttachRenderer(this.context, this.session, options);
    this.attachmentCleanup = beforeDispose;
  }
  createDetached(options, beforeDispose) {
    this.checkOpen();
    const detached = new NativeSession2(new Writable({
      write(_bytes, _encoding, complete) {
        complete();
      }
    }), {
      output: { chunkSize: 4096, spanCapacity: 2, maxBytes: 8192n, controlCapacity: 0 },
      outputBufferSize: 4096,
      scheduler: this.scheduler
    }, this);
    try {
      detached.attachRenderer(options, beforeDispose);
      return detached;
    } catch (error) {
      detached.dispose();
      throw error;
    }
  }
  setupTerminal(options = {}) {
    return this.changeTerminal("setup", options);
  }
  suspend() {
    return this.changeTerminal("suspend");
  }
  resume() {
    return this.changeTerminal("resume");
  }
  render(force, frame) {
    this.checkOpen();
    const result = this.lib.sceneFrameCommit(this.context, this.session, frame, force);
    if (result === 1 /* Pending */)
      this.schedule();
    return result;
  }
  renderSplit(frame, commits, pinnedRenderOffset, force) {
    this.checkOpen();
    const result = this.lib.sessionRenderSplit(this.context, this.session, frame, commits, pinnedRenderOffset, force);
    if (result.status === 1 /* Pending */)
      this.schedule();
    return result;
  }
  setScreen(alternate, width, height, trailingOutput) {
    this.checkOpen();
    this.lib.sessionSetScreen(this.context, this.session, alternate, width, height, trailingOutput);
    this.schedule();
  }
  whenPresented() {
    this.checkOpen();
    if (this.presentationWait)
      return this.presentationWait.promise;
    if (!this.lib.sessionGetRendererState(this.context, this.session).framePending)
      return Promise.resolve();
    const wait = this.presentationWait = completion();
    this.schedule();
    return wait.promise;
  }
  resize(width, height) {
    this.checkOpen();
    this.lib.sessionResizeRenderer(this.context, this.session, width, height);
  }
  control(command) {
    this.checkOpen();
    this.lib.sessionControl(this.context, this.session, command);
    this.schedule();
  }
  writeClipboard(target, bytes) {
    this.checkOpen();
    const accepted = this.lib.sessionClipboard(this.context, this.session, target, bytes);
    if (accepted)
      this.schedule();
    return accepted;
  }
  triggerNotification(message, title) {
    this.checkOpen();
    const accepted = this.lib.sessionNotification(this.context, this.session, message, title);
    if (accepted)
      this.schedule();
    return accepted;
  }
  setProgramStatus(status) {
    this.checkOpen();
    try {
      this.lib.sessionControl(this.context, this.session, { kind: "program-status", status });
    } catch (error) {
      if (error instanceof NativeError2 && (error.status === -19 /* InvalidPhase */ || error.status === -11 /* OutputBackpressure */)) {
        return false;
      }
      throw error;
    }
    this.schedule();
    return true;
  }
  setKittyImageTransport(mode) {
    this.checkOpen();
    this.lib.sessionSetKittyImageTransport(this.context, this.session, mode);
    this.schedule();
  }
  getKittyImageTransport() {
    this.checkOpen();
    return this.lib.sessionGetKittyImageTransport(this.context, this.session);
  }
  pollKittyImageTransport() {
    this.checkOpen();
    return this.lib.sessionPollKittyImageTransport(this.context, this.session, this.scheduler.now());
  }
  cancelKittyImageTransport(failed) {
    this.checkOpen();
    this.lib.sessionCancelKittyImageTransport(this.context, this.session, failed);
  }
  processKittyImageReply(bytes) {
    this.checkOpen();
    return this.lib.sessionProcessKittyImageReply(this.context, this.session, bytes);
  }
  startKittyFileProbe() {
    this.checkOpen();
    this.lib.sessionStartKittyFileProbe(this.context, this.session);
    this.schedule();
  }
  getCapabilities() {
    this.checkOpen();
    return this.lib.sessionGetCapabilities(this.context, this.session);
  }
  write(bytes) {
    this.checkOpen();
    try {
      this.lib.sessionWrite(this.context, this.session, bytes);
    } catch (error) {
      if (error instanceof NativeError2 && error.status === -11 /* OutputBackpressure */)
        return false;
      throw error;
    }
    this.schedule();
    return true;
  }
  idle() {
    this.lib.getYogaHost().assertMutable();
    if (this.stopped)
      return this.closed;
    if (this.idleWait)
      return this.idleWait.promise;
    const wait = this.idleWait = completion();
    this.schedule();
    return wait.promise;
  }
  close() {
    this.lib.getYogaHost().assertMutable();
    if (this.stopped || this.closeRequested)
      return this.closed;
    try {
      this.closeRequested = true;
      this.closeDeadlineNs ??= this.scheduler.now() + this.closeTimeoutNs;
      if (this.transition) {
        this.closeInterruption = new Error("NativeSession terminal transition interrupted by close");
        this.transition.wait.reject(this.closeInterruption);
        this.transition = null;
      }
      if (this._error)
        throw this._error;
      this.lib.sessionClose(this.context, this.session);
      if (this.lib.sessionGetState(this.context, this.session) === 2 /* Closed */)
        this.finish(null);
      else
        this.schedule();
    } catch (error) {
      this.finish(asError(error));
    }
    return this.closed;
  }
  armCloseTimeout() {
    this.checkOpen();
    this.closeDeadlineNs ??= this.scheduler.now() + this.closeTimeoutNs;
    this.schedule();
  }
  isCloseInterruption(error) {
    return this.closeInterruption !== null && error === this.closeInterruption;
  }
  dispose() {
    this.lib.getYogaHost().assertMutable();
    this.finish(this._error ?? new Error("NativeSession disposed without graceful close"));
  }
  restoreOnExit() {
    if (this._disposed || this.finishing)
      return false;
    this.exiting = true;
    try {
      if (this.sink !== process.stdout || process.stdout.fd !== 1 || this.sink.writableLength !== 0 || this.sink.writableCorked !== 0 || this._error || this.sink.destroyed || this.sink.errored || !this.sink.writable || this.sink.writableEnded)
        return false;
      if (this.output) {
        if (!this.output.completed || this.output.failed)
          return false;
        if (this.output.ticket)
          this.lib.sessionCompleteOutput(this.context, this.session, this.output.ticket, true);
        this.output = null;
      }
      for (;; ) {
        const status = this.lib.sessionPumpExit(this.context, this.session);
        if (status === 4 /* Closed */)
          return true;
        if (status === 1 /* Again */)
          continue;
        if (status !== 2 /* OutputPending */)
          throw new Error("Unexpected native exit pump status");
        if (this.lib.sessionDrainStdout(this.context, this.session) === 0)
          return false;
      }
    } catch (error) {
      this._error ??= asError(error);
      return false;
    }
  }
  checkOpen() {
    this.lib.getYogaHost().assertMutable();
    if (this._error)
      throw this._error;
    if (this.stopped || this.closeRequested)
      throw new Error("NativeSession is closing or disposed");
    this.owner?.checkOpen();
  }
  changeTerminal(kind, options) {
    this.checkOpen();
    if (this.transition) {
      if (this.transition.kind === kind)
        return this.transition.wait.promise;
      throw new Error("NativeSession terminal transition is pending");
    }
    switch (kind) {
      case "setup":
        this.lib.sessionSetupTerminal(this.context, this.session, options);
        break;
      case "suspend":
        this.lib.sessionSuspend(this.context, this.session);
        break;
      case "resume":
        this.lib.sessionResume(this.context, this.session);
        break;
    }
    const wait = completion();
    this.transition = { kind, wait };
    this.schedule();
    return wait.promise;
  }
  onError = (error) => {
    this.sinkErrorSeen = true;
    if (!this.stopped)
      this._error ??= asError(error);
    this.schedule();
  };
  onClose = () => {
    this.output = null;
    if (this.stopped)
      this.detach();
    else {
      this._error ??= new Error("NativeSession sink closed before graceful close");
      this.schedule();
    }
  };
  onFinish = () => {
    if (!this.stopped)
      this._error ??= new Error("NativeSession sink finished before graceful close");
    this.schedule();
  };
  onDrain = () => {
    if (this.stopped)
      return;
    this.blocked = false;
    this.schedule();
  };
  schedule(deadlineNs = null) {
    if (this.exiting) {
      if (this.stopped && this.canDetach())
        this.detach();
      return;
    }
    if (this.stopped && (this.detached || !this.canDetach()))
      return;
    const previous = this.scheduled;
    if (previous && (previous.deadlineNs === null || deadlineNs !== null && previous.deadlineNs <= deadlineNs)) {
      return;
    }
    const task = { deadlineNs, cancel: () => {} };
    try {
      previous?.cancel();
      this.scheduled = task;
      let delayMs;
      if (deadlineNs !== null) {
        const remaining = deadlineNs - this.scheduler.now();
        delayMs = Math.min(Number(((remaining > 0n ? remaining : 0n) + 999999n) / 1000000n), 2147483647);
      }
      task.cancel = this.scheduler.schedule(() => {
        if (this.scheduled !== task)
          return;
        this.scheduled = null;
        if (this.stopped) {
          if (this.canDetach())
            this.detach();
        } else
          this.turn();
      }, delayMs);
    } catch (error) {
      if (this.stopped) {
        if (this.canDetach())
          this.detach();
      } else
        this.finish(asError(error));
    }
  }
  turn() {
    let deadlineNs = null;
    try {
      if (this._error)
        throw this._error;
      const now = this.scheduler.now();
      const expired = this.closeDeadlineNs !== null && now >= this.closeDeadlineNs;
      if (this.output?.completed) {
        if (this.output.ticket)
          this.lib.sessionCompleteOutput(this.context, this.session, this.output.ticket, true);
        this.output = null;
        this.completePresentation();
      }
      const result = this.output ? null : this.lib.sessionPump(this.context, this.session, now, 1);
      if (expired && result?.status !== 4 /* Closed */) {
        throw new Error("NativeSession graceful close timed out; output cancelled without restoration");
      }
      if (!result)
        return;
      switch (result.status) {
        case 0 /* Idle */:
          if (this.transition) {
            const phase = this.transition.kind === "suspend" ? 4 /* Suspended */ : 2 /* Active */;
            if (this.lib.sessionGetTerminalState(this.context, this.session) !== phase) {
              throw new Error("NativeSession terminal transition did not complete");
            }
            this.transition.wait.resolve();
            this.transition = null;
          }
          if (!this.blocked) {
            this.idleWait?.resolve();
            this.idleWait = null;
          }
          break;
        case 1 /* Again */:
          this.schedule();
          break;
        case 2 /* OutputPending */:
          if (!this.blocked)
            this.writeOutput();
          break;
        case 3 /* WaitUntil */:
          deadlineNs = result.deadlineNs;
          break;
        case 4 /* Closed */:
          this.finish(null);
          break;
      }
    } catch (error) {
      this.finish(asError(error));
    } finally {
      if (this.closeDeadlineNs !== null && (deadlineNs === null || this.closeDeadlineNs < deadlineNs)) {
        deadlineNs = this.closeDeadlineNs;
      }
      if (deadlineNs !== null)
        this.schedule(deadlineNs);
    }
  }
  writeOutput() {
    if (this.buffer === null) {
      if (this.sink.writableLength > 0 || this.sink.writableCorked > 0) {
        this.writeSink(emptyOutput, null);
        return;
      }
      try {
        const written = this.lib.sessionDrainStdout(this.context, this.session);
        this.completePresentation();
        this.schedule(written === 0 ? this.scheduler.now() + 1000000n : null);
        return;
      } catch (error) {
        if (!(error instanceof NativeError2) || error.status !== -24 /* UnsupportedResource */)
          throw error;
        this.buffer = new Uint8Array(this.outputBufferSize);
      }
    }
    const ticket = this.lib.sessionReadOutput(this.context, this.session, this.buffer);
    if (!ticket)
      throw new Error("NativeSession output pending without bytes");
    if (ticket.byteCount > this.buffer.length)
      throw new Error("NativeSession output ticket exceeds its buffer");
    this.writeSink(this.buffer.subarray(0, ticket.byteCount), ticket);
  }
  writeSink(bytes, ticket) {
    if (this.output)
      throw new Error("NativeSession output is already in flight");
    const output = { ticket, completed: false, failed: false };
    this.output = output;
    this.blocked = true;
    try {
      const ready = this.sinkWrite.call(this.sink, bytes, "utf8", (error) => {
        if (this.output !== output || output.completed)
          return;
        output.completed = true;
        output.failed = error != null;
        if (error && !this.stopped)
          this._error ??= asError(error);
        this.schedule();
      });
      if (!this.stopped && ready)
        this.blocked = false;
    } catch (error) {
      this.output = null;
      if (this.stopped)
        this.detach();
      throw error;
    }
  }
  completePresentation() {
    if (this.presentationWait && !this.lib.sessionGetRendererState(this.context, this.session).framePending) {
      this.presentationWait.resolve();
      this.presentationWait = null;
    }
  }
  detach() {
    this.detached = true;
    this.output = null;
    for (const [event, listener] of [
      ["error", this.onError],
      ["close", this.onClose],
      ["finish", this.onFinish],
      ["drain", this.onDrain]
    ]) {
      try {
        this.sink.off(event, listener);
      } catch (error) {
        this._error ??= asError(error);
      }
    }
  }
  canDetach() {
    if (this.output && !this.output.completed)
      return false;
    return this.sink.closed || this.sinkErrorSeen || !this.output?.failed && !this.sink.destroyed;
  }
  finish(error) {
    if (this.finishing)
      return;
    if (this._disposed) {
      this.schedule();
      return;
    }
    this.finishing = true;
    try {
      this.stopped = true;
      this._error ??= error;
      const scheduled = this.scheduled;
      this.scheduled = null;
      try {
        scheduled?.cancel();
      } catch (error) {
        this._error ??= asError(error);
      }
      if (this._error) {
        try {
          this.lib.sessionCancel(this.context, this.session);
        } catch (error) {
          this._error ??= asError(error);
        }
      }
      for (const child of this.detachedSessions) {
        try {
          child.dispose();
          if (!child.disposed)
            this._error ??= child.error;
        } catch (error) {
          this._error ??= asError(error);
        }
      }
      if (this.detachedSessions.size === 0) {
        try {
          this.attachmentCleanup?.();
        } catch (error) {
          this._error ??= asError(error);
          try {
            this.lib.sessionCancel(this.context, this.session);
          } catch (error) {
            this._error ??= asError(error);
          }
        }
        try {
          this.lib.getYogaHost().runMutation(() => {
            if (!this.resourceContext.disposed) {
              if (this.owner)
                this.lib.destroySession(this.context, this.session);
              else
                this.resourceContext.destroy();
            }
            this._disposed = true;
            this.owner?.detachedSessions.delete(this);
          });
        } catch (error) {
          this._error ??= asError(error);
        }
      }
      if (!this.output && !this.sink.destroyed && !this.sink.writableFinished && !this.sink.errored)
        this.detach();
      else
        this.schedule();
      if (!this._disposed && !this._error)
        return;
      for (const wait of [this.closeWait, this.idleWait, this.presentationWait, this.transition?.wait]) {
        if (this._error)
          wait?.reject(this._error);
        else
          wait?.resolve();
      }
      this.idleWait = null;
      this.presentationWait = null;
      this.transition = null;
    } finally {
      try {
        if ((this._disposed || this._error) && this.owner?.stopped && !this.owner.finishing) {
          this.owner.finish(this._disposed ? this.owner.error : this._error);
        }
      } finally {
        this.finishing = false;
      }
    }
  }
}

// src/NativeScene.ts
var maxLayoutRounds = 8;
var maxHostRequests = 65536;

class NativeLifecyclePasses extends Set {
  order = new WeakMap;
  nextOrder = 0;
  work;
  add(renderable) {
    if (!this.order.has(renderable))
      this.order.set(renderable, ++this.nextOrder);
    this.refresh(renderable);
    return this;
  }
  refresh(renderable) {
    const order = this.order.get(renderable);
    if (order === undefined)
      return;
    const active = renderable._needsLifecyclePass();
    if (active === super.has(renderable))
      return;
    if (!active) {
      super.delete(renderable);
      return;
    }
    super.add(renderable);
    const work = this.work;
    if (!work || order <= work.order)
      return;
    let low = work.index;
    let high = work.pending.length;
    while (low < high) {
      const middle = low + high >>> 1;
      if (work.pending[middle].order < order)
        low = middle + 1;
      else
        high = middle;
    }
    if (work.pending[low]?.order !== order)
      work.pending.splice(low, 0, { renderable, order });
  }
  delete(renderable) {
    this.order.delete(renderable);
    return super.delete(renderable);
  }
  clear() {
    super.clear();
    this.order = new WeakMap;
  }
  *iteratePending() {
    if (this.work)
      throw new Error("Native scene lifecycle pass is already active");
    if (this.size === 0)
      return;
    const work = {
      pending: Array.from(this, (renderable) => ({ renderable, order: this.order.get(renderable) })),
      index: 0,
      order: 0
    };
    work.pending.sort((a, b) => a.order - b.order);
    this.work = work;
    try {
      while (work.index < work.pending.length) {
        const next = work.pending[work.index++];
        work.order = next.order;
        if (this.has(next.renderable) && this.order.get(next.renderable) === next.order)
          yield next.renderable;
      }
    } finally {
      this.work = undefined;
    }
  }
}

class NativeScene {
  driver;
  renderer;
  workBudget;
  get resourceContext() {
    return this.driver.resourceContext;
  }
  lifecyclePasses = new NativeLifecyclePasses;
  cleanupOwners = new Set;
  nodes = new Map;
  paintedFrame = null;
  paintRecording;
  cancelPaintYield = null;
  destroyed = false;
  destroying = false;
  geometryRevision = 0;
  layoutRevision = 0;
  staging = new SceneStaging;
  hookScans = new Set;
  scanningHooks = false;
  yogaHost;
  constructor(driver, renderer, workBudget) {
    this.driver = driver;
    this.renderer = renderer;
    this.workBudget = workBudget;
    this.yogaHost = driver.renderLib.getYogaHost();
  }
  get frame() {
    return this.paintedFrame;
  }
  get currentGeometryRevision() {
    return this.geometryRevision;
  }
  get observedLayoutRevision() {
    if (this.yogaHost.inCallback || this.destroyed || this.driver.disposed)
      return;
    return this.layoutRevision;
  }
  get stopped() {
    return this.destroyed || this.destroying || this.driver.disposed || this.renderer.isDestroyed;
  }
  changeGeometry() {
    this.geometryRevision = this.geometryRevision === Number.MAX_SAFE_INTEGER ? 0 : this.geometryRevision + 1;
    this.changeLayout();
  }
  changeLayout() {
    this.layoutRevision = this.layoutRevision === Number.MAX_SAFE_INTEGER ? 0 : this.layoutRevision + 1;
  }
  get hasStagedMutations() {
    return this.staging.pending;
  }
  flushStaged() {
    if (this.destroyed || this.driver.disposed) {
      this.staging.clear();
      this.yogaHost.forgetScene(this);
      return;
    }
    if (!this.staging.pending)
      return;
    try {
      this.driver.renderLib.sceneFlush(this.driver.context, this.staging);
    } catch (error) {
      if (!(error instanceof NativeError2) || error.status !== -12 /* SessionClosed */)
        throw error;
      this.staging.clear();
    } finally {
      if (!this.staging.pending)
        this.yogaHost.forgetScene(this);
    }
  }
  scheduleHookScan(renderable) {
    if (this.stopped)
      return;
    this.hookScans.add(renderable);
  }
  refreshPendingHooks(renderable) {
    if (this.scanningHooks || !this.hookScans.has(renderable))
      return;
    this.scanningHooks = true;
    try {
      renderable._scanNativeSceneHooks();
    } finally {
      this.scanningHooks = false;
    }
  }
  drainHookScans() {
    if (this.scanningHooks)
      throw new Error("Native scene hook discovery is already active");
    if (this.hookScans.size === 0)
      return;
    this.scanningHooks = true;
    let visits = 0;
    try {
      while (this.hookScans.size !== 0) {
        const pending = this.hookScans;
        this.hookScans = new Set;
        try {
          for (const renderable of pending) {
            if (this.stopped)
              return;
            if (++visits > maxHostRequests)
              throw new Error("Native scene hook discovery work limit exceeded");
            renderable._scanNativeSceneHooks();
            pending.delete(renderable);
          }
        } catch (error) {
          if (!this.stopped) {
            for (const renderable of this.hookScans)
              pending.add(renderable);
            this.hookScans = pending;
          }
          throw error;
        }
      }
    } finally {
      this.scanningHooks = false;
    }
  }
  getRenderables() {
    return this.nodes.values();
  }
  assertAlive() {
    if (this.destroyed || this.driver.disposed)
      throw new Error("Native scene is destroyed");
  }
  createNode(renderable, options) {
    this.yogaHost.assertMutable();
    this.assertAlive();
    if (this.destroying)
      throw new Error("Native scene is being destroyed");
    const kind = renderable.nativeIntegration.kind;
    if (options.enableLayout === false)
      throw new Error("Native scene requires Yoga layout");
    const handle = this.driver.renderLib.sceneCreateNode(this.driver.context, this.driver.session, kind, renderable.num);
    try {
      renderable._bindSceneHandle(handle);
      this.nodes.set(renderable.num, renderable);
    } catch (error) {
      try {
        this.driver.renderLib.sceneDestroyNode(this.driver.context, handle);
      } catch {}
      throw error;
    }
  }
  moveNode(child, parent, index) {
    const handle = child._getSceneHandle(this);
    const parentHandle = parent?._getSceneHandle(this) ?? null;
    this.driver.renderLib.sceneMoveNode(this.driver.context, handle, parentHandle, index);
    this.changeGeometry();
  }
  setViewport(content, viewport) {
    this.flushStaged();
    this.driver.renderLib.sceneSetViewport(this.driver.context, content._getSceneHandle(this), viewport ? viewport._getSceneHandle(this) : null);
  }
  setFocus(renderable, focused) {
    this.flushStaged();
    this.driver.renderLib.sceneSetFocus(this.driver.context, renderable._getSceneHandle(this), focused);
  }
  destroyNode(renderable) {
    renderable.assertMutable();
    const handle = renderable._getSceneHandle(this);
    let flushFailure;
    try {
      this.flushStaged();
    } catch (error) {
      flushFailure = { error };
    }
    try {
      this.driver.renderLib.sceneDestroyNode(this.driver.context, handle);
      this.staging.discard(handle);
      if (!this.staging.pending)
        this.yogaHost.forgetScene(this);
      this.changeGeometry();
      renderable._releaseSceneHandle();
      this.nodes.delete(renderable.num);
      this.hookScans.delete(renderable);
      this.renderer.unregisterLifecyclePass(renderable);
    } catch (error) {
      if (flushFailure) {
        throw new AggregateError([flushFailure.error, error], "Native scene flush and node cleanup both failed");
      }
      throw error;
    }
    if (flushFailure)
      throw flushFailure.error;
  }
  setHooks(renderable, flags, generation, initialWidth, initialHeight) {
    this.flushStaged();
    this.driver.renderLib.sceneSetHooks(this.driver.context, renderable._getSceneHandle(this), flags, generation, initialWidth, initialHeight);
  }
  setStyle(node, group, kind, edge, unit, value, flags = 0) {
    this.yogaHost.assertMutable();
    const handle = node._getSceneHandle(this);
    if (this.staging.full)
      this.flushStaged();
    if (this.staging.stageStyle(this.driver.context, handle, group, kind, edge, unit, value, flags)) {
      this.yogaHost.stageScene(this);
    }
    this.changeGeometry();
  }
  getStyle(node, group, kind, edge) {
    const handle = node._getSceneHandle(this);
    this.flushStaged();
    return this.driver.renderLib.sceneGetStyle(this.driver.context, handle, group, kind, edge);
  }
  setMeasureFunc(node, measure) {
    this.flushStaged();
    this.driver.renderLib.sceneSetMeasure(this.driver.context, node._getSceneHandle(this), measure);
  }
  hasMeasureFunc(node) {
    this.flushStaged();
    return this.driver.renderLib.sceneHasMeasure(this.driver.context, node._getSceneHandle(this));
  }
  markDirty(node) {
    this.flushStaged();
    this.driver.renderLib.sceneMarkDirty(this.driver.context, node._getSceneHandle(this));
  }
  setPositions(node, mask, units, values) {
    const edgeMaskMax = (1 << Edge2.Bottom + 1) - 1;
    if (!Number.isInteger(mask) || mask < 0 || mask > edgeMaskMax)
      throw new RangeError("Scene position mask must use four edges");
    for (let edge = 0;edge <= Edge2.Bottom; edge++) {
      if ((mask & 1 << edge) !== 0)
        SceneStaging.checkStyleValue(NativeStyleGroup.Value, values[edge]);
    }
    for (let edge = 0;edge <= Edge2.Bottom; edge++) {
      if ((mask & 1 << edge) === 0)
        continue;
      this.setStyle(node, NativeStyleGroup.Value, YogaValueKind.Position, edge, units[edge], values[edge], NativeStyleFlags.None);
    }
  }
  setPaint(renderable, paint) {
    this.yogaHost.assertMutable();
    const handle = renderable._getSceneHandle(this);
    if (this.staging.full)
      this.flushStaged();
    if (this.staging.stagePaint(this.driver.context, handle, paint, renderable))
      this.yogaHost.stageScene(this);
    this.changeGeometry();
  }
  setBackground(renderable, color) {
    this.yogaHost.assertMutable();
    const handle = renderable._getSceneHandle(this);
    if (this.staging.full)
      this.flushStaged();
    if (this.staging.stageBackground(this.driver.context, handle, color, renderable))
      this.yogaHost.stageScene(this);
  }
  setBoxDetails(renderable, details) {
    this.flushStaged();
    this.driver.renderLib.sceneSetBoxDetails(this.driver.context, renderable._getSceneHandle(this), details);
  }
  setBoxBorderStyle(renderable, style, sides) {
    this.setPaint(renderable, { borderStyle: style, border: sides, resetBorderCharacters: true });
  }
  setText(renderable, content) {
    this.flushStaged();
    const node = renderable._getSceneHandle(this);
    if (typeof content === "string") {
      this.driver.renderLib.sceneSetText(this.driver.context, node, this.driver.renderLib.encoder.encode(content));
    } else {
      this.driver.renderLib.sceneSetStyledText(this.driver.context, node, content);
    }
  }
  setTextOptions(renderable, options) {
    this.flushStaged();
    this.driver.renderLib.sceneSetTextOptions(this.driver.context, renderable._getSceneHandle(this), options);
  }
  setSlider(renderable, options) {
    this.flushStaged();
    this.driver.renderLib.sceneSetSlider(this.driver.context, renderable._getSceneHandle(this), options);
  }
  getSliderThumb(renderable) {
    this.flushStaged();
    return this.driver.renderLib.sceneGetSliderThumb(this.driver.context, renderable._getSceneHandle(this));
  }
  setArrow(renderable, options) {
    this.flushStaged();
    this.driver.renderLib.sceneSetArrow(this.driver.context, renderable._getSceneHandle(this), options);
  }
  setImage(renderable, image, fit, protocol, buffer) {
    this.flushStaged();
    const { renderLib: lib, context } = this.driver;
    lib.sceneSetImage(context, renderable._getSceneHandle(this), image?._getContextHandle(lib, context) ?? null, fit, protocol, buffer?._getSceneHandle(this) ?? null);
  }
  setEditorView(renderable, view) {
    this.flushStaged();
    this.driver.renderLib.sceneSetEditorView(this.driver.context, renderable._getSceneHandle(this), view);
  }
  setSurface(renderable, buffer) {
    this.flushStaged();
    this.driver.renderLib.sceneSetSurface(this.driver.context, renderable._getSceneHandle(this), buffer?._getSceneHandle(this) ?? null);
  }
  setTextView(renderable, view) {
    this.flushStaged();
    this.driver.renderLib.sceneSetTextView(this.driver.context, renderable._getSceneHandle(this), view);
  }
  setTextViewPaint(renderable, enabled) {
    this.flushStaged();
    this.driver.renderLib.sceneSetTextViewPaint(this.driver.context, renderable._getSceneHandle(this), enabled);
  }
  setEditorOptions(renderable, options) {
    this.flushStaged();
    this.driver.renderLib.sceneSetEditorOptions(this.driver.context, renderable._getSceneHandle(this), options);
  }
  getText(renderable) {
    this.flushStaged();
    return this.driver.renderLib.sceneGetText(this.driver.context, renderable._getSceneHandle(this));
  }
  drawText(renderable, buffer, x, y) {
    this.flushStaged();
    buffer._drawSceneText(this, renderable._getSceneHandle(this), x, y);
  }
  setTextSelection(renderable, operation, bounds, bg, fg) {
    this.flushStaged();
    return this.driver.renderLib.sceneSetTextSelection(this.driver.context, renderable._getSceneHandle(this), {
      operation,
      anchorX: bounds?.anchorX ?? 0,
      anchorY: bounds?.anchorY ?? 0,
      focusX: bounds?.focusX ?? 0,
      focusY: bounds?.focusY ?? 0,
      behavior: bounds?.behavior ?? "cell",
      bg,
      fg
    });
  }
  getTextSelection(renderable) {
    this.flushStaged();
    return this.driver.renderLib.sceneGetTextSelection(this.driver.context, renderable._getSceneHandle(this));
  }
  getSelectedText(renderable) {
    this.flushStaged();
    return this.driver.renderLib.sceneGetSelectedText(this.driver.context, renderable._getSceneHandle(this));
  }
  getTextLineInfo(renderable, firstLine, lineCount) {
    this.flushStaged();
    const handle = renderable._getSceneHandle(this);
    return this.driver.renderLib.sceneGetTextLineInfo(this.driver.context, handle, firstLine, lineCount);
  }
  getTextMetrics(renderable) {
    this.flushStaged();
    return this.driver.renderLib.sceneGetTextMetrics(this.driver.context, renderable._getSceneHandle(this));
  }
  getLayout(node, rawYoga = false) {
    const handle = node._getSceneHandle(this);
    this.flushStaged();
    return this.driver.renderLib.sceneGetLayout(this.driver.context, handle, rawYoga);
  }
  measureSnapshot(root) {
    this.yogaHost.assertMutable();
    this.assertAlive();
    if (this.frame)
      throw new Error("Cannot measure a snapshot during a native scene frame");
    const owner = this.renderer.root;
    root._getSceneHandle(this);
    const attached = root.parent === owner;
    if (root === owner || root.parent && !attached)
      throw new Error("Snapshot root belongs to another parent");
    if (!attached)
      owner.add(root);
    try {
      this.drainHookScans();
      this.runLifecyclePasses();
      this.drainHookScans();
      this.assertAlive();
      this.flushStaged();
      try {
        this.driver.renderLib.sceneMeasureLayout(this.driver.context, this.driver.session, owner._getSceneHandle(this));
      } finally {
        this.changeLayout();
      }
      return Math.max(1, Math.trunc(this.getLayout(root, true).height));
    } finally {
      if (!attached && root.parent === owner)
        owner.remove(root);
    }
  }
  paint(deltaTime, getPaintOptions) {
    this.yogaHost.assertMutable();
    this.assertAlive();
    if (this.cancelPaintYield || this.paintedFrame)
      throw new Error("Native scene is already painting a frame");
    this.renderer.root._setCurrentRenderable(undefined);
    this.drainHookScans();
    this.runLifecyclePasses();
    const continuation = this.advancePaint(deltaTime, getPaintOptions);
    if (continuation)
      return this.resumePaint(deltaTime, getPaintOptions, continuation);
  }
  runLifecyclePasses() {
    if (this.renderer.root.visible) {
      let visits = 0;
      for (const renderable of this.lifecyclePasses.iteratePending()) {
        if (this.stopped || this.renderer.controlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */)
          return;
        if (++visits > maxHostRequests)
          throw new Error("Native scene lifecycle work limit exceeded");
        if (!renderable.isDestroyed) {
          renderable.onLifecyclePass?.call(renderable);
        }
        this.drainHookScans();
      }
    }
  }
  async resumePaint(deltaTime, getPaintOptions, continuation) {
    while (continuation) {
      await continuation.wait;
      this.cancelPaintYield = null;
      if (continuation.interrupted === "restart") {
        this.cancelAttempt(continuation.request);
        this.drainHookScans();
        this.runLifecyclePasses();
        continuation = undefined;
      }
      continuation = this.advancePaint(deltaTime, getPaintOptions, continuation);
    }
  }
  advancePaint(deltaTime, getPaintOptions, continuation) {
    let request = continuation?.request ?? null;
    let recording = null;
    let yielded = false;
    try {
      while (continuation?.interrupted !== "cancel" && !this.stopped) {
        this.drainHookScans();
        const options = { ...getPaintOptions(), maxLayoutRounds, maxHostRequests };
        if (this.stopped || this.renderer.controlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */)
          return;
        this.flushStaged();
        const geometryRevision = this.geometryRevision;
        try {
          request = this.driver.renderLib.sceneFrameStep(this.driver.context, this.driver.session, request, options, this.workBudget, recording);
        } finally {
          this.changeLayout();
          this.paintRecording?.recorder.settle();
        }
        recording = null;
        request.geometryRevision = geometryRevision;
        if (request.kind === NativeSceneFrame2.Done) {
          this.paintedFrame = request;
          return;
        }
        if (request.kind === NativeSceneFrame2.Yield) {
          const wait = Promise.withResolvers();
          const state = continuation ?? { request, wait: wait.promise };
          state.request = request;
          state.wait = wait.promise;
          const cancel = this.driver.scheduler.schedule(wait.resolve);
          this.cancelPaintYield = (restart = false) => {
            const first = state.interrupted === undefined;
            state.interrupted = restart && state.interrupted !== "cancel" ? "restart" : "cancel";
            if (!first)
              return;
            try {
              cancel();
            } finally {
              wait.resolve();
            }
          };
          yielded = true;
          return state;
        }
        if (!sameHandle(request.session, this.driver.session) || !sameHandle(request.root, this.renderer.root._getSceneHandle(this))) {
          throw new Error("Native scene returned a stale host request");
        }
        if (request.kind === NativeSceneFrame2.Record) {
          recording = this.recordPaint(request, deltaTime);
          continue;
        }
        const renderable = this.nodes.get(request.num);
        if (!renderable || renderable.isDestroyed)
          continue;
        if (!sameHandle(request.node, renderable._getSceneHandle(this))) {
          throw new Error("Native scene returned a stale host request");
        }
        renderable._runNativeSceneHook(request, deltaTime);
      }
    } finally {
      this.paintRecording?.recorder.settle();
      if (!yielded && request && request !== this.paintedFrame)
        this.cancelAttempt(request);
    }
  }
  cancelAttempt(request) {
    if (this.driver.disposed)
      return;
    this.changeLayout();
    try {
      this.driver.renderLib.sceneFrameCancel(this.driver.context, this.driver.session, request.frameId);
    } catch {}
  }
  recordPaint(request, deltaTime) {
    const { renderLib: lib, context, session } = this.driver;
    const slots = lib.sceneFrameGetPaintSlots(context, session, request);
    const paint = this.paintRecording ??= this.createPaintRecording();
    paint.recorder.begin(context);
    try {
      for (let index = 0;index < slots.length; index++) {
        if (this.stopped)
          return null;
        const slot = slots[index];
        const renderable = this.nodes.get(slot.num);
        if (!renderable || renderable.isDestroyed)
          continue;
        if (!sameHandle(slot.node, renderable._getSceneHandle(this))) {
          throw new Error("Native scene returned a stale paint slot");
        }
        this.renderer.root._setCurrentRenderable(renderable);
        renderable._recordNativeScenePaint(slot, index, deltaTime, paint.buffer, paint.recorder, request.geometryRevision);
        this.renderer.root._setCurrentRenderable(undefined);
      }
      return paint.recorder.recording;
    } finally {
      paint.recorder.end();
    }
  }
  createPaintRecording() {
    const recorder = new NativePaintRecorder;
    const { renderLib: lib, context, session } = this.driver;
    return { recorder, buffer: OptimizedBuffer2.fromRecorder(lib, context, session, recorder) };
  }
  commit(force = false) {
    const frame = this.paintedFrame;
    if (!frame)
      throw new Error("Native scene has no painted frame");
    const result = this.driver.render(force, frame);
    this.paintedFrame = null;
    return result;
  }
  commitSplit(commits, pinnedRenderOffset, force) {
    const frame = this.paintedFrame;
    if (!frame)
      throw new Error("Native scene has no painted frame");
    const result = this.driver.renderSplit(frame, commits, pinnedRenderOffset, force);
    this.paintedFrame = null;
    return result;
  }
  cancelFrame() {
    this.cancelPaintYield?.();
    const frame = this.paintedFrame;
    this.paintedFrame = null;
    if (frame)
      this.cancelAttempt(frame);
  }
  interruptPaint() {
    this.cancelPaintYield?.();
  }
  restartPaint() {
    this.cancelPaintYield?.(true);
  }
  hitTest(x, y) {
    this.assertAlive();
    const id = this.driver.renderLib.sceneHitTest(this.driver.context, this.driver.session, x, y);
    const renderable = this.nodes.get(id);
    return renderable && !renderable.isDestroyed ? id : 0;
  }
  destroy() {
    if (this.destroyed || this.destroying)
      return;
    this.yogaHost.assertMutable();
    this.destroying = true;
    this.staging.clear();
    this.yogaHost.forgetScene(this);
    this.hookScans.clear();
    let failure;
    try {
      try {
        this.cancelPaintYield?.();
      } catch (error) {
        failure = { error };
      }
      for (const renderable of this.nodes.values()) {
        try {
          renderable.destroyRecursively();
        } catch (error) {
          failure ??= { error };
        }
      }
      this.destroyed = this.nodes.size === 0;
    } finally {
      this.staging.clear();
      this.yogaHost.forgetScene(this);
      this.destroying = false;
    }
    if (failure)
      throw failure.error;
  }
}
function sameHandle(left, right) {
  return left.contextId === right.contextId && left.slot === right.slot && left.generation === right.generation;
}

// src/console.ts
import { EventEmitter as EventEmitter7 } from "events";
import { Console } from "console";
import fs from "fs";
import path3 from "path";
import util2 from "util";

// src/lib/output.capture.ts
import { Writable as Writable2 } from "stream";
import { EventEmitter as EventEmitter6 } from "events";

class Capture extends EventEmitter6 {
  output = [];
  constructor() {
    super();
  }
  get size() {
    return this.output.length;
  }
  write(stream, data) {
    this.output.push({ stream, output: data });
    this.emit("write", stream, data);
  }
  claimOutput() {
    const output = this.output.map((o) => o.output).join("");
    this.clear();
    return output;
  }
  clear() {
    this.output = [];
  }
}

class CapturedWritableStream extends Writable2 {
  stream;
  capture;
  isTTY = true;
  columns = process.stdout.columns || 80;
  rows = process.stdout.rows || 24;
  constructor(stream, capture) {
    super();
    this.stream = stream;
    this.capture = capture;
  }
  _write(chunk, encoding, callback) {
    const data = chunk.toString();
    this.capture.write(this.stream, data);
    callback();
  }
  getColorDepth() {
    return process.stdout.getColorDepth?.() || 8;
  }
}

// src/lib/keybinding.internal.ts
var defaultKeyAliases = {
  enter: "return",
  esc: "escape",
  kp0: "0",
  kp1: "1",
  kp2: "2",
  kp3: "3",
  kp4: "4",
  kp5: "5",
  kp6: "6",
  kp7: "7",
  kp8: "8",
  kp9: "9",
  kpdecimal: ".",
  kpdivide: "/",
  kpmultiply: "*",
  kpminus: "-",
  kpplus: "+",
  kpenter: "enter",
  kpequal: "=",
  kpseparator: ",",
  kpleft: "left",
  kpright: "right",
  kpup: "up",
  kpdown: "down",
  kppageup: "pageup",
  kppagedown: "pagedown",
  kphome: "home",
  kpend: "end",
  kpinsert: "insert",
  kpdelete: "delete"
};
function mergeKeyAliases(defaults, custom) {
  return { ...defaults, ...custom };
}
function mergeKeyBindings(defaults, custom) {
  const map = new Map;
  for (const binding of defaults) {
    const key = getKeyBindingKey(binding);
    map.set(key, binding);
  }
  for (const binding of custom) {
    const key = getKeyBindingKey(binding);
    map.set(key, binding);
  }
  return Array.from(map.values());
}
function getKeyBindingKey(binding) {
  return `${binding.name}:${binding.ctrl ? 1 : 0}:${binding.shift ? 1 : 0}:${binding.meta ? 1 : 0}:${binding.super ? 1 : 0}`;
}
function getBaseCodeKeyName({ name: typedName, baseCode }) {
  if (!/^[^\x00-\x7f]$/u.test(typedName) || baseCode === undefined || baseCode < 32 || baseCode === 127) {
    return;
  }
  try {
    const name = String.fromCodePoint(baseCode);
    if (name.length === 1 && name >= "A" && name <= "Z") {
      return name.toLowerCase();
    }
    return name;
  } catch {
    return;
  }
}
function getKeyBindingKeys(binding) {
  const names = new Set([binding.name]);
  const baseCodeName = getBaseCodeKeyName(binding);
  if (baseCodeName) {
    names.add(baseCodeName);
  }
  return [...names].map((name) => getKeyBindingKey({ ...binding, name }));
}
function getKeyBindingAction(map, binding) {
  for (const key of getKeyBindingKeys(binding)) {
    const action = map.get(key);
    if (action !== undefined) {
      return action;
    }
  }
  return;
}
function matchesKeyBinding(binding, match) {
  const matchKey = getKeyBindingKey(match);
  return getKeyBindingKeys(binding).includes(matchKey);
}
function buildKeyBindingsMap(bindings, aliasMap) {
  const map = new Map;
  const aliases = aliasMap || {};
  for (const binding of bindings) {
    const key = getKeyBindingKey(binding);
    map.set(key, binding.action);
  }
  for (const binding of bindings) {
    const normalizedName = aliases[binding.name] || binding.name;
    if (normalizedName !== binding.name) {
      const aliasedKey = getKeyBindingKey({ ...binding, name: normalizedName });
      map.set(aliasedKey, binding.action);
    }
  }
  return map;
}
function keyBindingToString(binding) {
  const parts = [];
  if (binding.ctrl)
    parts.push("ctrl");
  if (binding.shift)
    parts.push("shift");
  if (binding.meta)
    parts.push("meta");
  if (binding.super)
    parts.push("super");
  parts.push(binding.name);
  return parts.join("+");
}

// src/console.ts
function getCallerInfo() {
  const err = new Error;
  const stackLines = err.stack?.split(`
`).slice(5) || [];
  if (!stackLines.length)
    return null;
  const callerLine = stackLines[0].trim();
  const regex = /at\s+(?:([\w$.<>]+)\s+\()?((?:\/|[A-Za-z]:\\)[^:]+):(\d+):(\d+)\)?/;
  const match = callerLine.match(regex);
  if (!match)
    return null;
  const functionName = match[1] || "<anonymous>";
  const fullPath = match[2];
  const fileName = fullPath.split(/[\\/]/).pop() || "<unknown>";
  const lineNumber = parseInt(match[3], 10) || 0;
  const columnNumber = parseInt(match[4], 10) || 0;
  return { functionName, fullPath, fileName, lineNumber, columnNumber };
}
var capture2 = singleton("ConsoleCapture", () => new Capture);
registerEnvVar2({
  name: "OTUI_USE_CONSOLE",
  description: "Whether to use the console. Will not capture console output if set to false.",
  type: "boolean",
  default: true
});
registerEnvVar2({
  name: "SHOW_CONSOLE",
  description: "Show the console at startup if set to true.",
  type: "boolean",
  default: false
});

class TerminalConsoleCache extends EventEmitter7 {
  _cachedLogs = [];
  MAX_CACHE_SIZE = 1000;
  _collectCallerInfo = false;
  _cachingEnabled = true;
  _originalConsole = null;
  get cachedLogs() {
    return this._cachedLogs;
  }
  constructor() {
    super();
  }
  activate() {
    if (!env2.OTUI_USE_CONSOLE)
      return;
    if (!this._originalConsole) {
      this._originalConsole = global.console;
    }
    this.setupConsoleCapture();
    this.overrideConsoleMethods();
  }
  setupConsoleCapture() {
    if (!env2.OTUI_USE_CONSOLE)
      return;
    const mockStdout = new CapturedWritableStream("stdout", capture2);
    const mockStderr = new CapturedWritableStream("stderr", capture2);
    global.console = new Console({
      stdout: mockStdout,
      stderr: mockStderr,
      colorMode: true,
      inspectOptions: {
        compact: false,
        breakLength: 80,
        depth: 2
      }
    });
  }
  overrideConsoleMethods() {
    console.log = (...args) => {
      this.appendToConsole("LOG" /* LOG */, ...args);
    };
    console.info = (...args) => {
      this.appendToConsole("INFO" /* INFO */, ...args);
    };
    console.warn = (...args) => {
      this.appendToConsole("WARN" /* WARN */, ...args);
    };
    console.error = (...args) => {
      this.appendToConsole("ERROR" /* ERROR */, ...args);
    };
    console.debug = (...args) => {
      this.appendToConsole("DEBUG" /* DEBUG */, ...args);
    };
    if (typeof console.timeStamp !== "function") {
      console.timeStamp = () => {};
    }
  }
  setCollectCallerInfo(enabled) {
    this._collectCallerInfo = enabled;
  }
  clearConsole() {
    this._cachedLogs = [];
  }
  setCachingEnabled(enabled) {
    this._cachingEnabled = enabled;
  }
  deactivate() {
    this.restoreOriginalConsole();
  }
  restoreOriginalConsole() {
    if (this._originalConsole) {
      global.console = this._originalConsole;
    }
  }
  addLogEntry(level, ...args) {
    const callerInfo = this._collectCallerInfo ? getCallerInfo() : null;
    const logEntry = [new Date, level, args, callerInfo];
    if (this._cachingEnabled) {
      if (this._cachedLogs.length >= this.MAX_CACHE_SIZE) {
        this._cachedLogs.shift();
      }
      this._cachedLogs.push(logEntry);
    }
    return logEntry;
  }
  appendToConsole(level, ...args) {
    if (this._cachedLogs.length >= this.MAX_CACHE_SIZE) {
      this._cachedLogs.shift();
    }
    const entry = this.addLogEntry(level, ...args);
    this.emit("entry", entry);
  }
  destroy() {
    this.deactivate();
  }
}
var terminalConsoleCache = singleton("TerminalConsoleCache", () => {
  const terminalConsoleCache = new TerminalConsoleCache;
  process.on("exit", () => {
    terminalConsoleCache.destroy();
  });
  return terminalConsoleCache;
});
var ConsolePosition2;
((ConsolePosition) => {
  ConsolePosition["TOP"] = "top";
  ConsolePosition["BOTTOM"] = "bottom";
  ConsolePosition["LEFT"] = "left";
  ConsolePosition["RIGHT"] = "right";
})(ConsolePosition2 ||= {});
var defaultConsoleKeybindings = [
  { name: "up", action: "scroll-up" },
  { name: "down", action: "scroll-down" },
  { name: "up", shift: true, action: "scroll-to-top" },
  { name: "down", shift: true, action: "scroll-to-bottom" },
  { name: "p", ctrl: true, action: "position-previous" },
  { name: "o", ctrl: true, action: "position-next" },
  { name: "+", action: "size-increase" },
  { name: "=", shift: true, action: "size-increase" },
  { name: "-", action: "size-decrease" },
  { name: "s", ctrl: true, action: "save-logs" },
  { name: "c", ctrl: true, shift: true, action: "copy-selection" }
];
var DEFAULT_CONSOLE_OPTIONS = {
  position: "bottom" /* BOTTOM */,
  sizePercent: 30,
  zIndex: Infinity,
  colorInfo: "#00FFFF",
  colorWarn: "#FFFF00",
  colorError: "#FF0000",
  colorDebug: "#808080",
  colorDefault: "#FFFFFF",
  backgroundColor: RGBA2.fromValues(0.1, 0.1, 0.1, 0.7),
  startInDebugMode: false,
  title: "Console",
  titleBarColor: RGBA2.fromValues(0.05, 0.05, 0.05, 0.7),
  titleBarTextColor: "#FFFFFF",
  cursorColor: "#00A0FF",
  maxStoredLogs: 2000,
  maxDisplayLines: 3000,
  onCopySelection: undefined,
  keyBindings: undefined,
  keyAliasMap: undefined,
  selectionColor: RGBA2.fromValues(0.3, 0.5, 0.8, 0.5),
  copyButtonColor: "#00A0FF"
};
var INDENT_WIDTH = 2;
var graphemeSegmenter = new Intl.Segmenter(undefined, { granularity: "grapheme" });
function wrapDisplayCells(text, firstCells, restCells) {
  const segments = [];
  let segment = "";
  let cells = 0;
  for (const { segment: grapheme } of graphemeSegmenter.segment(text)) {
    const width = stringWidth(grapheme);
    const budget = segments.length === 0 ? firstCells : restCells;
    if (segment.length > 0 && cells + width > budget) {
      segments.push(segment);
      segment = "";
      cells = 0;
    }
    segment += grapheme;
    cells += width;
  }
  if (segment.length > 0)
    segments.push(segment);
  return segments;
}

class TerminalConsole2 extends EventEmitter7 {
  isVisible = false;
  isFocused = false;
  renderer;
  keyHandler;
  options;
  _debugModeEnabled = false;
  frameBuffer = null;
  consoleX = 0;
  consoleY = 0;
  consoleWidth = 0;
  consoleHeight = 0;
  scrollTopIndex = 0;
  isScrolledToBottom = true;
  currentLineIndex = 0;
  _displayLines = [];
  _allLogEntries = [];
  _needsFrameBufferUpdate = false;
  _entryListener;
  _selectionStart = null;
  _selectionEnd = null;
  _isDragging = false;
  _copyButtonBounds = {
    x: 0,
    y: 0,
    width: 0,
    height: 0
  };
  _autoScrollInterval = null;
  clock;
  _keyBindingsMap;
  _keyAliasMap;
  _keyBindings;
  _mergedKeyBindings;
  _actionHandlers;
  markNeedsRerender() {
    this._needsFrameBufferUpdate = true;
    this.renderer.requestRender();
  }
  getCopyButtonLabel() {
    const copyBindings = this._mergedKeyBindings.filter((b) => b.action === "copy-selection");
    const copyBinding = copyBindings[copyBindings.length - 1];
    if (copyBinding) {
      const shortcut = keyBindingToString(copyBinding);
      return `[Copy (${shortcut})]`;
    }
    return "[Copy]";
  }
  _rgbaInfo;
  _rgbaWarn;
  _rgbaError;
  _rgbaDebug;
  _rgbaDefault;
  backgroundColor;
  _rgbaTitleBar;
  _rgbaTitleBarText;
  _title;
  _rgbaCursor;
  _rgbaSelection;
  _rgbaCopyButton;
  _positions = [
    "top" /* TOP */,
    "right" /* RIGHT */,
    "bottom" /* BOTTOM */,
    "left" /* LEFT */
  ];
  constructor(renderer, options = {}) {
    super();
    this.renderer = renderer;
    this.clock = options.clock ?? new SystemClock2;
    this.options = { ...DEFAULT_CONSOLE_OPTIONS, ...options };
    this.keyHandler = this.handleKeyPress.bind(this);
    this._debugModeEnabled = this.options.startInDebugMode;
    terminalConsoleCache.setCollectCallerInfo(this._debugModeEnabled);
    this._rgbaInfo = RGBA2.clone(parseColor2(this.options.colorInfo));
    this._rgbaWarn = RGBA2.clone(parseColor2(this.options.colorWarn));
    this._rgbaError = RGBA2.clone(parseColor2(this.options.colorError));
    this._rgbaDebug = RGBA2.clone(parseColor2(this.options.colorDebug));
    this._rgbaDefault = RGBA2.clone(parseColor2(this.options.colorDefault));
    this.backgroundColor = RGBA2.clone(parseColor2(this.options.backgroundColor));
    this._rgbaTitleBar = RGBA2.clone(parseColor2(this.options.titleBarColor));
    this._rgbaTitleBarText = RGBA2.clone(parseColor2(this.options.titleBarTextColor || this.options.colorDefault));
    this._title = this.options.title;
    this._rgbaCursor = RGBA2.clone(parseColor2(this.options.cursorColor));
    this._rgbaSelection = RGBA2.clone(parseColor2(this.options.selectionColor));
    this._rgbaCopyButton = RGBA2.clone(parseColor2(this.options.copyButtonColor));
    this._keyAliasMap = mergeKeyAliases(defaultKeyAliases, options.keyAliasMap || {});
    this._keyBindings = options.keyBindings || [];
    this._mergedKeyBindings = mergeKeyBindings(defaultConsoleKeybindings, this._keyBindings);
    this._keyBindingsMap = buildKeyBindingsMap(this._mergedKeyBindings, this._keyAliasMap);
    this._actionHandlers = this.buildActionHandlers();
    this._updateConsoleDimensions();
    this._scrollToBottom(true);
    this._entryListener = (logEntry) => {
      this._handleNewLog(logEntry);
    };
    terminalConsoleCache.on("entry", this._entryListener);
    if (env2.SHOW_CONSOLE) {
      this.show();
    }
  }
  buildActionHandlers() {
    return new Map([
      ["scroll-up", () => this.scrollUp()],
      ["scroll-down", () => this.scrollDown()],
      ["scroll-to-top", () => this.scrollToTop()],
      ["scroll-to-bottom", () => this.scrollToBottomAction()],
      ["position-previous", () => this.positionPrevious()],
      ["position-next", () => this.positionNext()],
      ["size-increase", () => this.sizeIncrease()],
      ["size-decrease", () => this.sizeDecrease()],
      ["save-logs", () => this.saveLogsAction()],
      ["copy-selection", () => this.triggerCopyAction()]
    ]);
  }
  activate() {
    terminalConsoleCache.activate();
  }
  deactivate() {
    terminalConsoleCache.deactivate();
  }
  _handleNewLog(logEntry) {
    if (!this.isVisible)
      return;
    this._allLogEntries.push(logEntry);
    if (this._allLogEntries.length > this.options.maxStoredLogs) {
      this._allLogEntries.splice(0, this._allLogEntries.length - this.options.maxStoredLogs);
    }
    const newDisplayLines = this._processLogEntry(logEntry);
    this._displayLines.push(...newDisplayLines);
    if (this._displayLines.length > this.options.maxDisplayLines) {
      this._displayLines.splice(0, this._displayLines.length - this.options.maxDisplayLines);
      const linesRemoved = this._displayLines.length - this.options.maxDisplayLines;
      this.scrollTopIndex = Math.max(0, this.scrollTopIndex - linesRemoved);
    }
    if (this.isScrolledToBottom) {
      this._scrollToBottom();
    }
    this.markNeedsRerender();
  }
  _updateConsoleDimensions(termWidth, termHeight) {
    const width = termWidth ?? this.renderer.width;
    const height = termHeight ?? this.renderer.height;
    const sizePercent = this.options.sizePercent / 100;
    switch (this.options.position) {
      case "top" /* TOP */:
        this.consoleX = 0;
        this.consoleY = 0;
        this.consoleWidth = width;
        this.consoleHeight = Math.max(1, Math.floor(height * sizePercent));
        break;
      case "bottom" /* BOTTOM */:
        this.consoleHeight = Math.max(1, Math.floor(height * sizePercent));
        this.consoleWidth = width;
        this.consoleX = 0;
        this.consoleY = height - this.consoleHeight;
        break;
      case "left" /* LEFT */:
        this.consoleWidth = Math.max(1, Math.floor(width * sizePercent));
        this.consoleHeight = height;
        this.consoleX = 0;
        this.consoleY = 0;
        break;
      case "right" /* RIGHT */:
        this.consoleWidth = Math.max(1, Math.floor(width * sizePercent));
        this.consoleHeight = height;
        this.consoleY = 0;
        this.consoleX = width - this.consoleWidth;
        break;
    }
    this.currentLineIndex = Math.max(0, Math.min(this.currentLineIndex, this.consoleHeight - 1));
  }
  handleKeyPress(event) {
    if (event.name === "escape") {
      this.blur();
      return;
    }
    const action = getKeyBindingAction(this._keyBindingsMap, event);
    if (action) {
      const handler = this._actionHandlers.get(action);
      if (handler) {
        handler();
        return;
      }
    }
  }
  scrollUp() {
    const logAreaHeight = Math.max(1, this.consoleHeight - 1);
    if (this.currentLineIndex > 0) {
      this.currentLineIndex--;
      this.markNeedsRerender();
    } else if (this.scrollTopIndex > 0) {
      this.scrollTopIndex--;
      this.isScrolledToBottom = false;
      this.markNeedsRerender();
    }
    return true;
  }
  scrollDown() {
    const displayLineCount = this._displayLines.length;
    const logAreaHeight = Math.max(1, this.consoleHeight - 1);
    const maxScrollTop = Math.max(0, displayLineCount - logAreaHeight);
    const canCursorMoveDown = this.currentLineIndex < logAreaHeight - 1 && this.scrollTopIndex + this.currentLineIndex < displayLineCount - 1;
    if (canCursorMoveDown) {
      this.currentLineIndex++;
      this.markNeedsRerender();
    } else if (this.scrollTopIndex < maxScrollTop) {
      this.scrollTopIndex++;
      this.isScrolledToBottom = this.scrollTopIndex === maxScrollTop;
      this.markNeedsRerender();
    }
    return true;
  }
  scrollToTop() {
    if (this.scrollTopIndex > 0 || this.currentLineIndex > 0) {
      this.scrollTopIndex = 0;
      this.currentLineIndex = 0;
      this.isScrolledToBottom = this._displayLines.length <= Math.max(1, this.consoleHeight - 1);
      this.markNeedsRerender();
    }
    return true;
  }
  scrollToBottomAction() {
    const logAreaHeightForScroll = Math.max(1, this.consoleHeight - 1);
    const maxScrollPossible = Math.max(0, this._displayLines.length - logAreaHeightForScroll);
    if (this.scrollTopIndex < maxScrollPossible || !this.isScrolledToBottom) {
      this._scrollToBottom(true);
      this.markNeedsRerender();
    }
    return true;
  }
  positionPrevious() {
    const currentPositionIndex = this._positions.indexOf(this.options.position);
    const prevIndex = (currentPositionIndex - 1 + this._positions.length) % this._positions.length;
    this.options.position = this._positions[prevIndex];
    this.resize(this.renderer.width, this.renderer.height);
    return true;
  }
  positionNext() {
    const currentPositionIndex = this._positions.indexOf(this.options.position);
    const nextIndex = (currentPositionIndex + 1) % this._positions.length;
    this.options.position = this._positions[nextIndex];
    this.resize(this.renderer.width, this.renderer.height);
    return true;
  }
  sizeIncrease() {
    this.options.sizePercent = Math.min(100, this.options.sizePercent + 5);
    this.resize(this.renderer.width, this.renderer.height);
    return true;
  }
  sizeDecrease() {
    this.options.sizePercent = Math.max(10, this.options.sizePercent - 5);
    this.resize(this.renderer.width, this.renderer.height);
    return true;
  }
  saveLogsAction() {
    this.saveLogsToFile();
    return true;
  }
  triggerCopyAction() {
    this.triggerCopy();
    return true;
  }
  attachStdin() {
    if (this.isFocused)
      return;
    this.renderer.keyInput.on("keypress", this.keyHandler);
    this.isFocused = true;
  }
  detachStdin() {
    if (!this.isFocused)
      return;
    this.renderer.keyInput.off("keypress", this.keyHandler);
    this.isFocused = false;
  }
  formatTimestamp(date) {
    return new Intl.DateTimeFormat("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false
    }).format(date);
  }
  formatArguments(args) {
    return args.map((arg) => {
      if (arg instanceof Error) {
        const errorProps = arg;
        return `Error: ${errorProps.message}
` + (errorProps.stack ? `${errorProps.stack}
` : "");
      }
      try {
        return util2.inspect(arg, { depth: 2 });
      } catch (e) {
        return String(arg);
      }
    }).join(" ").replace(/\r\n/g, `
`).replace(/[\x00-\x08\x0b-\x1f\x7f-\x9f]/g, (control) => `\\x${control.charCodeAt(0).toString(16).padStart(2, "0")}`);
  }
  resize(width, height) {
    this._updateConsoleDimensions(width, height);
    if (this.frameBuffer) {
      this.frameBuffer.resize(this.consoleWidth, this.consoleHeight);
      const displayLineCount = this._displayLines.length;
      const logAreaHeight = Math.max(1, this.consoleHeight - 1);
      const maxScrollTop = Math.max(0, displayLineCount - logAreaHeight);
      this.scrollTopIndex = Math.min(this.scrollTopIndex, maxScrollTop);
      this.isScrolledToBottom = this.scrollTopIndex === maxScrollTop;
      const visibleLineCount = Math.min(logAreaHeight, displayLineCount - this.scrollTopIndex);
      this.currentLineIndex = Math.max(0, Math.min(this.currentLineIndex, visibleLineCount - 1));
      if (this.isVisible) {
        this.markNeedsRerender();
      }
    }
  }
  clear() {
    terminalConsoleCache.clearConsole();
    this._allLogEntries = [];
    this._displayLines = [];
    this.markNeedsRerender();
  }
  toggle() {
    if (this.isVisible) {
      if (this.isFocused) {
        this.hide();
      } else {
        this.focus();
      }
    } else {
      this.show();
    }
    if (!this.renderer.isRunning) {
      this.renderer.requestRender();
    }
  }
  focus() {
    this.attachStdin();
    this._scrollToBottom(true);
    this.markNeedsRerender();
  }
  blur() {
    this.detachStdin();
    this.markNeedsRerender();
  }
  show() {
    if (this.renderer.isDestroyed)
      throw new Error("Cannot show the console after renderer destruction");
    if (!this.isVisible) {
      if (!this.frameBuffer) {
        this.frameBuffer = OptimizedBuffer2.create(this.consoleWidth, this.consoleHeight, this.renderer.widthMethod, {
          respectAlpha: this.backgroundColor.a < 1,
          id: "console framebuffer",
          owner: this.renderer.nativeScene
        });
      }
      this.isVisible = true;
      this._processCachedLogs();
      terminalConsoleCache.setCachingEnabled(false);
      const logCount = terminalConsoleCache.cachedLogs.length;
      const visibleLogLines = Math.min(this.consoleHeight, logCount);
      this.currentLineIndex = Math.max(0, visibleLogLines - 1);
      this.scrollTopIndex = 0;
      this._scrollToBottom(true);
      this.focus();
      this.markNeedsRerender();
    }
  }
  hide() {
    if (this.isVisible) {
      this.stopAutoScroll();
      this.isVisible = false;
      this.blur();
      terminalConsoleCache.setCachingEnabled(true);
    }
  }
  destroy() {
    this.stopAutoScroll();
    this.hide();
    this.deactivate();
    terminalConsoleCache.off("entry", this._entryListener);
    this.frameBuffer?.destroy();
    this.frameBuffer = null;
  }
  getCachedLogs() {
    return terminalConsoleCache.cachedLogs.map((logEntry) => logEntry[0].toISOString() + " " + logEntry.slice(1).join(" ")).join(`
`);
  }
  updateFrameBuffer() {
    if (!this.frameBuffer)
      return;
    this.frameBuffer.clear(this.backgroundColor);
    const displayLines = this._displayLines;
    const displayLineCount = displayLines.length;
    const logAreaHeight = Math.max(1, this.consoleHeight - 1);
    this.frameBuffer.fillRect(0, 0, this.consoleWidth, 1, this._rgbaTitleBar);
    const dynamicTitle = `${this._title}${this.isFocused ? " (Focused)" : ""}`;
    const titleX = Math.max(0, Math.floor((this.consoleWidth - dynamicTitle.length) / 2));
    this.frameBuffer.drawText(dynamicTitle, titleX, 0, this._rgbaTitleBarText, this._rgbaTitleBar);
    const copyLabel = this.getCopyButtonLabel();
    const copyButtonX = this.consoleWidth - copyLabel.length - 1;
    if (copyButtonX >= 0) {
      const copyButtonEnabled = this.hasSelection();
      const disabledColor = RGBA2.fromInts(100, 100, 100, 255);
      const copyColor = copyButtonEnabled ? this._rgbaCopyButton : disabledColor;
      this.frameBuffer.drawText(copyLabel, copyButtonX, 0, copyColor, this._rgbaTitleBar);
      this._copyButtonBounds = { x: copyButtonX, y: 0, width: copyLabel.length, height: 1 };
    } else {
      this._copyButtonBounds = { x: -1, y: -1, width: 0, height: 0 };
    }
    const startIndex = this.scrollTopIndex;
    const endIndex = Math.min(startIndex + logAreaHeight, displayLineCount);
    const visibleDisplayLines = displayLines.slice(startIndex, endIndex);
    let lineY = 1;
    for (let i = 0;i < visibleDisplayLines.length; i++) {
      if (lineY >= this.consoleHeight)
        break;
      const displayLine = visibleDisplayLines[i];
      const absoluteLineIndex = startIndex + i;
      let levelColor = this._rgbaDefault;
      switch (displayLine.level) {
        case "INFO" /* INFO */:
          levelColor = this._rgbaInfo;
          break;
        case "WARN" /* WARN */:
          levelColor = this._rgbaWarn;
          break;
        case "ERROR" /* ERROR */:
          levelColor = this._rgbaError;
          break;
        case "DEBUG" /* DEBUG */:
          levelColor = this._rgbaDebug;
          break;
      }
      const showCursor = this.isFocused && lineY - 1 === this.currentLineIndex;
      if (showCursor) {
        this.frameBuffer.drawText(">", 0, lineY, this._rgbaCursor, this.backgroundColor);
      } else {
        this.frameBuffer.drawText(" ", 0, lineY, this._rgbaDefault, this.backgroundColor);
      }
      const fullText = (displayLine.indent ? " ".repeat(INDENT_WIDTH) : "") + displayLine.text;
      const selectionRange = this.getLineSelectionRange(absoluteLineIndex);
      if (selectionRange) {
        const adjustedStart = Math.max(0, selectionRange.start);
        const adjustedEnd = Math.min(fullText.length, selectionRange.end);
        if (adjustedStart > 0) {
          this.frameBuffer.drawText(fullText.substring(0, adjustedStart), 1, lineY, levelColor);
        }
        if (adjustedStart < adjustedEnd) {
          this.frameBuffer.fillRect(1 + adjustedStart, lineY, adjustedEnd - adjustedStart, 1, this._rgbaSelection);
          this.frameBuffer.drawText(fullText.substring(adjustedStart, adjustedEnd), 1 + adjustedStart, lineY, levelColor, this._rgbaSelection);
        }
        if (adjustedEnd < fullText.length) {
          this.frameBuffer.drawText(fullText.substring(adjustedEnd), 1 + adjustedEnd, lineY, levelColor);
        }
      } else {
        this.frameBuffer.drawText(fullText, 1, lineY, levelColor);
      }
      lineY++;
    }
  }
  renderToBuffer(buffer) {
    if (!this.isVisible || !this.frameBuffer)
      return;
    if (this._needsFrameBufferUpdate) {
      this.updateFrameBuffer();
      this._needsFrameBufferUpdate = false;
    }
    buffer.drawFrameBuffer(this.consoleX, this.consoleY, this.frameBuffer);
  }
  setDebugMode(enabled) {
    this._debugModeEnabled = enabled;
    terminalConsoleCache.setCollectCallerInfo(enabled);
    if (this.isVisible) {
      this.markNeedsRerender();
    }
  }
  toggleDebugMode() {
    this.setDebugMode(!this._debugModeEnabled);
  }
  set keyBindings(bindings) {
    this._keyBindings = bindings;
    this._mergedKeyBindings = mergeKeyBindings(defaultConsoleKeybindings, bindings);
    this._keyBindingsMap = buildKeyBindingsMap(this._mergedKeyBindings, this._keyAliasMap);
    this.markNeedsRerender();
  }
  set keyAliasMap(aliases) {
    this._keyAliasMap = mergeKeyAliases(defaultKeyAliases, aliases);
    this._mergedKeyBindings = mergeKeyBindings(defaultConsoleKeybindings, this._keyBindings);
    this._keyBindingsMap = buildKeyBindingsMap(this._mergedKeyBindings, this._keyAliasMap);
    this.markNeedsRerender();
  }
  set onCopySelection(callback) {
    this.options.onCopySelection = callback;
  }
  get onCopySelection() {
    return this.options.onCopySelection;
  }
  _scrollToBottom(forceCursorToLastLine = false) {
    const displayLineCount = this._displayLines.length;
    const logAreaHeight = Math.max(1, this.consoleHeight - 1);
    const maxScrollTop = Math.max(0, displayLineCount - logAreaHeight);
    this.scrollTopIndex = maxScrollTop;
    this.isScrolledToBottom = true;
    const visibleLineCount = Math.min(logAreaHeight, displayLineCount - this.scrollTopIndex);
    if (forceCursorToLastLine || this.currentLineIndex >= visibleLineCount) {
      this.currentLineIndex = Math.max(0, visibleLineCount - 1);
    }
  }
  _processLogEntry(logEntry) {
    const [date, level, args, callerInfo] = logEntry;
    const displayLines = [];
    const timestamp = this.formatTimestamp(date);
    const callerSource = callerInfo ? `${callerInfo.fileName}:${callerInfo.lineNumber}` : "unknown";
    const prefix = `[${timestamp}] [${level}]` + (this._debugModeEnabled ? ` [${callerSource}]` : "") + " ";
    const formattedArgs = this.formatArguments(args);
    const initialLines = formattedArgs.split(`
`);
    const cells = Math.max(1, this.consoleWidth - 1);
    const indentedCells = Math.max(1, this.consoleWidth - 1 - INDENT_WIDTH);
    for (let i = 0;i < initialLines.length; i++) {
      const isFirstLineOfEntry = i === 0;
      const segments = isFirstLineOfEntry ? wrapDisplayCells(prefix + initialLines[i], cells, indentedCells) : wrapDisplayCells(initialLines[i], indentedCells, indentedCells);
      for (let segment = 0;segment < segments.length; segment++) {
        displayLines.push({ text: segments[segment], level, indent: !isFirstLineOfEntry || segment > 0 });
      }
    }
    return displayLines;
  }
  _processCachedLogs() {
    const logsToProcess = [...terminalConsoleCache.cachedLogs];
    terminalConsoleCache.clearConsole();
    this._allLogEntries.push(...logsToProcess);
    if (this._allLogEntries.length > this.options.maxStoredLogs) {
      this._allLogEntries.splice(0, this._allLogEntries.length - this.options.maxStoredLogs);
    }
    for (const logEntry of logsToProcess) {
      const processed = this._processLogEntry(logEntry);
      this._displayLines.push(...processed);
    }
    if (this._displayLines.length > this.options.maxDisplayLines) {
      this._displayLines.splice(0, this._displayLines.length - this.options.maxDisplayLines);
    }
  }
  hasSelection() {
    if (this._selectionStart === null || this._selectionEnd === null)
      return false;
    return this._selectionStart.line !== this._selectionEnd.line || this._selectionStart.col !== this._selectionEnd.col;
  }
  normalizeSelection() {
    if (!this._selectionStart || !this._selectionEnd)
      return null;
    const start = this._selectionStart;
    const end = this._selectionEnd;
    const startBeforeEnd = start.line < end.line || start.line === end.line && start.col <= end.col;
    if (startBeforeEnd) {
      return {
        startLine: start.line,
        startCol: start.col,
        endLine: end.line,
        endCol: end.col
      };
    } else {
      return {
        startLine: end.line,
        startCol: end.col,
        endLine: start.line,
        endCol: start.col
      };
    }
  }
  getSelectedText() {
    const selection = this.normalizeSelection();
    if (!selection)
      return "";
    const lines = [];
    for (let i = selection.startLine;i <= selection.endLine; i++) {
      if (i < 0 || i >= this._displayLines.length)
        continue;
      const line = this._displayLines[i];
      const fullText = (line.indent ? " ".repeat(INDENT_WIDTH) : "") + line.text;
      let text = fullText;
      if (i === selection.startLine && i === selection.endLine) {
        text = fullText.substring(selection.startCol, selection.endCol);
      } else if (i === selection.startLine) {
        text = fullText.substring(selection.startCol);
      } else if (i === selection.endLine) {
        text = fullText.substring(0, selection.endCol);
      }
      lines.push(text);
    }
    return lines.join(`
`);
  }
  clearSelection() {
    this._selectionStart = null;
    this._selectionEnd = null;
    this._isDragging = false;
    this.stopAutoScroll();
  }
  stopAutoScroll() {
    if (this._autoScrollInterval !== null) {
      this.clock.clearInterval(this._autoScrollInterval);
      this._autoScrollInterval = null;
    }
  }
  startAutoScroll(direction) {
    this.stopAutoScroll();
    this._autoScrollInterval = this.clock.setInterval(() => {
      if (direction === "up") {
        if (this.scrollTopIndex > 0) {
          this.scrollTopIndex--;
          this.isScrolledToBottom = false;
          if (this._selectionEnd) {
            this._selectionEnd = {
              line: this.scrollTopIndex,
              col: this._selectionEnd.col
            };
          }
          this.markNeedsRerender();
        } else {
          this.stopAutoScroll();
        }
      } else {
        const displayLineCount = this._displayLines.length;
        const logAreaHeight = Math.max(1, this.consoleHeight - 1);
        const maxScrollTop = Math.max(0, displayLineCount - logAreaHeight);
        if (this.scrollTopIndex < maxScrollTop) {
          this.scrollTopIndex++;
          this.isScrolledToBottom = this.scrollTopIndex === maxScrollTop;
          if (this._selectionEnd) {
            const maxLine = this.scrollTopIndex + logAreaHeight - 1;
            this._selectionEnd = {
              line: Math.min(maxLine, displayLineCount - 1),
              col: this._selectionEnd.col
            };
          }
          this.markNeedsRerender();
        } else {
          this.stopAutoScroll();
        }
      }
    }, 50);
  }
  triggerCopy() {
    if (!this.hasSelection())
      return;
    const text = this.getSelectedText();
    if (text && this.options.onCopySelection) {
      try {
        this.options.onCopySelection(text);
      } catch {}
      this.clearSelection();
      this.markNeedsRerender();
    }
  }
  getLineSelectionRange(lineIndex) {
    const selection = this.normalizeSelection();
    if (!selection)
      return null;
    if (lineIndex < selection.startLine || lineIndex > selection.endLine) {
      return null;
    }
    const line = this._displayLines[lineIndex];
    if (!line)
      return null;
    const fullTextLength = (line.indent ? INDENT_WIDTH : 0) + line.text.length;
    let start = 0;
    let end = fullTextLength;
    if (lineIndex === selection.startLine) {
      start = Math.max(0, selection.startCol);
    }
    if (lineIndex === selection.endLine) {
      end = Math.min(fullTextLength, selection.endCol);
    }
    if (start >= end)
      return null;
    return { start, end };
  }
  handleMouse(event) {
    if (!this.isVisible)
      return false;
    const localX = event.x - this.consoleX;
    const localY = event.y - this.consoleY;
    if (localX < 0 || localX >= this.consoleWidth || localY < 0 || localY >= this.consoleHeight) {
      return false;
    }
    if (event.type === "scroll" && event.scroll) {
      if (event.scroll.direction === "up") {
        this.scrollUp();
      } else if (event.scroll.direction === "down") {
        this.scrollDown();
      }
      return true;
    }
    if (localY === 0) {
      if (event.type === "down" && event.button === 0 && localX >= this._copyButtonBounds.x && localX < this._copyButtonBounds.x + this._copyButtonBounds.width) {
        this.triggerCopy();
        return true;
      }
      return true;
    }
    const lineIndex = this.scrollTopIndex + (localY - 1);
    const colIndex = Math.max(0, localX - 1);
    if (event.type === "down" && event.button === 0) {
      this.clearSelection();
      this._selectionStart = { line: lineIndex, col: colIndex };
      this._selectionEnd = { line: lineIndex, col: colIndex };
      this._isDragging = true;
      this.markNeedsRerender();
      return true;
    }
    if (event.type === "drag" && this._isDragging) {
      this._selectionEnd = { line: lineIndex, col: colIndex };
      const logAreaHeight = Math.max(1, this.consoleHeight - 1);
      const relativeY = localY - 1;
      if (relativeY <= 0) {
        this.startAutoScroll("up");
      } else if (relativeY >= logAreaHeight - 1) {
        this.startAutoScroll("down");
      } else {
        this.stopAutoScroll();
      }
      this.markNeedsRerender();
      return true;
    }
    if (event.type === "up") {
      if (this._isDragging) {
        this._selectionEnd = { line: lineIndex, col: colIndex };
        this._isDragging = false;
        this.stopAutoScroll();
        this.markNeedsRerender();
      }
      return true;
    }
    return true;
  }
  get visible() {
    return this.isVisible;
  }
  get bounds() {
    return {
      x: this.consoleX,
      y: this.consoleY,
      width: this.consoleWidth,
      height: this.consoleHeight
    };
  }
  saveLogsToFile() {
    try {
      const timestamp = Date.now();
      const filename = `_console_${timestamp}.log`;
      const filepath = path3.join(process.cwd(), filename);
      const allLogEntries = [...this._allLogEntries, ...terminalConsoleCache.cachedLogs];
      const logLines = [];
      for (const [date, level, args, callerInfo] of allLogEntries) {
        const timestampStr = this.formatTimestamp(date);
        const callerSource = callerInfo ? `${callerInfo.fileName}:${callerInfo.lineNumber}` : "unknown";
        const prefix = `[${timestampStr}] [${level}]` + (this._debugModeEnabled ? ` [${callerSource}]` : "") + " ";
        const formattedArgs = this.formatArguments(args);
        logLines.push(prefix + formattedArgs);
      }
      const content = logLines.join(`
`);
      fs.writeFileSync(filepath, content, "utf8");
      console.info(`Console logs saved to: ${filename}`);
    } catch (error) {
      console.error(`Failed to save console logs:`, error);
    }
  }
}

// src/renderer.ts
import { EventEmitter as EventEmitter8 } from "events";

// src/lib/objects-in-viewport.ts
function getObjectsInViewport(viewport, objects, direction = "column", padding = 10, minTriggerSize = 16) {
  if (viewport.width <= 0 || viewport.height <= 0) {
    return [];
  }
  if (objects.length === 0) {
    return [];
  }
  if (objects.length < minTriggerSize) {
    return objects;
  }
  const viewportTop = viewport.y - padding;
  const viewportBottom = viewport.y + viewport.height + padding;
  const viewportLeft = viewport.x - padding;
  const viewportRight = viewport.x + viewport.width + padding;
  const isRow = direction === "row";
  const children = objects;
  const totalChildren = children.length;
  if (totalChildren === 0)
    return [];
  const vpStart = isRow ? viewportLeft : viewportTop;
  const vpEnd = isRow ? viewportRight : viewportBottom;
  let lo = 0;
  let hi = totalChildren - 1;
  let candidate = -1;
  while (lo <= hi) {
    const mid = lo + hi >> 1;
    const c = children[mid];
    const start = isRow ? c.screenX : c.screenY;
    const end = isRow ? c.screenX + c.width : c.screenY + c.height;
    if (end < vpStart) {
      lo = mid + 1;
    } else if (start > vpEnd) {
      hi = mid - 1;
    } else {
      candidate = mid;
      break;
    }
  }
  const visibleChildren = [];
  if (candidate === -1) {
    candidate = lo > 0 ? lo - 1 : 0;
  }
  const maxLookBehind = 50;
  let left = candidate;
  let gapCount = 0;
  while (left - 1 >= 0) {
    const prev = children[left - 1];
    const prevEnd = isRow ? prev.screenX + prev.width : prev.screenY + prev.height;
    if (prevEnd <= vpStart) {
      gapCount++;
      if (gapCount >= maxLookBehind) {
        break;
      }
    } else {
      gapCount = 0;
    }
    left--;
  }
  let right = candidate + 1;
  while (right < totalChildren) {
    const next = children[right];
    if ((isRow ? next.screenX : next.screenY) >= vpEnd)
      break;
    right++;
  }
  for (let i = left;i < right; i++) {
    const child = children[i];
    const start = isRow ? child.screenX : child.screenY;
    const end = isRow ? child.screenX + child.width : child.screenY + child.height;
    if (end <= vpStart)
      continue;
    if (start >= vpEnd)
      break;
    if (isRow) {
      const childBottom = child.screenY + child.height;
      if (childBottom < viewportTop)
        continue;
      const childTop = child.screenY;
      if (childTop > viewportBottom)
        continue;
    } else {
      const childRight = child.screenX + child.width;
      if (childRight < viewportLeft)
        continue;
      const childLeft = child.screenX;
      if (childLeft > viewportRight)
        continue;
    }
    visibleChildren.push(child);
  }
  if (visibleChildren.length > 1) {
    visibleChildren.sort((a, b) => a.zIndex > b.zIndex ? 1 : a.zIndex < b.zIndex ? -1 : 0);
  }
  return visibleChildren;
}

// src/renderables/EditBufferRenderable.ts
var BrandedEditBufferRenderable = Symbol.for("@opentui/core/EditBufferRenderable");
var emptyVisualCursor = Object.freeze({
  visualRow: 0,
  visualCol: 0,
  logicalRow: 0,
  logicalCol: 0,
  offset: 0
});
var EditBufferRenderableEvents2;
((EditBufferRenderableEvents) => {
  EditBufferRenderableEvents["TRAITS_CHANGED"] = "traits-changed";
})(EditBufferRenderableEvents2 ||= {});
function sameCapture(a, b) {
  if (a === b)
    return true;
  if (!a || !b)
    return !a && !b;
  if (a.length !== b.length)
    return false;
  return a.every((item, i) => item === b[i]);
}
function sameTraits(a, b) {
  return a.suspend === b.suspend && a.status === b.status && sameCapture(a.capture, b.capture);
}
function isEditBufferRenderable2(obj) {
  return !!(obj && typeof obj === "object" && (BrandedEditBufferRenderable in obj));
}

class EditBufferRenderable2 extends Renderable2 {
  static nativeIntegration = this.defineNativeIntegration({
    kind: "editor",
    body: { native: this.prototype.renderSelf },
    lifecycle: {
      resize: { native: this.prototype.onResize },
      update: {
        idle: this.prototype.onUpdate,
        active: (renderable) => renderable._needsAutoScrollUpdate
      }
    },
    beforeAfter: false,
    paintBuffer: "destination",
    bufferComposition: "native",
    construction: "prototype"
  });
  [BrandedEditBufferRenderable] = true;
  static defaultFocusable = true;
  _traits = {};
  _textColor;
  _backgroundColor;
  _defaultAttributes;
  _selectionBg;
  _selectionFg;
  _wrapMode = "word";
  _scrollMargin = 0.2;
  _showCursor = true;
  _cursorColor;
  _cursorStyle;
  lastLocalSelection = null;
  _tabIndicator;
  _tabIndicatorColor;
  _cursorChangeListener = undefined;
  _contentChangeListener = undefined;
  _autoScrollVelocity = 0;
  _autoScrollAccumulator = 0;
  _scrollSpeed = 16;
  _keyboardSelectionActive = false;
  editBuffer;
  editorView;
  _defaultOptions = {
    textColor: RGBA2.fromValues(1, 1, 1, 1),
    backgroundColor: "transparent",
    selectionBg: undefined,
    selectionFg: undefined,
    selectable: true,
    attributes: 0,
    wrapMode: "word",
    scrollMargin: 0.2,
    scrollSpeed: 16,
    showCursor: true,
    cursorColor: RGBA2.fromValues(1, 1, 1, 1),
    cursorStyle: {
      style: "block",
      blinking: true
    },
    tabIndicator: undefined,
    tabIndicatorColor: undefined
  };
  constructor(ctx, options) {
    super(ctx, options);
    let editBuffer;
    let editorView;
    try {
      this._textColor = RGBA2.clone(parseColor2(options.textColor ?? this._defaultOptions.textColor));
      this._backgroundColor = RGBA2.clone(parseColor2(options.backgroundColor ?? this._defaultOptions.backgroundColor));
      this._defaultAttributes = options.attributes ?? this._defaultOptions.attributes;
      this._selectionBg = options.selectionBg ? RGBA2.clone(parseColor2(options.selectionBg)) : undefined;
      this._selectionFg = options.selectionFg ? RGBA2.clone(parseColor2(options.selectionFg)) : undefined;
      this.selectable = options.selectable ?? this._defaultOptions.selectable;
      this._wrapMode = options.wrapMode ?? this._defaultOptions.wrapMode;
      this._scrollMargin = options.scrollMargin ?? this._defaultOptions.scrollMargin;
      this._scrollSpeed = options.scrollSpeed ?? this._defaultOptions.scrollSpeed;
      this._showCursor = options.showCursor ?? this._defaultOptions.showCursor;
      this._cursorColor = RGBA2.clone(parseColor2(options.cursorColor ?? this._defaultOptions.cursorColor));
      this._cursorStyle = { ...options.cursorStyle ?? this._defaultOptions.cursorStyle };
      if (this._cursorStyle.color)
        this._cursorStyle.color = RGBA2.clone(this._cursorStyle.color);
      this._tabIndicator = options.tabIndicator ?? this._defaultOptions.tabIndicator;
      this._tabIndicatorColor = options.tabIndicatorColor ? RGBA2.clone(parseColor2(options.tabIndicatorColor)) : this._defaultOptions.tabIndicatorColor;
      editBuffer = EditBuffer2.create(this._ctx.widthMethod, this._ctx.nativeScene);
      this.editBuffer = editBuffer;
      editorView = EditorView2.create(editBuffer, Math.max(1, Math.trunc(this.width || 80)), Math.max(1, Math.trunc(this.height || 24)));
      this.editorView = editorView;
      this.editorView.setWrapMode(this._wrapMode);
      this.editorView.setScrollMargin(this._scrollMargin);
      if (options.selectionOccupancy === "boundary") {
        this.editorView.setSelectionOccupancy("boundary");
      }
      this.editBuffer.setDefaultFg(this._textColor);
      this.editBuffer.setDefaultBg(this._backgroundColor);
      this.editBuffer.setDefaultAttributes(this._defaultAttributes);
      if (options.syntaxStyle) {
        this.editBuffer.setSyntaxStyle(options.syntaxStyle);
      }
      if (this._tabIndicator !== undefined) {
        this.editorView.setTabIndicator(this._tabIndicator);
      }
      if (this._tabIndicatorColor !== undefined) {
        this.editorView.setTabIndicatorColor(this._tabIndicatorColor);
      }
      this._ctx.nativeScene.setEditorView(this, this.editorView._getSceneHandle(this._ctx.nativeScene));
      this.setNativeEditorOptions();
      this.setupEventListeners(options);
    } catch (error) {
      this.abortConstruction(error, (run) => {
        run(() => editorView?.destroy());
        run(() => editBuffer?.destroy());
      });
    }
  }
  get lineInfo() {
    return this.editorView.getLogicalLineInfo();
  }
  setupEventListeners(options) {
    this._cursorChangeListener = options.onCursorChange;
    this._contentChangeListener = options.onContentChange;
    this.editBuffer.on("cursor-changed", () => {
      if (this._cursorChangeListener) {
        const cursor = this.editBuffer.getCursorPosition();
        this._cursorChangeListener({
          line: cursor.row,
          visualColumn: cursor.col
        });
      }
    });
    this.editBuffer.on("content-changed", () => {
      this.requestRender();
      this.emit("line-info-change");
      if (this._contentChangeListener) {
        this._contentChangeListener({});
      }
    });
  }
  get lineCount() {
    return this.editBuffer.getLineCount();
  }
  get virtualLineCount() {
    return this.editorView.getVirtualLineCount();
  }
  get scrollY() {
    return this.editorView.getViewport().offsetY;
  }
  get plainText() {
    return this.editBuffer.getText();
  }
  get logicalCursor() {
    return this.editBuffer.getCursorPosition();
  }
  get visualCursor() {
    if (this.editorView.isDestroyed)
      return emptyVisualCursor;
    return this.editorView.getVisualCursor();
  }
  get cursorOffset() {
    return this.visualCursor.offset;
  }
  set cursorOffset(offset) {
    this.clearSelection();
    this.editorView.setCursorByOffset(offset ?? 0);
    this.requestRender();
  }
  get cursorCharacterOffset() {
    const len = this.plainText.length;
    if (len <= 0)
      return;
    const cursor = this.logicalCursor;
    const offset = this.cursorOffset;
    if (offset >= len) {
      if (cursor.col > 0)
        return len - 1;
      return 0;
    }
    if (this.plainText[offset] === `
` && cursor.col > 0) {
      return offset - 1;
    }
    return offset;
  }
  get textColor() {
    return RGBA2.clone(this._textColor);
  }
  set textColor(value) {
    const newColor = RGBA2.clone(parseColor2(value ?? this._defaultOptions.textColor));
    this.editBuffer.setDefaultFg(newColor);
    this._textColor = newColor;
    this.requestRender();
  }
  get selectionBg() {
    return this._selectionBg ? RGBA2.clone(this._selectionBg) : undefined;
  }
  get traits() {
    return this._traits;
  }
  set traits(value) {
    if (sameTraits(this._traits, value))
      return;
    const prev = this._traits;
    this._traits = value;
    this.emit("traits-changed" /* TRAITS_CHANGED */, value, prev);
  }
  set selectionBg(value) {
    const newColor = value ? RGBA2.clone(parseColor2(value)) : undefined;
    if (this._selectionBg !== newColor) {
      this.editorView.setSelectionColors(newColor, this._selectionFg);
      this._selectionBg = newColor;
      this.requestRender();
    }
  }
  get selectionFg() {
    return this._selectionFg ? RGBA2.clone(this._selectionFg) : undefined;
  }
  set selectionFg(value) {
    const newColor = value ? RGBA2.clone(parseColor2(value)) : undefined;
    if (this._selectionFg !== newColor) {
      this.editorView.setSelectionColors(this._selectionBg, newColor);
      this._selectionFg = newColor;
      this.requestRender();
    }
  }
  get backgroundColor() {
    return RGBA2.clone(this._backgroundColor);
  }
  set backgroundColor(value) {
    const newColor = RGBA2.clone(parseColor2(value ?? this._defaultOptions.backgroundColor));
    this.editBuffer.setDefaultBg(newColor);
    this._backgroundColor = newColor;
    this.requestRender();
  }
  get attributes() {
    return this._defaultAttributes;
  }
  set attributes(value) {
    const attributes = value ?? this._defaultOptions.attributes;
    if (this._defaultAttributes !== attributes) {
      this.runMutation(() => {
        this.editBuffer.setDefaultAttributes(attributes);
        this._defaultAttributes = attributes;
        this.requestRender();
      });
    }
  }
  get wrapMode() {
    return this._wrapMode;
  }
  set wrapMode(value) {
    if (this._wrapMode !== value) {
      this.runMutation(() => {
        this.editorView.setWrapMode(value);
        this._wrapMode = value;
        this.requestRender();
      });
    }
  }
  get showCursor() {
    return this._showCursor;
  }
  set showCursor(value) {
    value ??= this._defaultOptions.showCursor;
    if (this._showCursor !== value) {
      this.setNativeEditorOptions({ showCursor: value });
      this._showCursor = value;
      this.requestRender();
    }
  }
  get cursorColor() {
    return RGBA2.clone(this._cursorColor);
  }
  set cursorColor(value) {
    const newColor = RGBA2.clone(parseColor2(value ?? this._defaultOptions.cursorColor));
    this.setNativeEditorOptions({ color: newColor });
    this._cursorColor = newColor;
    if (this._focused) {
      this.requestRender();
    }
  }
  get cursorStyle() {
    return { ...this._cursorStyle, color: this._cursorStyle.color ? RGBA2.clone(this._cursorStyle.color) : undefined };
  }
  set cursorStyle(style) {
    const newStyle = { ...style, color: style.color ? RGBA2.clone(style.color) : undefined };
    if (this._cursorStyle.style !== newStyle.style || this._cursorStyle.blinking !== newStyle.blinking || this._cursorStyle.cursor !== newStyle.cursor) {
      this.setNativeEditorOptions({
        style: newStyle.style ?? "block",
        blinking: newStyle.blinking ?? true,
        cursor: newStyle.cursor
      });
      this._cursorStyle = newStyle;
      if (this._focused) {
        this.requestRender();
      }
    }
  }
  get selectionOccupancy() {
    return this.editorView.getSelectionOccupancy();
  }
  set selectionOccupancy(value) {
    const occupancy = value ?? "cell";
    if (this.selectionOccupancy === occupancy)
      return;
    this.editorView.setSelectionOccupancy(occupancy);
    this.requestRender();
  }
  get tabIndicator() {
    return this._tabIndicator;
  }
  set tabIndicator(value) {
    value ??= this._defaultOptions.tabIndicator;
    if (this._tabIndicator !== value) {
      this._tabIndicator = value;
      if (value !== undefined) {
        this.editorView.setTabIndicator(value);
      }
      this.requestRender();
    }
  }
  get tabIndicatorColor() {
    return this._tabIndicatorColor ? RGBA2.clone(this._tabIndicatorColor) : undefined;
  }
  set tabIndicatorColor(value) {
    const newColor = value ? RGBA2.clone(parseColor2(value)) : undefined;
    if (this._tabIndicatorColor !== newColor) {
      if (newColor !== undefined) {
        this.editorView.setTabIndicatorColor(newColor);
      }
      this._tabIndicatorColor = newColor;
      this.requestRender();
    }
  }
  get scrollSpeed() {
    return this._scrollSpeed;
  }
  set scrollSpeed(value) {
    this._scrollSpeed = Math.max(0, value);
  }
  onMouseEvent(event) {
    if (event.type === "scroll") {
      this.handleScroll(event);
    }
  }
  handleScroll(event) {
    if (!event.scroll)
      return;
    const { direction, delta } = event.scroll;
    const viewport = this.editorView.getViewport();
    if (direction === "up") {
      const newOffsetY = Math.max(0, viewport.offsetY - delta);
      this.editorView.setViewport(viewport.offsetX, newOffsetY, viewport.width, viewport.height, true);
      this.requestRender();
    } else if (direction === "down") {
      const totalVirtualLines = this.editorView.getTotalVirtualLineCount();
      const maxOffsetY = Math.max(0, totalVirtualLines - viewport.height);
      const newOffsetY = Math.min(viewport.offsetY + delta, maxOffsetY);
      this.editorView.setViewport(viewport.offsetX, newOffsetY, viewport.width, viewport.height, true);
      this.requestRender();
    }
    if (this._wrapMode === "none") {
      if (direction === "left") {
        const newOffsetX = Math.max(0, viewport.offsetX - delta);
        this.editorView.setViewport(newOffsetX, viewport.offsetY, viewport.width, viewport.height, true);
        this.requestRender();
      } else if (direction === "right") {
        const newOffsetX = viewport.offsetX + delta;
        this.editorView.setViewport(newOffsetX, viewport.offsetY, viewport.width, viewport.height, true);
        this.requestRender();
      }
    }
  }
  onResize(width, height) {
    this.editorView.setViewportSize(width, height);
  }
  refreshLocalSelection() {
    if (this.lastLocalSelection) {
      return this.updateLocalSelection(this.lastLocalSelection);
    }
    return false;
  }
  updateLocalSelection(localSelection) {
    if (!localSelection?.isActive) {
      this.editorView.resetLocalSelection();
      return true;
    }
    return this.editorView.setLocalSelection(localSelection.anchorX, localSelection.anchorY, localSelection.focusX, localSelection.focusY, this._selectionBg, this._selectionFg, false, false, localSelection.behavior);
  }
  shouldStartSelection(x, y) {
    if (!this.selectable)
      return false;
    const localX = x - this.x;
    const localY = y - this.y;
    return localX >= 0 && localX < this.width && localY >= 0 && localY < this.height;
  }
  onSelectionChanged(selection) {
    const localSelection = convertGlobalToLocalSelection2(selection, Math.trunc(this.x), Math.trunc(this.y));
    this.lastLocalSelection = localSelection;
    const updateCursor = true;
    const followCursor = this._keyboardSelectionActive;
    let changed;
    if (!localSelection?.isActive) {
      this._keyboardSelectionActive = false;
      this.editorView.resetLocalSelection();
      changed = true;
    } else if (selection?.isStart) {
      changed = this.editorView.setLocalSelection(localSelection.anchorX, localSelection.anchorY, localSelection.focusX, localSelection.focusY, this._selectionBg, this._selectionFg, updateCursor, followCursor, localSelection.behavior);
    } else {
      changed = this.editorView.updateLocalSelection(localSelection.anchorX, localSelection.anchorY, localSelection.focusX, localSelection.focusY, this._selectionBg, this._selectionFg, updateCursor, followCursor, localSelection.behavior);
    }
    const previousVelocity = this._autoScrollVelocity;
    const previousAccumulator = this._autoScrollAccumulator;
    if (changed && localSelection?.isActive && selection?.isDragging) {
      const viewport = this.editorView.getViewport();
      const focusY = localSelection.focusY;
      const scrollMargin = Math.max(1, Math.floor(viewport.height * this._scrollMargin));
      if (focusY < scrollMargin) {
        this._autoScrollVelocity = -this._scrollSpeed;
      } else if (focusY >= viewport.height - scrollMargin) {
        this._autoScrollVelocity = this._scrollSpeed;
      } else {
        this._autoScrollVelocity = 0;
      }
    } else {
      this._keyboardSelectionActive = false;
      this._autoScrollVelocity = 0;
      this._autoScrollAccumulator = 0;
    }
    if (previousVelocity !== 0 !== this._needsAutoScrollUpdate) {
      const generation = this._nativeSceneHookGeneration;
      try {
        this.refreshNativeSceneHooks();
      } catch (error) {
        if (generation === this._nativeSceneHookGeneration) {
          this._autoScrollVelocity = previousVelocity;
          this._autoScrollAccumulator = previousAccumulator;
        }
        throw error;
      }
    }
    if (changed) {
      this.requestRender();
    }
    return this.hasSelection();
  }
  get _needsAutoScrollUpdate() {
    return (this._autoScrollVelocity ?? 0) !== 0;
  }
  onUpdate(deltaTime) {
    super.onUpdate(deltaTime);
    if (this._autoScrollVelocity !== 0 && this.hasSelection()) {
      const deltaSeconds = deltaTime / 1000;
      this._autoScrollAccumulator += this._autoScrollVelocity * deltaSeconds;
      const linesToScroll = Math.floor(Math.abs(this._autoScrollAccumulator));
      if (linesToScroll > 0) {
        const direction = this._autoScrollVelocity > 0 ? 1 : -1;
        const viewport = this.editorView.getViewport();
        const totalVirtualLines = this.editorView.getTotalVirtualLineCount();
        const maxOffsetY = Math.max(0, totalVirtualLines - viewport.height);
        const newOffsetY = Math.max(0, Math.min(viewport.offsetY + direction * linesToScroll, maxOffsetY));
        if (newOffsetY !== viewport.offsetY) {
          this.editorView.setViewport(viewport.offsetX, newOffsetY, viewport.width, viewport.height, false);
          this._ctx.requestSelectionUpdate();
        }
        this._autoScrollAccumulator -= direction * linesToScroll;
      }
    }
  }
  getSelectedText() {
    return this.editorView.getSelectedText();
  }
  hasSelection() {
    return this.editorView.hasSelection();
  }
  getSelection() {
    return this.editorView.getSelection();
  }
  deleteSelectedText() {
    this.editorView.deleteSelectedText();
    this._ctx.clearSelection();
    this.requestRender();
  }
  setSelection(start, end) {
    this.lastLocalSelection = null;
    this.editorView.resetLocalSelection();
    this._ctx.clearSelection();
    this.editorView.setSelection(start, end, this._selectionBg, this._selectionFg);
    this.requestRender();
  }
  setSelectionInclusive(start, end) {
    this.lastLocalSelection = null;
    this.editorView.resetLocalSelection();
    this._ctx.clearSelection();
    this.editorView.setSelectionInclusive(start, end, this._selectionBg, this._selectionFg);
    this.requestRender();
  }
  clearSelection() {
    const had = this.hasSelection();
    this.lastLocalSelection = null;
    this.editorView.resetLocalSelection();
    this._ctx.clearSelection();
    if (had) {
      this.requestRender();
    }
    return had;
  }
  deleteSelection() {
    if (!this.hasSelection())
      return false;
    this.lastLocalSelection = null;
    this.deleteSelectedText();
    return true;
  }
  setCursor(row, col) {
    this.clearSelection();
    this.editBuffer.setCursor(row, col);
    this.requestRender();
  }
  insertChar(char) {
    this.insertOrReplaceSelection(char, () => this.editBuffer.insertChar(char));
  }
  insertText(text) {
    this.insertOrReplaceSelection(text, () => this.editBuffer.insertText(text));
  }
  insertOrReplaceSelection(text, insert) {
    const hasSelection = this.hasSelection();
    this.editBuffer.runMutation(() => {
      if (hasSelection) {
        this.editorView._replaceSelectedText(text);
        this._ctx.clearSelection();
      } else {
        insert();
      }
      this.requestRender();
    });
  }
  deleteChar() {
    if (this.hasSelection()) {
      this.deleteSelectedText();
      return true;
    }
    this._ctx.clearSelection();
    this.editBuffer.deleteChar();
    this.requestRender();
    return true;
  }
  deleteCharBackward() {
    if (this.hasSelection()) {
      this.deleteSelectedText();
      return true;
    }
    this._ctx.clearSelection();
    this.editBuffer.deleteCharBackward();
    this.requestRender();
    return true;
  }
  newLine() {
    this._ctx.clearSelection();
    this.editBuffer.newLine();
    this.requestRender();
    return true;
  }
  deleteLine() {
    this._ctx.clearSelection();
    this.editBuffer.deleteLine();
    this.requestRender();
    return true;
  }
  collapseSelectionToEdge(edge) {
    const selection = this.getSelection();
    if (!selection)
      return false;
    this.editBuffer.setCursorByOffset(edge === "start" ? selection.start : selection.end);
    this.clearSelection();
    return true;
  }
  moveCursorLeft(options) {
    const select = options?.select ?? false;
    if (!select && this.collapseSelectionToEdge("start"))
      return true;
    this.updateSelectionForMovement(select, true);
    this.editBuffer.moveCursorLeft();
    this.updateSelectionForMovement(select, false);
    this.requestRender();
    return true;
  }
  moveCursorRight(options) {
    const select = options?.select ?? false;
    if (!select && this.collapseSelectionToEdge("end"))
      return true;
    this.updateSelectionForMovement(select, true);
    this.editBuffer.moveCursorRight();
    this.updateSelectionForMovement(select, false);
    this.requestRender();
    return true;
  }
  moveCursorUp(options) {
    const select = options?.select ?? false;
    this.updateSelectionForMovement(select, true);
    this.editorView.moveUpVisual();
    this.updateSelectionForMovement(select, false);
    this.requestRender();
    return true;
  }
  moveCursorDown(options) {
    const select = options?.select ?? false;
    this.updateSelectionForMovement(select, true);
    this.editorView.moveDownVisual();
    this.updateSelectionForMovement(select, false);
    this.requestRender();
    return true;
  }
  gotoLine(line) {
    this.clearSelection();
    this.editBuffer.gotoLine(line);
    this.requestRender();
  }
  gotoLineStart() {
    this.setCursor(this.logicalCursor.row, 0);
  }
  gotoLineTextEnd() {
    const eol = this.editBuffer.getEOL();
    this.setCursor(eol.row, eol.col);
  }
  gotoLineHome(options) {
    const select = options?.select ?? false;
    if (!select && this.collapseSelectionToEdge("start"))
      return true;
    this.updateSelectionForMovement(select, true);
    const cursor = this.editorView.getCursor();
    if (cursor.col === 0 && cursor.row > 0) {
      this.editBuffer.setCursor(cursor.row - 1, 0);
      const prevLineEol = this.editBuffer.getEOL();
      this.editBuffer.setCursor(prevLineEol.row, prevLineEol.col);
    } else {
      this.editBuffer.setCursor(cursor.row, 0);
    }
    this.updateSelectionForMovement(select, false);
    this.requestRender();
    return true;
  }
  gotoLineEnd(options) {
    const select = options?.select ?? false;
    if (!select && this.collapseSelectionToEdge("end"))
      return true;
    this.updateSelectionForMovement(select, true);
    const cursor = this.editorView.getCursor();
    const eol = this.editBuffer.getEOL();
    const lineCount = this.editBuffer.getLineCount();
    if (cursor.col === eol.col && cursor.row < lineCount - 1) {
      this.editBuffer.setCursor(cursor.row + 1, 0);
    } else {
      this.editBuffer.setCursor(eol.row, eol.col);
    }
    this.updateSelectionForMovement(select, false);
    this.requestRender();
    return true;
  }
  gotoVisualLineHome(options) {
    const select = options?.select ?? false;
    if (!select && this.collapseSelectionToEdge("start"))
      return true;
    this.updateSelectionForMovement(select, true);
    const sol = this.editorView.getVisualSOL();
    this.editBuffer.setCursor(sol.logicalRow, sol.logicalCol);
    this.updateSelectionForMovement(select, false);
    this.requestRender();
    return true;
  }
  gotoVisualLineEnd(options) {
    const select = options?.select ?? false;
    if (!select && this.collapseSelectionToEdge("end"))
      return true;
    this.updateSelectionForMovement(select, true);
    this.editorView.gotoVisualLineEnd();
    this.updateSelectionForMovement(select, false);
    this.requestRender();
    return true;
  }
  gotoBufferHome(options) {
    const select = options?.select ?? false;
    if (!select && this.collapseSelectionToEdge("start"))
      return true;
    this.updateSelectionForMovement(select, true);
    this.editBuffer.setCursor(0, 0);
    this.updateSelectionForMovement(select, false);
    this.requestRender();
    return true;
  }
  gotoBufferEnd(options) {
    const select = options?.select ?? false;
    if (!select && this.collapseSelectionToEdge("end"))
      return true;
    this.updateSelectionForMovement(select, true);
    this.editBuffer.gotoLine(999999);
    this.updateSelectionForMovement(select, false);
    this.requestRender();
    return true;
  }
  selectAll() {
    this.updateSelectionForMovement(false, true);
    this.editBuffer.setCursor(0, 0);
    return this.gotoBufferEnd({ select: true });
  }
  deleteToLineEnd() {
    const cursor = this.editorView.getCursor();
    const eol = this.editBuffer.getEOL();
    if (eol.col > cursor.col) {
      this.editBuffer.deleteRange(cursor.row, cursor.col, eol.row, eol.col);
    }
    this.requestRender();
    return true;
  }
  deleteToLineStart() {
    const cursor = this.editorView.getCursor();
    if (cursor.col > 0) {
      this.editBuffer.deleteRange(cursor.row, 0, cursor.row, cursor.col);
    } else if (cursor.row > 0) {
      this.editBuffer.deleteCharBackward();
    }
    this.requestRender();
    return true;
  }
  undo() {
    this._ctx.clearSelection();
    this.editBuffer.undo();
    this.requestRender();
    return true;
  }
  redo() {
    this._ctx.clearSelection();
    this.editBuffer.redo();
    this.requestRender();
    return true;
  }
  moveWordForward(options) {
    const select = options?.select ?? false;
    if (!select && this.collapseSelectionToEdge("end"))
      return true;
    this.updateSelectionForMovement(select, true);
    const nextWord = this.editBuffer.getNextWordBoundary();
    this.editBuffer.setCursorByOffset(nextWord.offset);
    this.updateSelectionForMovement(select, false);
    this.requestRender();
    return true;
  }
  moveWordBackward(options) {
    const select = options?.select ?? false;
    if (!select && this.collapseSelectionToEdge("start"))
      return true;
    this.updateSelectionForMovement(select, true);
    const prevWord = this.editBuffer.getPrevWordBoundary();
    this.editBuffer.setCursorByOffset(prevWord.offset);
    this.updateSelectionForMovement(select, false);
    this.requestRender();
    return true;
  }
  deleteWordForward() {
    if (this.hasSelection()) {
      this.deleteSelectedText();
      return true;
    }
    const currentCursor = this.editBuffer.getCursorPosition();
    const nextWord = this.editBuffer.getNextWordBoundary();
    if (nextWord.offset > currentCursor.offset) {
      this.editBuffer.deleteRange(currentCursor.row, currentCursor.col, nextWord.row, nextWord.col);
    }
    this._ctx.clearSelection();
    this.requestRender();
    return true;
  }
  deleteWordBackward() {
    if (this.hasSelection()) {
      this.deleteSelectedText();
      return true;
    }
    const currentCursor = this.editBuffer.getCursorPosition();
    const prevWord = this.editBuffer.getPrevWordBoundary();
    if (prevWord.offset < currentCursor.offset) {
      this.editBuffer.deleteRange(prevWord.row, prevWord.col, currentCursor.row, currentCursor.col);
    }
    this._ctx.clearSelection();
    this.requestRender();
    return true;
  }
  renderSelf(buffer) {
    buffer.drawEditorView(this.editorView, Math.trunc(this._screenX), Math.trunc(this._screenY));
  }
  focus() {
    super.focus();
    this.requestRender();
  }
  blur() {
    super.blur();
    this.requestRender();
  }
  destroyOwnedResources() {
    this.runCleanup((run) => {
      run(() => {
        this.traits = {};
      });
      if (this._focused) {
        run(() => this.blur());
      }
      run(() => this.editorView.destroy());
      run(() => this.editBuffer.destroy());
    });
  }
  set onCursorChange(handler) {
    this._cursorChangeListener = handler;
  }
  get onCursorChange() {
    return this._cursorChangeListener;
  }
  set onContentChange(handler) {
    this._contentChangeListener = handler;
  }
  get onContentChange() {
    return this._contentChangeListener;
  }
  get syntaxStyle() {
    return this.editBuffer.getSyntaxStyle();
  }
  set syntaxStyle(style) {
    this.editBuffer.setSyntaxStyle(style);
    this.requestRender();
  }
  addHighlight(lineIdx, highlight) {
    this.editBuffer.addHighlight(lineIdx, highlight);
    this.requestRender();
  }
  addHighlightByCharRange(highlight) {
    this.editBuffer.addHighlightByCharRange(highlight);
    this.requestRender();
  }
  removeHighlightsByRef(hlRef) {
    this.editBuffer.removeHighlightsByRef(hlRef);
    this.requestRender();
  }
  clearLineHighlights(lineIdx) {
    this.editBuffer.clearLineHighlights(lineIdx);
    this.requestRender();
  }
  clearAllHighlights() {
    this.editBuffer.clearAllHighlights();
    this.requestRender();
  }
  getLineHighlights(lineIdx) {
    return this.editBuffer.getLineHighlights(lineIdx);
  }
  setText(text) {
    this.runMutation(() => {
      this.editBuffer.setText(text);
      this.requestRender();
    });
  }
  replaceText(text) {
    this.runMutation(() => {
      this.editBuffer.replaceText(text);
      this.requestRender();
    });
  }
  clear() {
    this.editBuffer.clear();
    this.editBuffer.clearAllHighlights();
    this.requestRender();
  }
  deleteRange(startLine, startCol, endLine, endCol) {
    this.editBuffer.deleteRange(startLine, startCol, endLine, endCol);
    this.requestRender();
  }
  getTextRange(startOffset, endOffset) {
    return this.editBuffer.getTextRange(startOffset, endOffset);
  }
  getTextRangeByCoords(startRow, startCol, endRow, endCol) {
    return this.editBuffer.getTextRangeByCoords(startRow, startCol, endRow, endCol);
  }
  setNativeEditorOptions(options = {}) {
    if (this.isDestroyed)
      return;
    this._ctx.nativeScene.setEditorOptions(this, {
      showCursor: this._showCursor,
      style: this._cursorStyle.style ?? "block",
      blinking: this._cursorStyle.blinking ?? true,
      color: this._cursorColor,
      cursor: this._cursorStyle.cursor,
      ...options
    });
  }
  updateSelectionForMovement(shiftPressed, isBeforeMovement) {
    if (!shiftPressed) {
      this._keyboardSelectionActive = false;
      this.clearSelection();
      return;
    }
    if (!this.selectable)
      return;
    this._keyboardSelectionActive = true;
    const visualCursor = this.editorView.getVisualCursor();
    const cursorX = Math.trunc(this.x) + visualCursor.visualCol;
    const cursorY = Math.trunc(this.y) + visualCursor.visualRow;
    if (isBeforeMovement) {
      if (!this._ctx.hasSelection || !this.hasSelection()) {
        this._ctx.startSelection(this, cursorX, cursorY);
      } else if (this._ctx.getSelection()?.behavior !== "cell") {
        if (this.editorView.convertSelectionToCell()) {
          const selection = this._ctx.getSelection();
          if (selection)
            selection.behavior = "cell";
        }
      }
      return;
    }
    this._ctx.updateSelection(this, cursorX, cursorY, { finishDragging: true });
  }
}

// src/lib/render-geometry.ts
function calculateRenderGeometry(screenMode, terminalWidth, terminalHeight, footerHeight) {
  const safeTerminalWidth = Math.max(terminalWidth, 0);
  const safeTerminalHeight = Math.max(terminalHeight, 0);
  if (screenMode !== "split-footer") {
    return {
      effectiveFooterHeight: 0,
      renderOffset: 0,
      renderWidth: safeTerminalWidth,
      renderHeight: safeTerminalHeight
    };
  }
  const effectiveFooterHeight = Math.min(footerHeight, safeTerminalHeight);
  return {
    effectiveFooterHeight,
    renderOffset: safeTerminalHeight - effectiveFooterHeight,
    renderWidth: safeTerminalWidth,
    renderHeight: effectiveFooterHeight
  };
}

// src/lib/terminal-capability-detection.ts
function isCapabilityResponse(sequence) {
  if (/\x1b\[\?\d+(?:;\d+)*\$y/.test(sequence)) {
    return true;
  }
  if (/\x1b\[1;(?!1R)\d+R/.test(sequence)) {
    return true;
  }
  if (/\x1bP>\|[\s\S]*?\x1b\\/.test(sequence)) {
    return true;
  }
  if (/\x1bP(?:1\+r4d73(?:=[^\x1b]*)?|0\+r(?:4d73)?)\x1b\\/i.test(sequence)) {
    return true;
  }
  if (/\x1b_G[\s\S]*?\x1b\\/.test(sequence)) {
    return true;
  }
  if (/\x1b\[\?\d+(?:;\d+)?u/.test(sequence)) {
    return true;
  }
  if (/\x1b\[\?[0-9;]*c/.test(sequence)) {
    return true;
  }
  if (/\x1b\]99;[^\x07\x1b]*i=opentui-notifications[^\x07\x1b]*p=\?[\s\S]*?(?:\x07|\x1b\\)/.test(sequence)) {
    return true;
  }
  if (/\x1b\]1337;Capabilities=[\s\S]*?(?:\x07|\x1b\\)/.test(sequence)) {
    return true;
  }
  if (/\x1b\]7501; *\?[^\x07\x1b]*(?:\x07|\x1b\\)/.test(sequence)) {
    return true;
  }
  return false;
}
function isPixelResolutionResponse(sequence) {
  return /\x1b\[4;\d+;\d+t/.test(sequence);
}
function parsePixelResolution(sequence) {
  const match = sequence.match(/\x1b\[4;(\d+);(\d+)t/);
  if (match) {
    const width = Number(match[2]);
    const height = Number(match[1]);
    if (!Number.isSafeInteger(width) || !Number.isSafeInteger(height) || width > 2147483647 || height > 2147483647)
      return null;
    return { width, height };
  }
  return null;
}

// src/renderer-theme-mode.ts
var OSC_THEME_RESPONSE = /\x1b](10|11);(?:(?:rgb:)([0-9a-fA-F]+)\/([0-9a-fA-F]+)\/([0-9a-fA-F]+)|#([0-9a-fA-F]{6}))(?:\x07|\x1b\\)/g;
function scaleOscThemeComponent(component) {
  const value = parseInt(component, 16);
  const maxValue = (1 << 4 * component.length) - 1;
  return Math.round(value / maxValue * 255).toString(16).padStart(2, "0");
}
function oscThemeColorToHex(r, g, b, hex6) {
  if (hex6) {
    return `#${hex6.toLowerCase()}`;
  }
  if (r && g && b) {
    return `#${scaleOscThemeComponent(r)}${scaleOscThemeComponent(g)}${scaleOscThemeComponent(b)}`;
  }
  return "#000000";
}
function inferThemeModeFromBackgroundColor(color) {
  const [r, g, b] = parseColor2(color).toInts();
  const brightness = (r * 299 + g * 587 + b * 114) / 1000;
  return brightness > 128 ? "light" : "dark";
}

class RendererThemeMode {
  host;
  clock;
  static QUERY_TIMEOUT_MS = 250;
  _themeMode = null;
  themeQueryPending = true;
  themeOscForeground = null;
  themeOscBackground = null;
  themeRefreshTimeoutId = null;
  waiters = new Set;
  constructor(host, clock) {
    this.host = host;
    this.clock = clock;
  }
  get themeMode() {
    return this._themeMode;
  }
  waitForThemeMode(timeoutMs, isDestroyed) {
    if (this._themeMode !== null || isDestroyed || timeoutMs === 0) {
      return Promise.resolve(this._themeMode);
    }
    return new Promise((resolve) => {
      const waiter = {
        resolve,
        timeoutHandle: null
      };
      if (timeoutMs > 0) {
        waiter.timeoutHandle = this.clock.setTimeout(() => {
          this.waiters.delete(waiter);
          waiter.timeoutHandle = null;
          resolve(this._themeMode);
        }, timeoutMs);
      }
      this.waiters.add(waiter);
    });
  }
  cancelRefresh() {
    if (this.themeRefreshTimeoutId === null) {
      return;
    }
    this.clock.clearTimeout(this.themeRefreshTimeoutId);
    this.themeRefreshTimeoutId = null;
    this.themeQueryPending = false;
  }
  dispose() {
    this.cancelRefresh();
    for (const waiter of this.waiters) {
      if (waiter.timeoutHandle !== null) {
        this.clock.clearTimeout(waiter.timeoutHandle);
      }
      waiter.resolve(this._themeMode);
    }
    this.waiters.clear();
  }
  handleSequence(sequence) {
    if (sequence === "\x1B[?997;1n" || sequence === "\x1B[?997;2n") {
      this.requestThemeOscColors();
      return { handled: true, changedMode: null };
    }
    let handledOscThemeResponse = false;
    let match;
    OSC_THEME_RESPONSE.lastIndex = 0;
    while (match = OSC_THEME_RESPONSE.exec(sequence)) {
      handledOscThemeResponse = true;
      const color = oscThemeColorToHex(match[2], match[3], match[4], match[5]);
      if (match[1] === "10") {
        this.themeOscForeground = color;
      } else {
        this.themeOscBackground = color;
      }
    }
    if (!handledOscThemeResponse) {
      return { handled: false, changedMode: null };
    }
    if (!this.themeQueryPending) {
      return { handled: true, changedMode: null };
    }
    if (!this.themeOscForeground || !this.themeOscBackground) {
      return { handled: true, changedMode: null };
    }
    const nextMode = inferThemeModeFromBackgroundColor(this.themeOscBackground);
    const changedMode = this.applyThemeMode(nextMode);
    this.completeThemeQuery();
    return { handled: true, changedMode };
  }
  clearThemeRefreshTimeout() {
    if (this.themeRefreshTimeoutId === null) {
      return;
    }
    this.clock.clearTimeout(this.themeRefreshTimeoutId);
    this.themeRefreshTimeoutId = null;
  }
  completeThemeQuery() {
    this.clearThemeRefreshTimeout();
    this.themeQueryPending = false;
  }
  requestThemeOscColors() {
    if (this.themeRefreshTimeoutId !== null) {
      return;
    }
    this.themeQueryPending = true;
    this.themeOscForeground = null;
    this.themeOscBackground = null;
    this.host.queryThemeColors();
    this.clearThemeRefreshTimeout();
    this.themeRefreshTimeoutId = this.clock.setTimeout(() => {
      this.completeThemeQuery();
    }, RendererThemeMode.QUERY_TIMEOUT_MS);
  }
  applyThemeMode(mode) {
    const changed = this._themeMode !== mode;
    this._themeMode = mode;
    if (!changed) {
      return null;
    }
    for (const waiter of this.waiters) {
      if (waiter.timeoutHandle !== null) {
        this.clock.clearTimeout(waiter.timeoutHandle);
      }
      waiter.resolve(mode);
    }
    this.waiters.clear();
    return mode;
  }
}

// src/renderer.ts
registerEnvVar2({
  name: "OTUI_DUMP_CAPTURES",
  description: "Dump captured stdout and console caches when the renderer exit handler runs.",
  type: "boolean",
  default: false
});
registerEnvVar2({
  name: "OTUI_USE_ALTERNATE_SCREEN",
  description: "When explicitly set, force screen mode selection: true=alternate-screen, false=main-screen.",
  type: "boolean",
  default: true
});
registerEnvVar2({
  name: "OTUI_OVERRIDE_STDOUT",
  description: "When explicitly set, force stdout routing: false=passthrough, true=capture in split-footer mode.",
  type: "boolean",
  default: true
});
registerEnvVar2({
  name: "OTUI_DEBUG",
  description: "Enable debug mode to capture all raw input for debugging purposes.",
  type: "boolean",
  default: false
});
registerEnvVar2({
  name: "OTUI_STDIN_LOG",
  description: "Write the raw stdin byte stream to this file for debugging.",
  type: "string",
  default: ""
});
registerEnvVar2({
  name: "OTUI_SHOW_STATS",
  description: "Show the debug overlay at startup.",
  type: "boolean",
  default: false
});
var KITTY_IMAGE_TRANSPORTS = ["raw", "zlib", "file"];
var DEFAULT_FOOTER_HEIGHT = 12;
var MAX_SCROLLBACK_SURFACE_HEIGHT_PASSES = 4;
var TRANSPARENT_RGBA = RGBA2.fromValues(0, 0, 0, 0);
var scrollbackSurfaceCounter = 0;
function normalizeFooterHeight(footerHeight) {
  if (footerHeight === undefined) {
    return DEFAULT_FOOTER_HEIGHT;
  }
  if (!Number.isFinite(footerHeight)) {
    throw new Error("footerHeight must be a finite number");
  }
  const normalizedFooterHeight = Math.trunc(footerHeight);
  if (normalizedFooterHeight <= 0) {
    throw new Error("footerHeight must be greater than 0");
  }
  return normalizedFooterHeight;
}
function resolveModes(config) {
  let screenMode = config.screenMode ?? "alternate-screen";
  if (process.env.OTUI_USE_ALTERNATE_SCREEN !== undefined) {
    screenMode = env2.OTUI_USE_ALTERNATE_SCREEN ? "alternate-screen" : "main-screen";
  }
  const footerHeight = screenMode === "split-footer" ? normalizeFooterHeight(config.footerHeight) : DEFAULT_FOOTER_HEIGHT;
  let externalOutputMode = config.externalOutputMode ?? (screenMode === "split-footer" ? "capture-stdout" : "passthrough");
  if (process.env.OTUI_OVERRIDE_STDOUT !== undefined) {
    externalOutputMode = env2.OTUI_OVERRIDE_STDOUT && screenMode === "split-footer" ? "capture-stdout" : "passthrough";
  }
  if (externalOutputMode === "capture-stdout" && screenMode !== "split-footer") {
    throw new Error('externalOutputMode "capture-stdout" requires screenMode "split-footer"');
  }
  return {
    screenMode,
    footerHeight,
    externalOutputMode
  };
}
var STDOUT_TAB_WIDTH = 8;
var graphemeSegmenter2 = new Intl.Segmenter(undefined, { granularity: "grapheme" });
function snapshotRowWidths(snapshot, rowColumns) {
  return snapshot.withBuffers(({ width, height, char }) => {
    const widths = [];
    for (let y = 0;y < height; y += 1) {
      let x = rowColumns;
      while (x > 0 && char[y * width + x - 1] === 0)
        x -= 1;
      widths.push(x);
    }
    return widths;
  });
}
function runCleanups(cleanups) {
  let failure;
  for (const cleanup of cleanups) {
    try {
      cleanup();
    } catch (error) {
      failure ??= { error };
    }
  }
  if (failure)
    throw failure.error;
}

class ExternalOutputQueue {
  maxCells;
  commits = [];
  constructor(maxCells) {
    this.maxCells = maxCells;
  }
  owns(snapshot) {
    return this.commits.some((commit) => commit.snapshot === snapshot);
  }
  get size() {
    return this.commits.length;
  }
  writeSnapshots(commits) {
    for (const { rowColumns, snapshot } of commits) {
      if (!Number.isInteger(rowColumns) || rowColumns < 0 || rowColumns > snapshot.width) {
        throw new RangeError("Scrollback commit rowColumns must be an integer from 0 to the snapshot width");
      }
      if (snapshot.width * snapshot.height > this.maxCells) {
        throw new Error("Scrollback snapshot exceeds the Session output capacity");
      }
    }
    const entries = commits.map((commit) => ({
      ...commit,
      cells: commit.snapshot.width * commit.snapshot.height,
      rowWidths: snapshotRowWidths(commit.snapshot, commit.rowColumns)
    }));
    for (const entry of entries)
      this.commits.push(entry);
    return entries;
  }
  batch(limit) {
    if (!(limit >= 1))
      throw new RangeError("ExternalOutputQueue.batch requires a limit of at least 1");
    let count = 0;
    let cells = 0;
    while (count < Math.min(limit, this.commits.length)) {
      cells += this.commits[count].cells;
      if (cells > this.maxCells)
        break;
      count += 1;
    }
    return this.commits.slice(0, count);
  }
  peek(limit = Number.POSITIVE_INFINITY) {
    return this.commits.slice(0, limit);
  }
  claim() {
    const output = this.commits;
    this.commits = [];
    return output;
  }
  drop(count) {
    for (const commit of this.commits.splice(0, count))
      commit.snapshot.destroy();
  }
  clear() {
    this.drop(this.commits.length);
  }
}

class ScrollbackSnapshotRenderContext extends EventEmitter8 {
  nativeOwner;
  width;
  height;
  terminalWidth;
  terminalHeight;
  resolution;
  frameId = 0;
  widthMethod;
  capabilities;
  hasSelection = false;
  currentFocusedRenderable = null;
  keyInput;
  _internalKeyInput;
  nativeScene;
  root;
  nextRenderBuffer;
  isDestroyed = false;
  controlState = "idle" /* IDLE */;
  detachedSession;
  constructor(width, height, widthMethod, terminalWidth, terminalHeight, resolution, capabilities, nativeOwner) {
    super();
    this.nativeOwner = nativeOwner;
    this.width = width;
    this.height = height;
    this.terminalWidth = terminalWidth;
    this.terminalHeight = terminalHeight;
    this.resolution = resolution;
    this.capabilities = capabilities;
    this.widthMethod = widthMethod;
    this.keyInput = new KeyHandler2;
    this._internalKeyInput = new InternalKeyHandler2;
    this.detachedSession = nativeOwner.createDetached({ width, height, remote: true, environment: {} }, () => {
      this.nativeScene?.cancelFrame();
      this.nativeScene?.destroy();
    });
    try {
      nativeOwner.renderLib.sessionSyncDetached(nativeOwner.context, this.detachedSession.session, nativeOwner.session);
      this.nativeScene = new NativeScene(this.detachedSession, this);
      this.nextRenderBuffer = OptimizedBuffer2.fromSession(nativeOwner.renderLib, nativeOwner.context, this.detachedSession.session, "next", () => this.nativeScene.frame);
    } catch (error) {
      this.detachedSession.dispose();
      throw error;
    }
  }
  renderSnapshot(root, buffer) {
    this.root = root;
    this.detachedSession.renderLib.sessionSyncDetached(this.detachedSession.context, this.detachedSession.session, this.nativeOwner.session);
    this.detachedSession.resize(this.width, this.height);
    try {
      this.nativeScene.paint(0, () => ({
        background: TRANSPARENT_RGBA,
        useMouse: false,
        excludedHitNum: 0,
        preserveUnwritten: true
      }));
      if (!this.nativeScene.frame)
        throw new Error("Detached scene did not complete painting");
      this.detachedSession.renderLib.sceneFrameCopyBuffer(this.detachedSession.context, this.detachedSession.session, this.nativeScene.frame, buffer._getSceneHandle(this.nativeScene));
    } finally {
      this.nativeScene.cancelFrame();
      if (this.isDestroyed)
        this.disposeSession();
    }
  }
  destroy() {
    if (this.isDestroyed)
      return;
    this.isDestroyed = true;
    runCleanups([
      () => this.removeAllListeners(),
      () => this.keyInput.removeAllListeners(),
      () => this._internalKeyInput.removeAllListeners(),
      () => this.disposeSession()
    ]);
  }
  disposeSession() {
    const dispose = () => this.detachedSession.dispose();
    if (!this.root?._deferUntilCleanupComplete(dispose))
      dispose();
  }
  requestRender() {}
  requestAnimationFrame(_callback) {
    return -1;
  }
  cancelAnimationFrame(_handle) {}
  setCursorPosition(_x, _y, _visible) {}
  setCursorStyle(_options) {}
  setCursorColor(_color) {}
  setMousePointer(_shape) {}
  requestLive() {}
  dropLive() {}
  getSelection() {
    return null;
  }
  get currentFocusedEditor() {
    if (!this.currentFocusedRenderable)
      return null;
    if (!isEditBufferRenderable2(this.currentFocusedRenderable))
      return null;
    return this.currentFocusedRenderable;
  }
  requestSelectionUpdate() {}
  focusRenderable(renderable) {
    this.currentFocusedRenderable = renderable;
  }
  blurRenderable(renderable) {
    if (this.currentFocusedRenderable === renderable) {
      this.currentFocusedRenderable = null;
    }
  }
  registerLifecyclePass(renderable) {
    this.getLifecyclePasses().add(renderable);
  }
  unregisterLifecyclePass(renderable) {
    this.getLifecyclePasses().delete(renderable);
  }
  getLifecyclePasses() {
    return this.nativeScene.lifecyclePasses;
  }
  clearSelection() {}
  startSelection(_renderable, _x, _y, _behavior) {}
  updateSelection(_currentRenderable, _x, _y, _options) {}
}
var DEFAULT_FORWARDED_ENV_KEYS = [
  "TMPDIR",
  "SSH_CONNECTION",
  "SSH_CLIENT",
  "SSH_TTY",
  "MOSH_CONNECTION",
  "TMUX",
  "ZELLIJ",
  "ZELLIJ_SESSION_NAME",
  "ZELLIJ_PANE_ID",
  "TERM",
  "OPENTUI_GRAPHICS",
  "OPENTUI_IMAGE_PROTOCOL",
  "TERM_PROGRAM",
  "TERM_PROGRAM_VERSION",
  "TERM_FEATURES",
  "VTE_VERSION",
  "FORCE_HYPERLINK",
  "ALACRITTY_SOCKET",
  "ALACRITTY_LOG",
  "COLORTERM",
  "TERMUX_VERSION",
  "VHS_RECORD",
  "OPENTUI_FORCE_WCWIDTH",
  "OPENTUI_FORCE_UNICODE",
  "OPENTUI_FORCE_NOZWJ",
  "OPENTUI_FORCE_EXPLICIT_WIDTH",
  "OPENTUI_NOTIFICATION_PROTOCOL",
  "OPENTUI_NOTIFICATIONS",
  "WT_SESSION",
  "STY",
  "WSL_DISTRO_NAME",
  "WSL_INTEROP"
];
var KITTY_FLAG_DISAMBIGUATE = 1;
var KITTY_FLAG_EVENT_TYPES = 2;
var KITTY_FLAG_ALTERNATE_KEYS = 4;
var KITTY_FLAG_ALL_KEYS_AS_ESCAPES = 8;
var KITTY_FLAG_REPORT_TEXT = 16;
var DEFAULT_STDIN_PARSER_MAX_BUFFER_BYTES = 64 * 1024 * 1024;
var NATIVE_PALETTE_QUERY_SIZE = 16;
function buildKittyKeyboardFlags2(config) {
  if (!config) {
    return 0;
  }
  let flags = 0;
  if (config.disambiguate !== false) {
    flags |= KITTY_FLAG_DISAMBIGUATE;
  }
  if (config.alternateKeys !== false) {
    flags |= KITTY_FLAG_ALTERNATE_KEYS;
  }
  if (config.events === true) {
    flags |= KITTY_FLAG_EVENT_TYPES;
  }
  if (config.allKeysAsEscapes === true) {
    flags |= KITTY_FLAG_ALL_KEYS_AS_ESCAPES;
  }
  if (config.reportText === true) {
    flags |= KITTY_FLAG_REPORT_TEXT;
  }
  return flags;
}

class MouseEvent2 {
  type;
  button;
  x;
  y;
  source;
  modifiers;
  scroll;
  target;
  currentTarget = null;
  isDragging;
  _propagationStopped = false;
  _defaultPrevented = false;
  get propagationStopped() {
    return this._propagationStopped;
  }
  get defaultPrevented() {
    return this._defaultPrevented;
  }
  constructor(target, attributes) {
    this.target = target;
    this.type = attributes.type;
    this.button = attributes.button;
    this.x = attributes.x;
    this.y = attributes.y;
    this.modifiers = attributes.modifiers;
    this.scroll = attributes.scroll;
    this.source = attributes.source;
    this.isDragging = attributes.isDragging;
  }
  stopPropagation() {
    this._propagationStopped = true;
  }
  preventDefault() {
    this._defaultPrevented = true;
  }
}
var MouseButton2;
((MouseButton) => {
  MouseButton[MouseButton["LEFT"] = 0] = "LEFT";
  MouseButton[MouseButton["MIDDLE"] = 1] = "MIDDLE";
  MouseButton[MouseButton["RIGHT"] = 2] = "RIGHT";
  MouseButton[MouseButton["WHEEL_UP"] = 4] = "WHEEL_UP";
  MouseButton[MouseButton["WHEEL_DOWN"] = 5] = "WHEEL_DOWN";
})(MouseButton2 ||= {});
var rendererTracker = singleton("RendererTracker", () => ({
  renderers: new Set,
  streamOwners: new WeakMap
}));
async function createCliRenderer2(config = {}) {
  if (process.argv.includes("--delay-start")) {
    await new Promise((resolve) => setTimeout(resolve, 5000));
  }
  const stdin = config.stdin ?? process.stdin;
  const stdout = config.stdout ?? process.stdout;
  const width = stdout.columns || config.width || 80;
  const height = stdout.rows || config.height || 24;
  const renderer = new CliRenderer2(stdin, stdout, width, height, config);
  try {
    await renderer.setupTerminal();
    return renderer;
  } catch (error) {
    try {
      renderer.destroy();
    } catch (destroyError) {
      console.error("Error destroying partially-set-up renderer:", destroyError);
    }
    await renderer.closed.catch(() => {});
    throw error;
  }
}
var CliRenderEvents2;
((CliRenderEvents) => {
  CliRenderEvents["RESIZE"] = "resize";
  CliRenderEvents["FRAME"] = "frame";
  CliRenderEvents["RENDER_ERROR"] = "render:error";
  CliRenderEvents["HANDLER_ERROR"] = "handler:error";
  CliRenderEvents["EXTERNAL_OUTPUT"] = "external_output";
  CliRenderEvents["FOCUS"] = "focus";
  CliRenderEvents["BLUR"] = "blur";
  CliRenderEvents["FOCUSED_RENDERABLE"] = "focused_renderable";
  CliRenderEvents["FOCUSED_EDITOR"] = "focused_editor";
  CliRenderEvents["THEME_MODE"] = "theme_mode";
  CliRenderEvents["PALETTE"] = "palette";
  CliRenderEvents["CAPABILITIES"] = "capabilities";
  CliRenderEvents["SELECTION"] = "selection";
  CliRenderEvents["DEBUG_OVERLAY_TOGGLE"] = "debugOverlay:toggle";
  CliRenderEvents["DESTROY"] = "destroy";
  CliRenderEvents["MEMORY_SNAPSHOT"] = "memory:snapshot";
})(CliRenderEvents2 ||= {});
var RendererControlState2;
((RendererControlState) => {
  RendererControlState["IDLE"] = "idle";
  RendererControlState["AUTO_STARTED"] = "auto_started";
  RendererControlState["EXPLICIT_STARTED"] = "explicit_started";
  RendererControlState["EXPLICIT_PAUSED"] = "explicit_paused";
  RendererControlState["EXPLICIT_SUSPENDED"] = "explicit_suspended";
  RendererControlState["EXPLICIT_STOPPED"] = "explicit_stopped";
})(RendererControlState2 ||= {});
var CLICK_REPEAT_INTERVAL_MS = 500;

class CliRenderer2 extends EventEmitter8 {
  static animationFrameId = 0;
  lib;
  nativeScene;
  nativeSession;
  nativeDestroyWait;
  nativeClosed;
  nativeTerminalTransition = null;
  pendingNativeResize = null;
  pendingNativeMode = null;
  nativeSplitAcceptedCount = 0;
  nativeSplitFlush = null;
  pendingNativeReplay = null;
  detachedSurfaces = new Set;
  nativeResizeWait = null;
  nativeKittyKeyboardFlags = 0;
  kittyTransportMode = "raw";
  kittyTransportTimer = null;
  _lastSceneTimeMs = 0;
  get lastSceneTimeMs() {
    return this._lastSceneTimeMs;
  }
  get closed() {
    return this.nativeClosed;
  }
  stdin;
  stdout;
  exitOnCtrlC;
  exitSignals;
  _exitListenersAdded = false;
  _isDestroyed = false;
  _destroyPending = false;
  _destroyFinalized = false;
  _destroyCleanupPrepared = false;
  _streamLeaseAcquired = false;
  flushTerminalInputOnClose = false;
  nextRenderBuffer;
  currentRenderBuffer;
  _isRunning = false;
  _targetFps = 30;
  _maxFps = 60;
  automaticMemorySnapshot = false;
  memorySnapshotInterval;
  memorySnapshotTimer = null;
  lastMemorySnapshot = {
    heapUsed: 0,
    heapTotal: 0,
    arrayBuffers: 0
  };
  root;
  width;
  height;
  gatherStats = false;
  frameTimes = [];
  maxStatSamples = 300;
  postProcessFns = [];
  backgroundColor = RGBA2.fromInts(0, 0, 0, 0);
  waitingForPixelResolution = false;
  pixelResolutionRequeryPending = false;
  clock;
  rendering = false;
  renderingCompletion = null;
  renderTimeout = null;
  lastTime = 0;
  frameCount = 0;
  _frameId = 0;
  lastFpsTime = 0;
  currentFps = 0;
  targetFrameTime = 1000 / this._targetFps;
  minTargetFrameTime = 1000 / this._maxFps;
  immediateRerenderRequested = false;
  liveRequestCounter = 0;
  _controlState = "idle" /* IDLE */;
  frameCallbacks = [];
  renderStats = {
    frameCount: 0,
    fps: 0,
    renderTime: 0,
    frameCallbackTime: 0
  };
  debugOverlay = {
    enabled: env2.OTUI_SHOW_STATS,
    corner: 3 /* bottomRight */
  };
  _console;
  _resolution = null;
  _keyHandler;
  stdinParser = null;
  oscSubscribers = new Set;
  hasLoggedStdinParserError = false;
  animationRequest = new Map;
  cancelFrameContinuation = null;
  cancelReadyFrame = null;
  resizeTimeoutId = null;
  pendingResizeSawDifferentSize = false;
  capabilityTimeoutId = null;
  terminalKeepAliveTimer = null;
  xtVersionWaiters = new Set;
  splitStartupSeedTimeoutId = null;
  pendingSplitStartupCursorSeed = false;
  resizeDebounceDelay = 100;
  enableMouseMovement = false;
  _useMouse = true;
  autoFocus = true;
  _screenMode = "alternate-screen";
  _footerHeight = DEFAULT_FOOTER_HEIGHT;
  _externalOutputMode = "passthrough";
  clearOnShutdown = true;
  _suspendedMouseEnabled = false;
  _previousControlState = "idle" /* IDLE */;
  capturedRenderable;
  lastOverRenderableNum = 0;
  lastOverRenderable;
  currentSelection = null;
  selectionContainers = [];
  lastClick = null;
  _splitHeight = 0;
  renderOffset = 0;
  splitTailColumn = 0;
  queuedSplitTail = null;
  pendingSplitFooterTransition = null;
  forceFullRepaintRequested = false;
  maxSplitCommitsPerFrame = 8;
  _terminalWidth = 0;
  _terminalHeight = 0;
  _terminalIsSetup = false;
  externalOutputQueue;
  pendingExternalOutputMode = null;
  realStdoutWrite;
  _useConsole = true;
  sigwinchHandler = (() => {
    const width = this.stdout.columns;
    const height = this.stdout.rows;
    if (width > 0 && height > 0)
      this.requestResize(width, height);
  }).bind(this);
  _capabilities = null;
  _latestPointer = { x: 0, y: 0 };
  _hasPointer = false;
  _lastPointerModifiers = {
    shift: false,
    alt: false,
    ctrl: false
  };
  _currentMousePointerStyle = undefined;
  _currentFocusedRenderable = null;
  focusChange;
  _openConsoleOnError = true;
  _paletteDetector = null;
  _paletteCache = new Map;
  _paletteDetectionPromise = null;
  _cancelPaletteDetection = null;
  _paletteDetectionSize = 0;
  _paletteDetectionGeneration = 0;
  _paletteEpoch = 0;
  _nativePaletteSignature = null;
  _emittedPaletteSignature = null;
  _palettePublishGeneration = 0;
  _onDestroy;
  themeModeState;
  _terminalFocusState = null;
  sequenceHandlers = [];
  prependedInputHandlers = [];
  shouldRestoreModesOnNextFocus = false;
  themeModeHandler;
  idleResolvers = [];
  _debugInputs = [];
  _debugModeEnabled = env2.OTUI_DEBUG;
  stdinLogPath = env2.OTUI_STDIN_LOG;
  handleError = ((error) => {
    console.error(error);
    if (this._openConsoleOnError && !this._isDestroyed && !this.nativeSession?.error && !this.nativeSession?.disposed) {
      this.console.show();
    }
  }).bind(this);
  dumpOutputCache(optionalMessage = "") {
    const cachedLogs = this._console.getCachedLogs();
    const capturedConsoleOutput = capture2.claimOutput();
    const capturedExternalOutputCommits = this.externalOutputQueue.claim();
    let capturedExternalOutput = "";
    for (const commit of capturedExternalOutputCommits) {
      capturedExternalOutput += `[snapshot ${commit.snapshot.width}x${commit.snapshot.height}]
`;
      commit.snapshot.destroy();
    }
    if (capturedConsoleOutput.length > 0 || capturedExternalOutput.length > 0 || cachedLogs.length > 0) {
      this.realStdoutWrite.call(this.stdout, optionalMessage);
    }
    if (cachedLogs.length > 0) {
      this.realStdoutWrite.call(this.stdout, `Console cache:
`);
      this.realStdoutWrite.call(this.stdout, cachedLogs);
    }
    if (capturedConsoleOutput.length > 0) {
      this.realStdoutWrite.call(this.stdout, `
Captured console output:
`);
      this.realStdoutWrite.call(this.stdout, capturedConsoleOutput + `
`);
    }
    if (capturedExternalOutput.length > 0) {
      this.realStdoutWrite.call(this.stdout, `
Captured external output:
`);
      this.realStdoutWrite.call(this.stdout, capturedExternalOutput + `
`);
    }
    this.realStdoutWrite.call(this.stdout, ANSI.reset);
  }
  exitHandler = (() => {
    this.destroy();
    this.closed.then(() => {
      if (env2.OTUI_DUMP_CAPTURES)
        this.dumpOutputCache(`=== CAPTURED OUTPUT ===
`);
    }).catch((error) => console.error("Native scene shutdown failed:", error));
  }).bind(this);
  nativeProcessExitHandler = () => {
    if (!this.nativeSession || this.nativeSession.disposed)
      return;
    const restored = this.nativeSession.restoreOnExit();
    try {
      this.destroy();
      if (this.flushTerminalInputOnClose)
        this.lib.terminalFlushInput();
    } finally {
      this.nativeSession.dispose();
      if (!restored && this._terminalIsSetup) {
        console.error("Native scene output cancelled at process exit; terminal restoration did not complete");
      }
    }
  };
  warningHandler = ((warning) => {
    console.warn(JSON.stringify(warning.message, null, 2));
  }).bind(this);
  _usesProcessStdout;
  outputIdleRenderScheduled = false;
  ordinaryFrameWaitingForOutput = false;
  ordinaryFrameWaitControlState = null;
  get controlState() {
    return this._controlState;
  }
  constructor(stdin, stdout, width, height, config = {}) {
    super();
    this.stdin = stdin;
    this.stdout = stdout;
    this._usesProcessStdout = stdout === process.stdout;
    this.realStdoutWrite = stdout.write;
    const workBudget = config.nativeSceneWorkBudget;
    if (workBudget !== undefined && (!Number.isInteger(workBudget) || workBudget <= 0 || workBudget > 4294967295)) {
      throw new Error("nativeSceneWorkBudget must be a positive u32");
    }
    this.kittyTransportMode = config.kittyImageTransport ?? "raw";
    const transportCode = KITTY_IMAGE_TRANSPORTS.indexOf(this.kittyTransportMode);
    if (transportCode < 0)
      throw new TypeError("Invalid kittyImageTransport");
    const useMemoryBufferedOutput = config.bufferedOutput === "memory";
    if (config.nativeSession) {
      if (useMemoryBufferedOutput)
        throw new Error("nativeSession does not support memory buffered output");
      if (!config.nativeSession.usesOutput(stdout))
        throw new Error("nativeSession must use the renderer stdout");
    }
    const { screenMode, footerHeight, externalOutputMode } = resolveModes(config);
    const initialGeometry = calculateRenderGeometry(screenMode, width, height, footerHeight);
    const remoteMode = config.remote ?? (!this._usesProcessStdout && !useMemoryBufferedOutput ? true : undefined);
    const forwardEnvKeys = config.forwardEnvKeys ?? (remoteMode === true ? [] : DEFAULT_FORWARDED_ENV_KEYS);
    if (rendererTracker.streamOwners.get(stdin)) {
      throw new Error("Cannot create CliRenderer: stdin is already used by another CliRenderer");
    }
    if (rendererTracker.streamOwners.get(stdout)) {
      throw new Error("Cannot create CliRenderer: stdout is already used by another CliRenderer");
    }
    let driver;
    try {
      const sink = useMemoryBufferedOutput ? new Writable3({
        write(_bytes, _encoding, complete) {
          complete();
        }
      }) : stdout;
      driver = config.nativeSession ?? new NativeSession2(sink);
      driver.attachRenderer({
        width: initialGeometry.renderWidth,
        height: initialGeometry.renderHeight,
        remote: remoteMode,
        environment: {
          ...Object.fromEntries(forwardEnvKeys.flatMap((key) => {
            const value = process.env[key];
            return value === undefined ? [] : [[key, value]];
          })),
          ...config.environment
        }
      }, () => {
        try {
          this.nativeScene?.cancelFrame();
        } finally {
          this.nativeScene?.destroy();
        }
      });
      this.nativeSession = driver;
      this.externalOutputQueue = new ExternalOutputQueue(Number(driver.maxWriteBytes / 24n));
      this.nativeDestroyWait = Promise.withResolvers();
      this.nativeClosed = this.nativeSession.closed.finally(() => this.nativeDestroyWait.promise).finally(() => {
        if (this.nativeSession.error && !this.nativeSession.disposed)
          this.nativeSession.dispose();
        if (this.flushTerminalInputOnClose)
          this.lib.terminalFlushInput();
        this.releaseStreamLease();
      });
      this.nativeClosed.catch(() => {});
      this.nativeScene = new NativeScene(this.nativeSession, this, config.nativeSceneWorkBudget);
      this.nativeSession.setKittyImageTransport(transportCode);
    } catch (error) {
      if (!config.nativeSession || this.nativeSession)
        driver?.dispose();
      this.nativeDestroyWait?.resolve();
      throw error;
    }
    this.lib = this.nativeSession.renderLib;
    try {
      const kittyConfig = config.useKittyKeyboard ?? {};
      this.nativeKittyKeyboardFlags = buildKittyKeyboardFlags2(kittyConfig);
      this._terminalWidth = width;
      this._terminalHeight = height;
      this._externalOutputMode = externalOutputMode;
      this.width = initialGeometry.renderWidth;
      this.height = initialGeometry.renderHeight;
      this._splitHeight = initialGeometry.effectiveFooterHeight;
      this.renderOffset = screenMode === "split-footer" ? 0 : initialGeometry.renderOffset;
      this._footerHeight = footerHeight;
      this.clearOnShutdown = config.clearOnShutdown ?? true;
      this.exitOnCtrlC = config.exitOnCtrlC === undefined ? true : config.exitOnCtrlC;
      this.exitSignals = config.exitSignals || [
        "SIGINT",
        "SIGTERM",
        "SIGQUIT",
        "SIGABRT",
        "SIGHUP",
        "SIGPIPE",
        "SIGBREAK",
        "SIGBUS"
      ];
      this.resizeDebounceDelay = config.debounceDelay || 100;
      this.targetFps = config.targetFps || 30;
      this.maxFps = config.maxFps || 60;
      this.clock = config.clock ?? new SystemClock2;
      this.themeModeState = new RendererThemeMode({
        queryThemeColors: () => {
          this.nativeSession.control({ kind: "query-theme-colors" });
        }
      }, this.clock);
      this.themeModeHandler = (sequence) => {
        const result = this.themeModeState.handleSequence(sequence);
        if (result.changedMode) {
          this.clearPaletteCache();
          if (this.shouldSyncNativePaletteState() || this.listenerCount("palette" /* PALETTE */) > 0) {
            this.refreshPalette();
          }
          this.emit("theme_mode" /* THEME_MODE */, result.changedMode);
        }
        return result.handled;
      };
      this.memorySnapshotInterval = config.memorySnapshotInterval ?? 0;
      this.gatherStats = config.gatherStats || false;
      this.maxStatSamples = config.maxStatSamples || 300;
      this.enableMouseMovement = config.enableMouseMovement ?? true;
      this._useMouse = config.useMouse ?? true;
      this.autoFocus = config.autoFocus ?? true;
      this.nextRenderBuffer = OptimizedBuffer2.fromSession(this.lib, this.nativeSession.context, this.nativeSession.session, "next", () => this.nativeScene.frame);
      this.currentRenderBuffer = OptimizedBuffer2.fromSession(this.lib, this.nativeSession.context, this.nativeSession.session, "current", () => this.nativeScene.frame);
      this._capabilities = this.nativeSession.getCapabilities();
      if (config.backgroundColor !== undefined)
        this.backgroundColor = RGBA2.clone(parseColor2(config.backgroundColor));
      this.postProcessFns = config.postProcessFns || [];
      this.prependedInputHandlers = config.prependInputHandlers || [];
      this.root = new RootRenderable2(this);
      if (this.memorySnapshotInterval > 0) {
        this.startMemorySnapshotTimer();
      }
      if (this._usesProcessStdout) {
        process.on("SIGWINCH", this.sigwinchHandler);
      }
      process.on("warning", this.warningHandler);
      process.on("uncaughtException", this.handleError);
      process.on("unhandledRejection", this.handleError);
      const useKittyForParsing = kittyConfig !== null;
      this._keyHandler = new InternalKeyHandler2;
      this._keyHandler.on("keypress", (event) => {
        if (this.exitOnCtrlC && matchesKeyBinding(event, { name: "c", ctrl: true })) {
          process.nextTick(this.exitHandler);
          return;
        }
      });
      this.addExitListeners();
      const stdinParserMaxBufferBytes = config.stdinParserMaxBufferBytes ?? DEFAULT_STDIN_PARSER_MAX_BUFFER_BYTES;
      this.stdinParser = new StdinParser2({
        timeoutMs: 20,
        maxPendingBytes: stdinParserMaxBufferBytes,
        armTimeouts: true,
        onTimeoutFlush: () => {
          this.drainStdinParser();
        },
        useKittyKeyboard: useKittyForParsing,
        protocolContext: {
          kittyKeyboardEnabled: useKittyForParsing,
          privateCapabilityRepliesActive: false,
          pixelResolutionQueryActive: false,
          explicitWidthCprActive: false,
          startupCursorCprActive: false
        },
        clock: this.clock
      });
      this._console = new TerminalConsole2(this, {
        ...config.consoleOptions ?? {},
        clock: this.clock
      });
      this.consoleMode = config.consoleMode ?? "console-overlay";
      this.applyScreenMode(screenMode, false, false);
      rendererTracker.streamOwners.set(stdin, this);
      rendererTracker.streamOwners.set(stdout, this);
      this._streamLeaseAcquired = true;
      rendererTracker.renderers.add(this);
      this.stdout.write = externalOutputMode === "capture-stdout" ? this.interceptStdoutWrite : this.realStdoutWrite;
      this._openConsoleOnError = config.openConsoleOnError ?? true;
      this._onDestroy = config.onDestroy;
      this.setupInput();
      process.on("exit", this.nativeProcessExitHandler);
      this.nativeSession.closed.then(() => this.removeCleanupListener(process, "exit", this.nativeProcessExitHandler), () => this.removeCleanupListener(process, "exit", this.nativeProcessExitHandler));
      this.nativeSession.closed.catch((error) => {
        if (this._isDestroyed)
          return;
        try {
          const setupPending = !this._terminalIsSetup && this.nativeTerminalTransition !== null;
          if (!setupPending)
            this.handleError(error);
        } catch {} finally {
          this.destroy();
        }
      });
    } catch (error) {
      try {
        this.destroy();
      } catch (destroyError) {
        console.error("Error destroying partially constructed renderer:", destroyError);
      } finally {
        this.nativeSession.dispose();
        this.nativeDestroyWait?.resolve();
        this.releaseStreamLease();
      }
      throw error;
    }
  }
  addExitListeners() {
    if (this._exitListenersAdded || this.exitSignals.length === 0)
      return;
    this.exitSignals.forEach((signal) => {
      process.addListener(signal, this.exitHandler);
    });
    this._exitListenersAdded = true;
  }
  startTerminalKeepAlive() {
    if (this.stdin !== process.stdin || this.terminalKeepAliveTimer !== null)
      return;
    this.terminalKeepAliveTimer = setInterval(() => {}, 60000);
  }
  stopTerminalKeepAlive() {
    if (this.terminalKeepAliveTimer === null)
      return;
    clearInterval(this.terminalKeepAliveTimer);
    this.terminalKeepAliveTimer = null;
  }
  removeExitListeners() {
    if (!this._exitListenersAdded || this.exitSignals.length === 0)
      return;
    this.exitSignals.forEach((signal) => {
      this.removeCleanupListener(process, signal, this.exitHandler);
    });
    this._exitListenersAdded = false;
  }
  removeCleanupListener(target, event, listener) {
    try {
      target.removeListener(event, listener);
    } catch (error) {
      if (!this._isDestroyed)
        throw error;
      console.error("Error removing native scene lifecycle listener:", error);
    }
  }
  get isDestroyed() {
    return this._isDestroyed;
  }
  registerLifecyclePass(renderable) {
    this.getLifecyclePasses().add(renderable);
  }
  unregisterLifecyclePass(renderable) {
    this.getLifecyclePasses().delete(renderable);
  }
  getLifecyclePasses() {
    return this.nativeScene.lifecyclePasses;
  }
  get currentFocusedRenderable() {
    return this._currentFocusedRenderable;
  }
  get currentFocusedEditor() {
    if (!this._currentFocusedRenderable)
      return null;
    if (!isEditBufferRenderable2(this._currentFocusedRenderable))
      return null;
    return this._currentFocusedRenderable;
  }
  normalizeClockTime(now, fallback) {
    if (Number.isFinite(now)) {
      return now;
    }
    return Number.isFinite(fallback) ? fallback : 0;
  }
  getElapsedMs(now, then) {
    if (!Number.isFinite(now) || !Number.isFinite(then)) {
      return 0;
    }
    return Math.max(now - then, 0);
  }
  focusRenderable(renderable) {
    if (renderable.ctx !== this) {
      throw new Error("Cannot focus renderables from another render context");
    }
    this.changeFocus(renderable);
  }
  blurRenderable(renderable) {
    if (this._currentFocusedRenderable !== renderable) {
      return;
    }
    this.changeFocus(null);
  }
  changeFocus(renderable) {
    if (this._currentFocusedRenderable === renderable)
      return;
    const change = this.focusChange = {};
    const previous = this._currentFocusedRenderable;
    const previousEditor = this.currentFocusedEditor;
    this._currentFocusedRenderable = renderable;
    let failure;
    const run = (operation) => {
      try {
        operation();
      } catch (error) {
        failure ??= { error };
      }
    };
    if (renderable)
      run(() => previous?.blur());
    const currentEditor = this.currentFocusedEditor;
    if (previousEditor !== currentEditor)
      run(() => this.emit("focused_editor" /* FOCUSED_EDITOR */, currentEditor, previousEditor));
    if (this.focusChange === change && this._currentFocusedRenderable === renderable && !renderable?.isDestroyed) {
      run(() => this.emit("focused_renderable" /* FOCUSED_RENDERABLE */, renderable, previous));
    }
    if (failure)
      throw failure.error;
  }
  setCapturedRenderable(renderable) {
    if (this.capturedRenderable === renderable) {
      return;
    }
    this.capturedRenderable = renderable;
  }
  get widthMethod() {
    return this.capabilities?.unicode ?? this.nextRenderBuffer.widthMethod;
  }
  get frameId() {
    return this._frameId;
  }
  scheduleRenderAfterOutputIdle() {
    if (this.outputIdleRenderScheduled || this._isDestroyed)
      return;
    this.outputIdleRenderScheduled = true;
    this.nativeSession.idle().then(() => {
      this.outputIdleRenderScheduled = false;
      const ordinaryFrameWasWaiting = this.ordinaryFrameWaitingForOutput;
      const ordinaryFrameWaitControlState = this.ordinaryFrameWaitControlState;
      this.ordinaryFrameWaitingForOutput = false;
      if (!this.rendering)
        this.ordinaryFrameWaitControlState = null;
      if (this._isDestroyed || ordinaryFrameWasWaiting && this._controlState !== ordinaryFrameWaitControlState && (this._controlState === "explicit_paused" /* EXPLICIT_PAUSED */ || this._controlState === "explicit_stopped" /* EXPLICIT_STOPPED */ || this._controlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */)) {
        this.resolveIdleIfNeeded();
        return;
      }
      this.scheduleRenderTimer();
      this.resolveIdleIfNeeded();
    }).catch((error) => {
      this.outputIdleRenderScheduled = false;
      this.ordinaryFrameWaitingForOutput = false;
      this.ordinaryFrameWaitControlState = null;
      if (!this._isDestroyed)
        this.handleError(error);
      this.resolveIdleIfNeeded();
    });
  }
  scheduleRenderTimer() {
    if (this.renderTimeout || this.cancelReadyFrame || this._isDestroyed || this._controlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */)
      return;
    this.scheduleFrame(this.nextFrameDelay());
  }
  nextFrameDelay() {
    const now = this.normalizeClockTime(this.clock.now(), this.lastTime);
    return Math.max(this.minTargetFrameTime - this.getElapsedMs(now, this.lastTime), 0);
  }
  scheduleFrame(delayMs) {
    this.clearFrameTimer();
    this.renderTimeout = this.clock.setTimeout(() => {
      this.renderTimeout = null;
      this.queueFrame();
    }, delayMs);
  }
  clearFrameTimer() {
    if (this.renderTimeout === null)
      return;
    this.clock.clearTimeout(this.renderTimeout);
    this.renderTimeout = null;
  }
  requestRender() {
    if (this._isDestroyed || this._controlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */) {
      return;
    }
    if (this.outputIdleRenderScheduled) {
      this.ordinaryFrameWaitControlState = this._controlState;
      return;
    }
    if (this._isRunning) {
      if (!this.rendering)
        this.scheduleRenderTimer();
      return;
    }
    if (this.rendering) {
      this.immediateRerenderRequested = true;
      this.ordinaryFrameWaitControlState = this._controlState;
      return;
    }
    if (!this.cancelReadyFrame && !this.renderTimeout) {
      const delay = this.nextFrameDelay();
      if (delay === 0)
        this.queueFrame();
      else
        this.scheduleFrame(delay);
    }
  }
  get consoleMode() {
    return this._useConsole ? "console-overlay" : "disabled";
  }
  set consoleMode(mode) {
    this._useConsole = mode === "console-overlay";
    if (this._useConsole) {
      this._console.activate();
    } else {
      this._console.deactivate();
    }
  }
  get isRunning() {
    return this._isRunning;
  }
  hasScheduledWork() {
    return Boolean(this.renderTimeout || this.cancelReadyFrame || this.outputIdleRenderScheduled || this.immediateRerenderRequested || this.nativeTerminalTransition || this.nativeResizeWait || this.pendingNativeResize && this._controlState !== "explicit_suspended" /* EXPLICIT_SUSPENDED */);
  }
  isIdleNow() {
    return this._isDestroyed || !this._isRunning && !this.rendering && !this.hasScheduledWork();
  }
  resolveIdleIfNeeded() {
    if (!this.isIdleNow())
      return;
    const resolvers = this.idleResolvers.splice(0);
    for (const resolve of resolvers) {
      resolve();
    }
  }
  idle() {
    if (this._isDestroyed)
      return this.closed;
    const idle = this.isIdleNow() ? Promise.resolve() : new Promise((resolve) => {
      this.idleResolvers.push(resolve);
    });
    return idle.then(() => this.nativeSession.idle());
  }
  getSchedulerState() {
    return {
      isRunning: this._isRunning,
      isRendering: this.rendering,
      hasScheduledRender: this.hasScheduledWork()
    };
  }
  get resolution() {
    return this._resolution;
  }
  get console() {
    return this._console;
  }
  get keyInput() {
    return this._keyHandler;
  }
  get _internalKeyInput() {
    return this._keyHandler;
  }
  get terminalWidth() {
    return this._terminalWidth;
  }
  get terminalHeight() {
    return this._terminalHeight;
  }
  get targetFps() {
    return this._targetFps;
  }
  set targetFps(targetFps) {
    this._targetFps = targetFps;
    this.targetFrameTime = 1000 / this._targetFps;
  }
  get maxFps() {
    return this._maxFps;
  }
  set maxFps(maxFps) {
    this._maxFps = maxFps;
    this.minTargetFrameTime = 1000 / this._maxFps;
  }
  get useMouse() {
    return this._useMouse;
  }
  set useMouse(useMouse) {
    if (this.nativeTerminalTransition || this._controlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */) {
      throw new Error("Cannot change native scene mouse modes during a terminal transition or suspension");
    }
    if (this._useMouse === useMouse)
      return;
    if (useMouse) {
      this.enableMouse();
      this.requestRender();
    } else {
      this.disableMouse();
      this.requestRender();
    }
  }
  get screenMode() {
    return this.pendingNativeMode?.screenMode ?? this._screenMode;
  }
  set screenMode(mode) {
    if (this.pendingExternalOutputMode === "passthrough" && mode !== "split-footer") {
      this.applyScreenMode(mode);
      return;
    }
    if (this.externalOutputMode === "capture-stdout" && mode !== "split-footer") {
      throw new Error('externalOutputMode "capture-stdout" requires screenMode "split-footer"');
    }
    this.applyScreenMode(mode);
  }
  get footerHeight() {
    return this.pendingNativeMode?.footerHeight ?? this._footerHeight;
  }
  set footerHeight(footerHeight) {
    const normalizedFooterHeight = normalizeFooterHeight(footerHeight);
    if (normalizedFooterHeight === this.footerHeight) {
      return;
    }
    if (this.screenMode === "split-footer") {
      this.applyScreenMode("split-footer", true, true, normalizedFooterHeight);
    } else {
      this._footerHeight = normalizedFooterHeight;
    }
  }
  get externalOutputMode() {
    return this.pendingExternalOutputMode ?? this._externalOutputMode;
  }
  set externalOutputMode(mode) {
    if (mode === "capture-stdout" && this.screenMode !== "split-footer") {
      throw new Error('externalOutputMode "capture-stdout" requires screenMode "split-footer"');
    }
    if (this._isDestroyed) {
      this.pendingExternalOutputMode = null;
      if (mode === "passthrough")
        this.applyExternalOutputMode(mode);
      return;
    }
    if (this.rendering || this.pendingNativeMode || this.externalOutputQueue.size > 0) {
      this.pendingExternalOutputMode = mode;
      this.requestRender();
      return;
    }
    const previousMode = this._externalOutputMode;
    if (previousMode === mode) {
      if (this.pendingExternalOutputMode !== null && this.pendingExternalOutputMode !== mode) {
        this.pendingExternalOutputMode = null;
      }
      return;
    }
    this.pendingExternalOutputMode = null;
    this.applyExternalOutputMode(mode);
    this.afterExternalOutputModeChanged(previousMode, mode);
  }
  applyExternalOutputMode(mode) {
    this._externalOutputMode = mode;
    this.stdout.write = mode === "capture-stdout" ? this.interceptStdoutWrite : this.realStdoutWrite;
  }
  afterExternalOutputModeChanged(previousMode, mode) {
    if (this._screenMode === "split-footer" && this._splitHeight > 0 && mode === "capture-stdout") {
      const previousSurfaceTopLine = this.renderOffset + 1;
      const previousSurfaceHeight = this._splitHeight;
      this.clearPendingSplitFooterTransition();
      this.resetSplitScrollback(this.getSplitCursorSeedRows());
      if (previousMode === "passthrough" && this._terminalIsSetup) {
        const nextSurfaceTopLine = this.renderOffset + 1;
        if (previousSurfaceTopLine !== nextSurfaceTopLine) {
          this.setPendingSplitFooterTransition({
            mode: "clear-stale-rows",
            sourceTopLine: previousSurfaceTopLine,
            sourceHeight: previousSurfaceHeight,
            targetTopLine: nextSurfaceTopLine,
            targetHeight: this._splitHeight,
            scrollLines: 0
          });
          this.forceFullRepaintRequested = true;
        }
      }
      this.requestRender();
      return;
    }
    if (this._screenMode === "split-footer" && this._splitHeight > 0 && previousMode === "capture-stdout" && mode === "passthrough") {
      this.clearPendingSplitFooterTransition();
      return;
    }
    this.syncSplitFooterState();
  }
  applyPendingExternalOutputModeIfReady() {
    if (this.rendering)
      return;
    const pendingMode = this.pendingExternalOutputMode;
    if (pendingMode === null || this.externalOutputQueue.size > 0 && !(pendingMode === "capture-stdout" && this._screenMode === "split-footer")) {
      return;
    }
    const previousMode = this._externalOutputMode;
    this.pendingExternalOutputMode = null;
    if (previousMode === pendingMode) {
      return;
    }
    this.applyExternalOutputMode(pendingMode);
    this.afterExternalOutputModeChanged(previousMode, pendingMode);
  }
  get liveRequestCount() {
    return this.liveRequestCounter;
  }
  get currentControlState() {
    return this._controlState;
  }
  get capabilities() {
    return this._capabilities;
  }
  get kittyImageTransport() {
    return this.kittyTransportMode;
  }
  set kittyImageTransport(mode) {
    const code = KITTY_IMAGE_TRANSPORTS.indexOf(mode);
    if (code < 0)
      throw new TypeError("Invalid kittyImageTransport");
    if (this._isDestroyed || mode === this.kittyTransportMode)
      return;
    this.kittyTransportMode = mode;
    this.startKittyTransportPolling();
    this.nativeSession.setKittyImageTransport(code);
    this.requestRender();
  }
  startKittyTransportPolling() {
    if (!this._terminalIsSetup || this.kittyTransportMode !== "file" || this.kittyTransportTimer !== null)
      return;
    this.kittyTransportTimer = this.clock.setInterval(() => {
      if (!this._isDestroyed && this.nativeSession.pollKittyImageTransport())
        this.requestRender();
    }, 1000);
  }
  get kittyImageTransportStatus() {
    const status = this.nativeSession.getKittyImageTransport();
    return {
      requested: KITTY_IMAGE_TRANSPORTS[status.requested],
      effective: ["raw", "zlib", "png", "file"][status.effective],
      fileState: ["disabled", "probing", "ready", "unsupported", "timeout", "io-error", "cancelled"][status.fileState],
      fallback: ["none", "not-ready", "unavailable", "budget", "busy", "preparation", "compression"][status.fallback],
      pendingFiles: status.pendingFiles,
      pendingBytes: status.pendingBytes
    };
  }
  cancelKittyImageTransport() {
    if (this._isDestroyed)
      return;
    this.nativeSession.cancelKittyImageTransport(false);
    this.requestRender();
  }
  triggerNotification(message, title) {
    if (this._isDestroyed)
      return false;
    return this.nativeSession.triggerNotification(message, title);
  }
  setProgramStatus(status) {
    if (this._isDestroyed)
      return false;
    return this.nativeSession.setProgramStatus(status);
  }
  get themeMode() {
    return this.themeModeState.themeMode;
  }
  waitForThemeMode(timeoutMs = 1000) {
    if (!Number.isFinite(timeoutMs) || timeoutMs < 0) {
      throw new Error("timeoutMs must be a non-negative finite number");
    }
    return this.themeModeState.waitForThemeMode(timeoutMs, this._isDestroyed);
  }
  getDebugInputs() {
    return [...this._debugInputs];
  }
  get useKittyKeyboard() {
    return this.nativeKittyKeyboardFlags !== 0;
  }
  set useKittyKeyboard(use) {
    const flags = use ? KITTY_FLAG_DISAMBIGUATE | KITTY_FLAG_ALTERNATE_KEYS : 0;
    this.enableKittyKeyboard(flags);
  }
  createScrollbackSurface(options = {}) {
    if (this._isDestroyed)
      throw new Error("Renderer is destroyed");
    if (this.screenMode !== "split-footer" || this.externalOutputMode !== "capture-stdout") {
      throw new Error('createScrollbackSurface requires screenMode "split-footer" and externalOutputMode "capture-stdout"');
    }
    const renderer = this;
    const surfaceId = scrollbackSurfaceCounter++;
    const startOnNewLine = options.startOnNewLine ?? true;
    const tailColumn = renderer.getPendingSplitTailColumn();
    const firstLineOffset = !startOnNewLine && tailColumn > 0 && tailColumn < renderer.width ? tailColumn : 0;
    const snapshotContext = new ScrollbackSnapshotRenderContext(renderer.width, 1, renderer.widthMethod, renderer._terminalWidth, renderer._terminalHeight, renderer.resolution, renderer.capabilities, renderer.nativeSession);
    let firstLineOffsetOwner = null;
    const renderContext = Object.create(snapshotContext);
    Object.defineProperty(renderContext, "claimFirstLineOffset", {
      value: (renderable) => {
        if (firstLineOffsetOwner?.isDestroyed) {
          firstLineOffsetOwner = null;
        }
        if (firstLineOffsetOwner) {
          return 0;
        }
        firstLineOffsetOwner = renderable ?? null;
        return firstLineOffset;
      },
      enumerable: true,
      configurable: true
    });
    let internalRoot;
    let publicRoot;
    let backingBuffer;
    try {
      internalRoot = new RootRenderable2(renderContext);
      snapshotContext.root = internalRoot;
      publicRoot = new BoxRenderable2(renderContext, {
        id: `scrollback-surface-root-${surfaceId}`,
        position: "absolute",
        left: 0,
        top: 0,
        width: renderer.width,
        height: "auto",
        border: false,
        backgroundColor: "transparent",
        shouldFill: false,
        flexDirection: "column"
      });
      internalRoot.add(publicRoot);
      backingBuffer = OptimizedBuffer2.create(renderer.width, 1, renderer.widthMethod, {
        id: `scrollback-surface-buffer-${surfaceId}`,
        owner: renderer.nativeScene
      });
    } catch (error) {
      runCleanups([() => internalRoot?.destroyRecursively(), () => snapshotContext.destroy()]);
      throw error;
    }
    const readGeometry = () => [
      renderer.width,
      renderer.widthMethod,
      renderer._terminalWidth,
      renderer._terminalHeight,
      renderer.resolution?.width,
      renderer.resolution?.height
    ].join();
    let renderedGeometry = readGeometry();
    let surfaceWidth = renderer.width;
    let surfaceHeight = 1;
    let surfaceDestroyed = false;
    let hasRendered = false;
    let nextCommitStartOnNewLine = startOnNewLine;
    const pendingWaits = new Set;
    const capabilitiesListener = (capabilities) => {
      snapshotContext.capabilities = capabilities;
      renderContext.emit("capabilities" /* CAPABILITIES */, capabilities);
    };
    const assertNotDestroyed = () => {
      if (surfaceDestroyed) {
        throw new Error("ScrollbackSurface is destroyed");
      }
    };
    const assertRendered = () => {
      if (!hasRendered) {
        throw new Error("ScrollbackSurface.commitRows requires render() before commitRows()");
      }
    };
    const assertGeometryStillCurrent = () => {
      if (readGeometry() !== renderedGeometry) {
        throw new Error("ScrollbackSurface.commitRows requires render() after renderer geometry changes");
      }
    };
    const assertRowRange = (startRow, endRowExclusive) => {
      if (!Number.isInteger(startRow) || !Number.isInteger(endRowExclusive)) {
        throw new Error("ScrollbackSurface.commitRows requires finite integer row bounds");
      }
      if (startRow < 0) {
        throw new Error("ScrollbackSurface.commitRows requires startRow >= 0");
      }
      if (endRowExclusive < startRow) {
        throw new Error("ScrollbackSurface.commitRows requires endRowExclusive >= startRow");
      }
      if (endRowExclusive > surfaceHeight) {
        throw new Error("ScrollbackSurface.commitRows row range exceeds rendered surface height");
      }
    };
    const collectPendingResources = (node) => {
      const pending = [];
      for (const resource of snapshotContext.nativeScene.getRenderables()) {
        if (resource.isDestroyed)
          continue;
        const promise = resource instanceof CodeRenderable2 && resource.isHighlighting ? resource.highlightingDone : resource instanceof ImageRenderable2 && resource.loading ? resource.loadPromise : null;
        if (!promise)
          continue;
        let ancestor = resource;
        while (ancestor && ancestor !== node)
          ancestor = ancestor.parent;
        if (ancestor === node)
          pending.push(promise);
      }
      return pending;
    };
    const waitForPendingHighlights = async (pending, timeoutMs) => {
      await new Promise((resolve, reject) => {
        let settled = false;
        const finish = (error) => {
          if (settled)
            return;
          settled = true;
          renderer.clock.clearTimeout(timeoutHandle);
          pendingWaits.delete(cancel);
          if (error)
            reject(error);
          else
            resolve();
        };
        const cancel = () => finish(new Error("ScrollbackSurface is destroyed"));
        const timeoutHandle = renderer.clock.setTimeout(() => finish(new Error("ScrollbackSurface.settle timed out waiting for CodeRenderable highlighting")), timeoutMs);
        pendingWaits.add(cancel);
        Promise.all(pending).then(() => finish(), finish);
      });
    };
    const renderSurface = () => {
      assertNotDestroyed();
      hasRendered = false;
      const geometry = readGeometry();
      const width = renderer.width;
      const widthMethod = renderer.widthMethod;
      snapshotContext.width = width;
      snapshotContext.widthMethod = widthMethod;
      snapshotContext.terminalWidth = renderer._terminalWidth;
      snapshotContext.terminalHeight = renderer._terminalHeight;
      snapshotContext.resolution = renderer.resolution;
      snapshotContext.capabilities = renderer.capabilities;
      publicRoot.width = width;
      let targetHeight = Math.max(1, surfaceHeight);
      if (backingBuffer.widthMethod !== widthMethod) {
        const replacement = OptimizedBuffer2.create(width, targetHeight, widthMethod, {
          id: `scrollback-surface-buffer-${surfaceId}`,
          owner: renderer.nativeScene
        });
        backingBuffer.destroy();
        backingBuffer = replacement;
      }
      for (let pass = 0;; pass += 1) {
        snapshotContext.height = targetHeight;
        internalRoot.resize(width, targetHeight);
        backingBuffer.resize(width, targetHeight);
        backingBuffer.clear(TRANSPARENT_RGBA);
        snapshotContext.frameId += 1;
        snapshotContext.renderSnapshot(internalRoot, backingBuffer);
        const measuredHeight = Math.max(1, publicRoot.height);
        if (pass === MAX_SCROLLBACK_SURFACE_HEIGHT_PASSES || measuredHeight === targetHeight)
          break;
        targetHeight = measuredHeight;
      }
      renderedGeometry = geometry;
      surfaceWidth = width;
      surfaceHeight = targetHeight;
      hasRendered = true;
    };
    const settleSurface = async (timeoutMs = 2000) => {
      assertNotDestroyed();
      if (!Number.isFinite(timeoutMs) || timeoutMs < 0)
        throw new Error("ScrollbackSurface.settle requires a finite non-negative timeout");
      const startedAt = renderer.clock.now();
      renderSurface();
      while (true) {
        assertNotDestroyed();
        const pending = collectPendingResources(publicRoot);
        if (pending.length === 0) {
          return;
        }
        const remainingMs = timeoutMs - (renderer.clock.now() - startedAt);
        if (remainingMs <= 0) {
          throw new Error("ScrollbackSurface.settle timed out waiting for CodeRenderable highlighting");
        }
        await waitForPendingHighlights(pending, remainingMs);
        assertNotDestroyed();
        renderSurface();
      }
    };
    const commitRows = (startRow, endRowExclusive, commitOptions = {}) => {
      assertNotDestroyed();
      assertRendered();
      assertGeometryStillCurrent();
      assertRowRange(startRow, endRowExclusive);
      if (startRow === endRowExclusive) {
        return;
      }
      const rowCount = endRowExclusive - startRow;
      const commitBuffer = OptimizedBuffer2.create(surfaceWidth, rowCount, backingBuffer.widthMethod, {
        id: `scrollback-surface-commit-${surfaceId}`,
        owner: renderer.nativeScene
      });
      try {
        commitBuffer.drawFrameBuffer(0, 0, backingBuffer, 0, startRow, surfaceWidth, rowCount);
        renderer.enqueueRenderedScrollbackCommit({
          snapshot: commitBuffer,
          rowColumns: commitOptions.rowColumns,
          startOnNewLine: nextCommitStartOnNewLine,
          trailingNewline: commitOptions.trailingNewline ?? true
        });
        nextCommitStartOnNewLine = false;
      } catch (error) {
        if (!renderer.externalOutputQueue.owns(commitBuffer))
          commitBuffer.destroy();
        throw error;
      }
    };
    const destroySurface = () => {
      if (surfaceDestroyed) {
        return;
      }
      surfaceDestroyed = true;
      renderer.detachedSurfaces.delete(destroySurface);
      renderer.off("capabilities" /* CAPABILITIES */, capabilitiesListener);
      for (const cancel of pendingWaits)
        cancel();
      runCleanups([
        () => internalRoot.destroyRecursively(),
        () => backingBuffer.destroy(),
        () => renderContext.removeAllListeners(),
        () => snapshotContext.destroy()
      ]);
    };
    renderer.detachedSurfaces.add(destroySurface);
    renderer.on("capabilities" /* CAPABILITIES */, capabilitiesListener);
    return {
      get renderContext() {
        return renderContext;
      },
      get root() {
        return publicRoot;
      },
      get width() {
        return surfaceWidth;
      },
      get height() {
        return surfaceHeight;
      },
      get isDestroyed() {
        return surfaceDestroyed;
      },
      render: renderSurface,
      settle: settleSurface,
      commitRows,
      destroy: destroySurface
    };
  }
  writeToScrollback(write) {
    if (this._isDestroyed)
      throw new Error("Renderer is destroyed");
    if (this.screenMode !== "split-footer" || this.externalOutputMode !== "capture-stdout") {
      throw new Error('writeToScrollback requires screenMode "split-footer" and externalOutputMode "capture-stdout"');
    }
    const snapshotContext = new ScrollbackSnapshotRenderContext(this.width, this.height, this.widthMethod, this._terminalWidth, this._terminalHeight, this.resolution, this.capabilities, this.nativeSession);
    let snapshot;
    let renderFailed = false;
    let snapshotRoot = null;
    let snapshotBuffer = null;
    try {
      snapshotRoot = new RootRenderable2(snapshotContext);
      snapshotContext.root = snapshotRoot;
      snapshot = write({
        width: this.width,
        widthMethod: this.widthMethod,
        tailColumn: this.getPendingSplitTailColumn(),
        renderContext: snapshotContext
      });
      if (!snapshot || !snapshot.root)
        throw new Error("writeToScrollback must return a snapshot root renderable");
      const rootRenderable = snapshot.root;
      const snapshotWidth = this.getSnapshotDimension("width", snapshot.width, rootRenderable.width, this.width);
      const snapshotHeight = this.getSnapshotDimension("height", snapshot.height, rootRenderable.height, Infinity);
      snapshotContext.width = snapshotWidth;
      snapshotContext.height = snapshotHeight;
      snapshotContext.widthMethod = this.widthMethod;
      snapshotRoot.resize(snapshotWidth, snapshotHeight);
      snapshotBuffer = OptimizedBuffer2.create(snapshotWidth, snapshotHeight, this.widthMethod, {
        id: "scrollback-snapshot-commit",
        owner: this.nativeScene
      });
      snapshotRoot.add(rootRenderable);
      snapshotContext.renderSnapshot(snapshotRoot, snapshotBuffer);
      this.enqueueRenderedScrollbackCommit({
        snapshot: snapshotBuffer,
        rowColumns: snapshot.rowColumns,
        startOnNewLine: snapshot.startOnNewLine,
        trailingNewline: snapshot.trailingNewline
      });
    } catch (error) {
      renderFailed = true;
      if (snapshotBuffer && !this.externalOutputQueue.owns(snapshotBuffer))
        snapshotBuffer.destroy();
      throw error;
    } finally {
      try {
        runCleanups([
          () => snapshotRoot?.destroyRecursively(),
          () => snapshot?.teardown?.(),
          () => snapshotContext.destroy()
        ]);
      } catch (error) {
        if (!renderFailed)
          throw error;
      }
    }
  }
  resetSplitFooterForReplay(options = {}) {
    if (this._isDestroyed)
      return;
    if (this._screenMode !== "split-footer" || this._externalOutputMode !== "capture-stdout") {
      throw new Error('resetSplitFooterForReplay requires screenMode "split-footer" and externalOutputMode "capture-stdout"');
    }
    if (!this._terminalIsSetup || this._controlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */) {
      throw new Error("resetSplitFooterForReplay requires an active terminal");
    }
    if (this.rendering || this.externalOutputQueue.size > 0) {
      this.pendingNativeReplay = { options, remaining: this.externalOutputQueue.size };
      this.requestRender();
      return;
    }
    this.applySplitFooterReplayReset(options);
  }
  applySplitFooterReplayReset(options) {
    const bytes = this.lib.encoder.encode(ANSI.resetScrollRegion + ANSI.reset + ANSI.home + ANSI.clearScreen + (options.clearSavedLines ? ANSI.clearSavedLines : "") + ANSI.home);
    if (!this.nativeSession.write(bytes))
      throw new NativeError2("Native terminal output", -11 /* OutputBackpressure */);
    this.abortSplitStartupCursorSeed();
    this.clearPendingSplitFooterTransition();
    this.resetSplitScrollback();
    this.pendingNativeReplay = null;
    this.forceFullRepaintRequested = true;
    this.requestRender();
  }
  getSnapshotDimension(axis, value, fallback, max) {
    const rawValue = value ?? fallback;
    if (!Number.isFinite(rawValue)) {
      throw new Error(`writeToScrollback produced a non-finite ${axis}`);
    }
    return Math.min(Math.max(Math.trunc(rawValue), 1), Math.max(max, 1));
  }
  advanceSplitTailColumn(tailColumn, columns, width) {
    if (columns <= 0) {
      return tailColumn;
    }
    let tail = tailColumn;
    let remaining = columns;
    while (remaining > 0) {
      if (tail >= width) {
        tail = 0;
      }
      const step = Math.min(remaining, width - tail);
      tail += step;
      remaining -= step;
      if (remaining > 0 && tail >= width) {
        tail = 0;
      }
    }
    return tail;
  }
  getSplitTailColumnAfterCommit(commit, initialTailColumn, width) {
    let tailColumn = initialTailColumn;
    if (commit.startOnNewLine && tailColumn > 0) {
      tailColumn = 0;
    }
    const rowWidths = commit.rowWidths;
    for (const [index, rowWidth] of rowWidths.entries()) {
      tailColumn = this.advanceSplitTailColumn(tailColumn, rowWidth, width);
      if (index < rowWidths.length - 1 || commit.trailingNewline) {
        tailColumn = 0;
      }
    }
    return tailColumn;
  }
  recordSplitCommit(commit) {
    this.splitTailColumn = this.getSplitTailColumnAfterCommit(commit, this.splitTailColumn, Math.max(this.width, 1));
  }
  getPendingSplitTailColumn() {
    const width = Math.max(this.width, 1);
    const skipped = this.pendingNativeReplay?.remaining ?? 0;
    const cached = this.queuedSplitTail;
    if (this.externalOutputQueue.size > skipped && cached?.width === width)
      return cached.column;
    let tailColumn = this.pendingNativeReplay ? 0 : this.splitTailColumn;
    for (const commit of this.externalOutputQueue.peek().slice(skipped)) {
      tailColumn = this.getSplitTailColumnAfterCommit(commit, tailColumn, width);
    }
    return tailColumn;
  }
  enqueueRenderedScrollbackCommit(options) {
    if (this.screenMode !== "split-footer" || this.externalOutputMode !== "capture-stdout") {
      throw new Error('scrollback commit requires screenMode "split-footer" and externalOutputMode "capture-stdout"');
    }
    const rowColumns = Math.min(Math.max(Math.trunc(options.rowColumns ?? options.snapshot.width), 0), options.snapshot.width);
    this.enqueueSplitCommits([
      {
        snapshot: options.snapshot,
        rowColumns,
        startOnNewLine: Boolean(options.startOnNewLine ?? true),
        trailingNewline: Boolean(options.trailingNewline ?? true)
      }
    ]);
  }
  enqueueSplitCommits(commits) {
    for (const commit of commits)
      commit.nativeSnapshot = commit.snapshot._getSceneHandle(this.nativeScene);
    const width = Math.max(this.width, 1);
    let column = this.getPendingSplitTailColumn();
    for (const entry of this.externalOutputQueue.writeSnapshots(commits)) {
      column = this.getSplitTailColumnAfterCommit(entry, column, width);
    }
    this.queuedSplitTail = { column, width };
    this.requestRender();
    if (this.listenerCount("external_output" /* EXTERNAL_OUTPUT */) > 0) {
      for (const commit of commits)
        this.emit("external_output" /* EXTERNAL_OUTPUT */, commit);
    }
  }
  splitStdoutRows(text) {
    const width = Math.max(1, this.width);
    const tailColumn = this.getPendingSplitTailColumn();
    const rows = [];
    let rowStart = 0;
    let line = "";
    let cells = 0;
    for (const { segment } of graphemeSegmenter2.segment(text)) {
      if (segment === "\r") {
        rows.length = rowStart;
        line = "";
        cells = 0;
        continue;
      }
      if (segment === `
` || segment === `\r
`) {
        rows.push({ line, cells, trailingNewline: true });
        rowStart = rows.length;
        line = "";
        cells = 0;
        continue;
      }
      const column = (rows.length === 0 && tailColumn < width ? tailColumn : 0) + cells;
      const tabCells = Math.min(STDOUT_TAB_WIDTH - column % STDOUT_TAB_WIDTH, Math.max(0, width - 1 - column));
      const grapheme = segment === "\t" ? " ".repeat(tabCells) : segment;
      const graphemeCells = stringWidth(grapheme);
      if (column > 0 && column + graphemeCells > width) {
        const padding = Math.max(0, width - column);
        rows.push({ line: line + " ".repeat(padding), cells: cells + padding, trailingNewline: false });
        line = "";
        cells = 0;
      }
      line += grapheme;
      cells += graphemeCells;
    }
    if (line.length > 0) {
      rows.push({ line, cells, trailingNewline: false });
    }
    return rows;
  }
  createStdoutSnapshotCommits(text) {
    const rows = this.splitStdoutRows(text);
    if (rows.length === 0) {
      return [];
    }
    const snapshotContext = new ScrollbackSnapshotRenderContext(this.width, 1, this.widthMethod, this._terminalWidth, this._terminalHeight, this.resolution, this.capabilities, this.nativeSession);
    const commits = [];
    let snapshotRoot;
    try {
      snapshotRoot = new RootRenderable2(snapshotContext);
      const snapshotRenderable = new TextRenderable2(snapshotContext, {
        id: "captured-stdout-snapshot",
        position: "absolute",
        left: 0,
        top: 0,
        height: 1
      });
      snapshotRoot.add(snapshotRenderable);
      for (const { line, cells, trailingNewline } of rows) {
        const snapshotWidth = Math.max(1, cells);
        snapshotContext.width = snapshotWidth;
        snapshotRoot.resize(snapshotWidth, 1);
        snapshotRenderable.width = snapshotWidth;
        snapshotRenderable.content = line;
        const snapshot = OptimizedBuffer2.create(snapshotWidth, 1, this.widthMethod, {
          id: "captured-stdout-snapshot",
          owner: this.nativeScene
        });
        commits.push({ snapshot, rowColumns: cells, startOnNewLine: false, trailingNewline });
        snapshotContext.renderSnapshot(snapshotRoot, snapshot);
      }
      return commits;
    } catch (error) {
      for (const commit of commits)
        commit.snapshot.destroy();
      throw error;
    } finally {
      runCleanups([() => snapshotRoot?.destroyRecursively(), () => snapshotContext.destroy()]);
    }
  }
  interceptStdoutWrite = (chunk, encoding, callback) => {
    const resolvedCallback = typeof encoding === "function" ? encoding : callback;
    const resolvedEncoding = typeof encoding === "string" ? encoding : undefined;
    const text = typeof chunk === "string" ? chunk : chunk?.toString(resolvedEncoding) ?? "";
    if (this._externalOutputMode === "capture-stdout" && this._screenMode === "split-footer" && this._splitHeight > 0) {
      const commits = this.createStdoutSnapshotCommits(text);
      try {
        this.enqueueSplitCommits(commits);
      } catch (error) {
        for (const commit of commits) {
          if (!this.externalOutputQueue.owns(commit.snapshot))
            commit.snapshot.destroy();
        }
        throw error;
      }
    }
    if (typeof resolvedCallback === "function") {
      process.nextTick(resolvedCallback);
    }
    return true;
  };
  getSplitPinnedRenderOffset() {
    return this._screenMode === "split-footer" ? Math.max(this._terminalHeight - this._splitHeight, 0) : 0;
  }
  getSplitCursorSeedRows() {
    const cursorState = this.getCursorState();
    const cursorRow = Number.isFinite(cursorState.y) ? Math.max(Math.trunc(cursorState.y), 1) : 1;
    return Math.min(cursorRow, Math.max(this._terminalHeight, 1));
  }
  isSplitCursorSeedFrameBlocked() {
    return this._screenMode === "split-footer" && this._externalOutputMode === "capture-stdout" && this._splitHeight > 0 && this.pendingSplitStartupCursorSeed && this.splitStartupSeedTimeoutId !== null;
  }
  clearSplitStartupCursorSeed() {
    this.pendingSplitStartupCursorSeed = false;
    if (this.splitStartupSeedTimeoutId !== null) {
      this.clock.clearTimeout(this.splitStartupSeedTimeoutId);
      this.splitStartupSeedTimeoutId = null;
    }
  }
  abortSplitStartupCursorSeed() {
    this.clearSplitStartupCursorSeed();
    this.stdinParser?.abortPendingStartupCursorCpr();
    this.updateStdinParserProtocolContext({ startupCursorCprActive: false });
  }
  resetSplitScrollback(seedRows = 0) {
    this.renderOffset = this.lib.sessionSplitControl(this.nativeSession.context, this.nativeSession.session, {
      kind: "reset",
      seedRows,
      pinnedRenderOffset: this.getSplitPinnedRenderOffset()
    });
    this.splitTailColumn = 0;
    this.queuedSplitTail = null;
  }
  syncSplitScrollback() {
    this.renderOffset = this.lib.sessionSplitControl(this.nativeSession.context, this.nativeSession.session, {
      kind: "sync",
      pinnedRenderOffset: this.getSplitPinnedRenderOffset()
    });
  }
  getSplitOutputOffset(surfaceOffset = this.renderOffset) {
    return this.lib.sessionSplitControl(this.nativeSession.context, this.nativeSession.session, {
      kind: "output-offset",
      surfaceOffset
    });
  }
  clearPendingSplitFooterTransition() {
    if (this.pendingSplitFooterTransition === null) {
      return;
    }
    this.lib.sessionSplitControl(this.nativeSession.context, this.nativeSession.session, { kind: "clear-transition" });
    this.pendingSplitFooterTransition = null;
  }
  setPendingSplitFooterTransition(transition) {
    this.lib.sessionSplitControl(this.nativeSession.context, this.nativeSession.session, {
      kind: "transition",
      ...transition
    });
    this.pendingSplitFooterTransition = transition;
  }
  setRenderOffset(offset) {
    this.lib.sessionSplitControl(this.nativeSession.context, this.nativeSession.session, {
      kind: "render-offset",
      renderOffset: offset
    });
    this.renderOffset = offset;
  }
  syncSplitFooterState() {
    const splitActive = this._screenMode === "split-footer" && this._splitHeight > 0;
    if (!splitActive) {
      this.clearPendingSplitFooterTransition();
      this.resetSplitScrollback();
      this.setRenderOffset(0);
      return;
    }
    if (this._externalOutputMode === "capture-stdout") {
      this.syncSplitScrollback();
    } else {
      this.clearPendingSplitFooterTransition();
      this.resetSplitScrollback();
      this.setRenderOffset(this.getSplitPinnedRenderOffset());
    }
  }
  getStaleSplitSurfaceClear(previousTopLine, previousHeight, nextTopLine, nextHeight) {
    if (!this._terminalIsSetup || previousHeight <= 0 || this._terminalHeight <= 0) {
      return "";
    }
    const terminalBottom = this._terminalHeight;
    const previousStart = Math.max(1, previousTopLine);
    const previousEnd = Math.min(terminalBottom, previousTopLine + previousHeight - 1);
    if (previousEnd < previousStart) {
      return "";
    }
    const nextStart = Math.max(1, nextTopLine);
    const nextEnd = Math.min(terminalBottom, nextTopLine + Math.max(nextHeight, 0) - 1);
    let clear = "";
    for (let line = previousStart;line <= previousEnd; line += 1) {
      if (line >= nextStart && line <= nextEnd) {
        continue;
      }
      clear += `${ANSI.moveCursor(line, 1)}\x1B[2K`;
    }
    return clear;
  }
  applyScreenMode(screenMode, emitResize = true, requestRender = true, footerHeight = this._footerHeight) {
    if (this._isDestroyed)
      return;
    if (this.nativeTerminalTransition && this._screenMode !== screenMode) {
      throw new Error("Cannot change native scene screen mode during a terminal transition");
    }
    if (this._screenMode === "split-footer" && screenMode !== "split-footer") {
      this.abortSplitStartupCursorSeed();
    }
    if (this.rendering || this._screenMode === "split-footer" && this.externalOutputQueue.size > 0 || this.nativeTerminalTransition) {
      this.pendingNativeMode = { screenMode, footerHeight };
      this.requestRender();
      return;
    }
    const prevScreenMode = this._screenMode;
    const prevSplitHeight = this._splitHeight;
    const nextGeometry = calculateRenderGeometry(screenMode, this._terminalWidth, this._terminalHeight, footerHeight);
    const nextSplitHeight = nextGeometry.effectiveFooterHeight;
    if (prevScreenMode === screenMode && prevSplitHeight === nextSplitHeight) {
      this._footerHeight = footerHeight;
      this.pendingNativeMode = null;
      return;
    }
    const terminalWritable = this._terminalIsSetup && this._controlState !== "explicit_suspended" /* EXPLICIT_SUSPENDED */;
    const prevUseAlternateScreen = prevScreenMode === "alternate-screen";
    const nextUseAlternateScreen = screenMode === "alternate-screen";
    const terminalScreenModeChanged = this._terminalIsSetup && prevUseAlternateScreen !== nextUseAlternateScreen;
    const leavingSplitFooter = prevSplitHeight > 0 && nextSplitHeight === 0;
    const previousSurfaceTopLine = this.renderOffset + 1;
    const shouldDeferSplitFooterResizeTransition = this._terminalIsSetup && prevScreenMode === "split-footer" && screenMode === "split-footer" && this._externalOutputMode === "capture-stdout" && prevSplitHeight > 0 && nextSplitHeight > 0 && !terminalScreenModeChanged;
    const splitStartupSeedBlocksFirstNativeFrame = this.pendingSplitStartupCursorSeed && this.splitStartupSeedTimeoutId !== null;
    const splitTransitionSourceTopLine = this.pendingSplitFooterTransition?.sourceTopLine ?? previousSurfaceTopLine;
    const splitTransitionSourceHeight = this.pendingSplitFooterTransition?.sourceHeight ?? prevSplitHeight;
    const splitTransitionSourceSurfaceOffset = Math.max(splitTransitionSourceTopLine - 1, 0);
    const splitTransitionSourceOutputOffset = prevScreenMode === "split-footer" && prevSplitHeight > 0 && this._externalOutputMode === "capture-stdout" ? this.getSplitOutputOffset(splitTransitionSourceSurfaceOffset) : splitTransitionSourceSurfaceOffset;
    const nextPinnedRenderOffset = nextGeometry.renderOffset;
    const nextSplitOutputOffset = screenMode === "split-footer" && nextSplitHeight > 0 && this._externalOutputMode === "capture-stdout" ? this.getSplitOutputOffset(nextPinnedRenderOffset) : nextPinnedRenderOffset;
    const pendingSplitFooterTransition = this.pendingSplitFooterTransition;
    const pendingSplitFooterReturn = pendingSplitFooterTransition !== null && nextSplitHeight === splitTransitionSourceHeight;
    const pendingSplitFooterViewportReturn = pendingSplitFooterReturn && pendingSplitFooterTransition.mode === "viewport-scroll" && (pendingSplitFooterTransition.scrollLines ?? 0) > 0;
    const shrinkingSplitFooter = nextSplitHeight > 0 && nextSplitHeight < splitTransitionSourceHeight;
    const growingSplitFooter = nextSplitHeight > splitTransitionSourceHeight && splitTransitionSourceHeight > 0;
    const nextSplitSurfaceOffset = screenMode !== "split-footer" || nextSplitHeight === 0 ? 0 : pendingSplitFooterViewportReturn ? pendingSplitFooterTransition.targetTopLine - 1 : pendingSplitFooterReturn ? splitTransitionSourceSurfaceOffset : shrinkingSplitFooter && splitTransitionSourceSurfaceOffset > 0 ? splitTransitionSourceSurfaceOffset : shrinkingSplitFooter ? nextSplitOutputOffset : growingSplitFooter ? Math.max(nextSplitOutputOffset, Math.min(splitTransitionSourceSurfaceOffset, nextPinnedRenderOffset)) : nextPinnedRenderOffset;
    const splitTransitionTargetTopLine = nextSplitSurfaceOffset + 1;
    const splitViewportScrollLines = pendingSplitFooterViewportReturn ? pendingSplitFooterTransition.scrollLines ?? 0 : nextSplitHeight > 0 && !pendingSplitFooterReturn ? Math.max(splitTransitionSourceOutputOffset - nextSplitOutputOffset, 0) : 0;
    const splitTransitionMode = (!shrinkingSplitFooter || pendingSplitFooterViewportReturn) && splitViewportScrollLines > 0 ? "viewport-scroll" : "clear-stale-rows";
    const splitFooterSurfaceMovesDown = nextSplitSurfaceOffset > splitTransitionSourceSurfaceOffset;
    const splitFooterSurfaceLeavesStaleRows = splitFooterSurfaceMovesDown || shrinkingSplitFooter;
    const shouldClearSplitSurfaceRowsImmediately = terminalWritable && !terminalScreenModeChanged && !shouldDeferSplitFooterResizeTransition && splitFooterSurfaceLeavesStaleRows && nextSplitHeight > 0;
    let scrollOutput = "";
    if (terminalWritable && !terminalScreenModeChanged && !shouldDeferSplitFooterResizeTransition) {
      if (prevSplitHeight === 0 && nextSplitHeight > 0) {
        scrollOutput = ANSI.scrollDown(this._terminalHeight - nextSplitHeight);
      } else if (splitViewportScrollLines > 0) {
        scrollOutput = ANSI.scrollUp(splitViewportScrollLines);
      }
    }
    const clearOutput = terminalWritable && leavingSplitFooter && !terminalScreenModeChanged ? ANSI.moveCursorAndClear(splitTransitionSourceTopLine, 1) : shouldClearSplitSurfaceRowsImmediately ? this.getStaleSplitSurfaceClear(splitTransitionSourceTopLine, splitTransitionSourceHeight, this._externalOutputMode === "capture-stdout" ? splitTransitionTargetTopLine : nextPinnedRenderOffset + 1, nextSplitHeight) : "";
    this.nativeSession.setScreen(nextUseAlternateScreen, nextGeometry.renderWidth, nextGeometry.renderHeight, this.lib.encoder.encode(scrollOutput + clearOutput));
    this._screenMode = screenMode;
    this._footerHeight = footerHeight;
    this._splitHeight = nextSplitHeight;
    this.width = nextGeometry.renderWidth;
    this.height = nextGeometry.renderHeight;
    this.pendingNativeMode = null;
    if (terminalWritable && leavingSplitFooter) {
      this.clearPendingSplitFooterTransition();
      this.renderOffset = 0;
      this.setRenderOffset(0);
    }
    if (this._screenMode === "split-footer" && this._externalOutputMode === "capture-stdout") {
      if (prevScreenMode !== "split-footer") {
        this.resetSplitScrollback(this.getSplitCursorSeedRows());
      } else {
        this.renderOffset = nextSplitSurfaceOffset;
        this.setRenderOffset(this.renderOffset);
      }
      if (shouldDeferSplitFooterResizeTransition) {
        if (splitStartupSeedBlocksFirstNativeFrame) {
          this.clearPendingSplitFooterTransition();
        } else {
          this.setPendingSplitFooterTransition({
            mode: splitTransitionMode,
            sourceTopLine: splitTransitionSourceTopLine,
            sourceHeight: splitTransitionSourceHeight,
            targetTopLine: splitTransitionTargetTopLine,
            targetHeight: nextSplitHeight,
            scrollLines: splitViewportScrollLines
          });
        }
        this.forceFullRepaintRequested = true;
      } else {
        this.clearPendingSplitFooterTransition();
      }
    } else {
      this.syncSplitFooterState();
    }
    this._console.resize(this.width, this.height);
    this.root.resize(this.width, this.height);
    if (emitResize) {
      this.emit("resize" /* RESIZE */, this.width, this.height);
    }
    if (requestRender) {
      this.requestRender();
    }
  }
  applyPendingNativeMode() {
    if (this._isDestroyed || this.rendering || this.nativeSplitFlush || this.nativeTerminalTransition)
      return;
    try {
      if (this.pendingNativeReplay?.remaining === 0)
        this.applySplitFooterReplayReset(this.pendingNativeReplay.options);
      if (this.pendingExternalOutputMode === "capture-stdout" && this._screenMode === "split-footer") {
        this.applyPendingExternalOutputModeIfReady();
      }
      if (this._screenMode === "split-footer" && this.externalOutputQueue.size > 0)
        return;
      if (this.pendingExternalOutputMode === "passthrough")
        this.applyPendingExternalOutputModeIfReady();
      const mode = this.pendingNativeMode;
      if (mode)
        this.applyScreenMode(mode.screenMode, true, true, mode.footerHeight);
      if (!this.pendingNativeMode)
        this.applyPendingExternalOutputModeIfReady();
    } catch (error) {
      if (error instanceof NativeError2 && (error.status === -13 /* OutputBusy */ || error.status === -11 /* OutputBackpressure */)) {
        this.scheduleRenderAfterOutputIdle();
      } else
        throw error;
    }
  }
  applyPendingNativeModeReported() {
    try {
      this.applyPendingNativeMode();
    } catch (error) {
      this.handleError(error);
    }
  }
  enableMouse() {
    if (this._terminalIsSetup)
      this.nativeSession.control({ kind: "mouse", mode: this.enableMouseMovement ? "motion" : "drag" });
    this._useMouse = true;
  }
  disableMouse() {
    if (this._terminalIsSetup && !this._isDestroyed && this._controlState !== "explicit_suspended" /* EXPLICIT_SUSPENDED */) {
      this.nativeSession.control({ kind: "mouse", mode: "disabled" });
    }
    this._useMouse = false;
    this.setCapturedRenderable(undefined);
    this.stdinParser?.resetMouseState();
  }
  enableKittyKeyboard(flags = 3) {
    if (this.nativeTerminalTransition || this._controlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */) {
      throw new Error("Cannot change native scene Kitty modes during a terminal transition or suspension");
    }
    if (!Number.isInteger(flags) || flags < 0 || flags > 31)
      throw new RangeError("Native scene Kitty flags must be in 0..31");
    if (this._terminalIsSetup)
      this.nativeSession.control({ kind: "kitty-keyboard-flags", flags });
    this.nativeKittyKeyboardFlags = flags;
    this.updateStdinParserProtocolContext({ kittyKeyboardEnabled: flags !== 0 });
  }
  disableKittyKeyboard() {
    if (this.nativeTerminalTransition || this._controlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */) {
      throw new Error("Cannot change native scene Kitty modes during a terminal transition or suspension");
    }
    if (this._terminalIsSetup)
      this.nativeSession.control({ kind: "kitty-keyboard-flags", flags: 0 });
    this.nativeKittyKeyboardFlags = 0;
    this.updateStdinParserProtocolContext({ kittyKeyboardEnabled: false }, true);
  }
  async setupTerminal() {
    if (this._terminalIsSetup)
      return;
    if (this.nativeTerminalTransition)
      return this.nativeTerminalTransition;
    const startupCursorCprActive = this._screenMode === "split-footer" && this._externalOutputMode === "capture-stdout";
    this.pendingSplitStartupCursorSeed = startupCursorCprActive;
    this.updateStdinParserProtocolContext({
      privateCapabilityRepliesActive: true,
      explicitWidthCprActive: true,
      startupCursorCprActive
    });
    try {
      await this.trackNativeTerminalTransition(this.nativeSession.setupTerminal({
        useAlternateScreen: this._screenMode === "alternate-screen",
        mouse: this._useMouse,
        mouseMovement: this.enableMouseMovement,
        kittyKeyboardFlags: this.nativeKittyKeyboardFlags,
        clearOnClose: this.clearOnShutdown
      }), () => {
        if (this._isDestroyed)
          return;
        this._terminalIsSetup = true;
        this._capabilities = this.nativeSession.getCapabilities();
        this.startKittyTransportPolling();
        this.nativeSession.startKittyFileProbe();
      });
    } catch (error) {
      this.abortSplitStartupCursorSeed();
      this.updateStdinParserProtocolContext({ privateCapabilityRepliesActive: false, explicitWidthCprActive: false });
      throw error;
    }
    if (this._isDestroyed)
      return;
    if (this.debugOverlay.enabled) {
      this.configureDebugOverlay({});
      if (!this.memorySnapshotInterval) {
        this.memorySnapshotInterval = 3000;
        this.startMemorySnapshotTimer();
        this.automaticMemorySnapshot = true;
      }
    }
    this.capabilityTimeoutId = this.clock.setTimeout(() => {
      this.capabilityTimeoutId = null;
      this.clearSplitStartupCursorSeed();
      if (this._screenMode === "split-footer" && this._externalOutputMode === "capture-stdout") {
        this.requestRender();
      }
      this.removeInputHandler(this.capabilityHandler);
      this.updateStdinParserProtocolContext({
        privateCapabilityRepliesActive: false,
        explicitWidthCprActive: false,
        startupCursorCprActive: false
      }, true);
      this.resolveXtVersionWaiters();
    }, 5000);
    if (this.pendingSplitStartupCursorSeed) {
      if (this.splitStartupSeedTimeoutId !== null) {
        this.clock.clearTimeout(this.splitStartupSeedTimeoutId);
      }
      this.splitStartupSeedTimeoutId = this.clock.setTimeout(() => {
        this.splitStartupSeedTimeoutId = null;
        if (!this.pendingSplitStartupCursorSeed) {
          return;
        }
        this.updateStdinParserProtocolContext({ startupCursorCprActive: false });
        if (this._screenMode === "split-footer" && this._externalOutputMode === "capture-stdout") {
          this.requestRender();
        }
        if (this.externalOutputQueue.size > 0)
          this.requestRender();
      }, 120);
    }
    this.queryPixelResolution();
    if (this.shouldSyncNativePaletteState()) {
      this.refreshPalette();
    }
  }
  trackNativeTerminalTransition(transition, complete) {
    const tracked = transition.then(() => complete?.()).finally(() => {
      if (this.nativeTerminalTransition === tracked)
        this.nativeTerminalTransition = null;
      this.applyPendingNativeModeReported();
      this.applyPendingNativeResize();
      this.resolveIdleIfNeeded();
    });
    this.nativeTerminalTransition = tracked;
    tracked.catch((error) => {
      if (this.canRender && !this.nativeSession.isCloseInterruption(error)) {
        this.handleError(error);
      }
    });
    return tracked;
  }
  stdinListener = ((chunk) => {
    const data = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    if (!this.stdinParser)
      return;
    if (this.stdinLogPath) {
      appendFileSync(this.stdinLogPath, data);
    }
    try {
      this.stdinParser.push(data);
      this.drainStdinParser();
    } catch (error) {
      this.handleStdinParserFailure(error);
    }
  }).bind(this);
  addInputHandler(handler) {
    this.sequenceHandlers.push(handler);
  }
  prependInputHandler(handler) {
    this.sequenceHandlers.unshift(handler);
  }
  removeInputHandler(handler) {
    this.sequenceHandlers = this.sequenceHandlers.filter((candidate) => candidate !== handler);
  }
  updateStdinParserProtocolContext(patch, drain = false) {
    if (!this.stdinParser)
      return;
    this.stdinParser.updateProtocolContext(patch);
    if (drain)
      this.drainStdinParser();
  }
  subscribeOsc(handler) {
    this.oscSubscribers.add(handler);
    return () => {
      this.oscSubscribers.delete(handler);
    };
  }
  processCapabilitySequence(sequence, hasCursorReport) {
    const hasStandardCapabilitySignature = isCapabilityResponse(sequence);
    const shouldProcessAsCapability = hasStandardCapabilitySignature || hasCursorReport && (this.capabilityTimeoutId !== null || this.nativeTerminalTransition !== null);
    if (!shouldProcessAsCapability) {
      return false;
    }
    try {
      this.nativeSession.control({ kind: "capability-response", bytes: Buffer.from(sequence) });
    } catch (error) {
      if (!(error instanceof NativeError2))
        throw error;
      return error.status !== -19 /* InvalidPhase */;
    }
    this._capabilities = this.nativeSession.getCapabilities();
    if (this._capabilities?.terminal?.from_xtversion) {
      this.resolveXtVersionWaiters();
    }
    if (hasStandardCapabilitySignature) {
      this.forceFullRepaintRequested = true;
      this.requestRender();
    }
    this.emit("capabilities" /* CAPABILITIES */, this._capabilities);
    const hadPendingSplitStartupCursorSeed = this.pendingSplitStartupCursorSeed;
    if (hadPendingSplitStartupCursorSeed && hasCursorReport && this._screenMode === "split-footer" && this._externalOutputMode === "capture-stdout") {
      this.resetSplitScrollback(this.getSplitCursorSeedRows());
      this.clearPendingSplitFooterTransition();
      this.clearSplitStartupCursorSeed();
      this.updateStdinParserProtocolContext({ startupCursorCprActive: false });
      this.requestRender();
    }
    const consumeStartupCursorReport = hadPendingSplitStartupCursorSeed && hasCursorReport && this.splitStartupSeedTimeoutId !== null;
    return hasStandardCapabilitySignature || consumeStartupCursorReport;
  }
  capabilityHandler = ((sequence) => {
    return this.processCapabilitySequence(sequence, false);
  }).bind(this);
  focusHandler = ((sequence) => {
    if (sequence === "\x1B[I") {
      if (this.shouldRestoreModesOnNextFocus) {
        this.nativeSession.control({ kind: "restore-modes" });
        this.shouldRestoreModesOnNextFocus = false;
      }
      if (this._terminalFocusState !== true) {
        this._terminalFocusState = true;
        this.emit("focus" /* FOCUS */);
      }
      return true;
    }
    if (sequence === "\x1B[O") {
      this.shouldRestoreModesOnNextFocus = true;
      if (this._terminalFocusState !== false) {
        this._terminalFocusState = false;
        this.emit("blur" /* BLUR */);
      }
      return true;
    }
    return false;
  }).bind(this);
  dispatchSequenceHandlers(sequence) {
    if (this._debugModeEnabled) {
      this._debugInputs.push({
        timestamp: new Date().toISOString(),
        sequence
      });
    }
    for (const handler of this.sequenceHandlers) {
      if (handler(sequence)) {
        return true;
      }
    }
    return false;
  }
  drainStdinParser() {
    if (!this.stdinParser)
      return;
    this.stdinParser.drain((event) => {
      this.handleStdinEvent(event);
    });
  }
  handleStdinEvent(event) {
    if (event.type === "response" && event.sequence.startsWith("\x1B_G")) {
      try {
        const result = this.nativeSession.processKittyImageReply(Buffer.from(event.sequence));
        if (result !== 0) {
          if (result === 2)
            this.requestRender();
          return;
        }
      } catch (error) {
        if (!(error instanceof NativeError2) || error.status !== -12 /* SessionClosed */ && error.status !== -9 /* StaleHandle */ && error.status !== -18 /* RendererNotAttached */) {
          throw error;
        }
      }
    }
    if (this._controlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */) {
      if (event.type === "response" && isPixelResolutionResponse(event.sequence)) {
        this.dispatchSequenceHandlers(event.sequence);
      }
      return;
    }
    switch (event.type) {
      case "key":
        if (this.dispatchSequenceHandlers(event.raw)) {
          return;
        }
        this._keyHandler.processParsedKey(event.key);
        return;
      case "mouse":
        if (this._useMouse && this.processSingleMouseEvent(event.event)) {
          return;
        }
        this.dispatchSequenceHandlers(event.raw);
        return;
      case "paste":
        this._keyHandler.processPaste(event.bytes, event.metadata);
        return;
      case "response":
        if (event.protocol === "osc") {
          for (const subscriber of this.oscSubscribers) {
            subscriber(event.sequence);
          }
        }
        if (event.protocol === "cpr" && this.processCapabilitySequence(event.sequence, true)) {
          return;
        }
        this.dispatchSequenceHandlers(event.sequence);
        return;
    }
  }
  handleStdinParserFailure(error) {
    if (!this.hasLoggedStdinParserError) {
      this.hasLoggedStdinParserError = true;
      if (true) {
        console.error("[stdin-parser-error] parser failure, resetting parser", error);
      }
    }
    try {
      this.stdinParser?.reset();
    } catch (resetError) {
      console.error("stdin parser reset failed after parser error", resetError);
    }
  }
  setupInput() {
    if (this.stdinLogPath) {
      writeFileSync(this.stdinLogPath, Buffer.alloc(0), { mode: 384 });
    }
    for (const handler of this.prependedInputHandlers) {
      this.addInputHandler(handler);
    }
    this.addInputHandler((sequence) => {
      if (isPixelResolutionResponse(sequence) && this.waitingForPixelResolution) {
        this.waitingForPixelResolution = false;
        if (this.pixelResolutionRequeryPending) {
          this.updateStdinParserProtocolContext({ pixelResolutionQueryActive: false });
          this.queryPixelResolution();
          return true;
        }
        try {
          const resolution = parsePixelResolution(sequence);
          if (resolution) {
            this.lib.sessionSetImageResolution(this.nativeSession.context, this.nativeSession.session, this._terminalWidth, this._terminalHeight, resolution.width, resolution.height);
            this._resolution = resolution;
            this.requestRender();
          }
        } finally {
          this.updateStdinParserProtocolContext({ pixelResolutionQueryActive: false }, true);
        }
        return true;
      }
      return false;
    });
    this.addInputHandler(this.capabilityHandler);
    this.addInputHandler(this.focusHandler);
    this.addInputHandler(this.themeModeHandler);
    if (this.stdin.setRawMode) {
      this.stdin.setRawMode(true);
    }
    this.stdin.on("data", this.stdinListener);
    this.stdin.resume();
    this.startTerminalKeepAlive();
  }
  dispatchMouseEvent(target, attributes) {
    const event = new MouseEvent2(target, attributes);
    this.sendMouseEvent(target, event);
    if (this._isDestroyed || target.isDestroyed)
      return event;
    if (this.autoFocus && event.type === "down" && event.button === 0 /* LEFT */ && !event.defaultPrevented) {
      let current = target;
      while (current) {
        if (current.focusable) {
          current.focus();
          break;
        }
        current = current.parent;
      }
    }
    return event;
  }
  sendMouseEvent(target, event) {
    if (this._isDestroyed || target.isDestroyed)
      return;
    try {
      target.processMouseEvent(event);
    } catch (error) {
      const handled = this.emit("handler:error" /* HANDLER_ERROR */, { error, event });
      if (!handled)
        console.error("Error in mouse handler:", error);
    }
  }
  processSingleMouseEvent(mouseEvent) {
    if (this._splitHeight > 0) {
      if (mouseEvent.y < this.renderOffset) {
        return false;
      }
      mouseEvent.y -= this.renderOffset;
    }
    this._latestPointer.x = mouseEvent.x;
    this._latestPointer.y = mouseEvent.y;
    this._hasPointer = true;
    this._lastPointerModifiers = mouseEvent.modifiers;
    if (this._console.visible) {
      const consoleBounds = this._console.bounds;
      if (mouseEvent.x >= consoleBounds.x && mouseEvent.x < consoleBounds.x + consoleBounds.width && mouseEvent.y >= consoleBounds.y && mouseEvent.y < consoleBounds.y + consoleBounds.height) {
        const event = new MouseEvent2(null, mouseEvent);
        const handled = this._console.handleMouse(event);
        if (handled)
          return true;
      }
    }
    if (mouseEvent.type === "scroll") {
      const maybeRenderableId = this.hitTest(mouseEvent.x, mouseEvent.y);
      const maybeRenderable = Renderable2.renderablesByNumber.get(maybeRenderableId);
      const fallbackTarget = this._currentFocusedRenderable && !this._currentFocusedRenderable.isDestroyed && this._currentFocusedRenderable.focused ? this._currentFocusedRenderable : null;
      const scrollTarget = maybeRenderable ?? fallbackTarget;
      if (scrollTarget) {
        const event = new MouseEvent2(scrollTarget, mouseEvent);
        this.sendMouseEvent(scrollTarget, event);
      }
      return true;
    }
    const maybeRenderableId = this.hitTest(mouseEvent.x, mouseEvent.y);
    const sameElement = maybeRenderableId === this.lastOverRenderableNum;
    this.lastOverRenderableNum = maybeRenderableId;
    const maybeRenderable = Renderable2.renderablesByNumber.get(maybeRenderableId);
    if (mouseEvent.type === "down" && mouseEvent.button === 0 /* LEFT */ && !this.currentSelection?.isDragging && !mouseEvent.modifiers.ctrl) {
      const canStartSelection = Boolean(maybeRenderable && maybeRenderable.selectable && !maybeRenderable.isDestroyed && maybeRenderable.shouldStartSelection(mouseEvent.x, mouseEvent.y));
      if (canStartSelection && maybeRenderable) {
        this.startSelection(maybeRenderable, mouseEvent.x, mouseEvent.y, this.nextClickBehavior(maybeRenderable, mouseEvent.x, mouseEvent.y));
        this.dispatchMouseEvent(maybeRenderable, mouseEvent);
        return true;
      }
    }
    if (mouseEvent.type === "drag" && this.currentSelection?.isDragging) {
      this.updateSelection(maybeRenderable, mouseEvent.x, mouseEvent.y);
      if (maybeRenderable) {
        const event = new MouseEvent2(maybeRenderable, {
          ...mouseEvent,
          isDragging: true
        });
        this.sendMouseEvent(maybeRenderable, event);
      }
      return true;
    }
    if (mouseEvent.type === "up" && mouseEvent.button === 0 /* LEFT */ && this.currentSelection?.isDragging) {
      if (maybeRenderable) {
        const event = new MouseEvent2(maybeRenderable, {
          ...mouseEvent,
          isDragging: true
        });
        this.sendMouseEvent(maybeRenderable, event);
      }
      this.finishSelection();
      return true;
    }
    if (mouseEvent.type === "down" && mouseEvent.button === 0 /* LEFT */ && this.currentSelection) {
      if (mouseEvent.modifiers.ctrl) {
        this.currentSelection.isDragging = true;
        this.updateSelection(maybeRenderable, mouseEvent.x, mouseEvent.y);
        return true;
      }
    }
    if (!sameElement && (mouseEvent.type === "drag" || mouseEvent.type === "move")) {
      if (this.lastOverRenderable && this.lastOverRenderable !== this.capturedRenderable && !this.lastOverRenderable.isDestroyed) {
        const event = new MouseEvent2(this.lastOverRenderable, {
          ...mouseEvent,
          type: "out"
        });
        this.sendMouseEvent(this.lastOverRenderable, event);
      }
      this.lastOverRenderable = maybeRenderable;
      if (maybeRenderable) {
        const event = new MouseEvent2(maybeRenderable, {
          ...mouseEvent,
          type: "over",
          source: this.capturedRenderable
        });
        this.sendMouseEvent(maybeRenderable, event);
      }
    }
    if (this.capturedRenderable && mouseEvent.type !== "up") {
      const event = new MouseEvent2(this.capturedRenderable, mouseEvent);
      this.sendMouseEvent(this.capturedRenderable, event);
      return true;
    }
    if (this.capturedRenderable && mouseEvent.type === "up") {
      const event = new MouseEvent2(this.capturedRenderable, {
        ...mouseEvent,
        type: "drag-end"
      });
      this.sendMouseEvent(this.capturedRenderable, event);
      this.sendMouseEvent(this.capturedRenderable, new MouseEvent2(this.capturedRenderable, mouseEvent));
      if (maybeRenderable) {
        const event = new MouseEvent2(maybeRenderable, {
          ...mouseEvent,
          type: "drop",
          source: this.capturedRenderable
        });
        this.sendMouseEvent(maybeRenderable, event);
      }
      this.lastOverRenderable = this.capturedRenderable;
      this.lastOverRenderableNum = this.capturedRenderable.num;
      this.setCapturedRenderable(undefined);
      this.requestRender();
    }
    let event;
    if (maybeRenderable) {
      if (mouseEvent.type === "drag" && mouseEvent.button === 0 /* LEFT */) {
        this.setCapturedRenderable(maybeRenderable);
      } else {
        this.setCapturedRenderable(undefined);
      }
      event = this.dispatchMouseEvent(maybeRenderable, mouseEvent);
    } else {
      this.setCapturedRenderable(undefined);
      this.lastOverRenderable = undefined;
    }
    if (!event?.defaultPrevented && mouseEvent.type === "down" && mouseEvent.button === 0 /* LEFT */ && this.currentSelection) {
      this.clearSelection();
    }
    return true;
  }
  recheckHoverState() {
    if (this._isDestroyed || !this._hasPointer)
      return;
    if (this.capturedRenderable)
      return;
    const hitId = this.hitTest(this._latestPointer.x, this._latestPointer.y);
    const hitRenderable = Renderable2.renderablesByNumber.get(hitId);
    const lastOver = this.lastOverRenderable;
    if (lastOver?.num === hitId) {
      this.lastOverRenderableNum = hitId;
      return;
    }
    const baseEvent = {
      type: "move",
      button: 0,
      x: this._latestPointer.x,
      y: this._latestPointer.y,
      modifiers: this._lastPointerModifiers
    };
    if (lastOver && !lastOver.isDestroyed) {
      const event = new MouseEvent2(lastOver, { ...baseEvent, type: "out" });
      this.sendMouseEvent(lastOver, event);
    }
    if (this._isDestroyed || this.capturedRenderable || this.lastOverRenderable !== lastOver)
      return;
    this.lastOverRenderable = hitRenderable?.isDestroyed ? undefined : hitRenderable;
    this.lastOverRenderableNum = this.lastOverRenderable?.num ?? 0;
    if (hitRenderable && !hitRenderable.isDestroyed) {
      const event = new MouseEvent2(hitRenderable, {
        ...baseEvent,
        type: "over"
      });
      this.sendMouseEvent(hitRenderable, event);
      if (this.lastOverRenderable === hitRenderable && (this._isDestroyed || hitRenderable.isDestroyed)) {
        this.lastOverRenderable = undefined;
        this.lastOverRenderableNum = 0;
      }
    }
  }
  setMousePointer(style) {
    this.setCursorStyle({ cursor: style });
  }
  hitTest(x, y) {
    return this.nativeScene.hitTest(x, y);
  }
  takeMemorySnapshot() {
    if (this._isDestroyed)
      return;
    const memoryUsage = process.memoryUsage();
    this.lastMemorySnapshot = {
      heapUsed: memoryUsage.heapUsed,
      heapTotal: memoryUsage.heapTotal,
      arrayBuffers: memoryUsage.arrayBuffers
    };
    this.lib.sessionUpdateMemoryStats(this.nativeSession.context, this.nativeSession.session, this.lastMemorySnapshot.heapUsed, this.lastMemorySnapshot.heapTotal, this.lastMemorySnapshot.arrayBuffers);
    this.emit("memory:snapshot" /* MEMORY_SNAPSHOT */, this.lastMemorySnapshot);
  }
  startMemorySnapshotTimer() {
    this.stopMemorySnapshotTimer();
    this.memorySnapshotTimer = this.clock.setInterval(() => {
      this.takeMemorySnapshot();
    }, this.memorySnapshotInterval);
  }
  stopMemorySnapshotTimer() {
    if (this.memorySnapshotTimer) {
      this.clock.clearInterval(this.memorySnapshotTimer);
      this.memorySnapshotTimer = null;
    }
  }
  setMemorySnapshotInterval(interval) {
    this.memorySnapshotInterval = interval;
    if (this._isRunning && interval > 0) {
      this.startMemorySnapshotTimer();
    } else if (interval <= 0 && this.memorySnapshotTimer) {
      this.clock.clearInterval(this.memorySnapshotTimer);
      this.memorySnapshotTimer = null;
    }
  }
  requestResize(width, height) {
    if (this._isDestroyed)
      return;
    if (width !== this._terminalWidth || height !== this._terminalHeight)
      this.pendingResizeSawDifferentSize = true;
    this.pendingNativeResize = { width, height };
    if (this.resizeTimeoutId !== null) {
      this.clock.clearTimeout(this.resizeTimeoutId);
      this.resizeTimeoutId = null;
    }
    if (this._splitHeight > 0) {
      this.applyPendingNativeResize();
      return;
    }
    this.resizeTimeoutId = this.clock.setTimeout(() => {
      this.resizeTimeoutId = null;
      this.applyPendingNativeResize();
    }, this.resizeDebounceDelay);
  }
  applyPendingNativeResize() {
    const resize = this.pendingNativeResize;
    if (!resize || this._isDestroyed || this.rendering || this.resizeTimeoutId !== null || this.nativeResizeWait || this.nativeTerminalTransition || this._controlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */)
      return;
    if (this.externalOutputQueue.size > 0 && !this.isSplitCursorSeedFrameBlocked()) {
      this.requestRender();
      return;
    }
    try {
      this.processResize(resize.width, resize.height, this.pendingResizeSawDifferentSize);
      if (this.pendingNativeResize === resize) {
        this.pendingNativeResize = null;
        this.pendingResizeSawDifferentSize = false;
      }
    } catch (error) {
      if (error instanceof NativeError2 && error.status === -19 /* InvalidPhase */)
        return;
      if (error instanceof NativeError2 && error.status === -13 /* OutputBusy */) {
        const wait = this.nativeSession.idle();
        this.nativeResizeWait = wait;
        wait.then(() => {
          this.nativeResizeWait = null;
          this.applyPendingNativeResize();
          this.resolveIdleIfNeeded();
        }, (error) => {
          this.nativeResizeWait = null;
          this.pendingNativeResize = null;
          if (!this._isDestroyed)
            this.handleError(error);
          this.resolveIdleIfNeeded();
        });
        return;
      }
      if (this.pendingNativeResize === resize) {
        this.pendingNativeResize = null;
        this.pendingResizeSawDifferentSize = false;
      }
      this.handleError(error);
    }
    this.resolveIdleIfNeeded();
  }
  pixelResolutionRetry = null;
  queryPixelResolution(retry = true) {
    this.pixelResolutionRequeryPending = true;
    if (this._isDestroyed || !this._terminalIsSetup || this._controlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */ || this.waitingForPixelResolution || this.pixelResolutionRetry)
      return;
    this.pixelResolutionRequeryPending = false;
    this.waitingForPixelResolution = true;
    this.updateStdinParserProtocolContext({ pixelResolutionQueryActive: true });
    try {
      this.nativeSession.control({ kind: "query-pixel-resolution" });
    } catch (error) {
      this.waitingForPixelResolution = false;
      this.pixelResolutionRequeryPending = true;
      this.updateStdinParserProtocolContext({ pixelResolutionQueryActive: false });
      if (!(error instanceof NativeError2))
        throw error;
      if (error.status === -19 /* InvalidPhase */)
        return;
      if (error.status !== -11 /* OutputBackpressure */ && error.status !== -13 /* OutputBusy */)
        throw error;
      if (!retry)
        return;
      const wait = this.nativeSession.idle();
      this.pixelResolutionRetry = wait;
      wait.then(() => {
        this.pixelResolutionRetry = null;
        if (!this._isDestroyed && this.pixelResolutionRequeryPending) {
          try {
            this.queryPixelResolution(false);
          } catch (error) {
            this.handleError(error);
          }
        }
      }, (error) => {
        this.pixelResolutionRetry = null;
        if (!this._isDestroyed)
          this.handleError(error);
      });
    }
  }
  processResize(width, height, repaintIfUnchanged = false) {
    if (width === this._terminalWidth && height === this._terminalHeight) {
      if (repaintIfUnchanged) {
        this.forceFullRepaintRequested = true;
        this.requestRender();
      }
      return;
    }
    const terminalWritable = this._terminalIsSetup && this._controlState !== "explicit_suspended" /* EXPLICIT_SUSPENDED */;
    if (terminalWritable && !this.isSplitCursorSeedFrameBlocked() && this.externalOutputQueue.size > 0) {
      this.pendingNativeResize = { width, height };
      this.requestRender();
      return;
    }
    const pendingSplitFooterTransition = this.pendingSplitFooterTransition;
    const previousGeometry = calculateRenderGeometry(this._screenMode, this._terminalWidth, this._terminalHeight, this._footerHeight);
    const prevWidth = this._terminalWidth;
    const previousTerminalHeight = this._terminalHeight;
    const visiblePreviousSplitHeight = pendingSplitFooterTransition?.sourceHeight ?? previousGeometry.effectiveFooterHeight;
    const nextGeometry = calculateRenderGeometry(this._screenMode, width, height, this._footerHeight);
    const splitFooterActive = this._screenMode === "split-footer";
    let clearStart = null;
    if (splitFooterActive && terminalWritable) {
      if (width < prevWidth && visiblePreviousSplitHeight > 0) {
        clearStart = Math.min(this.renderOffset + 1, Math.max(previousTerminalHeight - visiblePreviousSplitHeight * 2, 1));
      }
      if (pendingSplitFooterTransition !== null) {
        clearStart = clearStart === null ? pendingSplitFooterTransition.sourceTopLine : Math.min(clearStart, pendingSplitFooterTransition.sourceTopLine);
      }
    }
    if (clearStart === null)
      this.nativeSession.resize(nextGeometry.renderWidth, nextGeometry.renderHeight);
    else {
      this.nativeSession.setScreen(this._screenMode === "alternate-screen", nextGeometry.renderWidth, nextGeometry.renderHeight, this.lib.encoder.encode(ANSI.moveCursorAndClear(clearStart, 1)));
    }
    if (nextGeometry.renderWidth !== this.width || nextGeometry.renderHeight !== this.height) {
      this.nativeScene.restartPaint();
    }
    this._terminalWidth = width;
    this._terminalHeight = height;
    this._splitHeight = nextGeometry.effectiveFooterHeight;
    this.width = nextGeometry.renderWidth;
    this.height = nextGeometry.renderHeight;
    this._resolution = null;
    this.lib.sessionSetImageResolution(this.nativeSession.context, this.nativeSession.session, 0, 0, 0, 0);
    this.setCapturedRenderable(undefined);
    this.stdinParser?.resetMouseState();
    if (splitFooterActive) {
      this.forceFullRepaintRequested = true;
    }
    this.clearPendingSplitFooterTransition();
    if (this._screenMode === "split-footer" && this._externalOutputMode === "capture-stdout") {
      this.syncSplitScrollback();
    } else if (splitFooterActive) {
      this.syncSplitFooterState();
    }
    this._console.resize(this.width, this.height);
    this.root.resize(this.width, this.height);
    this.queryPixelResolution();
    this.emit("resize" /* RESIZE */, this.width, this.height);
    this.requestRender();
  }
  resize(width, height) {
    if (this._isDestroyed)
      return;
    if (this.resizeTimeoutId !== null) {
      this.clock.clearTimeout(this.resizeTimeoutId);
      this.resizeTimeoutId = null;
    }
    if (this.pendingNativeResize !== null) {
      this.deferResize(width, height);
      return;
    }
    try {
      this.processResize(width, height);
    } catch (error) {
      if (!(error instanceof NativeError2) || error.status !== -13 /* OutputBusy */ && error.status !== -27 /* FrameBusy */) {
        throw error;
      }
      this.deferResize(width, height);
    }
  }
  deferResize(width, height) {
    if (width !== this._terminalWidth || height !== this._terminalHeight)
      this.pendingResizeSawDifferentSize = true;
    this.pendingNativeResize = { width, height };
    this.applyPendingNativeResize();
  }
  setBackgroundColor(color) {
    this.backgroundColor = RGBA2.clone(parseColor2(color));
    this.requestRender();
  }
  toggleDebugOverlay() {
    const willBeEnabled = !this.debugOverlay.enabled;
    this.configureDebugOverlay({ enabled: willBeEnabled });
    if (willBeEnabled && !this.memorySnapshotInterval) {
      this.memorySnapshotInterval = 3000;
      this.startMemorySnapshotTimer();
      this.automaticMemorySnapshot = true;
    } else if (!willBeEnabled && this.automaticMemorySnapshot) {
      this.stopMemorySnapshotTimer();
      this.memorySnapshotInterval = 0;
      this.automaticMemorySnapshot = false;
    }
    this.emit("debugOverlay:toggle" /* DEBUG_OVERLAY_TOGGLE */, this.debugOverlay.enabled);
  }
  configureDebugOverlay(options) {
    const enabled = options.enabled ?? this.debugOverlay.enabled;
    const corner = options.corner ?? this.debugOverlay.corner;
    this.lib.sessionSetDebugOverlay(this.nativeSession.context, this.nativeSession.session, enabled, corner);
    this.debugOverlay.enabled = enabled;
    this.debugOverlay.corner = corner;
    this.requestRender();
  }
  setTerminalTitle(title) {
    this.nativeSession.control({ kind: "title", title });
  }
  resetTerminalBgColor() {
    this.nativeSession.control({ kind: "reset-background" });
  }
  copyToClipboardOSC52(text, target) {
    if (!this.isOsc52Supported())
      return false;
    return this.nativeSession.writeClipboard(target ?? 0 /* Clipboard */, this.lib.encoder.encode(text));
  }
  clearClipboardOSC52(target) {
    return this.nativeSession.writeClipboard(target ?? 0 /* Clipboard */, new Uint8Array(0));
  }
  isOsc52Supported() {
    return this.nativeSession.getCapabilities().osc52_support !== "unsupported";
  }
  dumpHitGrid() {
    this.lib.sessionDumpHitGrid(this.nativeSession.context, this.nativeSession.session);
  }
  getLinkIdAt(x, y) {
    if (this._isDestroyed || !Number.isInteger(x) || !Number.isInteger(y) || x < 0 || y < 0 || x > 2147483647 || y > 2147483647) {
      return 0;
    }
    return this.lib.sessionGetLinkId(this.nativeSession.context, this.nativeSession.session, x, y);
  }
  getLinkAt(x, y) {
    const linkId = this.getLinkIdAt(x, y);
    return linkId === 0 ? null : this.lib.contextGetLinkUrl(this.nativeSession.context, linkId) || null;
  }
  static setCursorPosition(renderer, x, y, visible = true) {
    renderer.setCursorPosition(x, y, visible);
  }
  static setCursorStyle(renderer, options) {
    renderer.setCursorStyle(options);
  }
  static setCursorColor(renderer, color) {
    renderer.setCursorColor(color);
  }
  setCursorPosition(x, y, visible = true) {
    this.lib.sessionSetCursor(this.nativeSession.context, this.nativeSession.session, { position: { x, y, visible } });
  }
  setCursorStyle(options) {
    this.lib.sessionSetCursor(this.nativeSession.context, this.nativeSession.session, options);
    if (options.cursor !== undefined) {
      this._currentMousePointerStyle = options.cursor;
    }
  }
  setCursorColor(color) {
    this.lib.sessionSetCursor(this.nativeSession.context, this.nativeSession.session, { color });
  }
  getCursorState() {
    return this.lib.sceneGetCursorState(this.nativeSession.context, this.nativeSession.session);
  }
  addPostProcessFn(processFn) {
    this.postProcessFns.push(processFn);
  }
  removePostProcessFn(processFn) {
    this.postProcessFns = this.postProcessFns.filter((fn) => fn !== processFn);
  }
  clearPostProcessFns() {
    this.postProcessFns = [];
  }
  setFrameCallback(callback) {
    this.frameCallbacks.push(callback);
  }
  hasFrameCallback(callback) {
    return this.frameCallbacks.includes(callback);
  }
  removeFrameCallback(callback) {
    this.frameCallbacks = this.frameCallbacks.filter((cb) => cb !== callback);
  }
  clearFrameCallbacks() {
    this.frameCallbacks = [];
  }
  get canRender() {
    return !this._isDestroyed && !this.nativeSession.error && !this.nativeSession.disposed;
  }
  requestAnimationFrame(callback) {
    if (!this.canRender)
      return -1;
    const id = CliRenderer2.animationFrameId++;
    this.animationRequest.set(id, callback);
    this.requestLive();
    return id;
  }
  cancelAnimationFrame(handle) {
    if (this.animationRequest.delete(handle))
      this.dropLive();
  }
  yieldFrame() {
    if (!this.canRender)
      return Promise.resolve();
    return new Promise((resolve) => {
      const finish = () => {
        this.cancelFrameContinuation = null;
        resolve();
      };
      const cancel = this.nativeSession.scheduler.schedule(finish);
      this.cancelFrameContinuation = () => {
        cancel();
        finish();
      };
    });
  }
  queueFrame() {
    if (this.cancelReadyFrame || this._isDestroyed)
      return;
    if (!this.canRender) {
      this.destroy();
      return;
    }
    this.cancelReadyFrame = this.nativeSession.scheduler.schedule(() => {
      this.cancelReadyFrame = null;
      this.loop();
    });
  }
  requestLive() {
    if (!this.canRender)
      return;
    this.liveRequestCounter++;
    if (this._controlState === "idle" /* IDLE */ && this.liveRequestCounter > 0) {
      this._controlState = "auto_started" /* AUTO_STARTED */;
      this.internalStart();
    } else if (this._controlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */ && this._previousControlState === "idle" /* IDLE */) {
      this._previousControlState = "auto_started" /* AUTO_STARTED */;
    }
  }
  dropLive() {
    if (this.liveRequestCounter === 0)
      return;
    this.liveRequestCounter--;
    if (this.liveRequestCounter === 0 && this._controlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */ && this._previousControlState === "auto_started" /* AUTO_STARTED */) {
      this._previousControlState = "idle" /* IDLE */;
    }
    if (this._controlState === "auto_started" /* AUTO_STARTED */ && this.liveRequestCounter === 0) {
      this._controlState = "idle" /* IDLE */;
      this._isRunning = false;
      this.resolveIdleIfNeeded();
    }
  }
  start() {
    this._controlState = "explicit_started" /* EXPLICIT_STARTED */;
    this.internalStart();
  }
  auto() {
    this._controlState = this._isRunning ? "auto_started" /* AUTO_STARTED */ : "idle" /* IDLE */;
  }
  internalStart() {
    if (!this._isRunning && !this._isDestroyed) {
      this._isRunning = true;
      this.cancelReadyFrame?.();
      this.cancelReadyFrame = null;
      this.clearFrameTimer();
      if (this.memorySnapshotInterval > 0) {
        this.startMemorySnapshotTimer();
      }
      this.startRenderLoop();
    }
  }
  pause() {
    this._controlState = "explicit_paused" /* EXPLICIT_PAUSED */;
    this.ordinaryFrameWaitControlState = null;
    this.halt(false);
  }
  suspend() {
    if (this.nativeSplitFlush)
      return this.nativeTerminalTransition;
    if (!this._terminalIsSetup || this.nativeTerminalTransition) {
      throw new Error("Native scene suspension requires completed terminal setup and no pending transition");
    }
    const flushNativeSplit = this.externalOutputQueue.size > 0 || this.pendingNativeReplay;
    if (flushNativeSplit)
      this.lib.getYogaHost().assertMutable();
    let nativeTransition;
    if (flushNativeSplit) {
      const count = this.externalOutputQueue.size;
      this.nativeSplitFlush = Promise.resolve().then(() => this.flushNativeSplitOutput(count));
      nativeTransition = (async () => {
        try {
          await this.nativeSplitFlush;
          if (this._isDestroyed)
            throw new Error("Native scene suspension interrupted by renderer destruction");
          return this.nativeSession.suspend();
        } finally {
          this.nativeSplitFlush = null;
        }
      })();
    } else {
      nativeTransition = this.nativeSession.suspend();
    }
    nativeTransition = this.trackNativeTerminalTransition(nativeTransition);
    if (this._controlState !== "explicit_suspended" /* EXPLICIT_SUSPENDED */) {
      this._previousControlState = this._controlState;
      this._suspendedMouseEnabled = this._useMouse;
    }
    this._controlState = "explicit_suspended" /* EXPLICIT_SUSPENDED */;
    this._cancelPaletteDetection?.(new Error("Cannot detect palette while renderer is suspended"));
    this.resolveXtVersionWaiters();
    this.nativeScene.interruptPaint();
    this.halt(false);
    this.clearSplitStartupCursorSeed();
    this.disableMouse();
    this.removeExitListeners();
    this.updateStdinParserProtocolContext({
      privateCapabilityRepliesActive: false,
      pixelResolutionQueryActive: this.waitingForPixelResolution,
      explicitWidthCprActive: false,
      startupCursorCprActive: false
    });
    if (this.stdinParser?.hasPendingPixelResolutionResponse())
      this.stdinParser.pausePendingTimeout();
    else
      this.stdinParser?.reset();
    this.stdin.removeListener("data", this.stdinListener);
    this.stopTerminalKeepAlive();
    this.themeModeState?.cancelRefresh();
    if (this.stdin.setRawMode) {
      this.stdin.setRawMode(false);
    }
    this.stdin.pause();
    return nativeTransition;
  }
  resume() {
    if (!this._terminalIsSetup || this.nativeTerminalTransition || this._controlState !== "explicit_suspended" /* EXPLICIT_SUSPENDED */) {
      throw new Error("Native scene resume requires completed suspension");
    }
    if (this.pendingSplitFooterTransition) {
      this.lib.sessionSplitControl(this.nativeSession.context, this.nativeSession.session, {
        kind: "clear-transition"
      });
    }
    const resumed = this.trackNativeTerminalTransition(this.nativeSession.resume(), () => {
      if (this._isDestroyed)
        return;
      if (this.pendingSplitFooterTransition)
        this.setPendingSplitFooterTransition(this.pendingSplitFooterTransition);
      this.finishResume();
    }).then(() => {
      if (!this._isDestroyed && (this.shouldSyncNativePaletteState() || this.listenerCount("palette" /* PALETTE */) > 0)) {
        this.clearPaletteCache();
        this.refreshPalette();
      }
    });
    resumed.catch(() => {});
    return resumed;
  }
  finishResume() {
    if (this.stdin.setRawMode) {
      this.stdin.setRawMode(true);
    }
    let drained;
    while ((drained = this.stdin.read()) !== null)
      this.stdinListener(drained);
    if (this.stdinParser?.hasPendingPixelResolutionResponse())
      this.stdinParser.pausePendingTimeout();
    else
      this.stdinParser?.reset();
    this.stdin.on("data", this.stdinListener);
    this.stdin.resume();
    this.startTerminalKeepAlive();
    this.addExitListeners();
    this._useMouse = this._suspendedMouseEnabled;
    if (this._screenMode === "split-footer" && this._splitHeight > 0) {
      this.syncSplitFooterState();
    }
    this.forceFullRepaintRequested = true;
    this.startKittyTransportPolling();
    this.nativeSession.startKittyFileProbe();
    this._controlState = this._previousControlState;
    if (this.pixelResolutionRequeryPending)
      this.queryPixelResolution();
    this.stdinParser?.resumePendingTimeout();
    this.applyPendingNativeResize();
    if (this._previousControlState === "auto_started" /* AUTO_STARTED */ || this._previousControlState === "explicit_started" /* EXPLICIT_STARTED */) {
      this.internalStart();
    } else {
      this.requestRender();
    }
  }
  stop() {
    this._controlState = "explicit_stopped" /* EXPLICIT_STOPPED */;
    this.ordinaryFrameWaitControlState = null;
    this.halt(true);
  }
  halt(stopSnapshots) {
    if (stopSnapshots && this._isRunning)
      this.stopMemorySnapshotTimer();
    this._isRunning = false;
    this.immediateRerenderRequested = false;
    this.cancelReadyFrame?.();
    this.cancelReadyFrame = null;
    this.clearFrameTimer();
    if (!this.rendering)
      this.resolveIdleIfNeeded();
  }
  destroy() {
    if (this._isDestroyed)
      return;
    this.lib.getYogaHost().assertMutable();
    this._isDestroyed = true;
    this._destroyPending = true;
    this._palettePublishGeneration++;
    this._cancelPaletteDetection?.(new Error("Cannot detect palette after renderer destruction"));
    const splitFlush = this.nativeSplitFlush;
    const terminalTransition = this.nativeTerminalTransition;
    queueMicrotask(async () => {
      try {
        if (splitFlush || this.externalOutputQueue.size > 0 || this.pendingNativeReplay) {
          this.nativeSession.armCloseTimeout();
          if (splitFlush)
            await splitFlush;
          else if (terminalTransition)
            await terminalTransition;
          if (this.externalOutputQueue.size > 0 || this.pendingNativeReplay)
            await this.flushNativeSplitOutput();
        }
        this.nativeSession.close();
      } catch (error) {
        this.externalOutputQueue.clear();
        this.nativeSession.dispose();
        console.error("Native split output cancelled during close:", error);
      }
    });
    this.finalizeDestroy();
  }
  cleanupBeforeDestroy() {
    if (this._destroyCleanupPrepared)
      return;
    this._destroyCleanupPrepared = true;
    if (this.kittyTransportTimer !== null) {
      this.clock.clearInterval(this.kittyTransportTimer);
      this.kittyTransportTimer = null;
      if (!this.nativeSession.disposed && !this.nativeSession.error)
        this.nativeSession.cancelKittyImageTransport(false);
    }
    this.pendingNativeResize = null;
    this.cancelReadyFrame?.();
    this.cancelReadyFrame = null;
    this.cancelFrameContinuation?.();
    this.animationRequest.clear();
    this.frameCallbacks = [];
    this.liveRequestCounter = 0;
    this.immediateRerenderRequested = false;
    if (this._usesProcessStdout) {
      this.removeCleanupListener(process, "SIGWINCH", this.sigwinchHandler);
    }
    this.removeCleanupListener(process, "uncaughtException", this.handleError);
    this.removeCleanupListener(process, "unhandledRejection", this.handleError);
    this.removeCleanupListener(process, "warning", this.warningHandler);
    this.removeExitListeners();
    if (this.resizeTimeoutId !== null) {
      this.clock.clearTimeout(this.resizeTimeoutId);
      this.resizeTimeoutId = null;
    }
    if (this.capabilityTimeoutId !== null) {
      this.clock.clearTimeout(this.capabilityTimeoutId);
      this.capabilityTimeoutId = null;
    }
    this.clearSplitStartupCursorSeed();
    if (this.memorySnapshotTimer) {
      this.clock.clearInterval(this.memorySnapshotTimer);
      this.memorySnapshotTimer = null;
    }
    this.clearFrameTimer();
    this.themeModeState?.cancelRefresh();
    this._isRunning = false;
    this.waitingForPixelResolution = false;
    this.pixelResolutionRequeryPending = false;
    try {
      this.updateStdinParserProtocolContext({
        privateCapabilityRepliesActive: false,
        pixelResolutionQueryActive: false,
        explicitWidthCprActive: false,
        startupCursorCprActive: false
      }, true);
    } catch (error) {
      this.handleStdinParserFailure(error);
    }
    this._useMouse = false;
    this.setCapturedRenderable(undefined);
    this.removeCleanupListener(this.stdin, "data", this.stdinListener);
    this.stopTerminalKeepAlive();
    if (this.stdin.setRawMode) {
      try {
        this.stdin.setRawMode(false);
      } catch (e) {
        console.error("Error disabling raw mode during destroy:", e);
      }
    }
    try {
      this.stdin.pause();
    } catch (e) {
      console.error("Error pausing stdin during destroy:", e);
    }
    this.externalOutputMode = "passthrough";
  }
  finalizeDestroy() {
    if (this._destroyFinalized)
      return;
    if (this.root?._deferUntilCleanupComplete(() => this.finalizeDestroy())) {
      this.cleanupBeforeDestroy();
      return;
    }
    this._destroyFinalized = true;
    this._destroyPending = false;
    this.cleanupBeforeDestroy();
    if (this._paletteDetector) {
      this._paletteDetector.cleanup();
      this._paletteDetector = null;
    }
    this._paletteCache.clear();
    this._paletteDetectionPromise = null;
    this._paletteDetectionSize = 0;
    this._paletteDetectionGeneration = 0;
    this._nativePaletteSignature = null;
    this._emittedPaletteSignature = null;
    this._paletteEpoch = 0;
    this.resolveXtVersionWaiters();
    this.themeModeState?.dispose();
    for (const destroy of this.detachedSurfaces) {
      try {
        destroy();
      } catch (error) {
        console.error("Error destroying detached surface:", error);
      }
    }
    try {
      this.emit("destroy" /* DESTROY */);
    } catch (error) {
      console.error("Error in native scene destroy listener:", error);
    } finally {
      try {
        destroyTimelineEngine(this);
      } catch (error) {
        console.error("Error releasing timeline engine:", error);
      }
    }
    try {
      this.root?.destroyRecursively();
    } catch (e) {
      console.error("Error destroying root renderable:", e instanceof Error ? e.stack : String(e));
    }
    this.stdinParser?.destroy();
    this.stdinParser = null;
    this.oscSubscribers.clear();
    try {
      this._console?.destroy();
    } catch (error) {
      console.error("Error destroying console:", error);
    }
    try {
      this.nativeScene.destroy();
    } catch (error) {
      console.error("Error destroying native scene:", error);
    }
    this._externalOutputMode = "passthrough";
    this.pendingExternalOutputMode = null;
    this.stdout.write = this.realStdoutWrite;
    const discardInput = this._terminalIsSetup && this._controlState !== "explicit_suspended" /* EXPLICIT_SUSPENDED */;
    if (discardInput) {
      const bufferedInput = this.stdin.readableLength;
      if (bufferedInput > 0)
        this.stdin.read(bufferedInput);
    }
    this.flushTerminalInputOnClose = discardInput && this.stdin === process.stdin;
    rendererTracker.renderers.delete(this);
    if (rendererTracker.renderers.size === 0) {
      destroyTreeSitterClient2().catch((error) => {
        console.error("Failed to destroy tree-sitter client:", error);
      });
    }
    if (this._onDestroy) {
      try {
        this._onDestroy();
      } catch (e) {
        console.error("Error in onDestroy callback:", e instanceof Error ? e.stack : String(e));
      }
    }
    this.nativeDestroyWait?.resolve();
    this.resolveIdleIfNeeded();
  }
  releaseStreamLease() {
    if (!this._streamLeaseAcquired)
      return;
    if (rendererTracker.streamOwners.get(this.stdin) === this)
      rendererTracker.streamOwners.delete(this.stdin);
    if (rendererTracker.streamOwners.get(this.stdout) === this)
      rendererTracker.streamOwners.delete(this.stdout);
    this._streamLeaseAcquired = false;
  }
  startRenderLoop() {
    if (!this._isRunning)
      return;
    this.lastTime = this.normalizeClockTime(this.clock.now(), 0);
    this.frameCount = 0;
    this.lastFpsTime = this.lastTime;
    this.currentFps = 0;
    this.renderStats.fps = 0;
    if (this.outputIdleRenderScheduled)
      return;
    this.queueFrame();
  }
  async loop(waitForActive = false) {
    if (this.rendering) {
      if (!waitForActive)
        return;
      this.renderingCompletion ??= Promise.withResolvers();
      return this.renderingCompletion.promise;
    }
    if (this._isDestroyed)
      return;
    this.cancelReadyFrame?.();
    this.cancelReadyFrame = null;
    this.clearFrameTimer();
    this.rendering = true;
    this.ordinaryFrameWaitControlState = this._controlState;
    let renderFailed = false;
    try {
      if (!this.canRender)
        return;
      if (this.nativeTerminalTransition && !await this.waitForTerminalTransition())
        return;
      if (!this.canRender || this.currentControlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */ || this.isSplitCursorSeedFrameBlocked())
        return;
      this._frameId++;
      const now = this.normalizeClockTime(this.clock.now(), this.lastTime);
      const elapsed = this.getElapsedMs(now, this.lastTime);
      const deltaTime = elapsed;
      this.lastTime = now;
      this.renderStats.frameCount++;
      const overallStart = performance.now();
      const animationFrameEnd = CliRenderer2.animationFrameId;
      const animationRequestStart = performance.now();
      for (const [id, callback] of this.animationRequest) {
        if (id >= animationFrameEnd)
          break;
        if (!this.canRender || this.currentControlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */)
          break;
        this.animationRequest.delete(id);
        try {
          callback(deltaTime);
        } finally {
          this.dropLive();
        }
        await this.yieldFrame();
      }
      const animationRequestEnd = performance.now();
      const animationRequestTime = animationRequestEnd - animationRequestStart;
      const start = performance.now();
      const frameCallbacks = this.frameCallbacks;
      const callbackCount = frameCallbacks.length;
      for (let index = 0;index < callbackCount; index++) {
        if (!this.canRender || this.currentControlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */)
          break;
        const frameCallback = frameCallbacks[index];
        if (this.frameCallbacks !== frameCallbacks && !this.frameCallbacks.includes(frameCallback))
          continue;
        try {
          await frameCallback(deltaTime);
        } catch (error) {
          console.error("Error in frame callback:", error);
        }
        await this.yieldFrame();
      }
      const end = performance.now();
      this.renderStats.frameCallbackTime = end - start;
      if (this.nativeTerminalTransition && !await this.waitForTerminalTransition())
        return;
      if (!this.canRender || this.currentControlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */)
        return;
      const sceneStart = performance.now();
      const requestedBeforeScene = this.immediateRerenderRequested;
      try {
        const painting = this.nativeScene.paint(deltaTime, () => ({
          background: this.backgroundColor,
          useMouse: this._useMouse,
          excludedHitNum: this.capturedRenderable?.num ?? 0
        }));
        if (painting)
          await painting;
      } catch (error) {
        this.immediateRerenderRequested = requestedBeforeScene;
        throw error;
      } finally {
        this._lastSceneTimeMs = performance.now() - sceneStart;
      }
      if (this._isDestroyed || this.currentControlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */ || !this.nativeScene.frame)
        return;
      for (const postProcessFn of this.postProcessFns) {
        if (!this.canRender)
          break;
        this.nextRenderBuffer._withNativePaint(() => postProcessFn(this.nextRenderBuffer, deltaTime));
      }
      if (this.canRender)
        this._console.renderToBuffer(this.nextRenderBuffer);
      if (this.canRender && !this.nativeSplitFlush) {
        const nativeStatus = await this.presentNativeScene();
        if (!this.canRender || this.currentControlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */)
          return;
        if (nativeStatus === "rendered")
          this.frameCount++;
        if (this.getElapsedMs(now, this.lastFpsTime) >= 1000) {
          this.currentFps = this.frameCount;
          this.frameCount = 0;
          this.lastFpsTime = now;
        }
        this.renderStats.fps = this.currentFps;
        if (nativeStatus === "rendered") {
          if (this._useMouse) {
            this.recheckHoverState();
          }
          if (!this.canRender)
            return;
          const overallFrameTime = performance.now() - overallStart;
          this.lib.sessionUpdateStats(this.nativeSession.context, this.nativeSession.session, overallFrameTime, this.renderStats.fps, this.renderStats.frameCallbackTime);
          if (this.listenerCount("frame" /* FRAME */) > 0) {
            this.emit("frame" /* FRAME */, {
              frameId: this.frameId
            });
          }
          if (!this.canRender)
            return;
          if (this.gatherStats) {
            this.collectStatSample(overallFrameTime);
          }
          if (this._isRunning || this.immediateRerenderRequested) {
            const immediate = this.immediateRerenderRequested;
            const targetFrameTime = immediate ? this.minTargetFrameTime : this.targetFrameTime;
            const remaining = targetFrameTime - this.getElapsedMs(this.normalizeClockTime(this.clock.now(), now), now);
            this.immediateRerenderRequested = false;
            if (immediate && remaining <= 0) {
              this.queueFrame();
            } else {
              this.scheduleFrame(Math.max(1, remaining));
            }
          } else {
            this.clearFrameTimer();
          }
        } else {
          this.immediateRerenderRequested = false;
          this.clearFrameTimer();
        }
      }
    } catch (error) {
      renderFailed = true;
      if (this.canRender) {
        const renderError = error instanceof Error ? error : new Error(String(error));
        const event = { error: renderError, renderable: this.root.takeCurrentRenderable() };
        const handled = this.emit("render:error" /* RENDER_ERROR */, event);
        if (!handled)
          this.handleError(renderError);
      }
    } finally {
      const completion = this.renderingCompletion;
      this.renderingCompletion = null;
      try {
        this.nativeScene.cancelFrame();
        this.rendering = false;
        this.logNativeDiagnostics();
        if (!this.canRender && !this._isDestroyed)
          this.destroy();
        if (this._destroyPending) {
          this.finalizeDestroy();
        }
        if (renderFailed && (this._isRunning || this.immediateRerenderRequested) && !this._isDestroyed) {
          this.immediateRerenderRequested = false;
          this.scheduleRenderTimer();
        }
        this.applyPendingNativeModeReported();
        this.applyPendingNativeResize();
        this.resolveIdleIfNeeded();
      } finally {
        completion?.resolve();
      }
    }
  }
  logNativeDiagnostics() {
    if (!this.canRender)
      return;
    try {
      this.lib.logContextDiagnostics(this.nativeSession.context, 1 /* Warn */);
    } catch (error) {
      if (!(error instanceof NativeError2) || error.status !== -6 /* ContextBusy */) {
        this.handleError(error);
      }
    }
  }
  async waitForTerminalTransition() {
    while (this.nativeTerminalTransition) {
      try {
        await this.nativeTerminalTransition;
      } catch {
        return false;
      }
    }
    return true;
  }
  intermediateRender() {
    this.immediateRerenderRequested = true;
    this.ordinaryFrameWaitControlState = this._controlState;
    this.loop();
  }
  async presentNativeScene() {
    if (this.isSplitCursorSeedFrameBlocked())
      return "blocked";
    const commits = this._splitHeight > 0 && this._externalOutputMode === "capture-stdout" ? this.pendingNativeReplay?.remaining === 0 ? [] : this.externalOutputQueue.batch(Math.min(this.maxSplitCommitsPerFrame, this.pendingNativeReplay?.remaining ?? Infinity)) : null;
    const split = commits === null ? null : this.nativeScene.commitSplit(commits.map((commit) => ({ ...commit, snapshot: commit.nativeSnapshot })), this.getSplitPinnedRenderOffset(), this.forceFullRepaintRequested);
    const status = split?.status ?? this.nativeScene.commit(this.forceFullRepaintRequested);
    if (commits && (status === 1 /* Pending */ || status === 0 /* Presented */)) {
      this.nativeSplitAcceptedCount = commits.length;
    }
    switch (status) {
      case 1 /* Pending */:
        await this.nativeSession.whenPresented();
        break;
      case 0 /* Presented */:
        break;
      case 2 /* Skipped */:
        this.ordinaryFrameWaitingForOutput = true;
        this.scheduleRenderAfterOutputIdle();
        return "retryable-skip";
      case 3 /* Failed */:
        console.error("[CliRenderer] Native frame render failed; waiting for the next render request to force repaint");
        return "failed";
      default:
        throw new Error("Unknown native scene presentation status");
    }
    if (this._isDestroyed || this.nativeSplitFlush)
      return "rendered";
    if (split && commits) {
      this.completeNativeSplitCommits(commits);
      if (this.externalOutputQueue.size > 0)
        this.requestRender();
      else
        this.applyPendingExternalOutputModeIfReady();
    }
    this.forceFullRepaintRequested = false;
    return "rendered";
  }
  completeNativeSplitCommits(commits) {
    if (!this._isDestroyed) {
      this.syncSplitScrollback();
      for (const commit of commits)
        this.recordSplitCommit(commit);
    }
    this.externalOutputQueue.drop(commits.length);
    if (this.pendingNativeReplay)
      this.pendingNativeReplay.remaining -= commits.length;
    this.nativeSplitAcceptedCount = 0;
    this.pendingSplitFooterTransition = null;
  }
  async flushNativeSplitOutput(remaining = this.externalOutputQueue.size) {
    const driver = this.nativeSession;
    await driver.whenPresented();
    this.nativeScene.cancelFrame();
    if (this.nativeSplitAcceptedCount > 0) {
      remaining -= this.nativeSplitAcceptedCount;
      this.completeNativeSplitCommits(this.externalOutputQueue.peek(this.nativeSplitAcceptedCount));
    }
    while (remaining > 0 || this.pendingNativeReplay?.remaining === 0) {
      if (this.pendingNativeReplay?.remaining === 0) {
        try {
          this.applySplitFooterReplayReset(this.pendingNativeReplay.options);
        } catch (error) {
          if (!(error instanceof NativeError2) || error.status !== -11 /* OutputBackpressure */)
            throw error;
          await driver.idle();
          continue;
        }
      }
      if (remaining === 0)
        break;
      const commits = this.externalOutputQueue.batch(Math.min(remaining, this.maxSplitCommitsPerFrame, this.pendingNativeReplay?.remaining ?? Infinity));
      if (this.lib.sessionGetRendererState(driver.context, driver.session).framePending) {
        throw new Error("Native split output flush requires no pending frame presentation");
      }
      const result = driver.renderSplit(null, commits.map((commit) => ({ ...commit, snapshot: commit.nativeSnapshot })), this.getSplitPinnedRenderOffset(), false);
      if (result.status === 3 /* Failed */)
        throw new Error("Native split output frame failed");
      if (result.status === 2 /* Skipped */) {
        await driver.idle();
        continue;
      }
      await driver.whenPresented();
      remaining -= commits.length;
      this.completeNativeSplitCommits(commits);
    }
    if (!this._isDestroyed)
      this.applyPendingExternalOutputModeIfReady();
  }
  collectStatSample(frameTime) {
    this.frameTimes.push(frameTime);
    if (this.frameTimes.length > this.maxStatSamples) {
      this.frameTimes.shift();
    }
  }
  getNativeStats() {
    return this.lib.sceneGetStats(this.nativeSession.context, this.nativeSession.session);
  }
  getStats() {
    const nativeStats = this.getNativeStats();
    const frameTimes = [...this.frameTimes];
    const sum = frameTimes.reduce((acc, time) => acc + time, 0);
    const avg = frameTimes.length ? sum / frameTimes.length : 0;
    const min = frameTimes.length ? Math.min(...frameTimes) : 0;
    const max = frameTimes.length ? Math.max(...frameTimes) : 0;
    return {
      ...nativeStats,
      fps: this.renderStats.fps,
      frameCount: this.renderStats.frameCount,
      frameTimes,
      averageFrameTime: avg,
      minFrameTime: min,
      maxFrameTime: max,
      frameCallbackTime: this.renderStats.frameCallbackTime
    };
  }
  resetStats() {
    this.frameTimes = [];
    this.renderStats.frameCount = 0;
  }
  setGatherStats(enabled) {
    this.gatherStats = enabled;
    if (!enabled) {
      this.frameTimes = [];
    }
  }
  getSelection() {
    return this.currentSelection;
  }
  get hasSelection() {
    return !!this.currentSelection;
  }
  getSelectionContainer() {
    return this.selectionContainers.length > 0 ? this.selectionContainers[this.selectionContainers.length - 1] : null;
  }
  clearSelection() {
    this.clearSelectionState();
    this.lastClick = null;
  }
  clearSelectionState() {
    if (this.currentSelection) {
      for (const renderable of this.currentSelection.touchedRenderables) {
        if (renderable.selectable && !renderable.isDestroyed) {
          renderable.onSelectionChanged(null);
        }
      }
      this.currentSelection = null;
    }
    this.selectionContainers = [];
  }
  startSelection(renderable, x, y, behavior = "cell") {
    if (!renderable.selectable)
      return;
    this.clearSelectionState();
    this.selectionContainers.push(renderable.parent || this.root);
    this.currentSelection = new Selection2(renderable, { x, y }, { x, y }, behavior);
    this.currentSelection.isStart = true;
    this.notifySelectablesOfSelectionChange();
  }
  nextClickBehavior(renderable, x, y) {
    const now = this.clock.now();
    const last = this.lastClick;
    const continued = last !== null && renderable.num === last.renderableId && now - last.time <= CLICK_REPEAT_INTERVAL_MS && Math.max(Math.abs(x - last.x), Math.abs(y - last.y)) <= 1;
    const count = continued ? Math.min(last.count + 1, 3) : 1;
    this.lastClick = { count, time: now, x, y, renderableId: renderable.num };
    return count === 1 ? "cell" : count === 2 ? "word" : "line";
  }
  updateSelection(currentRenderable, x, y, options) {
    if (this.currentSelection) {
      this.currentSelection.isStart = false;
      this.currentSelection.focus = { x, y };
      if (options?.finishDragging) {
        this.currentSelection.isDragging = false;
      }
      if (this.selectionContainers.length > 0) {
        const currentContainer = this.selectionContainers[this.selectionContainers.length - 1];
        if (!currentRenderable || !this.isWithinContainer(currentRenderable, currentContainer)) {
          const parentContainer = currentContainer.parent || this.root;
          this.selectionContainers.push(parentContainer);
        } else if (currentRenderable && this.selectionContainers.length > 1) {
          let containerIndex = this.selectionContainers.indexOf(currentRenderable);
          if (containerIndex === -1) {
            const immediateParent = currentRenderable.parent || this.root;
            containerIndex = this.selectionContainers.indexOf(immediateParent);
          }
          if (containerIndex !== -1 && containerIndex < this.selectionContainers.length - 1) {
            this.selectionContainers = this.selectionContainers.slice(0, containerIndex + 1);
          }
        }
      }
      this.notifySelectablesOfSelectionChange();
    }
  }
  requestSelectionUpdate() {
    if (this.currentSelection?.isDragging) {
      const pointer = this._latestPointer;
      const maybeRenderableId = this.hitTest(pointer.x, pointer.y);
      const maybeRenderable = Renderable2.renderablesByNumber.get(maybeRenderableId);
      this.updateSelection(maybeRenderable, pointer.x, pointer.y);
    }
  }
  isWithinContainer(renderable, container) {
    let current = renderable;
    while (current) {
      if (current === container)
        return true;
      current = current.parent;
    }
    return false;
  }
  finishSelection() {
    if (this.currentSelection) {
      this.currentSelection.isDragging = false;
      this.emit("selection" /* SELECTION */, this.currentSelection);
      this.notifySelectablesOfSelectionChange();
    }
  }
  notifySelectablesOfSelectionChange() {
    const selectedRenderables = [];
    const touchedRenderables = [];
    const currentContainer = this.selectionContainers.length > 0 ? this.selectionContainers[this.selectionContainers.length - 1] : this.root;
    if (this.currentSelection) {
      this.walkSelectableRenderables(currentContainer, this.currentSelection.bounds, selectedRenderables, touchedRenderables);
      for (const renderable of this.currentSelection.touchedRenderables) {
        if (!touchedRenderables.includes(renderable) && !renderable.isDestroyed) {
          renderable.onSelectionChanged(null);
        }
      }
      this.currentSelection.updateSelectedRenderables(selectedRenderables);
      this.currentSelection.updateTouchedRenderables(touchedRenderables);
    }
  }
  walkSelectableRenderables(container, selectionBounds, selectedRenderables, touchedRenderables) {
    const children = getObjectsInViewport(selectionBounds, container.getChildrenSortedByPrimaryAxis(), container.primaryAxis, 0, 0);
    for (const child of children) {
      if (child.selectable) {
        const hasSelection = child.onSelectionChanged(this.currentSelection);
        if (hasSelection) {
          selectedRenderables.push(child);
        }
        touchedRenderables.push(child);
      }
      if (child.getChildrenCount() > 0) {
        this.walkSelectableRenderables(child, selectionBounds, selectedRenderables, touchedRenderables);
      }
    }
  }
  get paletteDetectionStatus() {
    if (this._paletteDetectionPromise)
      return "detecting";
    if (this._paletteCache.size > 0)
      return "cached";
    return "idle";
  }
  getCachedPaletteBySize(size) {
    const exactMatch = this._paletteCache.get(size);
    if (exactMatch) {
      return exactMatch;
    }
    const largerSize = [...this._paletteCache.keys()].sort((a, b) => a - b).find((candidate) => candidate >= size);
    if (largerSize === undefined) {
      return null;
    }
    const source = this._paletteCache.get(largerSize);
    if (!source) {
      return null;
    }
    const projected = {
      ...source,
      palette: source.palette.slice(0, size)
    };
    this._paletteCache.set(size, projected);
    return projected;
  }
  ensurePaletteDetector() {
    if (!this._paletteDetector) {
      const isTmux = Boolean(this.capabilities?.multiplexer === "tmux" || this.capabilities?.terminal?.name?.toLowerCase()?.includes("tmux"));
      const isLegacyTmux = this.capabilities?.terminal?.name?.toLowerCase()?.includes("tmux") && this.capabilities?.terminal?.version?.localeCompare("3.6") < 0;
      const detector = createTerminalPalette2({
        stdin: this.stdin,
        stdout: this.stdout,
        writeFn: (data) => {
          if (this._isDestroyed || this._paletteDetector !== detector) {
            throw new Error("Palette detection was cancelled");
          }
          this.nativeSession.control({ kind: "palette-query", bytes: Buffer.from(data) });
          return true;
        },
        isLegacyTmux,
        isTmux,
        oscSource: {
          subscribeOsc: this.subscribeOsc.bind(this)
        },
        clock: this.clock
      });
      this._paletteDetector = detector;
    }
    return this._paletteDetector;
  }
  syncNativePaletteState(colors) {
    const signature = buildTerminalPaletteSignature2(colors);
    const epoch = this._nativePaletteSignature !== signature ? this._paletteEpoch + 1 >>> 0 : this._paletteEpoch;
    const normalized = normalizeTerminalPalette2(colors);
    this.lib.sessionSetPaletteState(this.nativeSession.context, this.nativeSession.session, normalized.palette, normalized.defaultForeground, normalized.defaultBackground, epoch);
    this._nativePaletteSignature = signature;
    this._paletteEpoch = epoch;
  }
  emitPaletteChange(colors) {
    if (this.listenerCount("palette" /* PALETTE */) === 0)
      return;
    const signature = buildTerminalPaletteSignature2(colors);
    if (this._emittedPaletteSignature === signature)
      return;
    this._emittedPaletteSignature = signature;
    this.emit("palette" /* PALETTE */, colors);
  }
  resolveXtVersionWaiters() {
    if (this.xtVersionWaiters.size === 0)
      return;
    const resolvers = [...this.xtVersionWaiters];
    this.xtVersionWaiters.clear();
    for (const resolve of resolvers) {
      resolve();
    }
  }
  waitForXtVersion() {
    if (this.capabilityTimeoutId === null || this._capabilities?.terminal?.from_xtversion) {
      return Promise.resolve();
    }
    return new Promise((resolve) => {
      this.xtVersionWaiters.add(resolve);
    });
  }
  shouldSyncNativePaletteState() {
    return Boolean(this._terminalIsSetup && !this._isDestroyed && this._capabilities?.ansi256 && !this._capabilities?.rgb);
  }
  refreshPalette() {
    const publishGeneration = this._palettePublishGeneration;
    this.getPalette({ size: NATIVE_PALETTE_QUERY_SIZE }).then(() => {
      if (this._isDestroyed)
        return;
      if (this._palettePublishGeneration === publishGeneration)
        this.requestRender();
    }).catch(() => {});
  }
  clearPaletteCache() {
    this._palettePublishGeneration++;
    this._paletteCache.clear();
  }
  async getPalette(options) {
    if (this._controlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */) {
      throw new Error("Cannot detect palette while renderer is suspended");
    }
    if (this._isDestroyed || !this._terminalIsSetup || this.nativeTerminalTransition) {
      throw new Error("Native palette detection requires an active terminal");
    }
    const requestedSize = options?.size ?? 16;
    const detectionTimeout = options?.timeout;
    if (!Number.isInteger(requestedSize) || requestedSize < 1 || requestedSize > 256) {
      throw new RangeError("Native palette size must be an integer from 1 to 256");
    }
    const requestedGeneration = this._palettePublishGeneration;
    const cachedPalette = this.getCachedPaletteBySize(requestedSize);
    if (cachedPalette) {
      return cachedPalette;
    }
    const terminal = this._capabilities?.terminal;
    const hasTmuxVersion = terminal?.name?.toLowerCase() === "tmux" && Boolean(terminal.version);
    if (this._capabilities?.multiplexer === "tmux" && !hasTmuxVersion) {
      await this.waitForXtVersion();
      if (this._isDestroyed || !this._terminalIsSetup || this.nativeTerminalTransition || this.currentControlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */) {
        throw new Error("Palette detection was cancelled");
      }
      const afterCapabilityWait = this.getCachedPaletteBySize(requestedSize);
      if (afterCapabilityWait) {
        return afterCapabilityWait;
      }
    }
    while (this._paletteDetectionPromise) {
      if (this._paletteDetectionSize >= requestedSize && this._paletteDetectionGeneration === this._palettePublishGeneration) {
        return this._paletteDetectionPromise.then((palette) => {
          const cached = this.getCachedPaletteBySize(requestedSize);
          if (cached) {
            return cached;
          }
          const projected = {
            ...palette,
            palette: palette.palette.slice(0, requestedSize)
          };
          if (!this._isDestroyed && requestedGeneration === this._palettePublishGeneration) {
            this._paletteCache.set(requestedSize, projected);
          }
          return projected;
        });
      }
      await this._paletteDetectionPromise;
      if (this._isDestroyed || !this._terminalIsSetup || this.nativeTerminalTransition || this.currentControlState === "explicit_suspended" /* EXPLICIT_SUSPENDED */) {
        throw new Error("Palette detection was cancelled");
      }
      const afterWait = this.getCachedPaletteBySize(requestedSize);
      if (afterWait) {
        return afterWait;
      }
    }
    const detector = this.ensurePaletteDetector();
    const publishGeneration = this._palettePublishGeneration;
    this._paletteDetectionSize = requestedSize;
    this._paletteDetectionGeneration = publishGeneration;
    let cancel = null;
    const cancelled = new Promise((_resolve, reject) => {
      cancel = (reason) => {
        detector.cleanup();
        if (this._paletteDetector === detector)
          this._paletteDetector = null;
        reject(reason);
      };
    });
    this._cancelPaletteDetection = cancel;
    const detection = detector.detect({ ...options, timeout: detectionTimeout });
    detection.catch(() => detector.cleanup());
    const completion = Promise.race([detection, cancelled]).then((result) => {
      detector.cleanup();
      if (this._paletteDetector === detector)
        this._paletteDetector = null;
      if (this._paletteDetectionPromise === pending) {
        this._paletteDetectionPromise = null;
        this._paletteDetectionSize = 0;
        this._paletteDetectionGeneration = 0;
      }
      const publish = !this._isDestroyed && this._palettePublishGeneration === publishGeneration;
      if (publish && this.shouldSyncNativePaletteState() && result.palette.length >= NATIVE_PALETTE_QUERY_SIZE) {
        this.syncNativePaletteState(result);
      }
      if (publish)
        this._paletteCache.set(result.palette.length, result);
      if (publish) {
        this.emitPaletteChange(result);
        if (this.shouldSyncNativePaletteState() && !this._paletteCache.has(NATIVE_PALETTE_QUERY_SIZE)) {
          this.refreshPalette();
        }
      }
      return result;
    }).catch((error) => {
      if (this._paletteDetectionPromise === pending) {
        this._paletteDetectionPromise = null;
        this._paletteDetectionSize = 0;
        this._paletteDetectionGeneration = 0;
      }
      detector.cleanup();
      if (this._paletteDetector === detector)
        this._paletteDetector = null;
      throw error;
    });
    const pending = completion.finally(() => {
      if (this._cancelPaletteDetection === cancel)
        this._cancelPaletteDetection = null;
    });
    this._paletteDetectionPromise = pending;
    const detected = await this._paletteDetectionPromise;
    const finalPalette = this.getCachedPaletteBySize(requestedSize) ?? detected;
    return finalPalette;
  }
}

export { isValidBorderStyle2, parseBorderStyle2, BorderChars2, getBorderFromSides2, getBorderSides2, borderCharsToArray2, BorderCharArrays2, KeyEvent2, PasteEvent2, KeyHandler2, InternalKeyHandler2, fonts2, measureText2, getCharacterPositions2, coordinateToCharacterIndex2, renderFontToFrameBuffer2, hastToStyledText2, SystemClock2, nonAlphanumericKeys2, terminalNamedSingleStrokeKeys2, parseKeypress2, LinearScrollAccel2, MacOSScrollAccel2, parseAlign2, parseAlignItems2, parseBoxSizing2, parseDimension2, parseDirection2, parseDisplay2, parseEdge2, parseFlexDirection2, parseGutter2, parseJustify2, parseLogLevel2, parseMeasureMode2, parseOverflow2, parsePositionType2, parseUnit2, parseWrap2, MouseParser2, Selection2, convertGlobalToLocalSelection2, ASCIIFontSelectionHelper2, StdinParser2, treeSitterToTextChunks2, treeSitterToStyledText2, addDefaultParsers2, TreeSitterClient2, DataPathsManager2, getDataPaths2, extensionToFiletype2, basenameToFiletype2, extToFiletype2, pathToFiletype2, infoStringToFiletype2, getTreeSitterClient2, destroyTreeSitterClient2, ExtmarksController2, createExtmarksController2, TerminalPalette2, createTerminalPalette2, normalizeTerminalPalette2, buildTerminalPaletteSignature2, decodePasteBytes2, stripAnsiSequences2, createHostClipboard2, createClipboard2, ClipboardTarget2, createRendererClipboardAdapter2, normalizeMarkdownLinkTarget, detectLinks2, acquireSessionBufferLease2, ResourceContext2, OptimizedBuffer2, h2, isVNode2, maybeMakeRenderable2, wrapWithDelegates2, instantiate2, delegate2, LayoutEvents2, RenderableEvents2, isRenderable2, BaseRenderable2, Renderable2, RootRenderable2, TextBuffer2, TextBufferView2, EditBuffer2, measureEditText2, EditorView2, convertThemeToStyles2, SyntaxStyle2, Timeline2, engine2, getTimelineEngine2, createTimeline2, ANSI, BoxRenderable2, TextBufferRenderable2, CodeRenderable2, ImageLoadError2, ImageError2, imageInfo2, NativeImage2, NativeImagePool2, resolveImageRenderProtocol2, ImageRenderable2, isTextNodeRenderable2, TextNodeRenderable2, RootTextNodeRenderable2, TextRenderable2, NativeSession2, defaultKeyAliases, mergeKeyAliases, mergeKeyBindings, getKeyBindingAction, buildKeyBindingsMap, capture2, ConsolePosition2, TerminalConsole2, EditBufferRenderableEvents2, isEditBufferRenderable2, EditBufferRenderable2, buildKittyKeyboardFlags2, MouseEvent2, MouseButton2, createCliRenderer2, CliRenderEvents2, RendererControlState2, CliRenderer2 };

//# debugId=B399986B5FE8DCDE64756E2164756E21
//# sourceMappingURL=chunk-bun-ef166q8d.js.map
