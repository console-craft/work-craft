export declare const nativeSymbols: {
    readonly ot_scene_set_hooks: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_frame_step_with_geometry: {
        readonly args: readonly ["ptr", "buffer", "ptr", "buffer", "u32", "ptr", "u32", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_frame_get_paint_slots: {
        readonly args: readonly ["ptr", "buffer", "buffer", "buffer", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_frame_cancel: {
        readonly args: readonly ["ptr", "buffer", "u64"];
        readonly returns: "i32";
    };
    readonly ot_scene_create_node: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_destroy_node: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_move_node: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32"];
        readonly returns: "i32";
    };
    readonly ot_scene_set_measure: {
        readonly args: readonly ["ptr", "buffer", "ptr"];
        readonly returns: "i32";
    };
    readonly ot_scene_has_measure: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_mark_dirty: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_set_style: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "u32", "u32", "f32", "u32"];
        readonly returns: "i32";
    };
    readonly ot_scene_get_style: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_set_paint: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_flush: {
        readonly args: readonly ["ptr", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_set_surface: {
        readonly args: readonly ["ptr", "buffer", "ptr"];
        readonly returns: "i32";
    };
    readonly ot_scene_set_box_details: {
        readonly args: readonly ["ptr", "buffer", "buffer", "ptr", "u32", "ptr", "u32"];
        readonly returns: "i32";
    };
    readonly ot_scene_set_viewport: {
        readonly args: readonly ["ptr", "buffer", "ptr"];
        readonly returns: "i32";
    };
    readonly ot_scene_set_focus: {
        readonly args: readonly ["ptr", "buffer", "u32"];
        readonly returns: "i32";
    };
    readonly ot_scene_set_slider: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_set_arrow: {
        readonly args: readonly ["ptr", "buffer", "buffer", "ptr", "u32"];
        readonly returns: "i32";
    };
    readonly ot_scene_get_slider_thumb: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_set_text: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32"];
        readonly returns: "i32";
    };
    readonly ot_scene_set_styled_text: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "ptr", "u32", "ptr", "u32"];
        readonly returns: "i32";
    };
    readonly ot_scene_set_text_options: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_set_text_selection: {
        readonly args: readonly ["ptr", "buffer", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_get_text_selection: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_get_selected_text: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_get_text: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_get_text_info: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_get_text_lines: {
        readonly args: readonly ["ptr", "buffer", "u32", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_get_layout: {
        readonly args: readonly ["ptr", "buffer", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_paint: {
        readonly args: readonly ["ptr", "buffer", "buffer", "u32", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_hit_test: {
        readonly args: readonly ["ptr", "buffer", "i32", "i32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_get_stats: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_get_cursor_state: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_frame_copy_buffer: {
        readonly args: readonly ["ptr", "buffer", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_measure_layout: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_render_split: {
        readonly args: readonly ["ptr", "buffer", "ptr", "ptr", "u32", "u32", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_split_control: {
        readonly args: readonly ["ptr", "buffer", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_set_screen: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "u32", "buffer", "u32"];
        readonly returns: "i32";
    };
    readonly ot_session_sync_detached: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_unicode_create: {
        readonly args: readonly ["ptr", "ptr", "u32", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_unicode_destroy: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_unicode_get: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_buffer_draw_unicode: {
        readonly args: readonly ["ptr", "buffer", "ptr", "buffer", "u32", "i32", "i32", "buffer", "buffer", "u32"];
        readonly returns: "i32";
    };
    readonly ot_embedded_terminal_create: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_embedded_terminal_destroy: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_embedded_terminal_write: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32"];
        readonly returns: "i32";
    };
    readonly ot_embedded_terminal_resize: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32"];
        readonly returns: "i32";
    };
    readonly ot_embedded_terminal_command: {
        readonly args: readonly ["ptr", "buffer", "u32", "i32"];
        readonly returns: "i32";
    };
    readonly ot_embedded_terminal_set_selection: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "u32", "u32"];
        readonly returns: "i32";
    };
    readonly ot_embedded_terminal_get_selected_text: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_embedded_terminal_compose: {
        readonly args: readonly ["ptr", "buffer", "buffer", "ptr", "i32", "i32"];
        readonly returns: "i32";
    };
    readonly ot_embedded_terminal_cursor_get: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_embedded_terminal_encode_key: {
        readonly args: readonly ["ptr", "buffer", "buffer", "ptr", "u32", "ptr", "u32", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_embedded_terminal_encode_mouse: {
        readonly args: readonly ["ptr", "buffer", "buffer", "buffer", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_embedded_terminal_encode_paste: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_embedded_terminal_encode_focus: {
        readonly args: readonly ["ptr", "buffer", "u32", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_embedded_terminal_drain_responses: {
        readonly args: readonly ["ptr", "buffer", "buffer", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_edit_buffer_create: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_edit_buffer_destroy: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_editor_view_create: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_editor_view_destroy: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_syntax_style_create: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_syntax_style_destroy: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_edit_buffer_set_syntax_style: {
        readonly args: readonly ["ptr", "buffer", "ptr"];
        readonly returns: "i32";
    };
    readonly ot_edit_buffer_set_text: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "u32"];
        readonly returns: "i32";
    };
    readonly ot_edit_buffer_insert_text: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32"];
        readonly returns: "i32";
    };
    readonly ot_edit_buffer_delete_range: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "u32", "u32"];
        readonly returns: "i32";
    };
    readonly ot_edit_buffer_set_cursor: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32"];
        readonly returns: "i32";
    };
    readonly ot_edit_buffer_get_text: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_edit_buffer_get_info: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_edit_buffer_set_tab_width: {
        readonly args: readonly ["ptr", "buffer", "u32"];
        readonly returns: "i32";
    };
    readonly ot_edit_buffer_command: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32"];
        readonly returns: "i32";
    };
    readonly ot_edit_buffer_history: {
        readonly args: readonly ["ptr", "buffer", "u32", "buffer", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_edit_buffer_get_position: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_edit_buffer_get_range: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "u32", "u32", "u32", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_edit_buffer_measure_text: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_edit_measure_text: {
        readonly args: readonly ["ptr", "ptr", "u32", "u32", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_edit_buffer_set_defaults: {
        readonly args: readonly ["ptr", "buffer", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_syntax_style_register: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_syntax_style_resolve: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_syntax_style_get_count: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_edit_buffer_highlight: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "ptr"];
        readonly returns: "i32";
    };
    readonly ot_edit_buffer_get_highlights: {
        readonly args: readonly ["ptr", "buffer", "u32", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_editor_view_set_viewport: {
        readonly args: readonly ["ptr", "buffer", "buffer", "u32", "u32"];
        readonly returns: "i32";
    };
    readonly ot_editor_view_get_viewport: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_editor_view_set_scroll_margin: {
        readonly args: readonly ["ptr", "buffer", "f32"];
        readonly returns: "i32";
    };
    readonly ot_editor_view_command: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32"];
        readonly returns: "i32";
    };
    readonly ot_editor_view_replace_selection: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_editor_view_set_tab_color: {
        readonly args: readonly ["ptr", "buffer", "ptr"];
        readonly returns: "i32";
    };
    readonly ot_editor_view_select: {
        readonly args: readonly ["ptr", "buffer", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_editor_view_get_info: {
        readonly args: readonly ["ptr", "buffer", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_editor_view_get_selection: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_editor_view_get_selected_text: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_editor_view_get_position: {
        readonly args: readonly ["ptr", "buffer", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_editor_view_get_lines: {
        readonly args: readonly ["ptr", "buffer", "u32", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_editor_view_measure: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_editor_view_set_placeholder: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "ptr", "u32"];
        readonly returns: "i32";
    };
    readonly ot_context_set_edit_event_callback: {
        readonly args: readonly ["ptr", "ptr"];
        readonly returns: "i32";
    };
    readonly ot_scene_set_editor_view: {
        readonly args: readonly ["ptr", "buffer", "ptr"];
        readonly returns: "i32";
    };
    readonly ot_scene_set_editor_options: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_image_destroy: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_image_inspect: {
        readonly args: readonly ["ptr", "buffer", "u64", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_image_decode: {
        readonly args: readonly ["ptr", "buffer", "u64", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_image_create_pixels: {
        readonly args: readonly ["ptr", "buffer", "u64", "u32", "u32", "u32", "u32", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_image_update_pixels: {
        readonly args: readonly ["ptr", "buffer", "buffer", "u64", "u32", "u32", "u32"];
        readonly returns: "i32";
    };
    readonly ot_image_clone: {
        readonly args: readonly ["ptr", "ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_image_retain: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_image_get_info: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_image_resize: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_image_extract: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "u32", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_image_extend: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "u32", "u32", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_image_transform: {
        readonly args: readonly ["ptr", "buffer", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_image_composite: {
        readonly args: readonly ["ptr", "buffer", "buffer", "i32", "i32", "u32", "u8", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_image_copy_pixels: {
        readonly args: readonly ["ptr", "buffer", "buffer", "u64", "u32", "u32"];
        readonly returns: "i32";
    };
    readonly ot_image_copy_png: {
        readonly args: readonly ["ptr", "buffer", "buffer", "u64", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_image_take_pixels: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_image_pixels_release: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_set_image: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "u32", "ptr"];
        readonly returns: "i32";
    };
    readonly ot_buffer_draw_image: {
        readonly args: readonly ["ptr", "buffer", "ptr", "buffer", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_set_image_resolution: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "u32", "u32"];
        readonly returns: "i32";
    };
    readonly ot_session_set_kitty_image_transport: {
        readonly args: readonly ["ptr", "buffer", "u32"];
        readonly returns: "i32";
    };
    readonly ot_session_get_kitty_image_transport: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_poll_kitty_image_transport: {
        readonly args: readonly ["ptr", "buffer", "u64", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_cancel_kitty_image_transport: {
        readonly args: readonly ["ptr", "buffer", "u32"];
        readonly returns: "i32";
    };
    readonly ot_session_process_kitty_image_reply: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_start_kitty_file_probe: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_create: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_destroy: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_view_create: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_view_destroy: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_set_text: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_append: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_clear: {
        readonly args: readonly ["ptr", "buffer", "u32"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_set_styled_text: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "ptr", "u32", "ptr", "u32"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_replace_styled_batch: {
        readonly args: readonly ["ptr", "buffer", "u32", "buffer", "u32", "buffer", "u32", "buffer", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_set_syntax_style: {
        readonly args: readonly ["ptr", "buffer", "ptr"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_get_info: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_get_text: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_get_range: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_set_defaults: {
        readonly args: readonly ["ptr", "buffer", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_set_tab_width: {
        readonly args: readonly ["ptr", "buffer", "u32"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_highlight: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "ptr"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_get_highlights: {
        readonly args: readonly ["ptr", "buffer", "u32", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_view_set_viewport: {
        readonly args: readonly ["ptr", "buffer", "buffer", "u32"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_view_command: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_view_set_tab_color: {
        readonly args: readonly ["ptr", "buffer", "ptr"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_view_select: {
        readonly args: readonly ["ptr", "buffer", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_view_get_info: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_view_get_selected_text: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_view_get_lines: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_text_buffer_view_measure: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_set_text_view: {
        readonly args: readonly ["ptr", "buffer", "ptr"];
        readonly returns: "i32";
    };
    readonly ot_scene_set_text_view_paint: {
        readonly args: readonly ["ptr", "buffer", "u32"];
        readonly returns: "i32";
    };
    readonly ot_buffer_draw_text_view: {
        readonly args: readonly ["ptr", "buffer", "ptr", "buffer", "i32", "i32"];
        readonly returns: "i32";
    };
    readonly ot_buffer_draw_editor_view: {
        readonly args: readonly ["ptr", "buffer", "ptr", "buffer", "i32", "i32"];
        readonly returns: "i32";
    };
    readonly ot_buffer_draw_scene_text: {
        readonly args: readonly ["ptr", "buffer", "ptr", "buffer", "i32", "i32"];
        readonly returns: "i32";
    };
    readonly ot_scene_frame_acquire_buffer_lease: {
        readonly args: readonly ["ptr", "buffer", "buffer", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_scene_frame_commit: {
        readonly args: readonly ["ptr", "buffer", "buffer", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_context_abi_version: {
        readonly args: readonly [];
        readonly returns: "u32";
    };
    readonly ot_context_create: {
        readonly args: readonly ["buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_context_destroy: {
        readonly args: readonly ["ptr"];
        readonly returns: "i32";
    };
    readonly ot_context_get_last_error: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_context_drain_diagnostics: {
        readonly args: readonly ["ptr", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_context_get_link_url: {
        readonly args: readonly ["ptr", "u32", "buffer", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_buffer_create: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_buffer_destroy: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_buffer_resize: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32"];
        readonly returns: "i32";
    };
    readonly ot_buffer_draw: {
        readonly args: readonly ["ptr", "buffer", "ptr", "buffer", "ptr", "buffer", "u32", "buffer", "u32"];
        readonly returns: "i32";
    };
    readonly ot_buffer_stack: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "i32", "i32", "u32", "u32", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_buffer_draw_grid: {
        readonly args: readonly ["ptr", "buffer", "ptr", "buffer", "buffer", "u32", "buffer", "u32"];
        readonly returns: "i32";
    };
    readonly ot_buffer_draw_packed: {
        readonly args: readonly ["ptr", "buffer", "ptr", "ptr", "u32", "i32", "i32", "u32", "u32"];
        readonly returns: "i32";
    };
    readonly ot_buffer_draw_supersample: {
        readonly args: readonly ["ptr", "buffer", "ptr", "ptr", "u32", "i32", "i32", "u32", "u32"];
        readonly returns: "i32";
    };
    readonly ot_buffer_draw_grayscale: {
        readonly args: readonly ["ptr", "buffer", "ptr", "buffer", "u32", "i32", "i32", "u32", "u32", "ptr", "ptr", "u32"];
        readonly returns: "i32";
    };
    readonly ot_buffer_color_matrix: {
        readonly args: readonly ["ptr", "buffer", "ptr", "buffer", "u32", "ptr", "u32", "buffer", "u32"];
        readonly returns: "i32";
    };
    readonly ot_buffer_acquire_lease: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_create: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_attach_renderer: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_attach_renderer_with_env: {
        readonly args: readonly ["ptr", "buffer", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_render: {
        readonly args: readonly ["ptr", "buffer", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_resize_renderer: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32"];
        readonly returns: "i32";
    };
    readonly ot_session_draw_buffer: {
        readonly args: readonly ["ptr", "buffer", "buffer", "i32", "i32"];
        readonly returns: "i32";
    };
    readonly ot_scene_frame_draw_buffer: {
        readonly args: readonly ["ptr", "buffer", "buffer", "buffer", "i32", "i32"];
        readonly returns: "i32";
    };
    readonly ot_session_set_debug_overlay: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32"];
        readonly returns: "i32";
    };
    readonly ot_session_update_stats: {
        readonly args: readonly ["ptr", "buffer", "f64", "u32", "f64"];
        readonly returns: "i32";
    };
    readonly ot_session_update_memory_stats: {
        readonly args: readonly ["ptr", "buffer", "u32", "u32", "u32"];
        readonly returns: "i32";
    };
    readonly ot_session_dump_hit_grid: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_get_renderer_state: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_acquire_buffer_lease: {
        readonly args: readonly ["ptr", "buffer", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_get_link_id: {
        readonly args: readonly ["ptr", "buffer", "i32", "i32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_buffer_lease_validate: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_buffer_lease_release: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_buffer_lease_get_real_char_size: {
        readonly args: readonly ["ptr", "buffer", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_buffer_lease_write_resolved_chars: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "u32", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_setup_terminal: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_suspend: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_resume: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_get_terminal_state: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_control: {
        readonly args: readonly ["ptr", "buffer", "buffer", "ptr", "u32"];
        readonly returns: "i32";
    };
    readonly ot_session_get_capabilities: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_clipboard: {
        readonly args: readonly ["ptr", "buffer", "u32", "buffer", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_set_palette_state: {
        readonly args: readonly ["ptr", "buffer", "buffer", "u32", "buffer", "buffer", "u32"];
        readonly returns: "i32";
    };
    readonly ot_session_notification: {
        readonly args: readonly ["ptr", "buffer", "buffer", "u32", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_pump: {
        readonly args: readonly ["ptr", "buffer", "u64", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_get_write_limit: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_write: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32"];
        readonly returns: "i32";
    };
    readonly ot_session_read_output: {
        readonly args: readonly ["ptr", "buffer", "ptr", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_drain_output: {
        readonly args: readonly ["ptr", "buffer", "u32", "buffer", "ptr", "ptr"];
        readonly returns: "i32";
    };
    readonly ot_session_drain_stdout: {
        readonly args: readonly ["ptr", "buffer", "u32", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_complete_output: {
        readonly args: readonly ["ptr", "buffer", "buffer", "u32"];
        readonly returns: "i32";
    };
    readonly ot_session_close: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_pump_exit: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_terminal_flush_input: {
        readonly args: readonly [];
        readonly returns: "i32";
    };
    readonly ot_session_cancel: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_get_state: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_session_destroy: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "i32";
    };
    readonly ot_clipboard_service_create: {
        readonly args: readonly ["ptr", "u32", "u32", "ptr", "u32"];
        readonly returns: "i32";
    };
    readonly ot_clipboard_service_begin_shutdown: {
        readonly args: readonly ["ptr"];
        readonly returns: "u8";
    };
    readonly ot_clipboard_service_poll_shutdown: {
        readonly args: readonly ["ptr"];
        readonly returns: "u8";
    };
    readonly ot_clipboard_service_destroy: {
        readonly args: readonly ["ptr"];
        readonly returns: "u8";
    };
    readonly ot_clipboard_service_drain: {
        readonly args: readonly ["ptr"];
        readonly returns: "u8";
    };
    readonly ot_clipboard_read_operation_start: {
        readonly args: readonly ["ptr", "buffer", "u32", "u8", "u32", "u32", "u32", "u32", "buffer"];
        readonly returns: "u8";
    };
    readonly ot_clipboard_write_operation_start: {
        readonly args: readonly ["ptr", "buffer", "u32", "u8", "u32", "buffer"];
        readonly returns: "u8";
    };
    readonly ot_clipboard_clear_operation_start: {
        readonly args: readonly ["ptr", "u8", "u32", "buffer"];
        readonly returns: "u8";
    };
    readonly ot_clipboard_operation_poll: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "u8";
    };
    readonly ot_clipboard_operation_cancel: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "u8";
    };
    readonly ot_clipboard_operation_result_mime_length: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "u8";
    };
    readonly ot_clipboard_operation_result_mime_copy: {
        readonly args: readonly ["ptr", "buffer", "buffer", "u32"];
        readonly returns: "u8";
    };
    readonly ot_clipboard_operation_result_data_length: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "u8";
    };
    readonly ot_clipboard_operation_result_data_copy: {
        readonly args: readonly ["ptr", "buffer", "buffer", "u32"];
        readonly returns: "u8";
    };
    readonly ot_clipboard_operation_result_error_code: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "u8";
    };
    readonly ot_clipboard_operation_result_diagnostic_length: {
        readonly args: readonly ["ptr", "buffer", "buffer"];
        readonly returns: "u8";
    };
    readonly ot_clipboard_operation_result_diagnostic_copy: {
        readonly args: readonly ["ptr", "buffer", "buffer", "u32"];
        readonly returns: "u8";
    };
    readonly ot_clipboard_operation_destroy: {
        readonly args: readonly ["ptr", "buffer"];
        readonly returns: "u8";
    };
};
export declare const nativeCallbacks: {
    readonly ot_scene_measure_callback: {
        readonly args: readonly ["u64", "u32", "u32", "f32", "u32", "f32", "u32", "ptr"];
        readonly returns: "void";
    };
    readonly ot_edit_event_callback: {
        readonly args: readonly ["u64", "u32", "u32", "u32"];
        readonly returns: "void";
    };
    readonly ot_output_write_callback: {
        readonly args: readonly ["ptr", "ptr", "u32"];
        readonly returns: "i64";
    };
};
export declare const nativeLayouts: {
    readonly ot_handle: {
        readonly size: 16;
        readonly alignment: 8;
        readonly fields: {
            readonly context_id: {
                readonly offset: 0;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
            readonly slot: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly generation: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_scene_slider_options: {
        readonly size: 64;
        readonly alignment: 8;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly orientation: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly min: {
                readonly offset: 16;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "f64";
            };
            readonly max: {
                readonly offset: 24;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "f64";
            };
            readonly value: {
                readonly offset: 32;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "f64";
            };
            readonly viewport_size: {
                readonly offset: 40;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "f64";
            };
            readonly foreground: {
                readonly offset: 48;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly background: {
                readonly offset: 56;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
        };
    };
    readonly ot_scene_slider_thumb: {
        readonly size: 24;
        readonly alignment: 8;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly size: {
                readonly offset: 8;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "f64";
            };
            readonly start: {
                readonly offset: 16;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "f64";
            };
        };
    };
    readonly ot_scene_arrow_options: {
        readonly size: 32;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly direction: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly attributes: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly foreground: {
                readonly offset: 16;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly background: {
                readonly offset: 24;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
        };
    };
    readonly ot_scene_text_options: {
        readonly size: 80;
        readonly alignment: 8;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly foreground: {
                readonly offset: 8;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly background: {
                readonly offset: 16;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly attributes: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly wrap_mode: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly truncate: {
                readonly offset: 32;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly first_line_offset: {
                readonly offset: 36;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly scroll_x: {
                readonly offset: 40;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "f64";
            };
            readonly scroll_y: {
                readonly offset: 48;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "f64";
            };
            readonly tab_indicator: {
                readonly offset: 56;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly tab_color_set: {
                readonly offset: 60;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly tab_color: {
                readonly offset: 64;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly text_align: {
                readonly offset: 72;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_scene_text_selection_options: {
        readonly size: 56;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly operation: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly behavior: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly anchor_x: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly anchor_y: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly focus_x: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly focus_y: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly flags: {
                readonly offset: 32;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 36;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly background: {
                readonly offset: 40;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly foreground: {
                readonly offset: 48;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
        };
    };
    readonly ot_styled_text_chunk: {
        readonly size: 48;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly byte_count: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly flags: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly foreground: {
                readonly offset: 16;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly background: {
                readonly offset: 24;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly attributes: {
                readonly offset: 32;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 36;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly link_offset: {
                readonly offset: 40;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly link_byte_count: {
                readonly offset: 44;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_scene_text_info: {
        readonly size: 32;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly byte_count: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly text_length: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly line_count: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly virtual_line_count: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly width_cols_max: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_scene_text_line: {
        readonly size: 16;
        readonly alignment: 4;
        readonly fields: {
            readonly start_cols: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly width_cols: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly source_line: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly wrap_index: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_scene_paint_options: {
        readonly size: 80;
        readonly alignment: 8;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly z_index: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly opacity: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "f32";
            };
            readonly translate_x: {
                readonly offset: 16;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "f64";
            };
            readonly translate_y: {
                readonly offset: 24;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "f64";
            };
            readonly border_sides: {
                readonly offset: 32;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly should_fill: {
                readonly offset: 36;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly background: {
                readonly offset: 40;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly border_color: {
                readonly offset: 48;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly border_style: {
                readonly offset: 56;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly focusable: {
                readonly offset: 60;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly focused_border_color: {
                readonly offset: 64;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly reserved: {
                readonly offset: 72;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_scene_box_details: {
        readonly size: 76;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly title_alignment: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly bottom_title_alignment: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly flags: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly title_color: {
                readonly offset: 24;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly border_characters: {
                readonly offset: 32;
                readonly size: 44;
                readonly alignment: 4;
                readonly type: "[11]u32";
            };
        };
    };
    readonly ot_scene_style_value: {
        readonly size: 16;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly unit: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly value: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "f32";
            };
        };
    };
    readonly ot_scene_layout: {
        readonly size: 48;
        readonly alignment: 8;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly left: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "f32";
            };
            readonly top: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "f32";
            };
            readonly right: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "f32";
            };
            readonly bottom: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "f32";
            };
            readonly width: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "f32";
            };
            readonly height: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "f32";
            };
            readonly screen_x: {
                readonly offset: 32;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "f64";
            };
            readonly screen_y: {
                readonly offset: 40;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "f64";
            };
        };
    };
    readonly ot_scene_stats: {
        readonly size: 64;
        readonly alignment: 8;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly last_frame_time: {
                readonly offset: 8;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "f64";
            };
            readonly average_frame_time: {
                readonly offset: 16;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "f64";
            };
            readonly render_time: {
                readonly offset: 24;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "f64";
            };
            readonly stdout_write_time: {
                readonly offset: 32;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "f64";
            };
            readonly frame_count: {
                readonly offset: 40;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
            readonly cells_updated: {
                readonly offset: 48;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly average_cells_updated: {
                readonly offset: 52;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly render_time_valid: {
                readonly offset: 56;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly stdout_write_time_valid: {
                readonly offset: 60;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_scene_cursor_state: {
        readonly size: 48;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly x: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly y: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly visible: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly style: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly blinking: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly r: {
                readonly offset: 32;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "f32";
            };
            readonly g: {
                readonly offset: 36;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "f32";
            };
            readonly b: {
                readonly offset: 40;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "f32";
            };
            readonly a: {
                readonly offset: 44;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "f32";
            };
        };
    };
    readonly ot_scene_hooks: {
        readonly size: 40;
        readonly alignment: 8;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly flags: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly generation: {
                readonly offset: 16;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
            readonly initial_width: {
                readonly offset: 24;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "f64";
            };
            readonly initial_height: {
                readonly offset: 32;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "f64";
            };
        };
    };
    readonly ot_scene_frame_options: {
        readonly size: 36;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly background: {
                readonly offset: 8;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly use_mouse: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly excluded_hit_num: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly max_layout_rounds: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly max_host_requests: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly preserve_unwritten: {
                readonly offset: 32;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_scene_frame_request: {
        readonly size: 112;
        readonly alignment: 8;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly session: {
                readonly offset: 8;
                readonly size: 16;
                readonly alignment: 8;
                readonly type: "ot_handle";
            };
            readonly root: {
                readonly offset: 24;
                readonly size: 16;
                readonly alignment: 8;
                readonly type: "ot_handle";
            };
            readonly node: {
                readonly offset: 40;
                readonly size: 16;
                readonly alignment: 8;
                readonly type: "ot_handle";
            };
            readonly frame_id: {
                readonly offset: 56;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
            readonly request_id: {
                readonly offset: 64;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
            readonly layout_epoch: {
                readonly offset: 72;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
            readonly hook_generation: {
                readonly offset: 80;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
            readonly kind: {
                readonly offset: 88;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly num: {
                readonly offset: 92;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly width: {
                readonly offset: 96;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly height: {
                readonly offset: 100;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 104;
                readonly size: 8;
                readonly alignment: 4;
                readonly type: "[2]u32";
            };
        };
    };
    readonly ot_scene_frame_geometry: {
        readonly size: 112;
        readonly alignment: 8;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly flags: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly paint: {
                readonly offset: 16;
                readonly size: 48;
                readonly alignment: 8;
                readonly type: "ot_scene_layout";
            };
            readonly public_layout: {
                readonly offset: 64;
                readonly size: 48;
                readonly alignment: 8;
                readonly type: "ot_scene_layout";
            };
        };
    };
    readonly ot_scene_paint_slot: {
        readonly size: 152;
        readonly alignment: 8;
        readonly fields: {
            readonly node: {
                readonly offset: 0;
                readonly size: 16;
                readonly alignment: 8;
                readonly type: "ot_handle";
            };
            readonly hook_generation: {
                readonly offset: 16;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
            readonly num: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly hooks: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly clip_x: {
                readonly offset: 32;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly clip_y: {
                readonly offset: 36;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly clip_width: {
                readonly offset: 40;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly clip_height: {
                readonly offset: 44;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly opacity: {
                readonly offset: 48;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "f32";
            };
            readonly flags: {
                readonly offset: 52;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly paint: {
                readonly offset: 56;
                readonly size: 48;
                readonly alignment: 8;
                readonly type: "ot_scene_layout";
            };
            readonly public_layout: {
                readonly offset: 104;
                readonly size: 48;
                readonly alignment: 8;
                readonly type: "ot_scene_layout";
            };
        };
    };
    readonly ot_scene_property_update: {
        readonly size: 24;
        readonly alignment: 8;
        readonly fields: {
            readonly node: {
                readonly offset: 0;
                readonly size: 16;
                readonly alignment: 8;
                readonly type: "ot_handle";
            };
            readonly fields: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly size_bytes: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_scene_style_property: {
        readonly size: 16;
        readonly alignment: 4;
        readonly fields: {
            readonly group: {
                readonly offset: 0;
                readonly size: 1;
                readonly alignment: 1;
                readonly type: "u8";
            };
            readonly kind: {
                readonly offset: 1;
                readonly size: 1;
                readonly alignment: 1;
                readonly type: "u8";
            };
            readonly edge: {
                readonly offset: 2;
                readonly size: 1;
                readonly alignment: 1;
                readonly type: "u8";
            };
            readonly unit: {
                readonly offset: 3;
                readonly size: 1;
                readonly alignment: 1;
                readonly type: "u8";
            };
            readonly flags: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly value: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "f32";
            };
            readonly reserved: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_session_options: {
        readonly size: 32;
        readonly alignment: 8;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly chunk_size: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly span_capacity: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly max_bytes: {
                readonly offset: 16;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
            readonly control_capacity: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_output_ticket: {
        readonly size: 32;
        readonly alignment: 8;
        readonly fields: {
            readonly session: {
                readonly offset: 0;
                readonly size: 16;
                readonly alignment: 8;
                readonly type: "ot_handle";
            };
            readonly request_id: {
                readonly offset: 16;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
            readonly byte_count: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_session_renderer_options: {
        readonly size: 24;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly width: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly height: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly remote: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_session_renderer_env_options: {
        readonly size: 32;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly width: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly height: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly remote_mode: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly entry_count: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly byte_count: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_split_snapshot: {
        readonly size: 24;
        readonly alignment: 8;
        readonly fields: {
            readonly buffer: {
                readonly offset: 0;
                readonly size: 16;
                readonly alignment: 8;
                readonly type: "ot_handle";
            };
            readonly row_columns: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly flags: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_split_control: {
        readonly size: 36;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly command: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly arguments: {
                readonly offset: 12;
                readonly size: 24;
                readonly alignment: 4;
                readonly type: "[6]u32";
            };
        };
    };
    readonly ot_session_renderer_state: {
        readonly size: 32;
        readonly alignment: 8;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly width: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly height: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly frame_count: {
                readonly offset: 16;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
            readonly frame_pending: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_buffer_options: {
        readonly size: 24;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly width: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly height: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly width_method: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly flags: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_unicode_char: {
        readonly size: 8;
        readonly alignment: 4;
        readonly fields: {
            readonly width: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly character: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_embedded_terminal_options: {
        readonly size: 24;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly cols: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly rows: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly max_scrollback: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_embedded_terminal_cursor: {
        readonly size: 56;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly x: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly y: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly has_value: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly visible: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly blinking: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly wide_tail: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly style: {
                readonly offset: 32;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly color_has_value: {
                readonly offset: 36;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly color_r: {
                readonly offset: 40;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly color_g: {
                readonly offset: 44;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly color_b: {
                readonly offset: 48;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 52;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_embedded_terminal_key: {
        readonly size: 32;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly action: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly composing: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly mods: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly consumed_mods: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly unshifted_codepoint: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_embedded_terminal_mouse: {
        readonly size: 32;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly action: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly button: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly mods: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly any_button_pressed: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly x: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "f32";
            };
            readonly y: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "f32";
            };
        };
    };
    readonly ot_edit_buffer_options: {
        readonly size: 16;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly width_method: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_edit_buffer_info: {
        readonly size: 48;
        readonly alignment: 8;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly content_epoch: {
                readonly offset: 8;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
            readonly byte_count: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly line_count: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly cursor_row: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly cursor_col: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly cursor_offset: {
                readonly offset: 32;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly can_undo: {
                readonly offset: 36;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly can_redo: {
                readonly offset: 40;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly tab_width: {
                readonly offset: 44;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_scene_editor_options: {
        readonly size: 40;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly show_cursor: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly style: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly blinking: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly color: {
                readonly offset: 24;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly mouse_pointer: {
                readonly offset: 32;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved2: {
                readonly offset: 36;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_edit_position: {
        readonly size: 24;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly valid: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly row: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly col: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly offset: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_editor_style: {
        readonly size: 32;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly flags: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly attributes: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly foreground: {
                readonly offset: 16;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly background: {
                readonly offset: 24;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
        };
    };
    readonly ot_edit_highlight: {
        readonly size: 20;
        readonly alignment: 4;
        readonly fields: {
            readonly start: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly end: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly style_id: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly priority: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly ref: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_editor_viewport: {
        readonly size: 24;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly x: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly y: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly width: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly height: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_editor_selection: {
        readonly size: 72;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly operation: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly behavior: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly start: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly end: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly anchor_x: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly anchor_y: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly focus_x: {
                readonly offset: 32;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly focus_y: {
                readonly offset: 36;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly update_cursor: {
                readonly offset: 40;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly follow_cursor: {
                readonly offset: 44;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly flags: {
                readonly offset: 48;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 52;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly foreground: {
                readonly offset: 56;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly background: {
                readonly offset: 64;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
        };
    };
    readonly ot_editor_view_info: {
        readonly size: 32;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly virtual_line_count: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly total_virtual_line_count: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly selection_present: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly selection_start: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly selection_end: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly selection_occupancy: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_editor_position: {
        readonly size: 28;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly visual_row: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly visual_col: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly logical_row: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly logical_col: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly offset: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_editor_measure: {
        readonly size: 16;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly line_count: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly width_cols_max: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_image_info: {
        readonly size: 32;
        readonly alignment: 4;
        readonly fields: {
            readonly width: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly height: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly source_width: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly source_height: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly format: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly color_status: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly orientation: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly has_alpha: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_image_pixels: {
        readonly size: 32;
        readonly alignment: 8;
        readonly fields: {
            readonly lease: {
                readonly offset: 0;
                readonly size: 16;
                readonly alignment: 8;
                readonly type: "ot_handle";
            };
            readonly pixels: {
                readonly offset: 16;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
            readonly byte_count: {
                readonly offset: 24;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
        };
    };
    readonly ot_image_draw_options: {
        readonly size: 64;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly flags: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly protocol: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly x: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly y: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly width: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly height: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly pixel_width: {
                readonly offset: 32;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly pixel_height: {
                readonly offset: 36;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly source_x: {
                readonly offset: 40;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly source_y: {
                readonly offset: 44;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly source_width: {
                readonly offset: 48;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly source_height: {
                readonly offset: 52;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 56;
                readonly size: 8;
                readonly alignment: 4;
                readonly type: "[2]u32";
            };
        };
    };
    readonly ot_session_kitty_image_transport: {
        readonly size: 32;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly requested: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly effective: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly file_state: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly fallback: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly pending_files: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly pending_bytes: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_text_buffer_info: {
        readonly size: 40;
        readonly alignment: 8;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly content_epoch: {
                readonly offset: 8;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
            readonly byte_count: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly text_length: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly line_count: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly highlight_count: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly tab_width: {
                readonly offset: 32;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 36;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_text_buffer_replacement: {
        readonly size: 56;
        readonly alignment: 8;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly buffer: {
                readonly offset: 8;
                readonly size: 16;
                readonly alignment: 8;
                readonly type: "ot_handle";
            };
            readonly view: {
                readonly offset: 24;
                readonly size: 16;
                readonly alignment: 8;
                readonly type: "ot_handle";
            };
            readonly byte_offset: {
                readonly offset: 40;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly byte_count: {
                readonly offset: 44;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly chunk_offset: {
                readonly offset: 48;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly chunk_count: {
                readonly offset: 52;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_text_buffer_replacement_info: {
        readonly size: 8;
        readonly alignment: 4;
        readonly fields: {
            readonly text_length: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly byte_count: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_buffer_draw_header: {
        readonly size: 16;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly operation: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly flags: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_buffer_draw_clear: {
        readonly size: 24;
        readonly alignment: 4;
        readonly fields: {
            readonly header: {
                readonly offset: 0;
                readonly size: 16;
                readonly alignment: 4;
                readonly type: "ot_buffer_draw_header";
            };
            readonly background: {
                readonly offset: 16;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
        };
    };
    readonly ot_buffer_draw_fill: {
        readonly size: 40;
        readonly alignment: 4;
        readonly fields: {
            readonly header: {
                readonly offset: 0;
                readonly size: 16;
                readonly alignment: 4;
                readonly type: "ot_buffer_draw_header";
            };
            readonly x: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly y: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly width: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly height: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly background: {
                readonly offset: 32;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
        };
    };
    readonly ot_buffer_draw_text_record: {
        readonly size: 44;
        readonly alignment: 4;
        readonly fields: {
            readonly header: {
                readonly offset: 0;
                readonly size: 16;
                readonly alignment: 4;
                readonly type: "ot_buffer_draw_header";
            };
            readonly x: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly y: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly attributes: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly foreground: {
                readonly offset: 28;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly background: {
                readonly offset: 36;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
        };
    };
    readonly ot_buffer_draw_cell: {
        readonly size: 48;
        readonly alignment: 4;
        readonly fields: {
            readonly header: {
                readonly offset: 0;
                readonly size: 16;
                readonly alignment: 4;
                readonly type: "ot_buffer_draw_header";
            };
            readonly x: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly y: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly character: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly attributes: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly foreground: {
                readonly offset: 32;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly background: {
                readonly offset: 40;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
        };
    };
    readonly ot_buffer_draw_box: {
        readonly size: 104;
        readonly alignment: 4;
        readonly fields: {
            readonly header: {
                readonly offset: 0;
                readonly size: 16;
                readonly alignment: 4;
                readonly type: "ot_buffer_draw_header";
            };
            readonly x: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly y: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly width: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly height: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly packed_options: {
                readonly offset: 32;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly foreground: {
                readonly offset: 36;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly background: {
                readonly offset: 44;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly title_color: {
                readonly offset: 52;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly border_chars: {
                readonly offset: 60;
                readonly size: 44;
                readonly alignment: 4;
                readonly type: "[11]u32";
            };
        };
    };
    readonly ot_buffer_draw_compose: {
        readonly size: 40;
        readonly alignment: 4;
        readonly fields: {
            readonly header: {
                readonly offset: 0;
                readonly size: 16;
                readonly alignment: 4;
                readonly type: "ot_buffer_draw_header";
            };
            readonly x: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly y: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly source_x: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly source_y: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly source_width: {
                readonly offset: 32;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly source_height: {
                readonly offset: 36;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_buffer_draw_alpha: {
        readonly size: 20;
        readonly alignment: 4;
        readonly fields: {
            readonly header: {
                readonly offset: 0;
                readonly size: 16;
                readonly alignment: 4;
                readonly type: "ot_buffer_draw_header";
            };
            readonly enabled: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_buffer_grid_options: {
        readonly size: 76;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly flags: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly foreground: {
                readonly offset: 16;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly background: {
                readonly offset: 24;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly border_chars: {
                readonly offset: 32;
                readonly size: 44;
                readonly alignment: 4;
                readonly type: "[11]u32";
            };
        };
    };
    readonly ot_buffer_lease_snapshot: {
        readonly size: 80;
        readonly alignment: 8;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly lease: {
                readonly offset: 8;
                readonly size: 16;
                readonly alignment: 8;
                readonly type: "ot_handle";
            };
            readonly width: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly height: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly generation: {
                readonly offset: 32;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
            readonly char_ptr: {
                readonly offset: 40;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
            readonly fg_ptr: {
                readonly offset: 48;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
            readonly bg_ptr: {
                readonly offset: 56;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
            readonly attributes_ptr: {
                readonly offset: 64;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
            readonly reserved: {
                readonly offset: 72;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
        };
    };
    readonly ot_session_terminal_options: {
        readonly size: 16;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly flags: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly kitty_keyboard_flags: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_session_control_options: {
        readonly size: 20;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly kind: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly argument: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_session_cursor_update: {
        readonly size: 24;
        readonly alignment: 4;
        readonly fields: {
            readonly fields: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly x: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly y: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly visible: {
                readonly offset: 12;
                readonly size: 1;
                readonly alignment: 1;
                readonly type: "u8";
            };
            readonly style: {
                readonly offset: 13;
                readonly size: 1;
                readonly alignment: 1;
                readonly type: "u8";
            };
            readonly blinking: {
                readonly offset: 14;
                readonly size: 1;
                readonly alignment: 1;
                readonly type: "u8";
            };
            readonly mouse_pointer: {
                readonly offset: 15;
                readonly size: 1;
                readonly alignment: 1;
                readonly type: "u8";
            };
            readonly color: {
                readonly offset: 16;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
        };
    };
    readonly ot_session_program_status: {
        readonly size: 32;
        readonly alignment: 4;
        readonly fields: {
            readonly state: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly kind: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly fields: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly progress: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly id_len: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly app_len: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly title_len: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly message_len: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_session_capabilities: {
        readonly size: 144;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly flags: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly width_method: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly multiplexer: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly image_protocol: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly osc52_support: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly kitty_keyboard_flags: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly term_name_len: {
                readonly offset: 32;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly term_version_len: {
                readonly offset: 36;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly term_from_xtversion: {
                readonly offset: 40;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 44;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly term_name: {
                readonly offset: 48;
                readonly size: 64;
                readonly alignment: 1;
                readonly type: "[64]u8";
            };
            readonly term_version: {
                readonly offset: 112;
                readonly size: 32;
                readonly alignment: 1;
                readonly type: "[32]u8";
            };
        };
    };
    readonly ot_session_pump_result: {
        readonly size: 24;
        readonly alignment: 8;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly status: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly deadline_ns: {
                readonly offset: 16;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
        };
    };
    readonly ot_context_options: {
        readonly size: 32;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly flags: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly object_capacity: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly render_cells_max: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 20;
                readonly size: 12;
                readonly alignment: 4;
                readonly type: "[3]u32";
            };
        };
    };
    readonly ot_context_error: {
        readonly size: 16;
        readonly alignment: 4;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly status: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly reserved: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_diagnostic: {
        readonly size: 4112;
        readonly alignment: 4;
        readonly fields: {
            readonly level: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly message_len: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly flags: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly message: {
                readonly offset: 16;
                readonly size: 4096;
                readonly alignment: 1;
                readonly type: "[4096]u8";
            };
        };
    };
    readonly ot_diagnostic_drain: {
        readonly size: 24;
        readonly alignment: 8;
        readonly fields: {
            readonly struct_size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly abi_version: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly count: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly remaining: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly dropped: {
                readonly offset: 16;
                readonly size: 8;
                readonly alignment: 8;
                readonly type: "u64";
            };
        };
    };
    readonly ot_scene_record_header: {
        readonly size: 8;
        readonly alignment: 4;
        readonly fields: {
            readonly size: {
                readonly offset: 0;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly operation: {
                readonly offset: 4;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_scene_record_slot: {
        readonly size: 16;
        readonly alignment: 4;
        readonly fields: {
            readonly header: {
                readonly offset: 0;
                readonly size: 8;
                readonly alignment: 4;
                readonly type: "ot_scene_record_header";
            };
            readonly slot: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly phase: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_scene_record_draw: {
        readonly size: 32;
        readonly alignment: 8;
        readonly fields: {
            readonly header: {
                readonly offset: 0;
                readonly size: 8;
                readonly alignment: 4;
                readonly type: "ot_scene_record_header";
            };
            readonly source: {
                readonly offset: 8;
                readonly size: 16;
                readonly alignment: 8;
                readonly type: "ot_handle";
            };
            readonly text_length: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly bottom_length: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_scene_record_stack: {
        readonly size: 32;
        readonly alignment: 4;
        readonly fields: {
            readonly header: {
                readonly offset: 0;
                readonly size: 8;
                readonly alignment: 4;
                readonly type: "ot_scene_record_header";
            };
            readonly operation: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly x: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly y: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly width: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly height: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly opacity: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "f32";
            };
        };
    };
    readonly ot_scene_record_grid: {
        readonly size: 92;
        readonly alignment: 4;
        readonly fields: {
            readonly header: {
                readonly offset: 0;
                readonly size: 8;
                readonly alignment: 4;
                readonly type: "ot_scene_record_header";
            };
            readonly options: {
                readonly offset: 8;
                readonly size: 76;
                readonly alignment: 4;
                readonly type: "ot_buffer_grid_options";
            };
            readonly column_count: {
                readonly offset: 84;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly row_count: {
                readonly offset: 88;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_scene_record_packed: {
        readonly size: 32;
        readonly alignment: 4;
        readonly fields: {
            readonly header: {
                readonly offset: 0;
                readonly size: 8;
                readonly alignment: 4;
                readonly type: "ot_scene_record_header";
            };
            readonly x: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly y: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly width: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly height: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly byte_count: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_scene_record_supersample: {
        readonly size: 32;
        readonly alignment: 4;
        readonly fields: {
            readonly header: {
                readonly offset: 0;
                readonly size: 8;
                readonly alignment: 4;
                readonly type: "ot_scene_record_header";
            };
            readonly x: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly y: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly format: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly stride: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly byte_count: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly reserved: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_scene_record_grayscale: {
        readonly size: 48;
        readonly alignment: 4;
        readonly fields: {
            readonly header: {
                readonly offset: 0;
                readonly size: 8;
                readonly alignment: 4;
                readonly type: "ot_scene_record_header";
            };
            readonly x: {
                readonly offset: 8;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly y: {
                readonly offset: 12;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly width: {
                readonly offset: 16;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly height: {
                readonly offset: 20;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly flags: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly sample_count: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly foreground: {
                readonly offset: 32;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly background: {
                readonly offset: 40;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
        };
    };
    readonly ot_scene_record_color_matrix: {
        readonly size: 88;
        readonly alignment: 4;
        readonly fields: {
            readonly header: {
                readonly offset: 0;
                readonly size: 8;
                readonly alignment: 4;
                readonly type: "ot_scene_record_header";
            };
            readonly matrix: {
                readonly offset: 8;
                readonly size: 64;
                readonly alignment: 4;
                readonly type: "[16]f32";
            };
            readonly strength: {
                readonly offset: 72;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "f32";
            };
            readonly channel: {
                readonly offset: 76;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly has_mask: {
                readonly offset: 80;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly mask_count: {
                readonly offset: 84;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
        };
    };
    readonly ot_scene_record_view: {
        readonly size: 32;
        readonly alignment: 8;
        readonly fields: {
            readonly header: {
                readonly offset: 0;
                readonly size: 8;
                readonly alignment: 4;
                readonly type: "ot_scene_record_header";
            };
            readonly source: {
                readonly offset: 8;
                readonly size: 16;
                readonly alignment: 8;
                readonly type: "ot_handle";
            };
            readonly x: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly y: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
        };
    };
    readonly ot_scene_record_image: {
        readonly size: 88;
        readonly alignment: 8;
        readonly fields: {
            readonly header: {
                readonly offset: 0;
                readonly size: 8;
                readonly alignment: 4;
                readonly type: "ot_scene_record_header";
            };
            readonly image: {
                readonly offset: 8;
                readonly size: 16;
                readonly alignment: 8;
                readonly type: "ot_handle";
            };
            readonly options: {
                readonly offset: 24;
                readonly size: 64;
                readonly alignment: 4;
                readonly type: "ot_image_draw_options";
            };
        };
    };
    readonly ot_scene_record_unicode: {
        readonly size: 56;
        readonly alignment: 8;
        readonly fields: {
            readonly header: {
                readonly offset: 0;
                readonly size: 8;
                readonly alignment: 4;
                readonly type: "ot_scene_record_header";
            };
            readonly unicode: {
                readonly offset: 8;
                readonly size: 16;
                readonly alignment: 8;
                readonly type: "ot_handle";
            };
            readonly index: {
                readonly offset: 24;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly x: {
                readonly offset: 28;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly y: {
                readonly offset: 32;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "i32";
            };
            readonly attributes: {
                readonly offset: 36;
                readonly size: 4;
                readonly alignment: 4;
                readonly type: "u32";
            };
            readonly foreground: {
                readonly offset: 40;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
            readonly background: {
                readonly offset: 48;
                readonly size: 8;
                readonly alignment: 2;
                readonly type: "[4]u16";
            };
        };
    };
};
export declare const nativeConstants: {
    readonly OT_CONTEXT_ABI_VERSION: 1;
    readonly OT_OK: 0;
    readonly OT_INVALID_ARGUMENT: -1;
    readonly OT_UNSUPPORTED_VERSION: -2;
    readonly OT_OUT_OF_MEMORY: -3;
    readonly OT_WRONG_THREAD: -4;
    readonly OT_INTERNAL_ERROR: -5;
    readonly OT_CONTEXT_BUSY: -6;
    readonly OT_WRONG_CONTEXT: -7;
    readonly OT_WRONG_KIND: -8;
    readonly OT_STALE_HANDLE: -9;
    readonly OT_WRONG_SESSION: -10;
    readonly OT_OUTPUT_BACKPRESSURE: -11;
    readonly OT_SESSION_CLOSED: -12;
    readonly OT_OUTPUT_BUSY: -13;
    readonly OT_STALE_OUTPUT: -14;
    readonly OT_OUTPUT_FAILED: -15;
    readonly OT_OBJECT_LIMIT: -16;
    readonly OT_RENDERER_ATTACHED: -17;
    readonly OT_RENDERER_NOT_ATTACHED: -18;
    readonly OT_INVALID_PHASE: -19;
    readonly OT_CONTROL_PACKET_LIMIT: -20;
    readonly OT_LEASE_LIMIT: -21;
    readonly OT_LEASE_BYTES_LIMIT: -22;
    readonly OT_STALE_LEASE: -23;
    readonly OT_UNSUPPORTED_RESOURCE: -24;
    readonly OT_STALE_FRAME: -25;
    readonly OT_LAYOUT_LIMIT: -26;
    readonly OT_FRAME_BUSY: -27;
    readonly OT_FRAME_REQUEST_LIMIT: -28;
    readonly OT_IMAGE_UNSUPPORTED_FORMAT: -40;
    readonly OT_IMAGE_UNSUPPORTED_COLOR_SPACE: -41;
    readonly OT_IMAGE_MALFORMED_DATA: -42;
    readonly OT_IMAGE_DIMENSION_LIMIT: -43;
    readonly OT_IMAGE_MEMORY_LIMIT: -44;
    readonly OT_IMAGE_OUTPUT_TOO_SMALL: -45;
    readonly OT_IMAGE_UNSUPPORTED_FEATURE: -46;
    readonly OT_IMAGE_BUSY: -47;
    readonly OT_SCENE_ROOT: 0;
    readonly OT_SCENE_BOX: 1;
    readonly OT_SCENE_TEXT: 2;
    readonly OT_SCENE_SLIDER: 3;
    readonly OT_SCENE_ARROW: 4;
    readonly OT_SCENE_EDITOR: 5;
    readonly OT_SCENE_CUSTOM: 6;
    readonly OT_SCENE_TEXT_VIEW: 7;
    readonly OT_SCENE_IMAGE: 8;
    readonly OT_SCENE_WRAP_NONE: 0;
    readonly OT_SCENE_WRAP_CHAR: 1;
    readonly OT_SCENE_WRAP_WORD: 2;
    readonly OT_SCENE_ALIGN_LEFT: 0;
    readonly OT_SCENE_ALIGN_CENTER: 1;
    readonly OT_SCENE_ALIGN_RIGHT: 2;
    readonly OT_STYLE_ENUM: 0;
    readonly OT_STYLE_FLOAT: 1;
    readonly OT_STYLE_VALUE: 2;
    readonly OT_STYLE_BORDER: 3;
    readonly OT_STYLE_DIMENSION: 4;
    readonly OT_STYLE_BORDER_WIDTH: 0;
    readonly OT_STYLE_FLAGS_NONE: 0;
    readonly OT_STYLE_DISABLE_FLEX_SHRINK: 1;
    readonly OT_STYLE_ENUM_DIRECTION: 0;
    readonly OT_STYLE_ENUM_FLEX_DIRECTION: 1;
    readonly OT_STYLE_ENUM_JUSTIFY_CONTENT: 2;
    readonly OT_STYLE_ENUM_ALIGN_CONTENT: 3;
    readonly OT_STYLE_ENUM_ALIGN_ITEMS: 4;
    readonly OT_STYLE_ENUM_ALIGN_SELF: 5;
    readonly OT_STYLE_ENUM_POSITION_TYPE: 6;
    readonly OT_STYLE_ENUM_FLEX_WRAP: 7;
    readonly OT_STYLE_ENUM_OVERFLOW: 8;
    readonly OT_STYLE_ENUM_DISPLAY: 9;
    readonly OT_STYLE_ENUM_BOX_SIZING: 10;
    readonly OT_STYLE_FLOAT_FLEX: 0;
    readonly OT_STYLE_FLOAT_FLEX_GROW: 1;
    readonly OT_STYLE_FLOAT_FLEX_SHRINK: 2;
    readonly OT_STYLE_FLOAT_ASPECT_RATIO: 3;
    readonly OT_STYLE_VALUE_WIDTH: 0;
    readonly OT_STYLE_VALUE_HEIGHT: 1;
    readonly OT_STYLE_VALUE_MIN_WIDTH: 2;
    readonly OT_STYLE_VALUE_MIN_HEIGHT: 3;
    readonly OT_STYLE_VALUE_MAX_WIDTH: 4;
    readonly OT_STYLE_VALUE_MAX_HEIGHT: 5;
    readonly OT_STYLE_VALUE_FLEX_BASIS: 6;
    readonly OT_STYLE_VALUE_MARGIN: 7;
    readonly OT_STYLE_VALUE_PADDING: 8;
    readonly OT_STYLE_VALUE_POSITION: 9;
    readonly OT_STYLE_VALUE_GAP: 10;
    readonly OT_DIMENSION_WIDTH: 0;
    readonly OT_DIMENSION_HEIGHT: 1;
    readonly OT_UNIT_UNDEFINED: 0;
    readonly OT_UNIT_POINT: 1;
    readonly OT_UNIT_PERCENT: 2;
    readonly OT_UNIT_AUTO: 3;
    readonly OT_EDGE_NONE: 0;
    readonly OT_EDGE_LEFT: 0;
    readonly OT_EDGE_TOP: 1;
    readonly OT_EDGE_RIGHT: 2;
    readonly OT_EDGE_BOTTOM: 3;
    readonly OT_EDGE_START: 4;
    readonly OT_EDGE_END: 5;
    readonly OT_EDGE_HORIZONTAL: 6;
    readonly OT_EDGE_VERTICAL: 7;
    readonly OT_EDGE_ALL: 8;
    readonly OT_GUTTER_COLUMN: 0;
    readonly OT_GUTTER_ROW: 1;
    readonly OT_GUTTER_ALL: 2;
    readonly OT_DIRECTION_INHERIT: 0;
    readonly OT_DIRECTION_LTR: 1;
    readonly OT_DIRECTION_RTL: 2;
    readonly OT_FLEX_DIRECTION_COLUMN: 0;
    readonly OT_FLEX_DIRECTION_COLUMN_REVERSE: 1;
    readonly OT_FLEX_DIRECTION_ROW: 2;
    readonly OT_FLEX_DIRECTION_ROW_REVERSE: 3;
    readonly OT_JUSTIFY_FLEX_START: 0;
    readonly OT_JUSTIFY_CENTER: 1;
    readonly OT_JUSTIFY_FLEX_END: 2;
    readonly OT_JUSTIFY_SPACE_BETWEEN: 3;
    readonly OT_JUSTIFY_SPACE_AROUND: 4;
    readonly OT_JUSTIFY_SPACE_EVENLY: 5;
    readonly OT_ALIGN_AUTO: 0;
    readonly OT_ALIGN_FLEX_START: 1;
    readonly OT_ALIGN_CENTER: 2;
    readonly OT_ALIGN_FLEX_END: 3;
    readonly OT_ALIGN_STRETCH: 4;
    readonly OT_ALIGN_BASELINE: 5;
    readonly OT_ALIGN_SPACE_BETWEEN: 6;
    readonly OT_ALIGN_SPACE_AROUND: 7;
    readonly OT_ALIGN_SPACE_EVENLY: 8;
    readonly OT_POSITION_STATIC: 0;
    readonly OT_POSITION_RELATIVE: 1;
    readonly OT_POSITION_ABSOLUTE: 2;
    readonly OT_FLEX_WRAP_NONE: 0;
    readonly OT_FLEX_WRAP_WRAP: 1;
    readonly OT_FLEX_WRAP_REVERSE: 2;
    readonly OT_OVERFLOW_VISIBLE: 0;
    readonly OT_OVERFLOW_HIDDEN: 1;
    readonly OT_OVERFLOW_SCROLL: 2;
    readonly OT_DISPLAY_FLEX: 0;
    readonly OT_DISPLAY_NONE: 1;
    readonly OT_BOX_SIZING_BORDER_BOX: 0;
    readonly OT_BOX_SIZING_CONTENT_BOX: 1;
    readonly OT_STYLE_ENUM_DIRECTION_MAX: 2;
    readonly OT_STYLE_ENUM_FLEX_DIRECTION_MAX: 3;
    readonly OT_STYLE_ENUM_JUSTIFY_CONTENT_MAX: 5;
    readonly OT_STYLE_ENUM_ALIGN_CONTENT_MAX: 8;
    readonly OT_STYLE_ENUM_ALIGN_ITEMS_MAX: 8;
    readonly OT_STYLE_ENUM_ALIGN_SELF_MAX: 8;
    readonly OT_STYLE_ENUM_POSITION_TYPE_MAX: 2;
    readonly OT_STYLE_ENUM_FLEX_WRAP_MAX: 2;
    readonly OT_STYLE_ENUM_OVERFLOW_MAX: 2;
    readonly OT_STYLE_ENUM_DISPLAY_MAX: 1;
    readonly OT_STYLE_ENUM_BOX_SIZING_MAX: 1;
    readonly OT_MEASURE_UNDEFINED: 0;
    readonly OT_MEASURE_EXACTLY: 1;
    readonly OT_MEASURE_AT_MOST: 2;
    readonly OT_LAYOUT_PUBLIC: 0;
    readonly OT_LAYOUT_YOGA: 1;
    readonly OT_LAYOUT_PAINT: 2;
    readonly OT_BORDER_NONE: 0;
    readonly OT_BORDER_LEFT: 1;
    readonly OT_BORDER_BOTTOM: 2;
    readonly OT_BORDER_RIGHT: 4;
    readonly OT_BORDER_TOP: 8;
    readonly OT_BORDER_ALL: 15;
    readonly OT_BORDER_SINGLE: 0;
    readonly OT_BORDER_DOUBLE: 1;
    readonly OT_BORDER_ROUNDED: 2;
    readonly OT_BORDER_HEAVY: 3;
    readonly OT_COLOR_RGB: 0;
    readonly OT_COLOR_INDEXED: 1;
    readonly OT_COLOR_DEFAULT: 2;
    readonly OT_COLOR_CHANNEL_MASK: 255;
    readonly OT_COLOR_META_SHIFT: 8;
    readonly OT_SCENE_TEXT_SELECTION_RESET: 0;
    readonly OT_SCENE_TEXT_SELECTION_SET: 1;
    readonly OT_SCENE_TEXT_SELECTION_UPDATE: 2;
    readonly OT_SCENE_TEXT_SELECTION_CELL: 0;
    readonly OT_SCENE_TEXT_SELECTION_WORD: 1;
    readonly OT_SCENE_TEXT_SELECTION_LINE: 2;
    readonly OT_SCENE_TEXT_SELECTION_BACKGROUND: 1;
    readonly OT_SCENE_TEXT_SELECTION_FOREGROUND: 2;
    readonly OT_SCENE_TEXT_FOREGROUND: 1;
    readonly OT_SCENE_TEXT_BACKGROUND: 2;
    readonly OT_SCENE_TEXT_LINK: 4;
    readonly OT_SCENE_MUTATIONS_MAX: 4096;
    readonly OT_SCENE_HOOK_UPDATE: 1;
    readonly OT_SCENE_HOOK_RESIZE: 2;
    readonly OT_SCENE_HOOK_LAYOUT_CHANGED: 4;
    readonly OT_SCENE_HOOK_RENDER_BEFORE: 8;
    readonly OT_SCENE_HOOK_RENDER_AFTER: 16;
    readonly OT_SCENE_HOOK_RENDER_SELF: 32;
    readonly OT_SCENE_HOOK_IDLE_UPDATE: 64;
    readonly OT_SCENE_FRAME_DONE: 0;
    readonly OT_SCENE_FRAME_UPDATE: 1;
    readonly OT_SCENE_FRAME_RESIZE: 2;
    readonly OT_SCENE_FRAME_LAYOUT_CHANGED: 3;
    readonly OT_SCENE_FRAME_RECORD: 4;
    readonly OT_SCENE_FRAME_YIELD: 5;
    readonly OT_SCENE_GEOMETRY_PAINT: 1;
    readonly OT_SCENE_GEOMETRY_PUBLIC: 2;
    readonly OT_SCENE_PROPERTY_Z_INDEX: 1;
    readonly OT_SCENE_PROPERTY_OPACITY: 2;
    readonly OT_SCENE_PROPERTY_TRANSLATE_X: 4;
    readonly OT_SCENE_PROPERTY_TRANSLATE_Y: 8;
    readonly OT_SCENE_PROPERTY_BORDER: 16;
    readonly OT_SCENE_PROPERTY_SHOULD_FILL: 32;
    readonly OT_SCENE_PROPERTY_BACKGROUND: 64;
    readonly OT_SCENE_PROPERTY_BORDER_COLOR: 128;
    readonly OT_SCENE_PROPERTY_BORDER_STYLE: 256;
    readonly OT_SCENE_PROPERTY_FOCUSABLE: 512;
    readonly OT_SCENE_PROPERTY_FOCUSED_BORDER_COLOR: 1024;
    readonly OT_SCENE_PROPERTY_STYLE: 2048;
    readonly OT_SCENE_PROPERTY_RESET_BORDER_CHARACTERS: 4096;
    readonly OT_SCENE_PROPERTY_RECORD_MAX: 88;
    readonly OT_SCENE_PROPERTY_BYTES_MAX: 360448;
    readonly OT_SESSION_OPEN: 0;
    readonly OT_SESSION_CLOSING: 1;
    readonly OT_SESSION_CLOSED_STATE: 2;
    readonly OT_SESSION_FAILED: 3;
    readonly OT_SESSION_CANCELLED_STATE: 4;
    readonly OT_SESSION_REMOTE_AUTO: 0;
    readonly OT_SESSION_REMOTE_LOCAL: 1;
    readonly OT_SESSION_REMOTE_REMOTE: 2;
    readonly OT_SESSION_ENV_ENTRIES_MAX: 256;
    readonly OT_SESSION_ENV_BYTES_MAX: 65536;
    readonly OT_RENDER_PRESENTED: 0;
    readonly OT_RENDER_PENDING: 1;
    readonly OT_RENDER_SKIPPED: 2;
    readonly OT_RENDER_FAILED: 3;
    readonly OT_SESSION_BUFFER_CURRENT: 0;
    readonly OT_SESSION_BUFFER_NEXT: 1;
    readonly OT_WIDTH_METHOD_WCWIDTH: 0;
    readonly OT_WIDTH_METHOD_UNICODE: 1;
    readonly OT_WIDTH_METHOD_NO_ZWJ: 2;
    readonly OT_WIDTH_METHOD_UNICODE_WIDE: 3;
    readonly OT_BUFFER_RESPECT_ALPHA: 1;
    readonly OT_EMBEDDED_TERMINAL_INVALIDATE: 0;
    readonly OT_EMBEDDED_TERMINAL_SCROLL: 1;
    readonly OT_EMBEDDED_TERMINAL_CLEAR_SELECTION: 2;
    readonly OT_EMBEDDED_TERMINAL_SET_TRANSPARENT_BACKGROUND: 3;
    readonly OT_EDIT_CURSOR_CHANGED: 1;
    readonly OT_EDIT_CONTENT_CHANGED: 2;
    readonly OT_EDIT_HISTORY_CURSOR_CHANGED: 4;
    readonly OT_MOUSE_POINTER_AUTO: 0;
    readonly OT_MOUSE_POINTER_DEFAULT: 1;
    readonly OT_MOUSE_POINTER_NONE: 2;
    readonly OT_MOUSE_POINTER_CONTEXT_MENU: 3;
    readonly OT_MOUSE_POINTER_HELP: 4;
    readonly OT_MOUSE_POINTER_POINTER: 5;
    readonly OT_MOUSE_POINTER_PROGRESS: 6;
    readonly OT_MOUSE_POINTER_WAIT: 7;
    readonly OT_MOUSE_POINTER_CELL: 8;
    readonly OT_MOUSE_POINTER_CROSSHAIR: 9;
    readonly OT_MOUSE_POINTER_TEXT: 10;
    readonly OT_MOUSE_POINTER_VERTICAL_TEXT: 11;
    readonly OT_MOUSE_POINTER_ALIAS: 12;
    readonly OT_MOUSE_POINTER_COPY: 13;
    readonly OT_MOUSE_POINTER_MOVE: 14;
    readonly OT_MOUSE_POINTER_NO_DROP: 15;
    readonly OT_MOUSE_POINTER_NOT_ALLOWED: 16;
    readonly OT_MOUSE_POINTER_GRAB: 17;
    readonly OT_MOUSE_POINTER_GRABBING: 18;
    readonly OT_MOUSE_POINTER_ALL_SCROLL: 19;
    readonly OT_MOUSE_POINTER_COL_RESIZE: 20;
    readonly OT_MOUSE_POINTER_ROW_RESIZE: 21;
    readonly OT_MOUSE_POINTER_N_RESIZE: 22;
    readonly OT_MOUSE_POINTER_E_RESIZE: 23;
    readonly OT_MOUSE_POINTER_S_RESIZE: 24;
    readonly OT_MOUSE_POINTER_W_RESIZE: 25;
    readonly OT_MOUSE_POINTER_NE_RESIZE: 26;
    readonly OT_MOUSE_POINTER_NW_RESIZE: 27;
    readonly OT_MOUSE_POINTER_SE_RESIZE: 28;
    readonly OT_MOUSE_POINTER_SW_RESIZE: 29;
    readonly OT_MOUSE_POINTER_EW_RESIZE: 30;
    readonly OT_MOUSE_POINTER_NS_RESIZE: 31;
    readonly OT_MOUSE_POINTER_NESW_RESIZE: 32;
    readonly OT_MOUSE_POINTER_NWSE_RESIZE: 33;
    readonly OT_MOUSE_POINTER_ZOOM_IN: 34;
    readonly OT_MOUSE_POINTER_ZOOM_OUT: 35;
    readonly OT_MOUSE_POINTER_MAX: 35;
    readonly OT_MOUSE_POINTER_UNCHANGED: 4294967295;
    readonly OT_EDIT_DELETE_FORWARD: 0;
    readonly OT_EDIT_BACKSPACE: 1;
    readonly OT_EDIT_NEW_LINE: 2;
    readonly OT_EDIT_DELETE_LINE: 3;
    readonly OT_EDIT_MOVE_LEFT: 4;
    readonly OT_EDIT_MOVE_RIGHT: 5;
    readonly OT_EDIT_MOVE_UP: 6;
    readonly OT_EDIT_MOVE_DOWN: 7;
    readonly OT_EDIT_GOTO_LINE: 8;
    readonly OT_EDIT_CURSOR_OFFSET: 9;
    readonly OT_EDIT_CLEAR: 10;
    readonly OT_EDIT_CLEAR_HISTORY: 11;
    readonly OT_EDIT_DEBUG_ROPE: 12;
    readonly OT_EDIT_POSITION_CURSOR: 0;
    readonly OT_EDIT_POSITION_NEXT_WORD: 1;
    readonly OT_EDIT_POSITION_PREV_WORD: 2;
    readonly OT_EDIT_POSITION_EOL: 3;
    readonly OT_EDIT_POSITION_OFFSET: 4;
    readonly OT_EDIT_POSITION_COORDS: 5;
    readonly OT_EDIT_POSITION_LINE_START: 6;
    readonly OT_EDITOR_STYLE_FOREGROUND: 1;
    readonly OT_EDITOR_STYLE_BACKGROUND: 2;
    readonly OT_EDITOR_STYLE_ATTRIBUTES: 4;
    readonly OT_EDIT_HIGHLIGHT_ADD_LINE: 0;
    readonly OT_EDIT_HIGHLIGHT_ADD_RANGE: 1;
    readonly OT_EDIT_HIGHLIGHT_REMOVE_REF: 2;
    readonly OT_EDIT_HIGHLIGHT_CLEAR_LINE: 3;
    readonly OT_EDIT_HIGHLIGHT_CLEAR_ALL: 4;
    readonly OT_EDITOR_MOVE_UP: 0;
    readonly OT_EDITOR_MOVE_DOWN: 1;
    readonly OT_EDITOR_GOTO_LINE_END: 2;
    readonly OT_EDITOR_DELETE_SELECTION: 3;
    readonly OT_EDITOR_CURSOR_OFFSET: 4;
    readonly OT_EDITOR_WRAP_MODE: 5;
    readonly OT_EDITOR_TAB_INDICATOR: 6;
    readonly OT_EDITOR_SELECT_SET: 0;
    readonly OT_EDITOR_SELECT_UPDATE: 1;
    readonly OT_EDITOR_SELECT_RESET: 2;
    readonly OT_EDITOR_SELECT_LOCAL: 3;
    readonly OT_EDITOR_SELECT_LOCAL_UPDATE: 4;
    readonly OT_EDITOR_SELECT_LOCAL_RESET: 5;
    readonly OT_EDITOR_SELECT_CELL: 6;
    readonly OT_EDITOR_SELECT_OCCUPANCY: 7;
    readonly OT_EDITOR_SELECT_INCLUSIVE: 8;
    readonly OT_EDITOR_SELECT_COLORS: 9;
    readonly OT_SELECT_DOCUMENT_SET: 0;
    readonly OT_SELECT_DOCUMENT_UPDATE: 1;
    readonly OT_SELECT_DOCUMENT_RESET: 2;
    readonly OT_SELECT_VIEWPORT_SET: 3;
    readonly OT_SELECT_VIEWPORT_UPDATE: 4;
    readonly OT_SELECT_VIEWPORT_RESET: 5;
    readonly OT_SELECTION_CELL: 0;
    readonly OT_SELECTION_WORD: 1;
    readonly OT_SELECTION_LINE: 2;
    readonly OT_SELECTION_OCCUPANCY_CELL: 0;
    readonly OT_SELECTION_OCCUPANCY_BOUNDARY: 1;
    readonly OT_EDITOR_POSITION_CURSOR: 0;
    readonly OT_EDITOR_POSITION_NEXT_WORD: 1;
    readonly OT_EDITOR_POSITION_PREV_WORD: 2;
    readonly OT_EDITOR_POSITION_EOL: 3;
    readonly OT_EDITOR_POSITION_VISUAL_SOL: 4;
    readonly OT_EDITOR_POSITION_VISUAL_EOL: 5;
    readonly OT_IMAGE_FIT: 0;
    readonly OT_IMAGE_COVER: 1;
    readonly OT_IMAGE_FILL: 2;
    readonly OT_IMAGE_PROTOCOL_AUTO: 0;
    readonly OT_IMAGE_PROTOCOL_KITTY: 1;
    readonly OT_IMAGE_PROTOCOL_SIXEL: 2;
    readonly OT_IMAGE_PROTOCOL_BLOCKS: 3;
    readonly OT_IMAGE_DRAW_SOURCE_WIDTH: 1;
    readonly OT_IMAGE_DRAW_SOURCE_HEIGHT: 2;
    readonly OT_IMAGE_FORMAT_UNKNOWN: 0;
    readonly OT_IMAGE_FORMAT_PNG: 1;
    readonly OT_IMAGE_FORMAT_RGBA: 2;
    readonly OT_IMAGE_FORMAT_JPEG: 3;
    readonly OT_IMAGE_FORMAT_WEBP: 4;
    readonly OT_IMAGE_FORMAT_GIF: 5;
    readonly OT_IMAGE_ASSUMED_SRGB: 0;
    readonly OT_IMAGE_EXPLICIT_SRGB: 1;
    readonly OT_IMAGE_RGBA8: 0;
    readonly OT_IMAGE_BGRA8: 1;
    readonly OT_IMAGE_ALPHA_STRAIGHT: 0;
    readonly OT_IMAGE_ALPHA_OPAQUE: 1;
    readonly OT_IMAGE_FILTER_DEFAULT: 0;
    readonly OT_IMAGE_FILTER_AREA: 1;
    readonly OT_IMAGE_FILTER_TRIANGLE: 2;
    readonly OT_IMAGE_FILTER_CUBIC_BSPLINE: 3;
    readonly OT_IMAGE_FILTER_CATMULL_ROM: 4;
    readonly OT_IMAGE_FILTER_MITCHELL: 5;
    readonly OT_IMAGE_FILTER_NEAREST: 6;
    readonly OT_IMAGE_ROTATE_90: 0;
    readonly OT_IMAGE_ROTATE_180: 1;
    readonly OT_IMAGE_ROTATE_270: 2;
    readonly OT_IMAGE_FLIP: 3;
    readonly OT_IMAGE_FLOP: 4;
    readonly OT_IMAGE_BLEND_SOURCE_OVER: 0;
    readonly OT_IMAGE_BLEND_SOURCE: 1;
    readonly OT_IMAGE_BLEND_DESTINATION_OVER: 2;
    readonly OT_TEXT_VIEW_WRAP_WIDTH: 0;
    readonly OT_TEXT_VIEW_WRAP_MODE: 1;
    readonly OT_TEXT_VIEW_FIRST_LINE_OFFSET: 2;
    readonly OT_TEXT_VIEW_TAB_INDICATOR: 3;
    readonly OT_TEXT_VIEW_TRUNCATE: 4;
    readonly OT_TEXT_VIEW_TEXT_ALIGN: 5;
    readonly OT_TEXT_REPLACEMENT_COUNT_MAX: 256;
    readonly OT_TEXT_REPLACEMENT_CHUNKS_MAX: 4096;
    readonly OT_TEXT_REPLACEMENT_BYTES_MAX: 4194304;
    readonly OT_TEXT_REPLACEMENT_URL_BYTES_MAX: 1048576;
    readonly OT_BUFFER_TEXT_BYTES_MAX: 65536;
    readonly OT_BUFFER_DRAW_CLEAR: 0;
    readonly OT_BUFFER_DRAW_FILL: 1;
    readonly OT_BUFFER_DRAW_TEXT: 2;
    readonly OT_BUFFER_DRAW_CELL: 3;
    readonly OT_BUFFER_DRAW_CELL_BLEND: 4;
    readonly OT_BUFFER_DRAW_CHAR: 5;
    readonly OT_BUFFER_DRAW_BOX: 6;
    readonly OT_BUFFER_DRAW_COMPOSE: 7;
    readonly OT_BUFFER_DRAW_RESPECT_ALPHA: 8;
    readonly OT_BUFFER_DRAW_HAS_BACKGROUND: 1;
    readonly OT_BUFFER_DRAW_HAS_SOURCE_WIDTH: 2;
    readonly OT_BUFFER_DRAW_HAS_SOURCE_HEIGHT: 4;
    readonly OT_BUFFER_STACK_DEPTH_MAX: 256;
    readonly OT_BUFFER_STACK_GET_OPACITY: 0;
    readonly OT_BUFFER_STACK_PUSH_SCISSOR: 1;
    readonly OT_BUFFER_STACK_POP_SCISSOR: 2;
    readonly OT_BUFFER_STACK_CLEAR_SCISSORS: 3;
    readonly OT_BUFFER_STACK_PUSH_OPACITY: 4;
    readonly OT_BUFFER_STACK_POP_OPACITY: 5;
    readonly OT_BUFFER_STACK_CLEAR_OPACITY: 6;
    readonly OT_BUFFER_GRID_INNER: 1;
    readonly OT_BUFFER_GRID_OUTER: 2;
    readonly OT_SESSION_CONTROL_PACKET_BYTES: 4096;
    readonly OT_TERMINAL_ALTERNATE_SCREEN: 1;
    readonly OT_TERMINAL_MOUSE: 2;
    readonly OT_TERMINAL_MOUSE_MOVEMENT: 4;
    readonly OT_TERMINAL_CLEAR_ON_CLOSE: 8;
    readonly OT_CONTROL_CAPABILITY_RESPONSE: 1;
    readonly OT_CONTROL_TITLE: 2;
    readonly OT_CONTROL_MOUSE: 3;
    readonly OT_CONTROL_KITTY_KEYBOARD_FLAGS: 4;
    readonly OT_CONTROL_RESTORE_MODES: 5;
    readonly OT_CONTROL_QUERY_PIXEL_RESOLUTION: 6;
    readonly OT_CONTROL_QUERY_THEME_COLORS: 7;
    readonly OT_CONTROL_CURSOR: 8;
    readonly OT_CONTROL_RESET_BACKGROUND: 9;
    readonly OT_CONTROL_PALETTE_QUERY: 10;
    readonly OT_CONTROL_PROGRAM_STATUS: 11;
    readonly OT_CURSOR_POSITION: 1;
    readonly OT_CURSOR_STYLE: 2;
    readonly OT_CURSOR_BLINKING: 4;
    readonly OT_CURSOR_COLOR: 8;
    readonly OT_CURSOR_MOUSE_POINTER: 16;
    readonly OT_PROGRAM_STATE_IDLE: 1;
    readonly OT_PROGRAM_STATE_WORKING: 2;
    readonly OT_PROGRAM_STATE_DONE: 3;
    readonly OT_PROGRAM_STATE_BLOCKED: 4;
    readonly OT_PROGRAM_STATE_ERROR: 5;
    readonly OT_PROGRAM_STATE_CLEAR: 6;
    readonly OT_PROGRAM_KIND_PERMISSION: 1;
    readonly OT_PROGRAM_KIND_QUESTION: 2;
    readonly OT_PROGRAM_KIND_AUTH: 3;
    readonly OT_PROGRAM_STATUS_PROGRESS: 1;
    readonly OT_CAP_KITTY_KEYBOARD: 1;
    readonly OT_CAP_KITTY_GRAPHICS: 2;
    readonly OT_CAP_RGB: 4;
    readonly OT_CAP_ANSI256: 8;
    readonly OT_CAP_SGR_PIXELS: 16;
    readonly OT_CAP_COLOR_SCHEME_UPDATES: 32;
    readonly OT_CAP_EXPLICIT_WIDTH: 64;
    readonly OT_CAP_SCALED_TEXT: 128;
    readonly OT_CAP_SIXEL: 256;
    readonly OT_CAP_FOCUS_TRACKING: 512;
    readonly OT_CAP_SYNC: 1024;
    readonly OT_CAP_BRACKETED_PASTE: 2048;
    readonly OT_CAP_HYPERLINKS: 4096;
    readonly OT_CAP_OSC52: 8192;
    readonly OT_CAP_NOTIFICATIONS: 16384;
    readonly OT_CAP_EXPLICIT_CURSOR_POSITIONING: 32768;
    readonly OT_CAP_REMOTE: 65536;
    readonly OT_CAP_PROGRAM_STATUS: 131072;
    readonly OT_TERMINAL_UNINITIALIZED: 0;
    readonly OT_TERMINAL_SETTING_UP: 1;
    readonly OT_TERMINAL_ACTIVE: 2;
    readonly OT_TERMINAL_SUSPENDING: 3;
    readonly OT_TERMINAL_SUSPENDED: 4;
    readonly OT_TERMINAL_RESUMING: 5;
    readonly OT_TERMINAL_CLOSING: 6;
    readonly OT_TERMINAL_RESTORED: 7;
    readonly OT_TERMINAL_FAILED: 8;
    readonly OT_TERMINAL_CANCELLED: 9;
    readonly OT_PUMP_IDLE: 0;
    readonly OT_PUMP_AGAIN: 1;
    readonly OT_PUMP_OUTPUT_PENDING: 2;
    readonly OT_PUMP_WAIT_UNTIL: 3;
    readonly OT_PUMP_CLOSED: 4;
    readonly OT_DIAGNOSTIC_MESSAGE_BYTES: 4096;
    readonly OT_DIAGNOSTIC_TRUNCATED: 1;
    readonly OT_SCENE_RECORD_BYTES_MAX: 67108864;
    readonly OT_SCENE_RECORD_PHASE_BEFORE: 0;
    readonly OT_SCENE_RECORD_PHASE_SELF: 1;
    readonly OT_SCENE_RECORD_PHASE_AFTER: 2;
    readonly OT_SCENE_RECORD_SLOT: 0;
    readonly OT_SCENE_RECORD_DRAW: 1;
    readonly OT_SCENE_RECORD_STACK: 2;
    readonly OT_SCENE_RECORD_GRID: 3;
    readonly OT_SCENE_RECORD_PACKED: 4;
    readonly OT_SCENE_RECORD_SUPERSAMPLE: 5;
    readonly OT_SCENE_RECORD_GRAYSCALE: 6;
    readonly OT_SCENE_RECORD_COLOR_MATRIX: 7;
    readonly OT_SCENE_RECORD_TEXT_VIEW: 8;
    readonly OT_SCENE_RECORD_EDITOR_VIEW: 9;
    readonly OT_SCENE_RECORD_SCENE_TEXT: 10;
    readonly OT_SCENE_RECORD_IMAGE: 11;
    readonly OT_SCENE_RECORD_UNICODE: 12;
    readonly OT_SCENE_RECORD_GRAYSCALE_FOREGROUND: 1;
    readonly OT_SCENE_RECORD_GRAYSCALE_BACKGROUND: 2;
    readonly OT_SCENE_RECORD_GRAYSCALE_SUPERSAMPLED: 4;
    readonly OT_CLIPBOARD_OPERATION_PENDING: 0;
    readonly OT_CLIPBOARD_OPERATION_READ: 1;
    readonly OT_CLIPBOARD_OPERATION_EMPTY: 2;
    readonly OT_CLIPBOARD_OPERATION_WRITTEN: 3;
    readonly OT_CLIPBOARD_OPERATION_CLEARED: 4;
    readonly OT_CLIPBOARD_OPERATION_UNSUPPORTED: 5;
    readonly OT_CLIPBOARD_OPERATION_CANCELLED: 6;
    readonly OT_CLIPBOARD_OPERATION_TIMED_OUT: 7;
    readonly OT_CLIPBOARD_OPERATION_LIMIT_EXCEEDED: 8;
    readonly OT_CLIPBOARD_OPERATION_FAILED: 9;
    readonly OT_CLIPBOARD_OPERATION_INVALID_HANDLE: 10;
    readonly OT_CLIPBOARD_START_OK: 0;
    readonly OT_CLIPBOARD_START_INVALID_SERVICE: 1;
    readonly OT_CLIPBOARD_START_SHUTTING_DOWN: 2;
    readonly OT_CLIPBOARD_START_LIMIT_EXCEEDED: 3;
    readonly OT_CLIPBOARD_START_INVALID_ARGUMENT: 4;
    readonly OT_CLIPBOARD_START_OUT_OF_MEMORY: 5;
    readonly OT_CLIPBOARD_CANCEL_REQUESTED: 0;
    readonly OT_CLIPBOARD_CANCEL_ALREADY_TERMINAL: 1;
    readonly OT_CLIPBOARD_CANCEL_INVALID_HANDLE: 2;
    readonly OT_CLIPBOARD_COPY_OK: 0;
    readonly OT_CLIPBOARD_COPY_BUFFER_TOO_SMALL: 1;
    readonly OT_CLIPBOARD_COPY_INVALID_HANDLE: 2;
    readonly OT_CLIPBOARD_COPY_INVALID_STATE: 3;
    readonly OT_CLIPBOARD_COPY_INVALID_ARGUMENT: 4;
    readonly OT_CLIPBOARD_DESTROY_DESTROYED: 0;
    readonly OT_CLIPBOARD_DESTROY_NOT_READY: 1;
    readonly OT_CLIPBOARD_DESTROY_INVALID_HANDLE: 2;
    readonly OT_CLIPBOARD_SHUTDOWN_PENDING: 0;
    readonly OT_CLIPBOARD_SHUTDOWN_READY: 1;
    readonly OT_CLIPBOARD_SHUTDOWN_INVALID_HANDLE: 2;
};
export declare const nativeStyleEnumMaxima: readonly [2, 3, 5, 8, 8, 8, 2, 2, 2, 1, 1];
