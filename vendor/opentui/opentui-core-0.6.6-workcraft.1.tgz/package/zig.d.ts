import { type FFICallbackInstance, type Pointer, type PointerInput } from "./platform/ffi.js";
import { type CursorStyle, type CursorStyleOptions, type SelectionOccupancy, type SelectionBehavior, type DebugOverlayCorner, type WidthMethod, type TerminalCapabilities, type Highlight, type LineInfo, type MousePointerStyle, type ImageRenderProtocol, type ProgramStatus } from "./types.js";
export type { LineInfo, AllocatorStats, AudioStreamCreateOptions, BuildOptions, NativeAudioCaptureStats, NativeAudioStreamStats, NativeRenderStats, };
import { RGBA } from "./lib/RGBA.js";
import { type StyledText } from "./lib/styled-text.js";
import { type MeasureFunction } from "./yoga.js";
import { YogaHost } from "./yoga.internal.js";
import type { NativeSpanFeedOptions, NativeSpanFeedStats, ReserveInfo, AudioCreateOptions, AudioStartOptions, AudioVoiceOptions, AudioStreamCreateOptions, NativeAudioStreamCloseReason as NativeAudioStreamCloseReasonType, NativeAudioStreamFormat as NativeAudioStreamFormatType, NativeAudioStreamState as NativeAudioStreamStateType, NativeAudioStreamStats, NativeAudioCaptureStats, AudioStats, BuildOptions, AllocatorStats, NativeRenderStats, NativeImageInfo } from "./zig-structs.js";
export declare const NativeAudioStreamState: {
    readonly Initializing: 0;
    readonly Buffering: 1;
    readonly Playing: 2;
    readonly Ended: 3;
    readonly Failed: 4;
    readonly Cancelled: 5;
    readonly Reconnecting: 6;
};
export type NativeAudioStreamState = NativeAudioStreamStateType;
export declare const NativeAudioStreamCloseReason: {
    readonly PreserveNativeTerminal: 0;
    readonly TransportError: 1;
    readonly Disposed: 2;
};
export type NativeAudioStreamCloseReason = NativeAudioStreamCloseReasonType;
export declare const NativeAudioStreamFormat: {
    readonly Mp3: 1;
    readonly Flac: 2;
    readonly Pcm: 3;
};
export type NativeAudioStreamFormat = NativeAudioStreamFormatType;
export type NativeHandle<T extends string> = Pointer & {
    readonly __nativeHandle: T;
};
declare const nativeContextBrand: unique symbol;
export type NativeContextHandle = {
    readonly [nativeContextBrand]: true;
};
/** Native hyperlink URL slot bound. Longer URLs fail allocation. */
export declare const MAX_LINK_URL_BYTES = 512;
export interface NativeContextOptions {
    objectCapacity: number;
    renderCellsMax: number;
}
export interface ContextObjectHandle {
    readonly context: NativeContextHandle;
    readonly contextId: bigint;
    readonly slot: number;
    readonly generation: number;
}
declare const contextResourceBrand: unique symbol;
export type SessionHandle = ContextObjectHandle & {
    readonly [contextResourceBrand]: "session";
};
export type ContextBufferHandle = ContextObjectHandle & {
    readonly [contextResourceBrand]: "buffer";
};
export type SceneNodeHandle = ContextObjectHandle & {
    readonly [contextResourceBrand]: "scene_node";
};
export type ContextEditBufferHandle = ContextObjectHandle & {
    readonly [contextResourceBrand]: "edit_buffer";
};
export type ContextEditorViewHandle = ContextObjectHandle & {
    readonly [contextResourceBrand]: "editor_view";
};
export type ContextSyntaxStyleHandle = ContextObjectHandle & {
    readonly [contextResourceBrand]: "syntax_style";
};
export type ContextTextBufferHandle = ContextObjectHandle & {
    readonly [contextResourceBrand]: "text_buffer";
};
export type ContextTextBufferViewHandle = ContextObjectHandle & {
    readonly [contextResourceBrand]: "text_buffer_view";
};
export type ContextImageHandle = ContextObjectHandle & {
    readonly [contextResourceBrand]: "image";
};
export type ContextImagePixelsHandle = ContextObjectHandle & {
    readonly [contextResourceBrand]: "image_pixels";
};
export type ContextUnicodeHandle = ContextObjectHandle & {
    readonly [contextResourceBrand]: "unicode";
};
export type ContextEmbeddedTerminalHandle = ContextObjectHandle & {
    readonly [contextResourceBrand]: "embedded_terminal";
};
export type SessionBuffer = "current" | "next";
export interface NativeContextEditBufferOptions {
    widthMethod?: WidthMethod | "no-zwj";
}
export interface NativeEditBufferInfo {
    contentEpoch: bigint;
    byteLength: number;
    lineCount: number;
    cursor: LogicalCursor;
    canUndo: boolean;
    canRedo: boolean;
    tabWidth: number;
}
export interface NativeTextBufferInfo {
    contentEpoch: bigint;
    byteLength: number;
    textLength: number;
    lineCount: number;
    highlightCount: number;
    tabWidth: number;
}
export interface NativeEncodedStyledText {
    bytes: Uint8Array;
    records: Uint32Array;
    count: number;
    urlBytes: Uint8Array;
}
export declare enum NativeTextViewCommand {
    WrapWidth = 0,
    WrapMode = 1,
    FirstLineOffset = 2,
    TabIndicator = 3,
    Truncate = 4,
    TextAlign = 5
}
export declare enum NativeEditCommand {
    DeleteForward = 0,
    Backspace = 1,
    NewLine = 2,
    DeleteLine = 3,
    MoveLeft = 4,
    MoveRight = 5,
    MoveUp = 6,
    MoveDown = 7,
    GotoLine = 8,
    CursorOffset = 9,
    Clear = 10,
    ClearHistory = 11,
    DebugRope = 12
}
export declare enum NativeEditPositionQuery {
    Cursor = 0,
    NextWord = 1,
    PrevWord = 2,
    Eol = 3,
    Offset = 4,
    Coords = 5,
    LineStart = 6
}
export declare enum NativeEditorStyleMask {
    Foreground = 1,
    Background = 2,
    Attributes = 4,
    All = 7
}
export interface NativeEditorStyle {
    fg?: RGBA | null;
    bg?: RGBA | null;
    attributes?: number | null;
}
export declare enum NativeEditHighlightOperation {
    AddLine = 0,
    AddRange = 1,
    RemoveRef = 2,
    ClearLine = 3,
    ClearAll = 4
}
export interface NativeEditorViewport {
    x: number;
    y: number;
    width: number;
    height: number;
}
export declare enum NativeEditorCommand {
    MoveUp = 0,
    MoveDown = 1,
    GotoLineEnd = 2,
    DeleteSelection = 3,
    CursorOffset = 4,
    WrapMode = 5,
    TabIndicator = 6
}
export declare enum NativeEditorSelectionOperation {
    Set = 0,
    Update = 1,
    Reset = 2,
    Local = 3,
    LocalUpdate = 4,
    LocalReset = 5,
    Cell = 6,
    Occupancy = 7,
    Inclusive = 8,
    Colors = 9
}
export interface NativeEditorSelection {
    operation: NativeEditorSelectionOperation;
    behavior?: number;
    start?: number;
    end?: number;
    anchorX?: number;
    anchorY?: number;
    focusX?: number;
    focusY?: number;
    updateCursor?: boolean;
    followCursor?: boolean;
    fg?: RGBA | null;
    bg?: RGBA | null;
}
export interface NativeEditorViewInfo {
    virtualLineCount: number;
    totalVirtualLineCount: number;
    selection: {
        start: number;
        end: number;
    } | null;
    selectionOccupancy: SelectionOccupancy;
}
export declare enum NativeEditorPositionQuery {
    Cursor = 0,
    NextWord = 1,
    PrevWord = 2,
    Eol = 3,
    VisualSol = 4,
    VisualEol = 5
}
export declare enum NativeEditEvent {
    CursorChanged = 1,
    ContentChanged = 2,
    HistoryCursorChanged = 4
}
export type NativeEditEventName = "cursor-changed" | "content-changed" | "cursorChanged";
export interface NativeSceneEditorOptions {
    showCursor: boolean;
    style: "block" | "line" | "underline" | "default";
    blinking: boolean;
    color: RGBA;
    cursor?: MousePointerStyle;
}
export interface NativeEditorReplacement {
    deleted: boolean;
    inserted: boolean;
}
export interface NativeSceneBoxDetails {
    title?: string;
    bottomTitle?: string;
    titleAlignment: "left" | "center" | "right";
    bottomTitleAlignment: "left" | "center" | "right";
    titleColor?: RGBA;
    customBorderChars?: Uint32Array;
}
export interface NativeScenePaint {
    zIndex: number;
    opacity: number;
    translateX: number;
    translateY: number;
    border: number;
    shouldFill: boolean;
    backgroundColor: RGBA;
    borderColor: RGBA;
    borderStyle: "single" | "double" | "rounded" | "heavy";
    focusable: boolean;
    focusedBorderColor: RGBA;
}
export type NativeScenePaintUpdate = Partial<NativeScenePaint> & {
    resetBorderCharacters?: true;
};
export declare const NATIVE_SCENE_MUTATIONS_MAX: 4096;
export declare enum NativeStyleGroup {
    Enum,
    Float,
    Value,
    Border,
    Dimension
}
export declare enum NativeStyleFlags {
    None,
    DisableFlexShrink
}
/** ENUM/FLOAT/DIMENSION writes occupy this unused-edge slot. */
export declare const NATIVE_EDGE_NONE: 0;
export declare enum NativeBorder {
    None,
    Left,
    Bottom,
    Right,
    Top,
    All
}
export interface NativeSceneLayout {
    left: number;
    top: number;
    right: number;
    bottom: number;
    width: number;
    height: number;
    screenX: number;
    screenY: number;
}
export interface NativeSceneFrameOptions {
    background: RGBA;
    useMouse: boolean;
    excludedHitNum: number;
    maxLayoutRounds: number;
    maxHostRequests: number;
    preserveUnwritten?: boolean;
}
export declare enum NativeSceneHook {
    Update,
    Resize,
    LayoutChanged,
    RenderBefore,
    RenderAfter,
    RenderSelf,
    IdleUpdate
}
export declare enum NativeSceneFrame {
    Done,
    Update,
    Resize,
    LayoutChanged,
    Record,
    Yield
}
export declare enum NativeScenePaintPhase {
    Before,
    Self,
    After
}
/** One node whose paint hooks a RECORD request asks the host to record, in paint order. */
export interface NativeScenePaintSlot {
    readonly node: SceneNodeHandle;
    readonly num: number;
    /** RenderBefore, RenderSelf, and RenderAfter hook bits to record. */
    readonly hooks: number;
    readonly opacity: number;
    readonly paintLayout: NativeSceneLayout;
    readonly publicLayout?: NativeSceneLayout;
}
/** An issued request. Pass it back unchanged; geometry is observation, not acknowledgement authority. */
export interface NativeSceneFrameRequest {
    readonly session: SessionHandle;
    readonly root: SceneNodeHandle;
    readonly node: SceneNodeHandle;
    readonly frameId: bigint;
    readonly requestId: bigint;
    readonly layoutEpoch: bigint;
    readonly hookGeneration: bigint;
    readonly kind: NativeSceneFrame;
    readonly num: number;
    readonly width: number;
    readonly height: number;
    paintLayout?: NativeSceneLayout;
    publicLayout?: NativeSceneLayout;
    /** Host observation revision; never part of native ticket authority. */
    geometryRevision?: number;
}
export interface NativeSplitSnapshot {
    snapshot: ContextBufferHandle;
    rowColumns: number;
    startOnNewLine: boolean;
    trailingNewline: boolean;
}
export type NativeSessionSplitControl = {
    kind: "reset";
    seedRows: number;
    pinnedRenderOffset: number;
} | {
    kind: "sync";
    pinnedRenderOffset: number;
} | {
    kind: "output-offset";
    surfaceOffset: number;
} | {
    kind: "render-offset";
    renderOffset: number;
} | {
    kind: "transition";
    mode: "viewport-scroll" | "clear-stale-rows";
    sourceTopLine: number;
    sourceHeight: number;
    targetTopLine: number;
    targetHeight: number;
    scrollLines?: number;
} | {
    kind: "clear-transition";
};
export interface NativeSceneTextOptions {
    fg: RGBA;
    bg: RGBA;
    attributes: number;
    wrapMode: "none" | "char" | "word";
    textAlign: "left" | "center" | "right";
    truncate: boolean;
    scrollX: number;
    scrollY: number;
    firstLineOffset: number;
    tabIndicator?: string | number;
    tabIndicatorColor?: RGBA;
}
export interface NativeBufferGrid {
    borderChars: Uint32Array;
    borderFg: RGBA;
    borderBg: RGBA;
    columnOffsets: Int32Array;
    rowOffsets: Int32Array;
    drawInner: boolean;
    drawOuter: boolean;
}
export interface NativeBufferStack {
    operation: "getOpacity" | "pushScissor" | "popScissor" | "clearScissors" | "pushOpacity" | "popOpacity" | "clearOpacity";
    x?: number;
    y?: number;
    width?: number;
    height?: number;
    opacity?: number;
}
export type NativeDrawingTarget = {
    readonly context: NativeContextHandle;
    readonly target: ContextBufferHandle;
    readonly frame: null;
} | {
    readonly context: NativeContextHandle;
    readonly target: SessionHandle;
    readonly frame: NativeSceneFrameRequest;
};
type BufferDrawPosition = {
    x?: number;
    y?: number;
};
type BufferDrawColors = {
    foreground?: RGBA;
    background?: RGBA;
};
export type NativeBufferDraw = {
    operation: "clear";
    background?: RGBA;
} | (BufferDrawPosition & {
    operation: "fill";
    width?: number;
    height?: number;
    background?: RGBA;
}) | (BufferDrawPosition & BufferDrawColors & {
    operation: "text";
    text?: string;
    attributes?: number;
}) | (BufferDrawPosition & BufferDrawColors & {
    operation: "cell" | "cellBlend" | "char";
    char?: number;
    attributes?: number;
}) | (BufferDrawPosition & BufferDrawColors & {
    operation: "box";
    width?: number;
    height?: number;
    titleColor?: RGBA;
    packedOptions?: number;
    borderChars?: Uint32Array;
    text?: string;
    bottomTitle?: string;
}) | (BufferDrawPosition & {
    operation: "compose";
    source: ContextBufferHandle;
    sourceX?: number;
    sourceY?: number;
    sourceWidth?: number;
    sourceHeight?: number;
}) | {
    operation: "respectAlpha";
    enabled: boolean;
};
export interface NativeContextImageDraw {
    x?: number;
    y?: number;
    width: number;
    height: number;
    pixelWidth?: number;
    pixelHeight?: number;
    sourceX?: number;
    sourceY?: number;
    sourceWidth?: number;
    sourceHeight?: number;
    protocol?: ImageRenderProtocol;
}
export interface NativeSceneTextSelectionOptions {
    operation: "reset" | "set" | "update";
    anchorX: number;
    anchorY: number;
    focusX: number;
    focusY: number;
    behavior: SelectionBehavior;
    bg?: RGBA;
    fg?: RGBA;
}
export interface NativeSceneTextMetrics {
    byteLength: number;
    textLength: number;
    lineCount: number;
    virtualLineCount: number;
    widthColsMax: number;
}
export interface NativeSceneSliderOptions {
    orientation: "horizontal" | "vertical";
    min: number;
    max: number;
    value: number;
    viewPortSize: number;
    foregroundColor: RGBA;
    backgroundColor: RGBA;
}
export interface NativeSceneArrowOptions {
    direction: "up" | "down" | "left" | "right";
    attributes: number;
    foregroundColor: RGBA;
    backgroundColor: RGBA;
    text?: string;
}
export interface NativeSessionBufferLease {
    handle: ContextObjectHandle;
    width: number;
    height: number;
    generation: bigint;
    char: Pointer;
    fg: Pointer;
    bg: Pointer;
    attributes: Pointer;
}
export type NativeContextBufferLease = NativeSessionBufferLease;
export interface NativeContextBufferOptions {
    width: number;
    height: number;
    widthMethod?: WidthMethod | "no-zwj";
    respectAlpha?: boolean;
}
export declare const NATIVE_BUFFER_TEXT_BYTES_MAX: 65536;
export interface NativeSessionOptions {
    chunkSize: number;
    spanCapacity: number;
    maxBytes: bigint;
    controlCapacity?: number;
}
export interface NativeOutputTicket {
    session: SessionHandle;
    requestId: bigint;
    byteCount: number;
}
export declare enum NativeSessionState {
    Open = 0,
    Closing = 1,
    Closed = 2,
    Failed = 3,
    Cancelled = 4
}
export interface NativeSessionRendererOptions {
    width: number;
    height: number;
    /** Omitted selects native auto detection, which ignores host hints when remote. */
    remote?: boolean;
    /** Initialization-only copied host hints: at most 256 entries and 65536 encoded bytes. */
    environment?: Readonly<Record<string, string>>;
}
export declare enum NativeSessionRenderStatus {
    Presented = 0,
    Pending = 1,
    Skipped = 2,
    Failed = 3
}
export interface NativeSessionRendererState {
    width: number;
    height: number;
    frameCount: bigint;
    framePending: boolean;
}
export interface NativeSessionKittyImageTransportStatus {
    requested: number;
    effective: number;
    fileState: number;
    fallback: number;
    pendingFiles: number;
    pendingBytes: number;
}
export declare const NATIVE_SESSION_CONTROL_PACKET_BYTES: 4096;
export interface NativeSessionTerminalOptions {
    useAlternateScreen?: boolean;
    mouse?: boolean;
    mouseMovement?: boolean;
    kittyKeyboardFlags?: number;
    clearOnClose?: boolean;
}
export declare enum NativeSessionTerminalPhase {
    Uninitialized = 0,
    SettingUp = 1,
    Active = 2,
    Suspending = 3,
    Suspended = 4,
    Resuming = 5,
    Closing = 6,
    Restored = 7,
    Failed = 8,
    Cancelled = 9
}
export declare enum NativeSessionPumpStatus {
    Idle = 0,
    Again = 1,
    OutputPending = 2,
    WaitUntil = 3,
    Closed = 4
}
export interface NativeSessionPumpResult {
    status: NativeSessionPumpStatus;
    deadlineNs: bigint | null;
}
export type NativeSessionControl = {
    kind: "capability-response";
    bytes: Uint8Array;
} | {
    kind: "palette-query";
    bytes: Uint8Array;
} | {
    kind: "title";
    title: string;
} | {
    kind: "mouse";
    mode: "disabled" | "drag" | "motion";
} | {
    kind: "kitty-keyboard-flags";
    flags: number;
} | {
    kind: "program-status";
    status: ProgramStatus;
} | {
    kind: "restore-modes" | "query-pixel-resolution" | "query-theme-colors" | "reset-background";
};
export interface NativeSessionCursorOptions extends CursorStyleOptions {
    position?: {
        x: number;
        y: number;
        visible: boolean;
    };
}
export interface NativeSessionCapabilities extends TerminalCapabilities {
    kittyKeyboardFlags: number;
}
export declare enum NativeStatus {
    Ok = 0,
    InvalidArgument = -1,
    UnsupportedVersion = -2,
    OutOfMemory = -3,
    WrongThread = -4,
    InternalError = -5,
    ContextBusy = -6,
    WrongContext = -7,
    WrongKind = -8,
    StaleHandle = -9,
    WrongSession = -10,
    OutputBackpressure = -11,
    SessionClosed = -12,
    OutputBusy = -13,
    StaleOutput = -14,
    OutputFailed = -15,
    ObjectLimit = -16,
    RendererAttached = -17,
    RendererNotAttached = -18,
    InvalidPhase = -19,
    ControlPacketLimit = -20,
    LeaseLimit = -21,
    LeaseBytesLimit = -22,
    StaleLease = -23,
    UnsupportedResource = -24,
    StaleFrame = -25,
    LayoutLimit = -26,
    FrameBusy = -27,
    FrameRequestLimit = -28
}
export declare class NativeError extends Error {
    readonly operation: string;
    readonly status: NativeStatus;
    constructor(operation: string, status: NativeStatus, reason?: string);
}
export type AudioEngineHandle = NativeHandle<"audio_engine">;
export type ImageHandle = ContextImageHandle;
export type ClipboardServiceHandle = number & {
    readonly __nativeHandle: "clipboard_service";
};
export type ClipboardOperationHandle = number & {
    readonly __nativeHandle: "clipboard_operation";
};
export declare enum NativeClipboardOperationStatus {
    Pending,
    Read,
    Empty,
    Written,
    Cleared,
    Unsupported,
    Cancelled,
    TimedOut,
    LimitExceeded,
    Failed,
    InvalidHandle
}
export declare enum NativeClipboardStartStatus {
    Ok,
    InvalidService,
    ShuttingDown,
    LimitExceeded,
    InvalidArgument,
    OutOfMemory
}
export declare enum NativeClipboardCancelStatus {
    Requested,
    AlreadyTerminal,
    InvalidHandle
}
export declare enum NativeClipboardCopyStatus {
    Ok,
    BufferTooSmall,
    InvalidHandle,
    InvalidState,
    InvalidArgument
}
export declare enum NativeClipboardDestroyStatus {
    Destroyed,
    NotReady,
    InvalidHandle
}
export declare enum NativeClipboardShutdownStatus {
    Pending,
    Ready,
    InvalidHandle
}
export type EmbeddedTerminalCursor = {
    x: number;
    y: number;
    hasValue: boolean;
    visible: boolean;
    blinking: boolean;
    wideTail: boolean;
    style: "bar" | "block" | "underline" | "block-hollow";
    color?: {
        r: number;
        g: number;
        b: number;
    };
};
export type EmbeddedTerminalKey = {
    action?: "release" | "press" | "repeat";
    key?: string;
    mods?: number;
    consumedMods?: number;
    composing?: boolean;
    text?: string;
    unshiftedCodepoint?: number;
};
export type EmbeddedTerminalMouse = {
    action: "press" | "release" | "motion";
    button?: "unknown" | "left" | "right" | "middle" | "four" | "five" | "six" | "seven";
    mods?: number;
    x: number;
    y: number;
    anyButtonPressed?: boolean;
};
declare const SCENE_NODE_KINDS: readonly ["root", "box", "text", "slider", "arrow", "editor", "custom", "text_view", "image"];
/** One ordered property stream, stored in native wire layout. Visual writes coalesce
 * at the node's latest visual record; last write wins per field. New or changed
 * translations only merge into the last record so prepared coordinates observe
 * preceding ancestor translations. Layout writes stay ordered because Yoga
 * shorthand/edge and dimension/flex-shrink operations can overlap. There are no
 * reads or callbacks between records. A successful flush ends coalescing.
 *
 * Records occupy their packed size, so a background-only or style batch is already
 * the borrowed bytes. Merging extra visual fields grows that record and shifts later
 * ones. Scratch snapshots caller getters before publication, including under reentry. */
export declare class SceneStaging {
    static readonly limit: 4096;
    private words;
    private readonly paintBySlot;
    private readonly packScratch;
    private readonly styleValue;
    private readonly styleValueWords;
    private context?;
    private readonly contextId;
    private readonly contextWords;
    private borrowed;
    private entryCount;
    private encodedWords;
    private lastBase;
    private runBase;
    private paintScratch;
    constructor(initialCapacity?: number);
    get pending(): boolean;
    get count(): number;
    get byteLength(): number;
    get full(): boolean;
    static checkStyleValue(group: number, value: number): number;
    private assertWritable;
    /** Returns the node's staged visual record, if any. */
    private checkHandle;
    private bind;
    private ensureWords;
    /** Callers write every field word; only the trailing alignment word needs clearing. */
    private reserve;
    stageStyle(context: NativeContextHandle, node: SceneNodeHandle, group: number, kind: number, edge: number, unit: number, value: number, flags: number): boolean;
    private writeStyle;
    /**
     * Whether Yoga certainly treats two staged values of one property as different. Undefined, auto
     * and NaN values, and signed zeros, can compare equal under Yoga's rules, so they never qualify.
     */
    private stylesDiffer;
    /**
     * Coalesces consecutive writes to one node property. The stream keeps a run of two records only
     * while Yoga certainly sees their values as different, and the newest value stays last. Yoga then
     * marks the node dirty, as some write in the original run would have, and ends with the same
     * value. Any write that cannot keep that guarantee is appended instead. Returns false to append.
     */
    private rewriteStyleRun;
    stageBackground(context: NativeContextHandle, node: SceneNodeHandle, color: RGBA, owner?: {
        assertMutable(): void;
    }): boolean;
    stagePaint(context: NativeContextHandle, node: SceneNodeHandle, paint: NativeScenePaintUpdate, owner?: {
        assertMutable(): void;
    }): boolean;
    private publishPaint;
    private packedFieldEquals;
    private writePackedFields;
    private mergePackedPaint;
    /** @internal Borrow until consume() acknowledges the native prefix. */
    _views(context: NativeContextHandle): Uint32Array;
    clear(): void;
    /** Never replay the accepted prefix. Remaining records stay in wire layout. An invalid
     * acknowledgement still ends the borrow, so staging stays writable. */
    consume(applied: number): void;
    discard(node: SceneNodeHandle): void;
    private reindex;
}
/** Encodes paint hooks into the ot_scene_record stream that acknowledges one RECORD request.
 * Recorded commands draw when native code paints the frame, not when a hook calls them. */
export declare class NativePaintRecorder {
    private buffer;
    private bytes;
    private words;
    private signed;
    private floats;
    private colors;
    private length;
    private context;
    private window;
    private readonly releases;
    private pendingSlot;
    private pendingPhase;
    private readonly opacity;
    private scissors;
    private textBytes?;
    private bottomBytes?;
    private readonly handleRecord;
    begin(context: NativeContextHandle): void;
    /** Stop recording. Deferred releases wait for settle(). */
    end(): void;
    /** Run deferred releases after the frame step that consumed the recording. */
    settle(): void;
    /** The encoded stream, or null when nothing was recorded. Valid until the next begin(). */
    get recording(): Uint8Array | null;
    /** Start one slot phase. Its SLOT record is written only if the phase draws. */
    slot(slot: number, phase: NativeScenePaintPhase, opacity: number): void;
    get currentOpacity(): number;
    draw(options: NativeBufferDraw): void;
    stack(options: NativeBufferStack): number;
    grid(options: NativeBufferGrid): void;
    packed(data: Uint8Array | PointerInput, byteLength: number, x: number, y: number, width: number, height: number): void;
    supersample(data: Uint8Array | PointerInput, byteLength: number, x: number, y: number, format: "rgba8unorm" | "bgra8unorm", stride: number): void;
    grayscale(data: Float32Array, x: number, y: number, width: number, height: number, foreground: RGBA | null, background: RGBA | null, supersampled: boolean): void;
    colorMatrix(matrix: Float32Array, mask: Float32Array | null, strength: number, channel: number): void;
    /** Draw a text-buffer view, editor view, or scene text node. */
    view(operation: "text" | "editor" | "scene", source: ContextObjectHandle, x: number, y: number): void;
    image(source: ContextImageHandle, options: NativeContextImageDraw): void;
    unicode(source: ContextUnicodeHandle, index: number, x: number, y: number, foreground: RGBA, background: RGBA, attributes: number): void;
    /** Runs one encoder. A call that throws leaves no partial record or slot header, so the hook can recover. */
    private transaction;
    private activeContext;
    private encodeHandle;
    /** Append one zeroed record of at most size bytes and return its offset. */
    private reserve;
    private append;
    /** Shrink a record reserved with an upper bound to its encoded end. */
    private finish;
    private grow;
}
export declare enum LogLevel {
    Error = 0,
    Warn = 1,
    Info = 2,
    Debug = 3
}
/**
 * VisualCursor represents a cursor position with both visual and logical coordinates.
 * Visual coordinates (visualRow, visualCol) are VIEWPORT-RELATIVE.
 * This means visualRow=0 is the first visible line in the viewport, not the first line in the document.
 * Logical coordinates (logicalRow, logicalCol) are document-absolute.
 */
export interface VisualCursor {
    visualRow: number;
    visualCol: number;
    logicalRow: number;
    logicalCol: number;
    offset: number;
}
export interface LogicalCursor {
    row: number;
    col: number;
    offset: number;
}
export interface MeasureResult {
    lineCount: number;
    widthColsMax: number;
}
export interface CursorState {
    x: number;
    y: number;
    visible: boolean;
    style: CursorStyle;
    blinking: boolean;
    color: RGBA;
}
export type NativeSpanFeedEventHandler = (eventId: number, arg0: Pointer, arg1: number | bigint) => void;
export type NativeBufferedOutput = "stdout" | "memory";
export interface NativeYogaLayout {
    left: number;
    top: number;
    right: number;
    bottom: number;
    width: number;
    height: number;
}
export type NativeYogaMeasureCallback = (node: Pointer | null, width: number, widthMode: number, height: number, heightMode: number) => void;
export type NativeYogaDirtiedCallback = (node: Pointer | null) => void;
export interface AudioEngineLib extends Pick<FFIRenderLib, Extract<keyof FFIRenderLib, `audio${string}` | "createAudioEngine" | "destroyAudioEngine">> {
}
export type RenderLib = Pick<FFIRenderLib, keyof FFIRenderLib>;
export declare class FFIRenderLib {
    private bufferDrawRecord;
    private sceneLayoutRecord;
    private sceneFrameRecord;
    private scenePaintSlots;
    private sceneCreateRecord;
    private sceneDestroyHandle;
    private sceneMoveRecord;
    private sceneHooksRecord;
    private sceneFlushApplied;
    private editorSelectionRecord;
    private readonly editorViewInfoRecord;
    private readonly selectionResetRecord;
    private readonly localSelectionResetRecord;
    private readonly selectionResetChanged;
    private readonly hitTestOutput;
    private readonly bufferStackInput;
    private readonly bufferStackOutput;
    private readonly drawTextBytes;
    private readonly drawBottomBytes;
    private opentui;
    private iccCacheClient;
    private readonly yogaLayout;
    private readonly yogaU32;
    private readonly yogaF32;
    private readonly yogaU64;
    private yogaHost?;
    private readonly ffiStructStorage;
    private disposed;
    private nativeContexts;
    private contextEditEvents;
    private sceneMeasures;
    private clipboardServices;
    private clipboardOperations;
    private audioEngines;
    private editMeasureContext?;
    private readonly invalidStandaloneHandle;
    readonly encoder: TextEncoder;
    private readonly emptyBytes;
    readonly decoder: TextDecoder;
    private logCallbackWrapper;
    private diagnosticDrain?;
    private nativeSpanFeedCallbackWrapper;
    private nativeSpanFeedHandlers;
    createContext(options: NativeContextOptions): NativeContextHandle;
    private nativeContextPointer;
    destroyContext(context: NativeContextHandle): void;
    private releaseContext;
    /** Destroys one Context object through the native destroy symbol of its kind. */
    private destroyContextObject;
    contextGetLinkUrl(context: NativeContextHandle, linkId: number): string;
    createContextTextBuffer(context: NativeContextHandle, options?: NativeContextEditBufferOptions): ContextTextBufferHandle;
    createContextUnicode(context: NativeContextHandle, text: string, widthMethod: WidthMethod | "no-zwj"): ContextUnicodeHandle;
    sceneMeasureLayout(context: NativeContextHandle, session: SessionHandle, root: SceneNodeHandle): void;
    sceneFrameCopyBuffer(context: NativeContextHandle, session: SessionHandle, frame: NativeSceneFrameRequest, target: ContextBufferHandle): void;
    sessionRenderSplit(context: NativeContextHandle, session: SessionHandle, frame: NativeSceneFrameRequest | null, snapshots: readonly NativeSplitSnapshot[], pinnedRenderOffset: number, force: boolean): {
        status: NativeSessionRenderStatus;
    };
    sessionSplitControl(context: NativeContextHandle, session: SessionHandle, command: NativeSessionSplitControl): number;
    sessionSetScreen(context: NativeContextHandle, session: SessionHandle, alternate: boolean, width: number, height: number, trailingOutput?: Uint8Array): void;
    sessionSyncDetached(context: NativeContextHandle, session: SessionHandle, parent: SessionHandle): void;
    getContextUnicode(context: NativeContextHandle, unicode: ContextUnicodeHandle): Array<{
        width: number;
        char: number;
    }>;
    destroyContextUnicode(context: NativeContextHandle, unicode: ContextUnicodeHandle): void;
    contextBufferDrawUnicode({ context, target, frame }: NativeDrawingTarget, unicode: ContextUnicodeHandle, index: number, x: number, y: number, foreground: RGBA, background: RGBA, attributes: number): void;
    createContextEmbeddedTerminal(context: NativeContextHandle, options: {
        cols: number;
        rows: number;
        maxScrollback?: number;
    }): ContextEmbeddedTerminalHandle;
    destroyContextEmbeddedTerminal(context: NativeContextHandle, terminal: ContextEmbeddedTerminalHandle): void;
    contextEmbeddedTerminalWrite(context: NativeContextHandle, terminal: ContextEmbeddedTerminalHandle, data: string | Uint8Array): void;
    contextEmbeddedTerminalResize(context: NativeContextHandle, terminal: ContextEmbeddedTerminalHandle, cols: number, rows: number): void;
    private contextTerminalCommand;
    contextEmbeddedTerminalInvalidate(context: NativeContextHandle, terminal: ContextEmbeddedTerminalHandle): void;
    contextEmbeddedTerminalScroll(context: NativeContextHandle, terminal: ContextEmbeddedTerminalHandle, delta: number): void;
    contextEmbeddedTerminalClearSelection(context: NativeContextHandle, terminal: ContextEmbeddedTerminalHandle): void;
    contextEmbeddedTerminalSetTransparentBackground(context: NativeContextHandle, terminal: ContextEmbeddedTerminalHandle, transparent: boolean): void;
    contextEmbeddedTerminalSetSelection(context: NativeContextHandle, terminal: ContextEmbeddedTerminalHandle, start: {
        x: number;
        y: number;
    }, end: {
        x: number;
        y: number;
    }): void;
    private contextTerminalBytes;
    contextEmbeddedTerminalGetSelectedText(context: NativeContextHandle, terminal: ContextEmbeddedTerminalHandle): Uint8Array;
    contextEmbeddedTerminalCompose({ context, target, frame }: NativeDrawingTarget, terminal: ContextEmbeddedTerminalHandle, x: number, y: number): void;
    contextEmbeddedTerminalCursor(context: NativeContextHandle, terminal: ContextEmbeddedTerminalHandle): EmbeddedTerminalCursor;
    contextEmbeddedTerminalEncodeKey(context: NativeContextHandle, terminal: ContextEmbeddedTerminalHandle, key: EmbeddedTerminalKey): Uint8Array;
    contextEmbeddedTerminalEncodeMouse(context: NativeContextHandle, terminal: ContextEmbeddedTerminalHandle, mouse: EmbeddedTerminalMouse): Uint8Array;
    contextEmbeddedTerminalEncodePaste(context: NativeContextHandle, terminal: ContextEmbeddedTerminalHandle, input: Uint8Array): Uint8Array;
    contextEmbeddedTerminalEncodeFocus(context: NativeContextHandle, terminal: ContextEmbeddedTerminalHandle, focused: boolean): Uint8Array;
    private embeddedTerminalResponses;
    contextEmbeddedTerminalDrainResponses(context: NativeContextHandle, terminal: ContextEmbeddedTerminalHandle): Uint8Array;
    destroyContextTextBuffer(context: NativeContextHandle, text: ContextTextBufferHandle): void;
    createContextTextBufferView(context: NativeContextHandle, text: ContextTextBufferHandle): ContextTextBufferViewHandle;
    destroyContextTextBufferView(context: NativeContextHandle, view: ContextTextBufferViewHandle): void;
    contextTextBufferSetText(context: NativeContextHandle, text: ContextTextBufferHandle, bytes: Uint8Array): void;
    contextTextBufferAppend(context: NativeContextHandle, text: ContextTextBufferHandle, bytes: Uint8Array): void;
    contextTextBufferClear(context: NativeContextHandle, text: ContextTextBufferHandle, reset?: boolean): void;
    contextTextBufferSetStyledText(context: NativeContextHandle, text: ContextTextBufferHandle, content: StyledText): void;
    encodeTextBufferStyledText(content: StyledText): NativeEncodedStyledText;
    contextTextBufferSetEncodedStyledText(context: NativeContextHandle, text: ContextTextBufferHandle, encoded: NativeEncodedStyledText): void;
    contextTextBufferReplaceStyledBatch(context: NativeContextHandle, replacements: {
        buffer: ContextTextBufferHandle;
        view: ContextTextBufferViewHandle;
        text: NativeEncodedStyledText;
    }[], beforeNative: () => void): Uint32Array | null;
    contextTextBufferSetSyntaxStyle(context: NativeContextHandle, text: ContextTextBufferHandle, style: ContextSyntaxStyleHandle | null): void;
    contextTextBufferGetInfo(context: NativeContextHandle, text: ContextTextBufferHandle): NativeTextBufferInfo;
    private readText;
    contextTextBufferGetText(context: NativeContextHandle, text: ContextTextBufferHandle): string;
    contextTextBufferGetRange(context: NativeContextHandle, text: ContextTextBufferHandle, start: number, end: number): string;
    contextTextBufferSetDefaults(context: NativeContextHandle, text: ContextTextBufferHandle, mask: NativeEditorStyleMask, style: NativeEditorStyle): void;
    contextTextBufferSetTabWidth(context: NativeContextHandle, text: ContextTextBufferHandle, width: number): void;
    contextTextBufferHighlight(context: NativeContextHandle, text: ContextTextBufferHandle, operation: NativeEditHighlightOperation, argument?: number, highlight?: Highlight): void;
    contextTextBufferGetHighlights(context: NativeContextHandle, text: ContextTextBufferHandle, line: number): Highlight[];
    contextTextBufferViewSetViewport(context: NativeContextHandle, view: ContextTextBufferViewHandle, viewport: NativeEditorViewport, sizeOnly?: boolean): void;
    contextTextBufferViewCommand(context: NativeContextHandle, view: ContextTextBufferViewHandle, command: NativeTextViewCommand, argument: number): void;
    contextTextBufferViewSetTabColor(context: NativeContextHandle, view: ContextTextBufferViewHandle, color: RGBA | null): void;
    contextTextBufferViewSelect(context: NativeContextHandle, view: ContextTextBufferViewHandle, selection: NativeEditorSelection): boolean;
    /**
     * Resets read only the operation, so each uses one prepared record. Text view selection never calls back.
     * A reset of a view with no selection changes nothing, so `clear` skips the native call after the checks.
     */
    contextTextBufferViewResetSelection(context: NativeContextHandle, view: ContextTextBufferViewHandle, local: boolean, clear?: boolean): void;
    contextTextBufferViewGetInfo(context: NativeContextHandle, view: ContextTextBufferViewHandle): NativeEditorViewInfo;
    contextTextBufferViewGetSelectedText(context: NativeContextHandle, view: ContextTextBufferViewHandle): string;
    contextTextBufferViewGetLines(context: NativeContextHandle, view: ContextTextBufferViewHandle, logical?: boolean, firstLine?: number, lineCount?: number): LineInfo;
    contextTextBufferViewMeasure(context: NativeContextHandle, view: ContextTextBufferViewHandle, width: number, height: number): MeasureResult;
    sceneSetTextView(context: NativeContextHandle, node: SceneNodeHandle, view: ContextTextBufferViewHandle | null): void;
    sceneSetTextViewPaint(context: NativeContextHandle, node: SceneNodeHandle, enabled: boolean): void;
    contextDrawTextBufferView({ context, target, frame }: NativeDrawingTarget, view: ContextTextBufferViewHandle, x: number, y: number): void;
    contextDrawEditorView({ context, target, frame }: NativeDrawingTarget, view: ContextEditorViewHandle, x: number, y: number): void;
    contextDrawSceneText({ context, target, frame }: NativeDrawingTarget, node: SceneNodeHandle, x: number, y: number): void;
    createContextEditBuffer(context: NativeContextHandle, options?: NativeContextEditBufferOptions): ContextEditBufferHandle;
    destroyContextEditBuffer(context: NativeContextHandle, editBuffer: ContextEditBufferHandle): void;
    createContextEditorView(context: NativeContextHandle, editBuffer: ContextEditBufferHandle, width: number, height: number): ContextEditorViewHandle;
    destroyContextEditorView(context: NativeContextHandle, view: ContextEditorViewHandle): void;
    createContextSyntaxStyle(context: NativeContextHandle): ContextSyntaxStyleHandle;
    destroyContextSyntaxStyle(context: NativeContextHandle, style: ContextSyntaxStyleHandle): void;
    contextEditBufferSetSyntaxStyle(context: NativeContextHandle, editBuffer: ContextEditBufferHandle, style: ContextSyntaxStyleHandle | null): void;
    contextEditBufferSetText(context: NativeContextHandle, editBuffer: ContextEditBufferHandle, bytes: Uint8Array, preserveHistory?: boolean): void;
    contextEditBufferInsertText(context: NativeContextHandle, editBuffer: ContextEditBufferHandle, bytes: Uint8Array): void;
    contextEditBufferDeleteRange(context: NativeContextHandle, editBuffer: ContextEditBufferHandle, startRow: number, startCol: number, endRow: number, endCol: number): void;
    contextEditBufferSetCursor(context: NativeContextHandle, editBuffer: ContextEditBufferHandle, row: number, col: number): void;
    contextEditBufferGetText(context: NativeContextHandle, editBuffer: ContextEditBufferHandle): string;
    contextEditBufferGetInfo(context: NativeContextHandle, editBuffer: ContextEditBufferHandle): NativeEditBufferInfo;
    contextEditBufferSetTabWidth(context: NativeContextHandle, editBuffer: ContextEditBufferHandle, width: number): void;
    contextEditBufferCommand(context: NativeContextHandle, editBuffer: ContextEditBufferHandle, command: NativeEditCommand, argument?: number): void;
    contextEditBufferHistory(context: NativeContextHandle, editBuffer: ContextEditBufferHandle, redo: boolean): string | null;
    contextEditBufferGetPosition(context: NativeContextHandle, editBuffer: ContextEditBufferHandle, query: NativeEditPositionQuery, a?: number, b?: number): LogicalCursor | null;
    contextEditBufferGetRange(context: NativeContextHandle, editBuffer: ContextEditBufferHandle, byCoords: boolean, startRow: number, startCol: number, endRow: number, endCol: number): string;
    contextEditBufferMeasureText(context: NativeContextHandle, editBuffer: ContextEditBufferHandle, bytes: Uint8Array): number;
    editMeasureText(bytes: Uint8Array, widthMethod: WidthMethod, tabWidth: number): number;
    contextEditBufferSetDefaults(context: NativeContextHandle, editBuffer: ContextEditBufferHandle, mask: NativeEditorStyleMask, style: NativeEditorStyle): void;
    contextSyntaxStyleRegister(context: NativeContextHandle, style: ContextSyntaxStyleHandle, name: string, definition: NativeEditorStyle): number;
    contextSyntaxStyleResolveByName(context: NativeContextHandle, style: ContextSyntaxStyleHandle, name: string): number | null;
    contextSyntaxStyleGetStyleCount(context: NativeContextHandle, style: ContextSyntaxStyleHandle): number;
    contextEditBufferHighlight(context: NativeContextHandle, editBuffer: ContextEditBufferHandle, operation: NativeEditHighlightOperation, argument?: number, highlight?: Highlight): void;
    contextEditBufferGetHighlights(context: NativeContextHandle, editBuffer: ContextEditBufferHandle, line: number): Highlight[];
    contextEditorViewSetViewport(context: NativeContextHandle, view: ContextEditorViewHandle, viewport: NativeEditorViewport, sizeOnly?: boolean, moveCursor?: boolean): void;
    contextEditorViewGetViewport(context: NativeContextHandle, view: ContextEditorViewHandle): NativeEditorViewport;
    contextEditorViewSetScrollMargin(context: NativeContextHandle, view: ContextEditorViewHandle, margin: number): void;
    contextEditorViewCommand(context: NativeContextHandle, view: ContextEditorViewHandle, command: NativeEditorCommand, argument?: number): void;
    contextEditorViewReplaceSelection(context: NativeContextHandle, view: ContextEditorViewHandle, bytes: Uint8Array): NativeEditorReplacement;
    contextEditorViewSetTabColor(context: NativeContextHandle, view: ContextEditorViewHandle, color: RGBA | null): void;
    contextEditorViewSelect(context: NativeContextHandle, view: ContextEditorViewHandle, selection: NativeEditorSelection): boolean;
    contextEditorViewGetInfo(context: NativeContextHandle, view: ContextEditorViewHandle, followCursor?: boolean): NativeEditorViewInfo;
    contextEditorViewGetSelection(context: NativeContextHandle, view: ContextEditorViewHandle): Pick<NativeEditorViewInfo, "selection" | "selectionOccupancy">;
    contextEditorViewGetSelectedText(context: NativeContextHandle, view: ContextEditorViewHandle): string;
    contextEditorViewGetPosition(context: NativeContextHandle, view: ContextEditorViewHandle, query: NativeEditorPositionQuery): VisualCursor;
    contextEditorViewGetLines(context: NativeContextHandle, view: ContextEditorViewHandle, logical?: boolean): LineInfo;
    contextEditorViewMeasure(context: NativeContextHandle, view: ContextEditorViewHandle, width: number, height: number): MeasureResult;
    contextEditorViewSetPlaceholder(context: NativeContextHandle, view: ContextEditorViewHandle, content: StyledText): void;
    onContextEditEvent(context: NativeContextHandle, editBuffer: ContextEditBufferHandle, handler: (event: NativeEditEventName) => void): () => void;
    sceneSetEditorView(context: NativeContextHandle, node: SceneNodeHandle, view: ContextEditorViewHandle | null): void;
    sceneSetEditorOptions(context: NativeContextHandle, node: SceneNodeHandle, options: NativeSceneEditorOptions): void;
    destroyContextImage(context: NativeContextHandle, image: ContextImageHandle): void;
    sceneSetImage(context: NativeContextHandle, node: SceneNodeHandle, image: ContextImageHandle | null, fit: "fit" | "cover" | "fill", protocol: ImageRenderProtocol, buffer: ContextBufferHandle | null): void;
    contextDrawImage({ context, target, frame }: NativeDrawingTarget, image: ContextImageHandle, options: NativeContextImageDraw): boolean;
    sessionSetImageResolution(context: NativeContextHandle, session: SessionHandle, terminalWidth: number, terminalHeight: number, pixelWidth: number, pixelHeight: number): void;
    sessionSetKittyImageTransport(context: NativeContextHandle, session: SessionHandle, mode: number): void;
    sessionGetKittyImageTransport(context: NativeContextHandle, session: SessionHandle): NativeSessionKittyImageTransportStatus;
    sessionPollKittyImageTransport(context: NativeContextHandle, session: SessionHandle, nowNs: bigint): boolean;
    sessionCancelKittyImageTransport(context: NativeContextHandle, session: SessionHandle, failed: boolean): void;
    sessionProcessKittyImageReply(context: NativeContextHandle, session: SessionHandle, bytes: Uint8Array): number;
    sessionStartKittyFileProbe(context: NativeContextHandle, session: SessionHandle): void;
    createContextBuffer(context: NativeContextHandle, options: NativeContextBufferOptions): ContextBufferHandle;
    destroyContextBuffer(context: NativeContextHandle, buffer: ContextBufferHandle): void;
    contextResizeBuffer(context: NativeContextHandle, buffer: ContextBufferHandle, width: number, height: number): void;
    contextDrawBuffer(drawing: NativeDrawingTarget, options: NativeBufferDraw): void;
    contextBufferStack({ context, target, frame }: NativeDrawingTarget, options: NativeBufferStack): number;
    contextDrawGrid({ context, target, frame }: NativeDrawingTarget, options: NativeBufferGrid): void;
    contextDrawPackedBuffer({ context, target, frame }: NativeDrawingTarget, data: Uint8Array | PointerInput, byteLength: number, x: number, y: number, width: number, height: number): void;
    contextDrawSuperSampleBuffer({ context, target, frame }: NativeDrawingTarget, data: Uint8Array | PointerInput, byteLength: number, x: number, y: number, format: "rgba8unorm" | "bgra8unorm", stride: number): void;
    contextDrawGrayscaleBuffer({ context, target, frame }: NativeDrawingTarget, data: Float32Array, x: number, y: number, width: number, height: number, foreground: RGBA | null, background: RGBA | null, supersampled: boolean): void;
    contextColorMatrixBuffer({ context, target, frame }: NativeDrawingTarget, matrix: Float32Array, mask: Float32Array | null, strength: number, channel: number): void;
    contextAcquireBufferLease(context: NativeContextHandle, buffer: ContextBufferHandle): NativeContextBufferLease;
    createSession(context: NativeContextHandle, options: NativeSessionOptions): SessionHandle;
    sessionGetWriteLimit(context: NativeContextHandle, session: SessionHandle): bigint;
    sessionWrite(context: NativeContextHandle, session: SessionHandle, bytes: Uint8Array): void;
    sessionAttachRenderer(context: NativeContextHandle, session: SessionHandle, options: NativeSessionRendererOptions): void;
    sessionResizeRenderer(context: NativeContextHandle, session: SessionHandle, width: number, height: number): void;
    sessionSetDebugOverlay(context: NativeContextHandle, session: SessionHandle, enabled: boolean, corner: DebugOverlayCorner): void;
    sessionUpdateStats(context: NativeContextHandle, session: SessionHandle, overallMs: number, fps: number, callbackMs: number): void;
    sessionUpdateMemoryStats(context: NativeContextHandle, session: SessionHandle, heapUsed: number, heapTotal: number, arrayBuffers: number): void;
    sessionDumpHitGrid(context: NativeContextHandle, session: SessionHandle): void;
    sessionGetRendererState(context: NativeContextHandle, session: SessionHandle): NativeSessionRendererState;
    sessionAcquireBufferLease(context: NativeContextHandle, session: SessionHandle, which: SessionBuffer): NativeSessionBufferLease;
    sessionGetLinkId(context: NativeContextHandle, session: SessionHandle, x: number, y: number): number;
    private acquireBufferLease;
    contextValidateBufferLease(context: NativeContextHandle, lease: ContextObjectHandle): void;
    contextReleaseBufferLease(context: NativeContextHandle, lease: ContextObjectHandle): void;
    contextBufferLeaseGetRealCharSize(context: NativeContextHandle, lease: ContextObjectHandle, addLineBreaks: boolean): number;
    contextBufferLeaseWriteResolvedChars(context: NativeContextHandle, lease: ContextObjectHandle, bytes: Uint8Array, addLineBreaks: boolean, cellLengths?: Uint8Array): number;
    sessionSetupTerminal(context: NativeContextHandle, session: SessionHandle, options?: NativeSessionTerminalOptions): void;
    sessionSuspend(context: NativeContextHandle, session: SessionHandle): void;
    sessionResume(context: NativeContextHandle, session: SessionHandle): void;
    sessionGetTerminalState(context: NativeContextHandle, session: SessionHandle): NativeSessionTerminalPhase;
    sessionPump(context: NativeContextHandle, session: SessionHandle, nowNs: bigint, workBudget: number): NativeSessionPumpResult;
    sessionPumpExit(context: NativeContextHandle, session: SessionHandle): NativeSessionPumpStatus;
    /** Discards terminal input queued on process stdin. Best effort; see `ot_terminal_flush_input`. */
    terminalFlushInput(): void;
    sessionControl(context: NativeContextHandle, session: SessionHandle, command: NativeSessionControl): void;
    sessionClipboard(context: NativeContextHandle, session: SessionHandle, target: number, bytes: Uint8Array): boolean;
    sessionNotification(context: NativeContextHandle, session: SessionHandle, message: string, title?: string): boolean;
    sessionSetPaletteState(context: NativeContextHandle, session: SessionHandle, palette: readonly RGBA[], foreground: RGBA, background: RGBA, epoch: number): void;
    sessionSetCursor(context: NativeContextHandle, session: SessionHandle, options: NativeSessionCursorOptions): void;
    sessionGetCapabilities(context: NativeContextHandle, session: SessionHandle): NativeSessionCapabilities;
    sessionReadOutput(context: NativeContextHandle, session: SessionHandle, bytes: Uint8Array): NativeOutputTicket | null;
    sessionDrainStdout(context: NativeContextHandle, session: SessionHandle, maxBytes?: number): number;
    sessionCompleteOutput(context: NativeContextHandle, session: SessionHandle, ticket: NativeOutputTicket, success: boolean): void;
    sessionClose(context: NativeContextHandle, session: SessionHandle): void;
    sessionCancel(context: NativeContextHandle, session: SessionHandle): void;
    sessionGetState(context: NativeContextHandle, session: SessionHandle): NativeSessionState;
    destroySession(context: NativeContextHandle, session: SessionHandle): void;
    sceneCreateNode(context: NativeContextHandle, session: SessionHandle, kind: (typeof SCENE_NODE_KINDS)[number], num: number): SceneNodeHandle;
    sceneDestroyNode(context: NativeContextHandle, node: SceneNodeHandle): void;
    sceneSetMeasure(context: NativeContextHandle, node: SceneNodeHandle, measure: MeasureFunction | null): void;
    sceneHasMeasure(context: NativeContextHandle, node: SceneNodeHandle): boolean;
    sceneMarkDirty(context: NativeContextHandle, node: SceneNodeHandle): void;
    sceneMoveNode(context: NativeContextHandle, node: SceneNodeHandle, parent: SceneNodeHandle | null, index: number): void;
    sceneSetViewport(context: NativeContextHandle, node: SceneNodeHandle, viewport: SceneNodeHandle | null): void;
    sceneSetFocus(context: NativeContextHandle, node: SceneNodeHandle, focused: boolean): void;
    sceneGetStyle(context: NativeContextHandle, node: SceneNodeHandle, group: number, kind: number, edge: number): {
        unit: number;
        value: number;
    };
    sceneSetBoxDetails(context: NativeContextHandle, node: SceneNodeHandle, details: NativeSceneBoxDetails): void;
    sceneSetSurface(context: NativeContextHandle, node: SceneNodeHandle, buffer: ContextBufferHandle | null): void;
    /** Consume only native's accepted prefix. Allocation or admission failures leave
     * the suffix staged so a retry cannot lose writes or replay accepted entries. A record
     * that native rejects for its node can never apply, so it is dropped and reported once;
     * paint fields the node staged since the last flush share that record and are dropped too. */
    sceneFlush(context: NativeContextHandle, staging: SceneStaging): void;
    sceneSetText(context: NativeContextHandle, node: SceneNodeHandle, bytes: Uint8Array): void;
    sceneSetStyledText(context: NativeContextHandle, node: SceneNodeHandle, content: StyledText): void;
    private encodeStyledText;
    sceneSetSlider(context: NativeContextHandle, node: SceneNodeHandle, options: NativeSceneSliderOptions): void;
    sceneGetSliderThumb(context: NativeContextHandle, node: SceneNodeHandle): {
        size: number;
        start: number;
    };
    sceneSetArrow(context: NativeContextHandle, node: SceneNodeHandle, options: NativeSceneArrowOptions): void;
    sceneSetTextOptions(context: NativeContextHandle, node: SceneNodeHandle, options: NativeSceneTextOptions): void;
    sceneSetTextSelection(context: NativeContextHandle, node: SceneNodeHandle, options: NativeSceneTextSelectionOptions): boolean;
    sceneGetTextSelection(context: NativeContextHandle, node: SceneNodeHandle): {
        start: number;
        end: number;
    } | null;
    sceneGetSelectedText(context: NativeContextHandle, node: SceneNodeHandle): string;
    sceneGetTextMetrics(context: NativeContextHandle, node: SceneNodeHandle): NativeSceneTextMetrics;
    private sceneTextMetrics;
    sceneGetText(context: NativeContextHandle, node: SceneNodeHandle): string;
    sceneGetTextLineInfo(context: NativeContextHandle, node: SceneNodeHandle, firstLine?: number, lineCount?: number): LineInfo;
    sceneGetLayout(context: NativeContextHandle, node: SceneNodeHandle, observation?: boolean | "paint"): NativeSceneLayout;
    sceneSetHooks(context: NativeContextHandle, node: SceneNodeHandle, flags: number, generation: bigint, initialWidth: number, initialHeight: number): void;
    /** Paint options can change between steps; attempt limits remain fixed.
     * A RECORD acknowledgement passes its recording; null records nothing. */
    sceneFrameStep(context: NativeContextHandle, session: SessionHandle, previous: NativeSceneFrameRequest | null, options: NativeSceneFrameOptions, maxWorkItems?: number, recording?: Uint8Array | null): NativeSceneFrameRequest;
    private sceneFrameStepWithMeasures;
    /** Run a native release now, or after the frame step that paints the Context's open paint recording.
     * A recording names resources that native code reads only when it paints, so every resource that a
     * paint hook can draw is released through here. */
    releaseAfterPaint(context: NativeContextHandle, release: () => void): void;
    /** Slots of the exact pending RECORD request, in paint order. */
    sceneFrameGetPaintSlots(context: NativeContextHandle, session: SessionHandle, frame: NativeSceneFrameRequest): NativeScenePaintSlot[];
    sceneFrameAcquireBufferLease(context: NativeContextHandle, session: SessionHandle, frame: NativeSceneFrameRequest, which: SessionBuffer): NativeContextBufferLease;
    /** Every returned status consumes the draft; an admission exception preserves it for retry. */
    sceneFrameCommit(context: NativeContextHandle, session: SessionHandle, frame: NativeSceneFrameRequest, force: boolean): NativeSessionRenderStatus;
    sceneFrameCancel(context: NativeContextHandle, session: SessionHandle, frameId: bigint): void;
    sceneHitTest(context: NativeContextHandle, session: SessionHandle, x: number, y: number): number;
    sceneGetStats(context: NativeContextHandle, session: SessionHandle): NativeRenderStats;
    sceneGetCursorState(context: NativeContextHandle, session: SessionHandle): CursorState;
    constructor(libPath?: string);
    /** Drains queued Context diagnostics and logs the records at `maxLevel` or more severe; it drops the rest. One call
     * drains at most one full queue. Records that console handlers add meanwhile wait for the next call. */
    logContextDiagnostics(context: NativeContextHandle, maxLevel?: LogLevel): void;
    private logMessage;
    private setupLogging;
    private setLogCallback;
    /** Hands the process log callback to the newest remaining main-thread library, or clears it after the last one. */
    private releaseProcessLog;
    dispose(): void;
    private ensureNativeSpanFeedCallback;
    clipboardServiceCreate(maxConcurrentOperations: number, maxProviderTransfers: number, waylandSeat?: string): ClipboardServiceHandle | null;
    private clipboardContext;
    private clipboardOperationArgs;
    clipboardServiceBeginShutdown(service: ClipboardServiceHandle): NativeClipboardShutdownStatus;
    clipboardServicePollShutdown(service: ClipboardServiceHandle): NativeClipboardShutdownStatus;
    clipboardServiceDestroy(service: ClipboardServiceHandle): NativeClipboardDestroyStatus;
    clipboardServiceDrain(service: ClipboardServiceHandle): number;
    private clipboardStart;
    clipboardReadOperationStart(service: ClipboardServiceHandle, request: Uint8Array, selection: number, maxBytes: number, maxImagePixels: number, maxConversionBytes: number, timeoutMs: number): {
        status: NativeClipboardStartStatus;
        operation: ClipboardOperationHandle | null;
    };
    clipboardWriteOperationStart(service: ClipboardServiceHandle, textUtf8: Uint8Array, selection: number, timeoutMs: number): {
        status: NativeClipboardStartStatus;
        operation: ClipboardOperationHandle | null;
    };
    clipboardClearOperationStart(service: ClipboardServiceHandle, selection: number, timeoutMs: number): {
        status: NativeClipboardStartStatus;
        operation: ClipboardOperationHandle | null;
    };
    clipboardOperationPoll(operation: ClipboardOperationHandle): NativeClipboardOperationStatus;
    clipboardOperationCancel(operation: ClipboardOperationHandle): NativeClipboardCancelStatus;
    private clipboardResultLength;
    clipboardOperationResultMimeLength(operation: ClipboardOperationHandle): {
        status: NativeClipboardCopyStatus;
        length: number;
    };
    clipboardOperationResultMimeCopy(operation: ClipboardOperationHandle, output: Uint8Array): NativeClipboardCopyStatus;
    clipboardOperationResultDataLength(operation: ClipboardOperationHandle): {
        status: NativeClipboardCopyStatus;
        length: number;
    };
    clipboardOperationResultDataCopy(operation: ClipboardOperationHandle, output: Uint8Array): NativeClipboardCopyStatus;
    clipboardOperationResultErrorCode(operation: ClipboardOperationHandle): {
        status: NativeClipboardCopyStatus;
        errorCode: number;
    };
    clipboardOperationResultDiagnosticLength(operation: ClipboardOperationHandle): {
        status: NativeClipboardCopyStatus;
        length: number;
    };
    clipboardOperationResultDiagnosticCopy(operation: ClipboardOperationHandle, output: Uint8Array): NativeClipboardCopyStatus;
    clipboardOperationDestroy(operation: ClipboardOperationHandle): NativeClipboardDestroyStatus;
    getYogaHost(): YogaHost;
    private yogaMutation;
    private yogaChecked;
    yogaConfigCreate(): Pointer;
    yogaConfigFree(config: Pointer): void;
    yogaConfigSetCallbacks(config: Pointer, measure: Pointer, dirtied: Pointer): boolean;
    yogaConfigClearCallbacks(config: Pointer, measure: Pointer): boolean;
    yogaConfigSetUseWebDefaults(config: Pointer, enabled: boolean): void;
    yogaConfigGetUseWebDefaults(config: Pointer): boolean;
    yogaConfigSetPointScaleFactor(config: Pointer, pointScaleFactor: number): void;
    yogaConfigGetPointScaleFactor(config: Pointer): number;
    yogaConfigSetErrata(config: Pointer, errata: number): void;
    yogaConfigGetErrata(config: Pointer): number;
    yogaConfigSetExperimentalFeatureEnabled(config: Pointer, feature: number, enabled: boolean): void;
    yogaConfigIsExperimentalFeatureEnabled(config: Pointer, feature: number): boolean;
    yogaNodeCreateForOpenTUI(): Pointer;
    yogaNodeCreateWithConfig(config: Pointer): Pointer;
    yogaNodeGetConfig(node: Pointer): Pointer;
    yogaNodeFree(node: Pointer): void;
    yogaNodeFreeRecursive(node: Pointer): void;
    yogaNodeReset(node: Pointer): void;
    yogaNodeCopyStyle(dstNode: Pointer, srcNode: Pointer): void;
    yogaNodeInsertChild(node: Pointer, child: Pointer, index: number): void;
    yogaNodeRemoveChild(node: Pointer, child: Pointer): void;
    yogaNodeRemoveAllChildren(node: Pointer): void;
    yogaNodeGetChild(node: Pointer, index: number): Pointer | null;
    yogaNodeGetChildCount(node: Pointer): number;
    yogaNodeGetParent(node: Pointer): Pointer | null;
    yogaNodeCalculateLayout(node: Pointer, width: number, height: number, direction: number): void;
    yogaNodeIsDirty(node: Pointer): boolean;
    yogaNodeMarkDirty(node: Pointer): void;
    yogaNodeGetHasNewLayout(node: Pointer): boolean;
    yogaNodeSetHasNewLayout(node: Pointer, hasNewLayout: boolean): void;
    yogaNodeSetIsReferenceBaseline(node: Pointer, isReferenceBaseline: boolean): void;
    yogaNodeIsReferenceBaseline(node: Pointer): boolean;
    yogaNodeSetAlwaysFormsContainingBlock(node: Pointer, alwaysFormsContainingBlock: boolean): void;
    yogaNodeGetAlwaysFormsContainingBlock(node: Pointer): boolean;
    yogaNodeGetComputedLayout(node: Pointer): NativeYogaLayout;
    yogaNodeLayoutGetEdge(node: Pointer, kind: number, edge: number): number;
    yogaNodeStyleSetEnum(node: Pointer, kind: number, value: number): void;
    yogaNodeStyleGetEnum(node: Pointer, kind: number): number;
    yogaNodeStyleSetFloat(node: Pointer, kind: number, value: number): void;
    yogaNodeStyleGetFloat(node: Pointer, kind: number): number;
    yogaNodeStyleSetBorder(node: Pointer, edge: number, border: number): void;
    yogaNodeStyleGetBorder(node: Pointer, edge: number): number;
    yogaNodeStyleSetValue(node: Pointer, kind: number, edgeOrGutter: number, unit: number, value: number): void;
    yogaNodeStyleGetValue(node: Pointer, kind: number, edgeOrGutter: number): number | bigint;
    yogaNodeSetMeasureFunc(node: Pointer, enabled: boolean): void;
    yogaNodeUnsetMeasureFunc(node: Pointer): void;
    yogaNodeHasMeasureFunc(node: Pointer): boolean;
    yogaNodeSetDirtiedFunc(node: Pointer, enabled: boolean): void;
    yogaNodeUnsetDirtiedFunc(node: Pointer): void;
    yogaStoreMeasureResult(config: Pointer, width: number, height: number): void;
    createYogaMeasureCallback(callback: NativeYogaMeasureCallback): FFICallbackInstance;
    createYogaDirtiedCallback(callback: NativeYogaDirtiedCallback): FFICallbackInstance;
    /** Always 0: native resources no longer allocate from a process arena. */
    getArenaAllocatedBytes(): number;
    getBuildOptions(): BuildOptions;
    /** Stats of the process allocator, which backs native span feeds. Each Context has its own allocator, so Context
     * resources such as text, buffers, scenes, images, and audio engines are not counted. */
    getAllocatorStats(): AllocatorStats;
    private tryCreateStandaloneContext;
    createAudioEngine(options?: AudioCreateOptions | null): AudioEngineHandle | null;
    destroyAudioEngine(engine: AudioEngineHandle): void;
    private audioContext;
    audioRefreshPlaybackDevices(engine: AudioEngineHandle): number;
    audioGetPlaybackDeviceCount(engine: AudioEngineHandle): number;
    audioGetPlaybackDeviceName(engine: AudioEngineHandle, index: number): string;
    audioIsPlaybackDeviceDefault(engine: AudioEngineHandle, index: number): boolean;
    audioSelectPlaybackDevice(engine: AudioEngineHandle, index: number): number;
    audioClearPlaybackDeviceSelection(engine: AudioEngineHandle): void;
    audioRefreshCaptureDevices(engine: AudioEngineHandle): number;
    audioGetCaptureDeviceCount(engine: AudioEngineHandle): number;
    audioGetCaptureDeviceName(engine: AudioEngineHandle, index: number): string;
    audioIsCaptureDeviceDefault(engine: AudioEngineHandle, index: number): boolean;
    audioSelectCaptureDevice(engine: AudioEngineHandle, index: number): number;
    audioClearCaptureDeviceSelection(engine: AudioEngineHandle): void;
    audioStartCapture(engine: AudioEngineHandle, options: AudioStartOptions | undefined, channels: number, capacityFrames: number): number;
    audioStopCapture(engine: AudioEngineHandle): number;
    audioIsCaptureRunning(engine: AudioEngineHandle): boolean;
    audioReadCapture(engine: AudioEngineHandle, outBuffer: Float32Array, frameCount: number): {
        status: number;
        framesRead: number;
    };
    audioGetCaptureStats(engine: AudioEngineHandle): {
        status: number;
        stats: NativeAudioCaptureStats | null;
    };
    audioStart(engine: AudioEngineHandle, options?: AudioStartOptions | null): number;
    audioStartMixer(engine: AudioEngineHandle): number;
    audioStop(engine: AudioEngineHandle): number;
    audioCreateStream(engine: AudioEngineHandle, options: AudioStreamCreateOptions): {
        status: number;
        streamId: number | null;
    };
    audioWriteStream(engine: AudioEngineHandle, streamId: number, data: Uint8Array): number;
    audioEndStream(engine: AudioEngineHandle, streamId: number): number;
    audioRestartStream(engine: AudioEngineHandle, streamId: number): number;
    audioSetStreamVolume(engine: AudioEngineHandle, streamId: number, volume: number): number;
    audioSetStreamPan(engine: AudioEngineHandle, streamId: number, pan: number): number;
    audioSetStreamGroup(engine: AudioEngineHandle, streamId: number, groupId: number): number;
    audioGetStreamStats(engine: AudioEngineHandle, streamId: number): NativeAudioStreamStats | null;
    audioCloseStream(engine: AudioEngineHandle, streamId: number, reason: NativeAudioStreamCloseReason): {
        status: number;
        stats: NativeAudioStreamStats | null;
    };
    audioLoad(engine: AudioEngineHandle, data: Uint8Array): {
        status: number;
        soundId: number | null;
    };
    audioUnload(engine: AudioEngineHandle, soundId: number): number;
    audioPlay(engine: AudioEngineHandle, soundId: number, options?: AudioVoiceOptions): {
        status: number;
        voiceId: number | null;
    };
    audioStopVoice(engine: AudioEngineHandle, voiceId: number): number;
    audioSetVoiceGroup(engine: AudioEngineHandle, voiceId: number, groupId: number): number;
    audioCreateGroup(engine: AudioEngineHandle, name: string): {
        status: number;
        groupId: number | null;
    };
    audioSetGroupVolume(engine: AudioEngineHandle, groupId: number, volume: number): number;
    audioSetMasterVolume(engine: AudioEngineHandle, volume: number): number;
    audioMixToBuffer(engine: AudioEngineHandle, outBuffer: Float32Array, frameCount: number, channels: number): number;
    audioEnableTap(engine: AudioEngineHandle, enabled: boolean, capacityFrames: number): number;
    audioReadTap(engine: AudioEngineHandle, outBuffer: Float32Array, frameCount: number, channels: number): {
        status: number;
        framesRead: number;
    };
    audioGetStats(engine: AudioEngineHandle): AudioStats | null;
    registerNativeSpanFeedStream(stream: Pointer, handler: NativeSpanFeedEventHandler): void;
    unregisterNativeSpanFeedStream(stream: Pointer): void;
    createNativeSpanFeed(options?: NativeSpanFeedOptions | null): Pointer;
    attachNativeSpanFeed(stream: Pointer): number;
    destroyNativeSpanFeed(stream: Pointer): number;
    streamWrite(stream: Pointer, data: Uint8Array | string): number;
    streamCommit(stream: Pointer): number;
    streamDrainSpans(stream: Pointer, outBuffer: Uint8Array, maxSpans: number): number;
    streamReleaseSpan(stream: Pointer, slotIndex: number, releaseId: bigint): number;
    streamClose(stream: Pointer): number;
    streamGetStats(stream: Pointer): NativeSpanFeedStats | null;
    streamReserve(stream: Pointer, minLen: number): {
        status: number;
        info: ReserveInfo | null;
    };
    streamCommitReserved(stream: Pointer, length: number): number;
    private imageStatus;
    private imageCall;
    private imageOutput;
    private imageInfoOutput;
    imageInfo(context: NativeContextHandle, data: Uint8Array): {
        status: number;
        info: NativeImageInfo;
    };
    imageDecode(context: NativeContextHandle, data: Uint8Array): {
        status: number;
        handle: ImageHandle | null;
    };
    imageCreateFromRgba(context: NativeContextHandle, pixels: Uint8Array, width: number, height: number, stride: number): {
        status: number;
        handle: ImageHandle | null;
    };
    imageCreateFromPixels(context: NativeContextHandle, pixels: Uint8Array, width: number, height: number, stride: number, format: number, alpha: number): {
        status: number;
        handle: ImageHandle | null;
    };
    imageUpdatePixels(image: ImageHandle, pixels: Uint8Array, stride: number, format: number, alpha: number): number;
    imageDestroy(image: ImageHandle): void;
    imageRetain(image: ImageHandle): {
        status: number;
        handle: ImageHandle | null;
    };
    imageRetainIccCache(): void;
    imageReleaseIccCache(): void;
    imageGetInfo(image: ImageHandle): {
        status: number;
        info: NativeImageInfo;
    };
    imageEnsureEncodedPng(image: ImageHandle): number;
    imageCopyPng(image: ImageHandle, destination: Uint8Array): {
        status: number;
        byteCount: number;
    };
    imageTakePixels(image: ImageHandle): {
        status: number;
        lease: ContextImagePixelsHandle | null;
        pointer: Pointer | null;
        byteCount: number;
    };
    imageReleasePixels(lease: ContextImagePixelsHandle): void;
    imageClone(image: ImageHandle, context?: NativeContextHandle): {
        status: number;
        handle: ImageHandle | null;
    };
    imageCopyPixels(image: ImageHandle, destination: Uint8Array, stride: number, bgra: boolean): number;
    imageResize(image: ImageHandle, width: number, height: number, filter: number): {
        status: number;
        handle: ImageHandle | null;
    };
    imageExtract(image: ImageHandle, left: number, top: number, width: number, height: number): {
        status: number;
        handle: ImageHandle | null;
    };
    imageExtend(image: ImageHandle, top: number, right: number, bottom: number, left: number, background: Uint8Array): {
        status: number;
        handle: ImageHandle | null;
    };
    imageTransform(image: ImageHandle, operation: number): {
        status: number;
        handle: ImageHandle | null;
    };
    imageComposite(base: ImageHandle, overlay: ImageHandle, left: number, top: number, blend: number, opacity: number): {
        status: number;
        handle: ImageHandle | null;
    };
}
export declare function setRenderLibPath(libPath: string): void;
export declare function resolveRenderLib(): RenderLib;
