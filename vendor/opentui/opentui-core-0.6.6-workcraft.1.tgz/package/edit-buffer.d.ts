import { type LogicalCursor, type RenderLib, type ContextEditBufferHandle } from "./zig.js";
import { type WidthMethod, type Highlight } from "./types.js";
import { RGBA } from "./lib/RGBA.js";
import { EventEmitter } from "events";
import type { SyntaxStyle } from "./syntax-style.js";
import type { NativeResourceOwner, ResourceContext } from "./buffer.js";
export type { LogicalCursor };
/**
 * EditBuffer provides a text editing buffer with cursor management,
 * incremental editing, and grapheme-aware operations.
 */
export declare class EditBuffer extends EventEmitter {
    private lib;
    private native;
    private unsubscribe?;
    readonly id: number;
    private _destroyed;
    private _syntaxStyle?;
    constructor(lib: RenderLib, handle: ContextEditBufferHandle, source: NativeResourceOwner);
    static create(widthMethod: WidthMethod, source: NativeResourceOwner): EditBuffer;
    private guard;
    /** @internal Editor views must use the buffer's library and Context. */
    _getOwner(): ResourceContext;
    /** @internal Resources can be shared by scenes in the same Context. */
    _getSceneHandle(scene: NativeResourceOwner): ContextEditBufferHandle;
    runMutation<T>(operation: () => T): T;
    private command;
    private position;
    private highlight;
    private setDefaults;
    private setNativeText;
    /**
     * Set text and completely reset the buffer state (clears history, resets add_buffer).
     * Use this for initial text setting or when you want a clean slate.
     */
    setText(text: string): void;
    /** Historical name for copied text replacement without undo history. */
    setTextOwned(text: string): void;
    /**
     * Replace text while preserving undo history (creates an undo point).
     * Use this when you want the setText operation to be undoable.
     */
    replaceText(text: string): void;
    /** Historical name for copied text replacement that preserves undo history. */
    replaceTextOwned(text: string): void;
    getLineCount(): number;
    setTabWidth(width: number): void;
    getTabWidth(): number;
    getText(): string;
    insertChar(char: string): void;
    insertText(text: string): void;
    deleteChar(): void;
    deleteCharBackward(): void;
    deleteRange(startLine: number, startCol: number, endLine: number, endCol: number): void;
    newLine(): void;
    deleteLine(): void;
    moveCursorLeft(): void;
    moveCursorRight(): void;
    moveCursorUp(): void;
    moveCursorDown(): void;
    gotoLine(line: number): void;
    setCursor(line: number, col: number): void;
    setCursorToLineCol(line: number, col: number): void;
    setCursorByOffset(offset: number): void;
    getCursorPosition(): LogicalCursor;
    getNextWordBoundary(): LogicalCursor;
    getPrevWordBoundary(): LogicalCursor;
    getEOL(): LogicalCursor;
    offsetToPosition(offset: number): {
        row: number;
        col: number;
    } | null;
    positionToOffset(row: number, col: number): number;
    getLineStartOffset(row: number): number;
    /**
     * Returns the global display offset at the end of `text` as this buffer would lay it out, without storing it: its
     * cells under this buffer's width method, tab width, and control notation, plus one per line break. Use
     * `measureEditText()` to measure without a buffer.
     */
    measureText(text: string): number;
    getTextRange(startOffset: number, endOffset: number): string;
    getTextRangeByCoords(startRow: number, startCol: number, endRow: number, endCol: number): string;
    debugLogRope(): void;
    undo(): string | null;
    redo(): string | null;
    canUndo(): boolean;
    canRedo(): boolean;
    clearHistory(): void;
    setDefaultFg(fg: RGBA | null): void;
    setDefaultBg(bg: RGBA | null): void;
    setDefaultAttributes(attributes: number | null): void;
    resetDefaults(): void;
    setSyntaxStyle(style: SyntaxStyle | null): void;
    getSyntaxStyle(): SyntaxStyle | null;
    addHighlight(lineIdx: number, highlight: Highlight): void;
    addHighlightByCharRange(highlight: Highlight): void;
    removeHighlightsByRef(hlRef: number): void;
    clearLineHighlights(lineIdx: number): void;
    clearAllHighlights(): void;
    getLineHighlights(lineIdx: number): Array<Highlight>;
    clear(): void;
    destroy(): void;
}
/**
 * Returns the editor offset at the end of `text` as an edit buffer with these settings lays it out, without an edit
 * buffer: its cells under `widthMethod`, `tabWidth`, and control notation, plus one per line break. `tabWidth` defaults
 * to the tab width of a new edit buffer and rounds as in `EditBuffer.setTabWidth()`.
 */
export declare function measureEditText(text: string, options: {
    widthMethod: WidthMethod;
    tabWidth?: number;
}): number;
