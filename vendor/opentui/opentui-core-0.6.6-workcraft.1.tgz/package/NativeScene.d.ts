import type { NativeSession } from "./NativeSession.js";
import type { Renderable, RenderableOptions } from "./Renderable.js";
import type { ImageFit } from "./renderables/Image.js";
import type { NativeImage } from "./image.js";
import { OptimizedBuffer } from "./buffer.js";
import type { ImageRenderProtocol } from "./types.js";
import { type CliRenderer } from "./renderer.js";
import type { StyledText } from "./lib/styled-text.js";
import type { RGBA } from "./lib/RGBA.js";
import type { LocalSelectionBounds } from "./lib/selection.js";
import { type Value, type MeasureFunction } from "./yoga.js";
import { NativeSessionRenderStatus, type NativeSceneFrameOptions, type NativeSceneFrameRequest, type NativeSceneLayout, type NativeScenePaint, type NativeScenePaintUpdate, type NativeSceneBoxDetails, type NativeSceneTextOptions, type NativeSceneSliderOptions, type NativeSceneArrowOptions, type NativeSceneEditorOptions, type ContextEditorViewHandle, type ContextTextBufferViewHandle, type SceneNodeHandle } from "./zig.js";
type PaintOptions = () => Pick<NativeSceneFrameOptions, "background" | "useMouse" | "excludedHitNum" | "preserveUnwritten">;
declare class NativeLifecyclePasses extends Set<Renderable> {
    private order;
    private nextOrder;
    private work?;
    add(renderable: Renderable): this;
    refresh(renderable: Renderable): void;
    delete(renderable: Renderable): boolean;
    clear(): void;
    iteratePending(): IterableIterator<Renderable>;
}
/** Retained built-in scene with sparse owner-thread hooks. */
export declare class NativeScene {
    readonly driver: NativeSession;
    private readonly renderer;
    private readonly workBudget?;
    get resourceContext(): import("./buffer.js").ResourceContext;
    readonly lifecyclePasses: NativeLifecyclePasses;
    /** @internal Renderables whose destroy walk is still running; renderer finalization waits for them. */
    readonly cleanupOwners: Set<Renderable>;
    private readonly nodes;
    private paintedFrame;
    private paintRecording?;
    private cancelPaintYield;
    private destroyed;
    private destroying;
    private geometryRevision;
    private layoutRevision;
    private readonly staging;
    private hookScans;
    private scanningHooks;
    private readonly yogaHost;
    constructor(driver: NativeSession, renderer: Pick<CliRenderer, "root" | "isDestroyed" | "controlState" | "unregisterLifecyclePass">, workBudget?: number | undefined);
    /** @internal Buffer wrappers borrow the completed paint ticket. */
    get frame(): NativeSceneFrameRequest | null;
    /** @internal Accepted geometry mutations invalidate hook-local layout observations. */
    get currentGeometryRevision(): number;
    /** @internal Layout reads return the same values until this changes. Undefined while callbacks run inside
     * native layout, because that layout is still being computed. */
    get observedLayoutRevision(): number | undefined;
    /** The scene does no more hook or frame work once it, its Session, or its renderer is gone or going. */
    private get stopped();
    private changeGeometry;
    /** Native layout and frame calls can publish new observations without a host write. */
    private changeLayout;
    /** @internal Whether style or paint writes await native acceptance. */
    get hasStagedMutations(): boolean;
    /** @internal Apply staged style/paint writes. Runs before every native scene call
     * except node creation, moves, and hit tests, which observe no style or paint.
     * Failed flushes retain their unaccepted suffix for retry, except a record that native
     * rejects for its node (InvalidArgument, WrongKind, StaleHandle). That record is dropped,
     * including other paint fields the node staged since the last flush, and the error is
     * thrown once by whichever call flushes, which may belong to another node.
     * A closing Session paints no more frames, so like a disposed one it drops staged writes. */
    flushStaged(): void;
    /** @internal Keep construction pending until a boundary after derived class fields have run. */
    scheduleHookScan(renderable: Renderable): void;
    /** @internal Restore assignment accessors at attachment, but keep discovery pending:
     * an intermediate constructor can attach before the most-derived fields run. */
    refreshPendingHooks(renderable: Renderable): void;
    /** Scans may publish hooks natively or register lifecycle passes, so this runs
     * before lifecycle passes and native resumes. Reentrant scheduling drains in
     * bounded batches without walking the scene. */
    private drainHookScans;
    /** @internal Detached settlement visits owned controllers, not the render tree. */
    getRenderables(): IterableIterator<Renderable>;
    /** @internal Reject stale scene operations before accessing their Context. */
    assertAlive(): void;
    /** @internal Scene nodes retain native ownership even when their body is a host hook. */
    createNode(renderable: Renderable, options: RenderableOptions): void;
    /** @internal Native acceptance precedes all wrapper topology changes. */
    moveNode(child: Renderable, parent: Renderable | null, index: number): void;
    setViewport(content: Renderable, viewport: Renderable | null): void;
    setFocus(renderable: Renderable, focused: boolean): void;
    /** @internal The wrapper's existing cleanup walk releases nodes child-first. Staged
     * writes flush first so no entry outlives its handle; a flush failure must not
     * leave the native node alive behind a destroyed wrapper. */
    destroyNode(renderable: Renderable): void;
    /** @internal Hook identities publish only after native acceptance. Geometry remains native-owned. */
    setHooks(renderable: Renderable, flags: number, generation: bigint, initialWidth: number, initialHeight: number): void;
    /** @internal Shared Yoga normalization stages through the checked scene style boundary. */
    setStyle(node: {
        _getSceneHandle(owner: NativeScene): SceneNodeHandle;
    }, group: number, kind: number, edge: number, unit: number, value: number, flags?: number): void;
    /** @internal Accept this scene's staged prefix before reading native style.
     * This boundary does not run layout; geometry remains the completed observation. */
    getStyle(node: {
        _getSceneHandle(owner: NativeScene): SceneNodeHandle;
    }, group: number, kind: number, edge: number): Value;
    setMeasureFunc(node: {
        _getSceneHandle(owner: NativeScene): SceneNodeHandle;
    }, measure: MeasureFunction | null): void;
    hasMeasureFunc(node: {
        _getSceneHandle(owner: NativeScene): SceneNodeHandle;
    }): boolean;
    markDirty(node: {
        _getSceneHandle(owner: NativeScene): SceneNodeHandle;
    }): void;
    /** @internal Masked position edges stage as ordinary Yoga position values.
     * Every masked value is validated before the first edge is staged so a rejected edge
     * leaves no partial position behind. */
    setPositions(node: {
        _getSceneHandle(owner: NativeScene): SceneNodeHandle;
    }, mask: number, units: Uint32Array, values: Float32Array): void;
    /** @internal Partial visual writes stage before requested wrapper state is published.
     * Border appearance and Yoga widths are accepted atomically by native. */
    setPaint(renderable: Renderable, paint: NativeScenePaintUpdate): void;
    setBackground(renderable: Renderable, color: RGBA): void;
    setBoxDetails(renderable: Renderable, details: NativeSceneBoxDetails): void;
    /** Border style clears custom glyphs in the same staged record as border widths. */
    setBoxBorderStyle(renderable: Renderable, style: NativeScenePaint["borderStyle"], sides: number): void;
    /** @internal Native copies bytes and styles before the wrapper publishes caller identity. */
    setText(renderable: Renderable, content: string | StyledText): void;
    /** @internal Text options commit together without exposing the node-owned buffer or view. */
    setTextOptions(renderable: Renderable, options: NativeSceneTextOptions): void;
    /** @internal Native owns slider drawing and thumb geometry; the host retains input callbacks. */
    setSlider(renderable: Renderable, options: NativeSceneSliderOptions): void;
    /** @internal Input-time query only, never a per-node frame pass. */
    getSliderThumb(renderable: Renderable): {
        size: number;
        start: number;
    };
    /** @internal Standard arrow paint commits before its wrapper projection. */
    setArrow(renderable: Renderable, options: NativeSceneArrowOptions): void;
    setImage(renderable: Renderable, image: NativeImage | null, fit: ImageFit, protocol: ImageRenderProtocol, buffer: OptimizedBuffer | null): void;
    setEditorView(renderable: Renderable, view: ContextEditorViewHandle): void;
    setSurface(renderable: Renderable, buffer: OptimizedBuffer | null): void;
    setTextView(renderable: Renderable, view: ContextTextBufferViewHandle | null): void;
    setTextViewPaint(renderable: Renderable, enabled: boolean): void;
    setEditorOptions(renderable: Renderable, options: NativeSceneEditorOptions): void;
    /** @internal Query native text metrics only when requested, never during JS frame traversal. */
    getText(renderable: Renderable): string;
    /** @internal Inherited Text drawing records or draws at the caller's position. */
    drawText(renderable: Renderable, buffer: OptimizedBuffer, x: number, y: number): void;
    setTextSelection(renderable: Renderable, operation: "set" | "update" | "reset", bounds: LocalSelectionBounds | null, bg?: RGBA, fg?: RGBA): boolean;
    getTextSelection(renderable: Renderable): {
        start: number;
        end: number;
    } | null;
    getSelectedText(renderable: Renderable): string;
    /** @internal Line arrays are copied only for explicit line-info queries. */
    getTextLineInfo(renderable: Renderable, firstLine?: number, lineCount?: number): import("./types.js").LineInfo;
    /** @internal Scalar metrics do not copy the document or its line arrays. */
    getTextMetrics(renderable: Renderable): import("./zig.js").NativeSceneTextMetrics;
    /** @internal Accept staging, then read completed geometry without running layout.
     * Native owns callback-time projections and composes accepted ancestor translations. */
    getLayout(node: {
        _getSceneHandle(owner: NativeScene): SceneNodeHandle;
    }, rawYoga?: boolean | "paint"): NativeSceneLayout;
    /** @internal Measure a snapshot using its existing scene root, without preparing a frame. */
    measureSnapshot(root: Renderable): number;
    paint(deltaTime: number, getPaintOptions: PaintOptions): void | Promise<void>;
    private runLifecyclePasses;
    private resumePaint;
    private advancePaint;
    /** Destruction, Session shutdown, or a resize may have cancelled the attempt already; keep the caller's failure. */
    private cancelAttempt;
    /** Run every slot's paint hooks in paint order before native code paints the frame. */
    private recordPaint;
    private createPaintRecording;
    commit(force?: boolean): NativeSessionRenderStatus;
    /** @internal Split output uses the same painted ticket and presentation endpoint. */
    commitSplit(commits: Parameters<NativeSession["renderSplit"]>[1], pinnedRenderOffset: number, force: boolean): ReturnType<NativeSession["renderSplit"]>;
    /** @internal Called after active effects and captures unwind, never during synchronous node destruction. */
    cancelFrame(): void;
    /** @internal Wake a parked turn without revoking active synchronous framebuffer scopes. */
    interruptPaint(): void;
    /** @internal An accepted native resize cancels only a parked attempt, not a synchronous hook scope. */
    restartPaint(): void;
    hitTest(x: number, y: number): number;
    destroy(): void;
}
export {};
