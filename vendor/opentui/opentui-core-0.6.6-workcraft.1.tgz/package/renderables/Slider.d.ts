import { type RenderableOptions, Renderable } from "../Renderable.js";
import { type RenderContext } from "../types.js";
import { type ColorInput, RGBA } from "../lib/RGBA.js";
import { OptimizedBuffer } from "../buffer.js";
export interface SliderOptions extends RenderableOptions<SliderRenderable> {
    orientation: "vertical" | "horizontal";
    value?: number;
    min?: number;
    max?: number;
    viewPortSize?: number;
    backgroundColor?: ColorInput;
    foregroundColor?: ColorInput;
    onChange?: (value: number) => void;
}
export declare class SliderRenderable extends Renderable {
    static readonly nativeIntegration: import("../Renderable.js").NativeRenderableIntegration;
    private _orientation;
    private _value;
    private _min;
    private _max;
    private _viewPortSize;
    private _backgroundColor;
    private _foregroundColor;
    private _onChange?;
    constructor(ctx: RenderContext, options: SliderOptions);
    get orientation(): "vertical" | "horizontal";
    set orientation(value: "vertical" | "horizontal");
    get value(): number;
    set value(newValue: number);
    private publishValue;
    get min(): number;
    set min(newMin: number);
    get max(): number;
    set max(newMax: number);
    set viewPortSize(size: number);
    get viewPortSize(): number;
    private defaultViewPortSize;
    get backgroundColor(): RGBA;
    set backgroundColor(value: ColorInput);
    get foregroundColor(): RGBA;
    set foregroundColor(value: ColorInput);
    private setNativeSceneSlider;
    private calculateDragOffsetVirtual;
    private setupMouseHandling;
    private updateValueFromMouseDirect;
    private updateValueFromMouseWithOffset;
    private getThumbRect;
    protected renderSelf(buffer: OptimizedBuffer): void;
}
