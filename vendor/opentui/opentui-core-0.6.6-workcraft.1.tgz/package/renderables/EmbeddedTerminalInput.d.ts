import type { EmbeddedTerminalKey, EmbeddedTerminalMouse } from "../zig.js";
export type EmbeddedTerminalInputEvent = {
    readonly kind: "key";
    readonly key: Readonly<EmbeddedTerminalKey>;
} | {
    readonly kind: "paste";
    readonly byteLength: number;
} | {
    readonly kind: "mouse";
    readonly mouse: Readonly<EmbeddedTerminalMouse>;
    readonly scrollDirection?: "up" | "down" | "left" | "right";
} | {
    readonly kind: "focus";
    readonly focused: boolean;
};
/** Caller-owned, one-shot encoding against the same live terminal's current modes. */
export type EmbeddedTerminalInputRequest = {
    readonly event: EmbeddedTerminalInputEvent;
    readonly payloadBytes: number;
    resume(send: (bytes: Uint8Array) => void): void;
    cancel(): void;
};
/** Resolve synchronously or retain in a bounded caller queue; automatic replies bypass this hook. */
export type EmbeddedTerminalInputAdmission = (request: EmbeddedTerminalInputRequest) => void;
/** Internal controller separates admission/accounting from the mutable payload's lifetime copy. */
export declare function createEmbeddedTerminalInputRequest(event: EmbeddedTerminalInputEvent, payloadBytes: number, run: (send: (bytes: Uint8Array) => void) => void, retainPayload?: () => void): {
    request: EmbeddedTerminalInputRequest;
    retain(): void;
};
