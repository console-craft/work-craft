import type { NativeScene } from "./NativeScene.js";
import type { Pointer } from "./platform/ffi.js";
import { type RenderLib, type SceneNodeHandle } from "./zig.js";
import { Config, type Dimension, type Value } from "./yoga.js";
export type ValueInput = number | "auto" | `${number}%` | Value | undefined;
export declare const YogaEnumKind: {
    readonly Direction: 0;
    readonly FlexDirection: 1;
    readonly JustifyContent: 2;
    readonly AlignContent: 3;
    readonly AlignItems: 4;
    readonly AlignSelf: 5;
    readonly PositionType: 6;
    readonly FlexWrap: 7;
    readonly Overflow: 8;
    readonly Display: 9;
    readonly BoxSizing: 10;
};
export declare const YogaFloatKind: {
    readonly Flex: 0;
    readonly FlexGrow: 1;
    readonly FlexShrink: 2;
    readonly AspectRatio: 3;
};
export declare const YogaValueKind: {
    readonly Width: 0;
    readonly Height: 1;
    readonly MinWidth: 2;
    readonly MinHeight: 3;
    readonly MaxWidth: 4;
    readonly MaxHeight: 5;
    readonly FlexBasis: 6;
    readonly Margin: 7;
    readonly Padding: 8;
    readonly Position: 9;
    readonly Gap: 10;
};
export type YogaEnumKindId = (typeof YogaEnumKind)[keyof typeof YogaEnumKind];
export type YogaFloatKindId = (typeof YogaFloatKind)[keyof typeof YogaFloatKind];
export type YogaValueKindId = (typeof YogaValueKind)[keyof typeof YogaValueKind];
type SceneStyleNode = {
    _getSceneHandle(owner: NativeScene): SceneNodeHandle;
};
export declare function sceneSetEnum(scene: NativeScene, node: SceneStyleNode, kind: YogaEnumKindId, value: number): void;
export declare function sceneGetEnum(scene: NativeScene, node: SceneStyleNode, kind: YogaEnumKindId): number;
export declare function sceneSetFloat(scene: NativeScene, node: SceneStyleNode, kind: YogaFloatKindId, value: number | undefined): void;
export declare function sceneGetFloat(scene: NativeScene, node: SceneStyleNode, kind: YogaFloatKindId): number;
export declare function sceneSetValue(scene: NativeScene, node: SceneStyleNode, kind: YogaValueKindId, edge: number, valueInput: ValueInput): void;
export declare function sceneGetValue(scene: NativeScene, node: SceneStyleNode, kind: YogaValueKindId, edge: number): Value;
export declare function sceneSetDimension(scene: NativeScene, node: SceneStyleNode, dimension: Dimension, input: ValueInput, disableFlexShrink?: boolean): void;
export declare const UNDEFINED_VALUE: Value;
/** Callback state owned by one loaded RenderLib, never by the process. */
export declare class YogaHost {
    private readonly renderLib;
    readonly configs: Map<Pointer, Config>;
    private readonly pendingScenes;
    private defaultConfig?;
    private callbackDepth;
    private mutationDepth;
    private callbackError?;
    constructor(renderLib: RenderLib);
    getDefaultConfig(): Config;
    assertMutable(): void;
    stageScene(scene: NativeScene): void;
    forgetScene(scene: NativeScene): void;
    flushSceneMutations(): void;
    /** Whether a Yoga callback is executing on this library's owner thread. */
    get inCallback(): boolean;
    invokeCallback(callback: () => unknown): void;
    runMutation<T>(operation: () => T): T;
    throwCallbackError(failure?: {
        value: unknown;
    }): void;
    dispose(): void;
}
export declare function rejectAsyncCallback(value: unknown): void;
export declare function parseYogaValue(value: ValueInput): Value;
export {};
