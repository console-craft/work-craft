var __create = Object.create;
var __getProtoOf = Object.getPrototypeOf;
var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
function __accessProp(key) {
  return this[key];
}
var __toESMCache_node;
var __toESMCache_esm;
var __toESM = (mod, isNodeMode, target) => {
  var canCache = mod != null && typeof mod === "object";
  if (canCache) {
    var cache = isNodeMode ? __toESMCache_node ??= new WeakMap : __toESMCache_esm ??= new WeakMap;
    var cached = cache.get(mod);
    if (cached)
      return cached;
  }
  target = mod != null ? __create(__getProtoOf(mod)) : {};
  const to = isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, "default") ? __defProp(target, "default", { value: mod, enumerable: true }) : target;
  if (mod && typeof mod === "object" || typeof mod === "function") {
    for (let key of __getOwnPropNames(mod))
      if (!__hasOwnProp.call(to, key))
        __defProp(to, key, {
          get: __accessProp.bind(mod, key),
          enumerable: true
        });
  }
  if (canCache)
    cache.set(mod, to);
  return to;
};
var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
var __returnValue = (v) => v;
function __exportSetter(name, newValue) {
  this[name] = __returnValue.bind(null, newValue);
}
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, {
      get: all[name],
      enumerable: true,
      configurable: true,
      set: __exportSetter.bind(all, name)
    });
};

// ../../node_modules/.bun/emoji-regex@10.6.0/node_modules/emoji-regex/index.js
var require_emoji_regex = __commonJS(function(exports, module) {
  module.exports = () => {
    return /[#*0-9]\uFE0F?\u20E3|[\xA9\xAE\u203C\u2049\u2122\u2139\u2194-\u2199\u21A9\u21AA\u231A\u231B\u2328\u23CF\u23ED-\u23EF\u23F1\u23F2\u23F8-\u23FA\u24C2\u25AA\u25AB\u25B6\u25C0\u25FB\u25FC\u25FE\u2600-\u2604\u260E\u2611\u2614\u2615\u2618\u2620\u2622\u2623\u2626\u262A\u262E\u262F\u2638-\u263A\u2640\u2642\u2648-\u2653\u265F\u2660\u2663\u2665\u2666\u2668\u267B\u267E\u267F\u2692\u2694-\u2697\u2699\u269B\u269C\u26A0\u26A7\u26AA\u26B0\u26B1\u26BD\u26BE\u26C4\u26C8\u26CF\u26D1\u26E9\u26F0-\u26F5\u26F7\u26F8\u26FA\u2702\u2708\u2709\u270F\u2712\u2714\u2716\u271D\u2721\u2733\u2734\u2744\u2747\u2757\u2763\u27A1\u2934\u2935\u2B05-\u2B07\u2B1B\u2B1C\u2B55\u3030\u303D\u3297\u3299]\uFE0F?|[\u261D\u270C\u270D](?:\uD83C[\uDFFB-\uDFFF]|\uFE0F)?|[\u270A\u270B](?:\uD83C[\uDFFB-\uDFFF])?|[\u23E9-\u23EC\u23F0\u23F3\u25FD\u2693\u26A1\u26AB\u26C5\u26CE\u26D4\u26EA\u26FD\u2705\u2728\u274C\u274E\u2753-\u2755\u2795-\u2797\u27B0\u27BF\u2B50]|\u26D3\uFE0F?(?:\u200D\uD83D\uDCA5)?|\u26F9(?:\uD83C[\uDFFB-\uDFFF]|\uFE0F)?(?:\u200D[\u2640\u2642]\uFE0F?)?|\u2764\uFE0F?(?:\u200D(?:\uD83D\uDD25|\uD83E\uDE79))?|\uD83C(?:[\uDC04\uDD70\uDD71\uDD7E\uDD7F\uDE02\uDE37\uDF21\uDF24-\uDF2C\uDF36\uDF7D\uDF96\uDF97\uDF99-\uDF9B\uDF9E\uDF9F\uDFCD\uDFCE\uDFD4-\uDFDF\uDFF5\uDFF7]\uFE0F?|[\uDF85\uDFC2\uDFC7](?:\uD83C[\uDFFB-\uDFFF])?|[\uDFC4\uDFCA](?:\uD83C[\uDFFB-\uDFFF])?(?:\u200D[\u2640\u2642]\uFE0F?)?|[\uDFCB\uDFCC](?:\uD83C[\uDFFB-\uDFFF]|\uFE0F)?(?:\u200D[\u2640\u2642]\uFE0F?)?|[\uDCCF\uDD8E\uDD91-\uDD9A\uDE01\uDE1A\uDE2F\uDE32-\uDE36\uDE38-\uDE3A\uDE50\uDE51\uDF00-\uDF20\uDF2D-\uDF35\uDF37-\uDF43\uDF45-\uDF4A\uDF4C-\uDF7C\uDF7E-\uDF84\uDF86-\uDF93\uDFA0-\uDFC1\uDFC5\uDFC6\uDFC8\uDFC9\uDFCF-\uDFD3\uDFE0-\uDFF0\uDFF8-\uDFFF]|\uDDE6\uD83C[\uDDE8-\uDDEC\uDDEE\uDDF1\uDDF2\uDDF4\uDDF6-\uDDFA\uDDFC\uDDFD\uDDFF]|\uDDE7\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEF\uDDF1-\uDDF4\uDDF6-\uDDF9\uDDFB\uDDFC\uDDFE\uDDFF]|\uDDE8\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDEE\uDDF0-\uDDF7\uDDFA-\uDDFF]|\uDDE9\uD83C[\uDDEA\uDDEC\uDDEF\uDDF0\uDDF2\uDDF4\uDDFF]|\uDDEA\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDED\uDDF7-\uDDFA]|\uDDEB\uD83C[\uDDEE-\uDDF0\uDDF2\uDDF4\uDDF7]|\uDDEC\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEE\uDDF1-\uDDF3\uDDF5-\uDDFA\uDDFC\uDDFE]|\uDDED\uD83C[\uDDF0\uDDF2\uDDF3\uDDF7\uDDF9\uDDFA]|\uDDEE\uD83C[\uDDE8-\uDDEA\uDDF1-\uDDF4\uDDF6-\uDDF9]|\uDDEF\uD83C[\uDDEA\uDDF2\uDDF4\uDDF5]|\uDDF0\uD83C[\uDDEA\uDDEC-\uDDEE\uDDF2\uDDF3\uDDF5\uDDF7\uDDFC\uDDFE\uDDFF]|\uDDF1\uD83C[\uDDE6-\uDDE8\uDDEE\uDDF0\uDDF7-\uDDFB\uDDFE]|\uDDF2\uD83C[\uDDE6\uDDE8-\uDDED\uDDF0-\uDDFF]|\uDDF3\uD83C[\uDDE6\uDDE8\uDDEA-\uDDEC\uDDEE\uDDF1\uDDF4\uDDF5\uDDF7\uDDFA\uDDFF]|\uDDF4\uD83C\uDDF2|\uDDF5\uD83C[\uDDE6\uDDEA-\uDDED\uDDF0-\uDDF3\uDDF7-\uDDF9\uDDFC\uDDFE]|\uDDF6\uD83C\uDDE6|\uDDF7\uD83C[\uDDEA\uDDF4\uDDF8\uDDFA\uDDFC]|\uDDF8\uD83C[\uDDE6-\uDDEA\uDDEC-\uDDF4\uDDF7-\uDDF9\uDDFB\uDDFD-\uDDFF]|\uDDF9\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDED\uDDEF-\uDDF4\uDDF7\uDDF9\uDDFB\uDDFC\uDDFF]|\uDDFA\uD83C[\uDDE6\uDDEC\uDDF2\uDDF3\uDDF8\uDDFE\uDDFF]|\uDDFB\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDEE\uDDF3\uDDFA]|\uDDFC\uD83C[\uDDEB\uDDF8]|\uDDFD\uD83C\uDDF0|\uDDFE\uD83C[\uDDEA\uDDF9]|\uDDFF\uD83C[\uDDE6\uDDF2\uDDFC]|\uDF44(?:\u200D\uD83D\uDFEB)?|\uDF4B(?:\u200D\uD83D\uDFE9)?|\uDFC3(?:\uD83C[\uDFFB-\uDFFF])?(?:\u200D(?:[\u2640\u2642]\uFE0F?(?:\u200D\u27A1\uFE0F?)?|\u27A1\uFE0F?))?|\uDFF3\uFE0F?(?:\u200D(?:\u26A7\uFE0F?|\uD83C\uDF08))?|\uDFF4(?:\u200D\u2620\uFE0F?|\uDB40\uDC67\uDB40\uDC62\uDB40(?:\uDC65\uDB40\uDC6E\uDB40\uDC67|\uDC73\uDB40\uDC63\uDB40\uDC74|\uDC77\uDB40\uDC6C\uDB40\uDC73)\uDB40\uDC7F)?)|\uD83D(?:[\uDC3F\uDCFD\uDD49\uDD4A\uDD6F\uDD70\uDD73\uDD76-\uDD79\uDD87\uDD8A-\uDD8D\uDDA5\uDDA8\uDDB1\uDDB2\uDDBC\uDDC2-\uDDC4\uDDD1-\uDDD3\uDDDC-\uDDDE\uDDE1\uDDE3\uDDE8\uDDEF\uDDF3\uDDFA\uDECB\uDECD-\uDECF\uDEE0-\uDEE5\uDEE9\uDEF0\uDEF3]\uFE0F?|[\uDC42\uDC43\uDC46-\uDC50\uDC66\uDC67\uDC6B-\uDC6D\uDC72\uDC74-\uDC76\uDC78\uDC7C\uDC83\uDC85\uDC8F\uDC91\uDCAA\uDD7A\uDD95\uDD96\uDE4C\uDE4F\uDEC0\uDECC](?:\uD83C[\uDFFB-\uDFFF])?|[\uDC6E-\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4\uDEB5](?:\uD83C[\uDFFB-\uDFFF])?(?:\u200D[\u2640\u2642]\uFE0F?)?|[\uDD74\uDD90](?:\uD83C[\uDFFB-\uDFFF]|\uFE0F)?|[\uDC00-\uDC07\uDC09-\uDC14\uDC16-\uDC25\uDC27-\uDC3A\uDC3C-\uDC3E\uDC40\uDC44\uDC45\uDC51-\uDC65\uDC6A\uDC79-\uDC7B\uDC7D-\uDC80\uDC84\uDC88-\uDC8E\uDC90\uDC92-\uDCA9\uDCAB-\uDCFC\uDCFF-\uDD3D\uDD4B-\uDD4E\uDD50-\uDD67\uDDA4\uDDFB-\uDE2D\uDE2F-\uDE34\uDE37-\uDE41\uDE43\uDE44\uDE48-\uDE4A\uDE80-\uDEA2\uDEA4-\uDEB3\uDEB7-\uDEBF\uDEC1-\uDEC5\uDED0-\uDED2\uDED5-\uDED8\uDEDC-\uDEDF\uDEEB\uDEEC\uDEF4-\uDEFC\uDFE0-\uDFEB\uDFF0]|\uDC08(?:\u200D\u2B1B)?|\uDC15(?:\u200D\uD83E\uDDBA)?|\uDC26(?:\u200D(?:\u2B1B|\uD83D\uDD25))?|\uDC3B(?:\u200D\u2744\uFE0F?)?|\uDC41\uFE0F?(?:\u200D\uD83D\uDDE8\uFE0F?)?|\uDC68(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?\uDC68|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDC68\uDC69]\u200D\uD83D(?:\uDC66(?:\u200D\uD83D\uDC66)?|\uDC67(?:\u200D\uD83D[\uDC66\uDC67])?)|[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC66(?:\u200D\uD83D\uDC66)?|\uDC67(?:\u200D\uD83D[\uDC66\uDC67])?)|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]))|\uD83C(?:\uDFFB(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?\uDC68\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC30\u200D\uD83D\uDC68\uD83C[\uDFFC-\uDFFF])|\uD83E(?:[\uDD1D\uDEEF]\u200D\uD83D\uDC68\uD83C[\uDFFC-\uDFFF]|[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3])))?|\uDFFC(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?\uDC68\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC30\u200D\uD83D\uDC68\uD83C[\uDFFB\uDFFD-\uDFFF])|\uD83E(?:[\uDD1D\uDEEF]\u200D\uD83D\uDC68\uD83C[\uDFFB\uDFFD-\uDFFF]|[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3])))?|\uDFFD(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?\uDC68\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC30\u200D\uD83D\uDC68\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF])|\uD83E(?:[\uDD1D\uDEEF]\u200D\uD83D\uDC68\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF]|[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3])))?|\uDFFE(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?\uDC68\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC30\u200D\uD83D\uDC68\uD83C[\uDFFB-\uDFFD\uDFFF])|\uD83E(?:[\uDD1D\uDEEF]\u200D\uD83D\uDC68\uD83C[\uDFFB-\uDFFD\uDFFF]|[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3])))?|\uDFFF(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?\uDC68\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC30\u200D\uD83D\uDC68\uD83C[\uDFFB-\uDFFE])|\uD83E(?:[\uDD1D\uDEEF]\u200D\uD83D\uDC68\uD83C[\uDFFB-\uDFFE]|[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3])))?))?|\uDC69(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?[\uDC68\uDC69]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC66(?:\u200D\uD83D\uDC66)?|\uDC67(?:\u200D\uD83D[\uDC66\uDC67])?|\uDC69\u200D\uD83D(?:\uDC66(?:\u200D\uD83D\uDC66)?|\uDC67(?:\u200D\uD83D[\uDC66\uDC67])?))|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]))|\uD83C(?:\uDFFB(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:[\uDC68\uDC69]|\uDC8B\u200D\uD83D[\uDC68\uDC69])\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC30\u200D\uD83D\uDC69\uD83C[\uDFFC-\uDFFF])|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83D[\uDC68\uDC69]\uD83C[\uDFFC-\uDFFF]|\uDEEF\u200D\uD83D\uDC69\uD83C[\uDFFC-\uDFFF])))?|\uDFFC(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:[\uDC68\uDC69]|\uDC8B\u200D\uD83D[\uDC68\uDC69])\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC30\u200D\uD83D\uDC69\uD83C[\uDFFB\uDFFD-\uDFFF])|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83D[\uDC68\uDC69]\uD83C[\uDFFB\uDFFD-\uDFFF]|\uDEEF\u200D\uD83D\uDC69\uD83C[\uDFFB\uDFFD-\uDFFF])))?|\uDFFD(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:[\uDC68\uDC69]|\uDC8B\u200D\uD83D[\uDC68\uDC69])\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC30\u200D\uD83D\uDC69\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF])|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83D[\uDC68\uDC69]\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF]|\uDEEF\u200D\uD83D\uDC69\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF])))?|\uDFFE(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:[\uDC68\uDC69]|\uDC8B\u200D\uD83D[\uDC68\uDC69])\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC30\u200D\uD83D\uDC69\uD83C[\uDFFB-\uDFFD\uDFFF])|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83D[\uDC68\uDC69]\uD83C[\uDFFB-\uDFFD\uDFFF]|\uDEEF\u200D\uD83D\uDC69\uD83C[\uDFFB-\uDFFD\uDFFF])))?|\uDFFF(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:[\uDC68\uDC69]|\uDC8B\u200D\uD83D[\uDC68\uDC69])\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC30\u200D\uD83D\uDC69\uD83C[\uDFFB-\uDFFE])|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83D[\uDC68\uDC69]\uD83C[\uDFFB-\uDFFE]|\uDEEF\u200D\uD83D\uDC69\uD83C[\uDFFB-\uDFFE])))?))?|\uDD75(?:\uD83C[\uDFFB-\uDFFF]|\uFE0F)?(?:\u200D[\u2640\u2642]\uFE0F?)?|\uDE2E(?:\u200D\uD83D\uDCA8)?|\uDE35(?:\u200D\uD83D\uDCAB)?|\uDE36(?:\u200D\uD83C\uDF2B\uFE0F?)?|\uDE42(?:\u200D[\u2194\u2195]\uFE0F?)?|\uDEB6(?:\uD83C[\uDFFB-\uDFFF])?(?:\u200D(?:[\u2640\u2642]\uFE0F?(?:\u200D\u27A1\uFE0F?)?|\u27A1\uFE0F?))?)|\uD83E(?:[\uDD0C\uDD0F\uDD18-\uDD1F\uDD30-\uDD34\uDD36\uDD77\uDDB5\uDDB6\uDDBB\uDDD2\uDDD3\uDDD5\uDEC3-\uDEC5\uDEF0\uDEF2-\uDEF8](?:\uD83C[\uDFFB-\uDFFF])?|[\uDD26\uDD35\uDD37-\uDD39\uDD3C-\uDD3E\uDDB8\uDDB9\uDDCD\uDDCF\uDDD4\uDDD6-\uDDDD](?:\uD83C[\uDFFB-\uDFFF])?(?:\u200D[\u2640\u2642]\uFE0F?)?|[\uDDDE\uDDDF](?:\u200D[\u2640\u2642]\uFE0F?)?|[\uDD0D\uDD0E\uDD10-\uDD17\uDD20-\uDD25\uDD27-\uDD2F\uDD3A\uDD3F-\uDD45\uDD47-\uDD76\uDD78-\uDDB4\uDDB7\uDDBA\uDDBC-\uDDCC\uDDD0\uDDE0-\uDDFF\uDE70-\uDE7C\uDE80-\uDE8A\uDE8E-\uDEC2\uDEC6\uDEC8\uDECD-\uDEDC\uDEDF-\uDEEA\uDEEF]|\uDDCE(?:\uD83C[\uDFFB-\uDFFF])?(?:\u200D(?:[\u2640\u2642]\uFE0F?(?:\u200D\u27A1\uFE0F?)?|\u27A1\uFE0F?))?|\uDDD1(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3\uDE70]|\uDD1D\u200D\uD83E\uDDD1|\uDDD1\u200D\uD83E\uDDD2(?:\u200D\uD83E\uDDD2)?|\uDDD2(?:\u200D\uD83E\uDDD2)?))|\uD83C(?:\uDFFB(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1\uD83C[\uDFFC-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC30\u200D\uD83E\uDDD1\uD83C[\uDFFC-\uDFFF])|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3\uDE70]|\uDD1D\u200D\uD83E\uDDD1\uD83C[\uDFFB-\uDFFF]|\uDEEF\u200D\uD83E\uDDD1\uD83C[\uDFFC-\uDFFF])))?|\uDFFC(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1\uD83C[\uDFFB\uDFFD-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC30\u200D\uD83E\uDDD1\uD83C[\uDFFB\uDFFD-\uDFFF])|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3\uDE70]|\uDD1D\u200D\uD83E\uDDD1\uD83C[\uDFFB-\uDFFF]|\uDEEF\u200D\uD83E\uDDD1\uD83C[\uDFFB\uDFFD-\uDFFF])))?|\uDFFD(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC30\u200D\uD83E\uDDD1\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF])|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3\uDE70]|\uDD1D\u200D\uD83E\uDDD1\uD83C[\uDFFB-\uDFFF]|\uDEEF\u200D\uD83E\uDDD1\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF])))?|\uDFFE(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1\uD83C[\uDFFB-\uDFFD\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC30\u200D\uD83E\uDDD1\uD83C[\uDFFB-\uDFFD\uDFFF])|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3\uDE70]|\uDD1D\u200D\uD83E\uDDD1\uD83C[\uDFFB-\uDFFF]|\uDEEF\u200D\uD83E\uDDD1\uD83C[\uDFFB-\uDFFD\uDFFF])))?|\uDFFF(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1\uD83C[\uDFFB-\uDFFE]|\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC30\u200D\uD83E\uDDD1\uD83C[\uDFFB-\uDFFE])|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3\uDE70]|\uDD1D\u200D\uD83E\uDDD1\uD83C[\uDFFB-\uDFFF]|\uDEEF\u200D\uD83E\uDDD1\uD83C[\uDFFB-\uDFFE])))?))?|\uDEF1(?:\uD83C(?:\uDFFB(?:\u200D\uD83E\uDEF2\uD83C[\uDFFC-\uDFFF])?|\uDFFC(?:\u200D\uD83E\uDEF2\uD83C[\uDFFB\uDFFD-\uDFFF])?|\uDFFD(?:\u200D\uD83E\uDEF2\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF])?|\uDFFE(?:\u200D\uD83E\uDEF2\uD83C[\uDFFB-\uDFFD\uDFFF])?|\uDFFF(?:\u200D\uD83E\uDEF2\uD83C[\uDFFB-\uDFFE])?))?)/g;
  };
});

// src/yoga.ts
var exports_yoga = {};
__export(exports_yoga, {
  ALIGN_AUTO: () => ALIGN_AUTO2,
  ALIGN_BASELINE: () => ALIGN_BASELINE2,
  ALIGN_CENTER: () => ALIGN_CENTER2,
  ALIGN_FLEX_END: () => ALIGN_FLEX_END2,
  ALIGN_FLEX_START: () => ALIGN_FLEX_START2,
  ALIGN_SPACE_AROUND: () => ALIGN_SPACE_AROUND2,
  ALIGN_SPACE_BETWEEN: () => ALIGN_SPACE_BETWEEN2,
  ALIGN_SPACE_EVENLY: () => ALIGN_SPACE_EVENLY2,
  ALIGN_STRETCH: () => ALIGN_STRETCH2,
  Align: () => Align2,
  BOX_SIZING_BORDER_BOX: () => BOX_SIZING_BORDER_BOX2,
  BOX_SIZING_CONTENT_BOX: () => BOX_SIZING_CONTENT_BOX2,
  BoxSizing: () => BoxSizing2,
  Config: () => Config2,
  DIMENSION_HEIGHT: () => DIMENSION_HEIGHT2,
  DIMENSION_WIDTH: () => DIMENSION_WIDTH2,
  DIRECTION_INHERIT: () => DIRECTION_INHERIT2,
  DIRECTION_LTR: () => DIRECTION_LTR2,
  DIRECTION_RTL: () => DIRECTION_RTL2,
  DISPLAY_CONTENTS: () => DISPLAY_CONTENTS2,
  DISPLAY_FLEX: () => DISPLAY_FLEX2,
  DISPLAY_NONE: () => DISPLAY_NONE2,
  Dimension: () => Dimension2,
  Direction: () => Direction2,
  Display: () => Display2,
  EDGE_ALL: () => EDGE_ALL2,
  EDGE_BOTTOM: () => EDGE_BOTTOM2,
  EDGE_END: () => EDGE_END2,
  EDGE_HORIZONTAL: () => EDGE_HORIZONTAL2,
  EDGE_LEFT: () => EDGE_LEFT2,
  EDGE_RIGHT: () => EDGE_RIGHT2,
  EDGE_START: () => EDGE_START2,
  EDGE_TOP: () => EDGE_TOP2,
  EDGE_VERTICAL: () => EDGE_VERTICAL2,
  ERRATA_ABSOLUTE_PERCENT_AGAINST_INNER_SIZE: () => ERRATA_ABSOLUTE_PERCENT_AGAINST_INNER_SIZE2,
  ERRATA_ABSOLUTE_POSITION_WITHOUT_INSETS_EXCLUDES_PADDING: () => ERRATA_ABSOLUTE_POSITION_WITHOUT_INSETS_EXCLUDES_PADDING2,
  ERRATA_ALL: () => ERRATA_ALL2,
  ERRATA_CLASSIC: () => ERRATA_CLASSIC2,
  ERRATA_NONE: () => ERRATA_NONE2,
  ERRATA_STRETCH_FLEX_BASIS: () => ERRATA_STRETCH_FLEX_BASIS2,
  EXPERIMENTAL_FEATURE_WEB_FLEX_BASIS: () => EXPERIMENTAL_FEATURE_WEB_FLEX_BASIS2,
  Edge: () => Edge2,
  Errata: () => Errata2,
  ExperimentalFeature: () => ExperimentalFeature2,
  FLEX_DIRECTION_COLUMN: () => FLEX_DIRECTION_COLUMN2,
  FLEX_DIRECTION_COLUMN_REVERSE: () => FLEX_DIRECTION_COLUMN_REVERSE2,
  FLEX_DIRECTION_ROW: () => FLEX_DIRECTION_ROW2,
  FLEX_DIRECTION_ROW_REVERSE: () => FLEX_DIRECTION_ROW_REVERSE2,
  FlexDirection: () => FlexDirection2,
  GUTTER_ALL: () => GUTTER_ALL2,
  GUTTER_COLUMN: () => GUTTER_COLUMN2,
  GUTTER_ROW: () => GUTTER_ROW2,
  Gutter: () => Gutter2,
  JUSTIFY_CENTER: () => JUSTIFY_CENTER2,
  JUSTIFY_FLEX_END: () => JUSTIFY_FLEX_END2,
  JUSTIFY_FLEX_START: () => JUSTIFY_FLEX_START2,
  JUSTIFY_SPACE_AROUND: () => JUSTIFY_SPACE_AROUND2,
  JUSTIFY_SPACE_BETWEEN: () => JUSTIFY_SPACE_BETWEEN2,
  JUSTIFY_SPACE_EVENLY: () => JUSTIFY_SPACE_EVENLY2,
  Justify: () => Justify2,
  LOG_LEVEL_DEBUG: () => LOG_LEVEL_DEBUG2,
  LOG_LEVEL_ERROR: () => LOG_LEVEL_ERROR2,
  LOG_LEVEL_FATAL: () => LOG_LEVEL_FATAL2,
  LOG_LEVEL_INFO: () => LOG_LEVEL_INFO2,
  LOG_LEVEL_VERBOSE: () => LOG_LEVEL_VERBOSE2,
  LOG_LEVEL_WARN: () => LOG_LEVEL_WARN2,
  LogLevel: () => LogLevel3,
  MEASURE_MODE_AT_MOST: () => MEASURE_MODE_AT_MOST2,
  MEASURE_MODE_EXACTLY: () => MEASURE_MODE_EXACTLY2,
  MEASURE_MODE_UNDEFINED: () => MEASURE_MODE_UNDEFINED2,
  MeasureMode: () => MeasureMode2,
  NODE_TYPE_DEFAULT: () => NODE_TYPE_DEFAULT2,
  NODE_TYPE_TEXT: () => NODE_TYPE_TEXT2,
  Node: () => Node2,
  NodeType: () => NodeType2,
  OVERFLOW_HIDDEN: () => OVERFLOW_HIDDEN2,
  OVERFLOW_SCROLL: () => OVERFLOW_SCROLL2,
  OVERFLOW_VISIBLE: () => OVERFLOW_VISIBLE2,
  Overflow: () => Overflow2,
  POSITION_TYPE_ABSOLUTE: () => POSITION_TYPE_ABSOLUTE2,
  POSITION_TYPE_RELATIVE: () => POSITION_TYPE_RELATIVE2,
  POSITION_TYPE_STATIC: () => POSITION_TYPE_STATIC2,
  PositionType: () => PositionType2,
  UNIT_AUTO: () => UNIT_AUTO2,
  UNIT_PERCENT: () => UNIT_PERCENT2,
  UNIT_POINT: () => UNIT_POINT2,
  UNIT_UNDEFINED: () => UNIT_UNDEFINED2,
  Unit: () => Unit2,
  WRAP_NO_WRAP: () => WRAP_NO_WRAP2,
  WRAP_WRAP: () => WRAP_WRAP2,
  WRAP_WRAP_REVERSE: () => WRAP_WRAP_REVERSE2,
  Wrap: () => Wrap2,
  YogaError: () => YogaError2,
  YogaStatus: () => YogaStatus2,
  default: () => yoga_default
});

// src/native-abi.generated.ts
var nativeSymbols = {
  ot_scene_set_hooks: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_scene_frame_step_with_geometry: {
    args: ["ptr", "buffer", "ptr", "buffer", "u32", "ptr", "u32", "buffer", "buffer"],
    returns: "i32"
  },
  ot_scene_frame_get_paint_slots: { args: ["ptr", "buffer", "buffer", "buffer", "u32", "buffer"], returns: "i32" },
  ot_scene_frame_cancel: { args: ["ptr", "buffer", "u64"], returns: "i32" },
  ot_scene_create_node: { args: ["ptr", "buffer", "u32", "u32", "buffer"], returns: "i32" },
  ot_scene_destroy_node: { args: ["ptr", "buffer"], returns: "i32" },
  ot_scene_move_node: { args: ["ptr", "buffer", "ptr", "u32"], returns: "i32" },
  ot_scene_set_measure: { args: ["ptr", "buffer", "ptr"], returns: "i32" },
  ot_scene_has_measure: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_scene_mark_dirty: { args: ["ptr", "buffer"], returns: "i32" },
  ot_scene_set_style: { args: ["ptr", "buffer", "u32", "u32", "u32", "u32", "f32", "u32"], returns: "i32" },
  ot_scene_get_style: { args: ["ptr", "buffer", "u32", "u32", "u32", "buffer"], returns: "i32" },
  ot_scene_set_paint: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_scene_flush: { args: ["ptr", "ptr", "u32", "buffer"], returns: "i32" },
  ot_scene_set_surface: { args: ["ptr", "buffer", "ptr"], returns: "i32" },
  ot_scene_set_box_details: { args: ["ptr", "buffer", "buffer", "ptr", "u32", "ptr", "u32"], returns: "i32" },
  ot_scene_set_viewport: { args: ["ptr", "buffer", "ptr"], returns: "i32" },
  ot_scene_set_focus: { args: ["ptr", "buffer", "u32"], returns: "i32" },
  ot_scene_set_slider: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_scene_set_arrow: { args: ["ptr", "buffer", "buffer", "ptr", "u32"], returns: "i32" },
  ot_scene_get_slider_thumb: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_scene_set_text: { args: ["ptr", "buffer", "ptr", "u32"], returns: "i32" },
  ot_scene_set_styled_text: { args: ["ptr", "buffer", "ptr", "u32", "ptr", "u32", "ptr", "u32"], returns: "i32" },
  ot_scene_set_text_options: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_scene_set_text_selection: { args: ["ptr", "buffer", "buffer", "buffer"], returns: "i32" },
  ot_scene_get_text_selection: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_scene_get_selected_text: { args: ["ptr", "buffer", "ptr", "u32", "buffer"], returns: "i32" },
  ot_scene_get_text: { args: ["ptr", "buffer", "ptr", "u32", "buffer"], returns: "i32" },
  ot_scene_get_text_info: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_scene_get_text_lines: { args: ["ptr", "buffer", "u32", "ptr", "u32", "buffer"], returns: "i32" },
  ot_scene_get_layout: { args: ["ptr", "buffer", "u32", "buffer"], returns: "i32" },
  ot_scene_paint: { args: ["ptr", "buffer", "buffer", "u32", "u32", "buffer"], returns: "i32" },
  ot_scene_hit_test: { args: ["ptr", "buffer", "i32", "i32", "buffer"], returns: "i32" },
  ot_scene_get_stats: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_scene_get_cursor_state: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_scene_frame_copy_buffer: { args: ["ptr", "buffer", "buffer", "buffer"], returns: "i32" },
  ot_scene_measure_layout: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_session_render_split: { args: ["ptr", "buffer", "ptr", "ptr", "u32", "u32", "u32", "buffer"], returns: "i32" },
  ot_session_split_control: { args: ["ptr", "buffer", "buffer", "buffer"], returns: "i32" },
  ot_session_set_screen: { args: ["ptr", "buffer", "u32", "u32", "u32", "buffer", "u32"], returns: "i32" },
  ot_session_sync_detached: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_unicode_create: { args: ["ptr", "ptr", "u32", "u32", "buffer"], returns: "i32" },
  ot_unicode_destroy: { args: ["ptr", "buffer"], returns: "i32" },
  ot_unicode_get: { args: ["ptr", "buffer", "ptr", "u32", "buffer"], returns: "i32" },
  ot_buffer_draw_unicode: {
    args: ["ptr", "buffer", "ptr", "buffer", "u32", "i32", "i32", "buffer", "buffer", "u32"],
    returns: "i32"
  },
  ot_embedded_terminal_create: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_embedded_terminal_destroy: { args: ["ptr", "buffer"], returns: "i32" },
  ot_embedded_terminal_write: { args: ["ptr", "buffer", "ptr", "u32"], returns: "i32" },
  ot_embedded_terminal_resize: { args: ["ptr", "buffer", "u32", "u32"], returns: "i32" },
  ot_embedded_terminal_command: { args: ["ptr", "buffer", "u32", "i32"], returns: "i32" },
  ot_embedded_terminal_set_selection: { args: ["ptr", "buffer", "u32", "u32", "u32", "u32"], returns: "i32" },
  ot_embedded_terminal_get_selected_text: { args: ["ptr", "buffer", "ptr", "u32", "buffer"], returns: "i32" },
  ot_embedded_terminal_compose: { args: ["ptr", "buffer", "buffer", "ptr", "i32", "i32"], returns: "i32" },
  ot_embedded_terminal_cursor_get: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_embedded_terminal_encode_key: {
    args: ["ptr", "buffer", "buffer", "ptr", "u32", "ptr", "u32", "ptr", "u32", "buffer"],
    returns: "i32"
  },
  ot_embedded_terminal_encode_mouse: { args: ["ptr", "buffer", "buffer", "buffer", "u32", "buffer"], returns: "i32" },
  ot_embedded_terminal_encode_paste: { args: ["ptr", "buffer", "ptr", "u32", "ptr", "u32", "buffer"], returns: "i32" },
  ot_embedded_terminal_encode_focus: { args: ["ptr", "buffer", "u32", "ptr", "u32", "buffer"], returns: "i32" },
  ot_embedded_terminal_drain_responses: { args: ["ptr", "buffer", "buffer", "u32", "buffer"], returns: "i32" },
  ot_edit_buffer_create: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_edit_buffer_destroy: { args: ["ptr", "buffer"], returns: "i32" },
  ot_editor_view_create: { args: ["ptr", "buffer", "u32", "u32", "buffer"], returns: "i32" },
  ot_editor_view_destroy: { args: ["ptr", "buffer"], returns: "i32" },
  ot_syntax_style_create: { args: ["ptr", "buffer"], returns: "i32" },
  ot_syntax_style_destroy: { args: ["ptr", "buffer"], returns: "i32" },
  ot_edit_buffer_set_syntax_style: { args: ["ptr", "buffer", "ptr"], returns: "i32" },
  ot_edit_buffer_set_text: { args: ["ptr", "buffer", "ptr", "u32", "u32"], returns: "i32" },
  ot_edit_buffer_insert_text: { args: ["ptr", "buffer", "ptr", "u32"], returns: "i32" },
  ot_edit_buffer_delete_range: { args: ["ptr", "buffer", "u32", "u32", "u32", "u32"], returns: "i32" },
  ot_edit_buffer_set_cursor: { args: ["ptr", "buffer", "u32", "u32"], returns: "i32" },
  ot_edit_buffer_get_text: { args: ["ptr", "buffer", "ptr", "u32", "buffer"], returns: "i32" },
  ot_edit_buffer_get_info: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_edit_buffer_set_tab_width: { args: ["ptr", "buffer", "u32"], returns: "i32" },
  ot_edit_buffer_command: { args: ["ptr", "buffer", "u32", "u32"], returns: "i32" },
  ot_edit_buffer_history: { args: ["ptr", "buffer", "u32", "buffer", "u32", "buffer"], returns: "i32" },
  ot_edit_buffer_get_position: { args: ["ptr", "buffer", "u32", "u32", "u32", "buffer"], returns: "i32" },
  ot_edit_buffer_get_range: {
    args: ["ptr", "buffer", "u32", "u32", "u32", "u32", "u32", "ptr", "u32", "buffer"],
    returns: "i32"
  },
  ot_edit_buffer_measure_text: { args: ["ptr", "buffer", "ptr", "u32", "buffer"], returns: "i32" },
  ot_edit_measure_text: { args: ["ptr", "ptr", "u32", "u32", "u32", "buffer"], returns: "i32" },
  ot_edit_buffer_set_defaults: { args: ["ptr", "buffer", "u32", "buffer"], returns: "i32" },
  ot_syntax_style_register: { args: ["ptr", "buffer", "ptr", "u32", "buffer", "buffer"], returns: "i32" },
  ot_syntax_style_resolve: { args: ["ptr", "buffer", "ptr", "u32", "buffer"], returns: "i32" },
  ot_syntax_style_get_count: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_edit_buffer_highlight: { args: ["ptr", "buffer", "u32", "u32", "ptr"], returns: "i32" },
  ot_edit_buffer_get_highlights: { args: ["ptr", "buffer", "u32", "ptr", "u32", "buffer"], returns: "i32" },
  ot_editor_view_set_viewport: { args: ["ptr", "buffer", "buffer", "u32", "u32"], returns: "i32" },
  ot_editor_view_get_viewport: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_editor_view_set_scroll_margin: { args: ["ptr", "buffer", "f32"], returns: "i32" },
  ot_editor_view_command: { args: ["ptr", "buffer", "u32", "u32"], returns: "i32" },
  ot_editor_view_replace_selection: { args: ["ptr", "buffer", "ptr", "u32", "buffer"], returns: "i32" },
  ot_editor_view_set_tab_color: { args: ["ptr", "buffer", "ptr"], returns: "i32" },
  ot_editor_view_select: { args: ["ptr", "buffer", "buffer", "buffer"], returns: "i32" },
  ot_editor_view_get_info: { args: ["ptr", "buffer", "u32", "buffer"], returns: "i32" },
  ot_editor_view_get_selection: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_editor_view_get_selected_text: { args: ["ptr", "buffer", "ptr", "u32", "buffer"], returns: "i32" },
  ot_editor_view_get_position: { args: ["ptr", "buffer", "u32", "buffer"], returns: "i32" },
  ot_editor_view_get_lines: { args: ["ptr", "buffer", "u32", "ptr", "u32", "buffer"], returns: "i32" },
  ot_editor_view_measure: { args: ["ptr", "buffer", "u32", "u32", "buffer"], returns: "i32" },
  ot_editor_view_set_placeholder: { args: ["ptr", "buffer", "ptr", "u32", "ptr", "u32"], returns: "i32" },
  ot_context_set_edit_event_callback: { args: ["ptr", "ptr"], returns: "i32" },
  ot_scene_set_editor_view: { args: ["ptr", "buffer", "ptr"], returns: "i32" },
  ot_scene_set_editor_options: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_image_destroy: { args: ["ptr", "buffer"], returns: "i32" },
  ot_image_inspect: { args: ["ptr", "buffer", "u64", "buffer"], returns: "i32" },
  ot_image_decode: { args: ["ptr", "buffer", "u64", "buffer"], returns: "i32" },
  ot_image_create_pixels: {
    args: ["ptr", "buffer", "u64", "u32", "u32", "u32", "u32", "u32", "buffer"],
    returns: "i32"
  },
  ot_image_update_pixels: { args: ["ptr", "buffer", "buffer", "u64", "u32", "u32", "u32"], returns: "i32" },
  ot_image_clone: { args: ["ptr", "ptr", "buffer", "buffer"], returns: "i32" },
  ot_image_retain: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_image_get_info: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_image_resize: { args: ["ptr", "buffer", "u32", "u32", "u32", "buffer"], returns: "i32" },
  ot_image_extract: { args: ["ptr", "buffer", "u32", "u32", "u32", "u32", "buffer"], returns: "i32" },
  ot_image_extend: { args: ["ptr", "buffer", "u32", "u32", "u32", "u32", "buffer", "buffer"], returns: "i32" },
  ot_image_transform: { args: ["ptr", "buffer", "u32", "buffer"], returns: "i32" },
  ot_image_composite: { args: ["ptr", "buffer", "buffer", "i32", "i32", "u32", "u8", "buffer"], returns: "i32" },
  ot_image_copy_pixels: { args: ["ptr", "buffer", "buffer", "u64", "u32", "u32"], returns: "i32" },
  ot_image_copy_png: { args: ["ptr", "buffer", "buffer", "u64", "buffer"], returns: "i32" },
  ot_image_take_pixels: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_image_pixels_release: { args: ["ptr", "buffer"], returns: "i32" },
  ot_scene_set_image: { args: ["ptr", "buffer", "ptr", "u32", "u32", "ptr"], returns: "i32" },
  ot_buffer_draw_image: { args: ["ptr", "buffer", "ptr", "buffer", "buffer", "buffer"], returns: "i32" },
  ot_session_set_image_resolution: { args: ["ptr", "buffer", "u32", "u32", "u32", "u32"], returns: "i32" },
  ot_session_set_kitty_image_transport: { args: ["ptr", "buffer", "u32"], returns: "i32" },
  ot_session_get_kitty_image_transport: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_session_poll_kitty_image_transport: { args: ["ptr", "buffer", "u64", "buffer"], returns: "i32" },
  ot_session_cancel_kitty_image_transport: { args: ["ptr", "buffer", "u32"], returns: "i32" },
  ot_session_process_kitty_image_reply: { args: ["ptr", "buffer", "ptr", "u32", "buffer"], returns: "i32" },
  ot_session_start_kitty_file_probe: { args: ["ptr", "buffer"], returns: "i32" },
  ot_text_buffer_create: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_text_buffer_destroy: { args: ["ptr", "buffer"], returns: "i32" },
  ot_text_buffer_view_create: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_text_buffer_view_destroy: { args: ["ptr", "buffer"], returns: "i32" },
  ot_text_buffer_set_text: { args: ["ptr", "buffer", "ptr", "u32"], returns: "i32" },
  ot_text_buffer_append: { args: ["ptr", "buffer", "ptr", "u32"], returns: "i32" },
  ot_text_buffer_clear: { args: ["ptr", "buffer", "u32"], returns: "i32" },
  ot_text_buffer_set_styled_text: { args: ["ptr", "buffer", "ptr", "u32", "ptr", "u32", "ptr", "u32"], returns: "i32" },
  ot_text_buffer_replace_styled_batch: {
    args: ["ptr", "buffer", "u32", "buffer", "u32", "buffer", "u32", "buffer", "u32", "buffer"],
    returns: "i32"
  },
  ot_text_buffer_set_syntax_style: { args: ["ptr", "buffer", "ptr"], returns: "i32" },
  ot_text_buffer_get_info: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_text_buffer_get_text: { args: ["ptr", "buffer", "ptr", "u32", "buffer"], returns: "i32" },
  ot_text_buffer_get_range: { args: ["ptr", "buffer", "u32", "u32", "ptr", "u32", "buffer"], returns: "i32" },
  ot_text_buffer_set_defaults: { args: ["ptr", "buffer", "u32", "buffer"], returns: "i32" },
  ot_text_buffer_set_tab_width: { args: ["ptr", "buffer", "u32"], returns: "i32" },
  ot_text_buffer_highlight: { args: ["ptr", "buffer", "u32", "u32", "ptr"], returns: "i32" },
  ot_text_buffer_get_highlights: { args: ["ptr", "buffer", "u32", "ptr", "u32", "buffer"], returns: "i32" },
  ot_text_buffer_view_set_viewport: { args: ["ptr", "buffer", "buffer", "u32"], returns: "i32" },
  ot_text_buffer_view_command: { args: ["ptr", "buffer", "u32", "u32"], returns: "i32" },
  ot_text_buffer_view_set_tab_color: { args: ["ptr", "buffer", "ptr"], returns: "i32" },
  ot_text_buffer_view_select: { args: ["ptr", "buffer", "buffer", "buffer"], returns: "i32" },
  ot_text_buffer_view_get_info: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_text_buffer_view_get_selected_text: { args: ["ptr", "buffer", "ptr", "u32", "buffer"], returns: "i32" },
  ot_text_buffer_view_get_lines: { args: ["ptr", "buffer", "u32", "u32", "ptr", "u32", "buffer"], returns: "i32" },
  ot_text_buffer_view_measure: { args: ["ptr", "buffer", "u32", "u32", "buffer"], returns: "i32" },
  ot_scene_set_text_view: { args: ["ptr", "buffer", "ptr"], returns: "i32" },
  ot_scene_set_text_view_paint: { args: ["ptr", "buffer", "u32"], returns: "i32" },
  ot_buffer_draw_text_view: { args: ["ptr", "buffer", "ptr", "buffer", "i32", "i32"], returns: "i32" },
  ot_buffer_draw_editor_view: { args: ["ptr", "buffer", "ptr", "buffer", "i32", "i32"], returns: "i32" },
  ot_buffer_draw_scene_text: { args: ["ptr", "buffer", "ptr", "buffer", "i32", "i32"], returns: "i32" },
  ot_scene_frame_acquire_buffer_lease: { args: ["ptr", "buffer", "buffer", "u32", "buffer"], returns: "i32" },
  ot_scene_frame_commit: { args: ["ptr", "buffer", "buffer", "u32", "buffer"], returns: "i32" },
  ot_context_abi_version: { args: [], returns: "u32" },
  ot_context_create: { args: ["buffer", "buffer"], returns: "i32" },
  ot_context_destroy: { args: ["ptr"], returns: "i32" },
  ot_context_get_last_error: { args: ["ptr", "buffer"], returns: "i32" },
  ot_context_drain_diagnostics: { args: ["ptr", "ptr", "u32", "buffer"], returns: "i32" },
  ot_context_get_link_url: { args: ["ptr", "u32", "buffer", "u32", "buffer"], returns: "i32" },
  ot_buffer_create: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_buffer_destroy: { args: ["ptr", "buffer"], returns: "i32" },
  ot_buffer_resize: { args: ["ptr", "buffer", "u32", "u32"], returns: "i32" },
  ot_buffer_draw: { args: ["ptr", "buffer", "ptr", "buffer", "ptr", "buffer", "u32", "buffer", "u32"], returns: "i32" },
  ot_buffer_stack: {
    args: ["ptr", "buffer", "ptr", "u32", "i32", "i32", "u32", "u32", "buffer", "buffer"],
    returns: "i32"
  },
  ot_buffer_draw_grid: { args: ["ptr", "buffer", "ptr", "buffer", "buffer", "u32", "buffer", "u32"], returns: "i32" },
  ot_buffer_draw_packed: { args: ["ptr", "buffer", "ptr", "ptr", "u32", "i32", "i32", "u32", "u32"], returns: "i32" },
  ot_buffer_draw_supersample: {
    args: ["ptr", "buffer", "ptr", "ptr", "u32", "i32", "i32", "u32", "u32"],
    returns: "i32"
  },
  ot_buffer_draw_grayscale: {
    args: ["ptr", "buffer", "ptr", "buffer", "u32", "i32", "i32", "u32", "u32", "ptr", "ptr", "u32"],
    returns: "i32"
  },
  ot_buffer_color_matrix: {
    args: ["ptr", "buffer", "ptr", "buffer", "u32", "ptr", "u32", "buffer", "u32"],
    returns: "i32"
  },
  ot_buffer_acquire_lease: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_session_create: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_session_attach_renderer: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_session_attach_renderer_with_env: { args: ["ptr", "buffer", "buffer", "buffer"], returns: "i32" },
  ot_session_render: { args: ["ptr", "buffer", "u32", "buffer"], returns: "i32" },
  ot_session_resize_renderer: { args: ["ptr", "buffer", "u32", "u32"], returns: "i32" },
  ot_session_draw_buffer: { args: ["ptr", "buffer", "buffer", "i32", "i32"], returns: "i32" },
  ot_scene_frame_draw_buffer: { args: ["ptr", "buffer", "buffer", "buffer", "i32", "i32"], returns: "i32" },
  ot_session_set_debug_overlay: { args: ["ptr", "buffer", "u32", "u32"], returns: "i32" },
  ot_session_update_stats: { args: ["ptr", "buffer", "f64", "u32", "f64"], returns: "i32" },
  ot_session_update_memory_stats: { args: ["ptr", "buffer", "u32", "u32", "u32"], returns: "i32" },
  ot_session_dump_hit_grid: { args: ["ptr", "buffer"], returns: "i32" },
  ot_session_get_renderer_state: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_session_acquire_buffer_lease: { args: ["ptr", "buffer", "u32", "buffer"], returns: "i32" },
  ot_session_get_link_id: { args: ["ptr", "buffer", "i32", "i32", "buffer"], returns: "i32" },
  ot_buffer_lease_validate: { args: ["ptr", "buffer"], returns: "i32" },
  ot_buffer_lease_release: { args: ["ptr", "buffer"], returns: "i32" },
  ot_buffer_lease_get_real_char_size: { args: ["ptr", "buffer", "u32", "buffer"], returns: "i32" },
  ot_buffer_lease_write_resolved_chars: {
    args: ["ptr", "buffer", "ptr", "u32", "u32", "ptr", "u32", "buffer"],
    returns: "i32"
  },
  ot_session_setup_terminal: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_session_suspend: { args: ["ptr", "buffer"], returns: "i32" },
  ot_session_resume: { args: ["ptr", "buffer"], returns: "i32" },
  ot_session_get_terminal_state: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_session_control: { args: ["ptr", "buffer", "buffer", "ptr", "u32"], returns: "i32" },
  ot_session_get_capabilities: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_session_clipboard: { args: ["ptr", "buffer", "u32", "buffer", "u32", "buffer"], returns: "i32" },
  ot_session_set_palette_state: { args: ["ptr", "buffer", "buffer", "u32", "buffer", "buffer", "u32"], returns: "i32" },
  ot_session_notification: { args: ["ptr", "buffer", "buffer", "u32", "ptr", "u32", "buffer"], returns: "i32" },
  ot_session_pump: { args: ["ptr", "buffer", "u64", "u32", "buffer"], returns: "i32" },
  ot_session_get_write_limit: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_session_write: { args: ["ptr", "buffer", "ptr", "u32"], returns: "i32" },
  ot_session_read_output: { args: ["ptr", "buffer", "ptr", "u32", "buffer"], returns: "i32" },
  ot_session_drain_output: { args: ["ptr", "buffer", "u32", "buffer", "ptr", "ptr"], returns: "i32" },
  ot_session_drain_stdout: { args: ["ptr", "buffer", "u32", "buffer"], returns: "i32" },
  ot_session_complete_output: { args: ["ptr", "buffer", "buffer", "u32"], returns: "i32" },
  ot_session_close: { args: ["ptr", "buffer"], returns: "i32" },
  ot_session_pump_exit: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_terminal_flush_input: { args: [], returns: "i32" },
  ot_session_cancel: { args: ["ptr", "buffer"], returns: "i32" },
  ot_session_get_state: { args: ["ptr", "buffer", "buffer"], returns: "i32" },
  ot_session_destroy: { args: ["ptr", "buffer"], returns: "i32" },
  ot_clipboard_service_create: { args: ["ptr", "u32", "u32", "ptr", "u32"], returns: "i32" },
  ot_clipboard_service_begin_shutdown: { args: ["ptr"], returns: "u8" },
  ot_clipboard_service_poll_shutdown: { args: ["ptr"], returns: "u8" },
  ot_clipboard_service_destroy: { args: ["ptr"], returns: "u8" },
  ot_clipboard_service_drain: { args: ["ptr"], returns: "u8" },
  ot_clipboard_read_operation_start: {
    args: ["ptr", "buffer", "u32", "u8", "u32", "u32", "u32", "u32", "buffer"],
    returns: "u8"
  },
  ot_clipboard_write_operation_start: { args: ["ptr", "buffer", "u32", "u8", "u32", "buffer"], returns: "u8" },
  ot_clipboard_clear_operation_start: { args: ["ptr", "u8", "u32", "buffer"], returns: "u8" },
  ot_clipboard_operation_poll: { args: ["ptr", "buffer"], returns: "u8" },
  ot_clipboard_operation_cancel: { args: ["ptr", "buffer"], returns: "u8" },
  ot_clipboard_operation_result_mime_length: { args: ["ptr", "buffer", "buffer"], returns: "u8" },
  ot_clipboard_operation_result_mime_copy: { args: ["ptr", "buffer", "buffer", "u32"], returns: "u8" },
  ot_clipboard_operation_result_data_length: { args: ["ptr", "buffer", "buffer"], returns: "u8" },
  ot_clipboard_operation_result_data_copy: { args: ["ptr", "buffer", "buffer", "u32"], returns: "u8" },
  ot_clipboard_operation_result_error_code: { args: ["ptr", "buffer", "buffer"], returns: "u8" },
  ot_clipboard_operation_result_diagnostic_length: { args: ["ptr", "buffer", "buffer"], returns: "u8" },
  ot_clipboard_operation_result_diagnostic_copy: { args: ["ptr", "buffer", "buffer", "u32"], returns: "u8" },
  ot_clipboard_operation_destroy: { args: ["ptr", "buffer"], returns: "u8" }
};
var nativeCallbacks = {
  ot_scene_measure_callback: { args: ["u64", "u32", "u32", "f32", "u32", "f32", "u32", "ptr"], returns: "void" },
  ot_edit_event_callback: { args: ["u64", "u32", "u32", "u32"], returns: "void" },
  ot_output_write_callback: { args: ["ptr", "ptr", "u32"], returns: "i64" }
};
var nativeLayouts = {
  ot_handle: {
    size: 16,
    alignment: 8,
    fields: {
      context_id: { offset: 0, size: 8, alignment: 8, type: "u64" },
      slot: { offset: 8, size: 4, alignment: 4, type: "u32" },
      generation: { offset: 12, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_scene_slider_options: {
    size: 64,
    alignment: 8,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      orientation: { offset: 8, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 12, size: 4, alignment: 4, type: "u32" },
      min: { offset: 16, size: 8, alignment: 8, type: "f64" },
      max: { offset: 24, size: 8, alignment: 8, type: "f64" },
      value: { offset: 32, size: 8, alignment: 8, type: "f64" },
      viewport_size: { offset: 40, size: 8, alignment: 8, type: "f64" },
      foreground: { offset: 48, size: 8, alignment: 2, type: "[4]u16" },
      background: { offset: 56, size: 8, alignment: 2, type: "[4]u16" }
    }
  },
  ot_scene_slider_thumb: {
    size: 24,
    alignment: 8,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      size: { offset: 8, size: 8, alignment: 8, type: "f64" },
      start: { offset: 16, size: 8, alignment: 8, type: "f64" }
    }
  },
  ot_scene_arrow_options: {
    size: 32,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      direction: { offset: 8, size: 4, alignment: 4, type: "u32" },
      attributes: { offset: 12, size: 4, alignment: 4, type: "u32" },
      foreground: { offset: 16, size: 8, alignment: 2, type: "[4]u16" },
      background: { offset: 24, size: 8, alignment: 2, type: "[4]u16" }
    }
  },
  ot_scene_text_options: {
    size: 80,
    alignment: 8,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      foreground: { offset: 8, size: 8, alignment: 2, type: "[4]u16" },
      background: { offset: 16, size: 8, alignment: 2, type: "[4]u16" },
      attributes: { offset: 24, size: 4, alignment: 4, type: "u32" },
      wrap_mode: { offset: 28, size: 4, alignment: 4, type: "u32" },
      truncate: { offset: 32, size: 4, alignment: 4, type: "u32" },
      first_line_offset: { offset: 36, size: 4, alignment: 4, type: "u32" },
      scroll_x: { offset: 40, size: 8, alignment: 8, type: "f64" },
      scroll_y: { offset: 48, size: 8, alignment: 8, type: "f64" },
      tab_indicator: { offset: 56, size: 4, alignment: 4, type: "u32" },
      tab_color_set: { offset: 60, size: 4, alignment: 4, type: "u32" },
      tab_color: { offset: 64, size: 8, alignment: 2, type: "[4]u16" },
      text_align: { offset: 72, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_scene_text_selection_options: {
    size: 56,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      operation: { offset: 8, size: 4, alignment: 4, type: "u32" },
      behavior: { offset: 12, size: 4, alignment: 4, type: "u32" },
      anchor_x: { offset: 16, size: 4, alignment: 4, type: "i32" },
      anchor_y: { offset: 20, size: 4, alignment: 4, type: "i32" },
      focus_x: { offset: 24, size: 4, alignment: 4, type: "i32" },
      focus_y: { offset: 28, size: 4, alignment: 4, type: "i32" },
      flags: { offset: 32, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 36, size: 4, alignment: 4, type: "u32" },
      background: { offset: 40, size: 8, alignment: 2, type: "[4]u16" },
      foreground: { offset: 48, size: 8, alignment: 2, type: "[4]u16" }
    }
  },
  ot_styled_text_chunk: {
    size: 48,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      byte_count: { offset: 8, size: 4, alignment: 4, type: "u32" },
      flags: { offset: 12, size: 4, alignment: 4, type: "u32" },
      foreground: { offset: 16, size: 8, alignment: 2, type: "[4]u16" },
      background: { offset: 24, size: 8, alignment: 2, type: "[4]u16" },
      attributes: { offset: 32, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 36, size: 4, alignment: 4, type: "u32" },
      link_offset: { offset: 40, size: 4, alignment: 4, type: "u32" },
      link_byte_count: { offset: 44, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_scene_text_info: {
    size: 32,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      byte_count: { offset: 8, size: 4, alignment: 4, type: "u32" },
      text_length: { offset: 12, size: 4, alignment: 4, type: "u32" },
      line_count: { offset: 16, size: 4, alignment: 4, type: "u32" },
      virtual_line_count: { offset: 20, size: 4, alignment: 4, type: "u32" },
      width_cols_max: { offset: 24, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 28, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_scene_text_line: {
    size: 16,
    alignment: 4,
    fields: {
      start_cols: { offset: 0, size: 4, alignment: 4, type: "u32" },
      width_cols: { offset: 4, size: 4, alignment: 4, type: "u32" },
      source_line: { offset: 8, size: 4, alignment: 4, type: "u32" },
      wrap_index: { offset: 12, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_scene_paint_options: {
    size: 80,
    alignment: 8,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      z_index: { offset: 8, size: 4, alignment: 4, type: "i32" },
      opacity: { offset: 12, size: 4, alignment: 4, type: "f32" },
      translate_x: { offset: 16, size: 8, alignment: 8, type: "f64" },
      translate_y: { offset: 24, size: 8, alignment: 8, type: "f64" },
      border_sides: { offset: 32, size: 4, alignment: 4, type: "u32" },
      should_fill: { offset: 36, size: 4, alignment: 4, type: "u32" },
      background: { offset: 40, size: 8, alignment: 2, type: "[4]u16" },
      border_color: { offset: 48, size: 8, alignment: 2, type: "[4]u16" },
      border_style: { offset: 56, size: 4, alignment: 4, type: "u32" },
      focusable: { offset: 60, size: 4, alignment: 4, type: "u32" },
      focused_border_color: { offset: 64, size: 8, alignment: 2, type: "[4]u16" },
      reserved: { offset: 72, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_scene_box_details: {
    size: 76,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      title_alignment: { offset: 8, size: 4, alignment: 4, type: "u32" },
      bottom_title_alignment: { offset: 12, size: 4, alignment: 4, type: "u32" },
      flags: { offset: 16, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 20, size: 4, alignment: 4, type: "u32" },
      title_color: { offset: 24, size: 8, alignment: 2, type: "[4]u16" },
      border_characters: { offset: 32, size: 44, alignment: 4, type: "[11]u32" }
    }
  },
  ot_scene_style_value: {
    size: 16,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      unit: { offset: 8, size: 4, alignment: 4, type: "u32" },
      value: { offset: 12, size: 4, alignment: 4, type: "f32" }
    }
  },
  ot_scene_layout: {
    size: 48,
    alignment: 8,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      left: { offset: 8, size: 4, alignment: 4, type: "f32" },
      top: { offset: 12, size: 4, alignment: 4, type: "f32" },
      right: { offset: 16, size: 4, alignment: 4, type: "f32" },
      bottom: { offset: 20, size: 4, alignment: 4, type: "f32" },
      width: { offset: 24, size: 4, alignment: 4, type: "f32" },
      height: { offset: 28, size: 4, alignment: 4, type: "f32" },
      screen_x: { offset: 32, size: 8, alignment: 8, type: "f64" },
      screen_y: { offset: 40, size: 8, alignment: 8, type: "f64" }
    }
  },
  ot_scene_stats: {
    size: 64,
    alignment: 8,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      last_frame_time: { offset: 8, size: 8, alignment: 8, type: "f64" },
      average_frame_time: { offset: 16, size: 8, alignment: 8, type: "f64" },
      render_time: { offset: 24, size: 8, alignment: 8, type: "f64" },
      stdout_write_time: { offset: 32, size: 8, alignment: 8, type: "f64" },
      frame_count: { offset: 40, size: 8, alignment: 8, type: "u64" },
      cells_updated: { offset: 48, size: 4, alignment: 4, type: "u32" },
      average_cells_updated: { offset: 52, size: 4, alignment: 4, type: "u32" },
      render_time_valid: { offset: 56, size: 4, alignment: 4, type: "u32" },
      stdout_write_time_valid: { offset: 60, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_scene_cursor_state: {
    size: 48,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      x: { offset: 8, size: 4, alignment: 4, type: "u32" },
      y: { offset: 12, size: 4, alignment: 4, type: "u32" },
      visible: { offset: 16, size: 4, alignment: 4, type: "u32" },
      style: { offset: 20, size: 4, alignment: 4, type: "u32" },
      blinking: { offset: 24, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 28, size: 4, alignment: 4, type: "u32" },
      r: { offset: 32, size: 4, alignment: 4, type: "f32" },
      g: { offset: 36, size: 4, alignment: 4, type: "f32" },
      b: { offset: 40, size: 4, alignment: 4, type: "f32" },
      a: { offset: 44, size: 4, alignment: 4, type: "f32" }
    }
  },
  ot_scene_hooks: {
    size: 40,
    alignment: 8,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      flags: { offset: 8, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 12, size: 4, alignment: 4, type: "u32" },
      generation: { offset: 16, size: 8, alignment: 8, type: "u64" },
      initial_width: { offset: 24, size: 8, alignment: 8, type: "f64" },
      initial_height: { offset: 32, size: 8, alignment: 8, type: "f64" }
    }
  },
  ot_scene_frame_options: {
    size: 36,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      background: { offset: 8, size: 8, alignment: 2, type: "[4]u16" },
      use_mouse: { offset: 16, size: 4, alignment: 4, type: "u32" },
      excluded_hit_num: { offset: 20, size: 4, alignment: 4, type: "u32" },
      max_layout_rounds: { offset: 24, size: 4, alignment: 4, type: "u32" },
      max_host_requests: { offset: 28, size: 4, alignment: 4, type: "u32" },
      preserve_unwritten: { offset: 32, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_scene_frame_request: {
    size: 112,
    alignment: 8,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      session: { offset: 8, size: 16, alignment: 8, type: "ot_handle" },
      root: { offset: 24, size: 16, alignment: 8, type: "ot_handle" },
      node: { offset: 40, size: 16, alignment: 8, type: "ot_handle" },
      frame_id: { offset: 56, size: 8, alignment: 8, type: "u64" },
      request_id: { offset: 64, size: 8, alignment: 8, type: "u64" },
      layout_epoch: { offset: 72, size: 8, alignment: 8, type: "u64" },
      hook_generation: { offset: 80, size: 8, alignment: 8, type: "u64" },
      kind: { offset: 88, size: 4, alignment: 4, type: "u32" },
      num: { offset: 92, size: 4, alignment: 4, type: "u32" },
      width: { offset: 96, size: 4, alignment: 4, type: "u32" },
      height: { offset: 100, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 104, size: 8, alignment: 4, type: "[2]u32" }
    }
  },
  ot_scene_frame_geometry: {
    size: 112,
    alignment: 8,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      flags: { offset: 8, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 12, size: 4, alignment: 4, type: "u32" },
      paint: { offset: 16, size: 48, alignment: 8, type: "ot_scene_layout" },
      public_layout: { offset: 64, size: 48, alignment: 8, type: "ot_scene_layout" }
    }
  },
  ot_scene_paint_slot: {
    size: 152,
    alignment: 8,
    fields: {
      node: { offset: 0, size: 16, alignment: 8, type: "ot_handle" },
      hook_generation: { offset: 16, size: 8, alignment: 8, type: "u64" },
      num: { offset: 24, size: 4, alignment: 4, type: "u32" },
      hooks: { offset: 28, size: 4, alignment: 4, type: "u32" },
      clip_x: { offset: 32, size: 4, alignment: 4, type: "i32" },
      clip_y: { offset: 36, size: 4, alignment: 4, type: "i32" },
      clip_width: { offset: 40, size: 4, alignment: 4, type: "u32" },
      clip_height: { offset: 44, size: 4, alignment: 4, type: "u32" },
      opacity: { offset: 48, size: 4, alignment: 4, type: "f32" },
      flags: { offset: 52, size: 4, alignment: 4, type: "u32" },
      paint: { offset: 56, size: 48, alignment: 8, type: "ot_scene_layout" },
      public_layout: { offset: 104, size: 48, alignment: 8, type: "ot_scene_layout" }
    }
  },
  ot_scene_property_update: {
    size: 24,
    alignment: 8,
    fields: {
      node: { offset: 0, size: 16, alignment: 8, type: "ot_handle" },
      fields: { offset: 16, size: 4, alignment: 4, type: "u32" },
      size_bytes: { offset: 20, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_scene_style_property: {
    size: 16,
    alignment: 4,
    fields: {
      group: { offset: 0, size: 1, alignment: 1, type: "u8" },
      kind: { offset: 1, size: 1, alignment: 1, type: "u8" },
      edge: { offset: 2, size: 1, alignment: 1, type: "u8" },
      unit: { offset: 3, size: 1, alignment: 1, type: "u8" },
      flags: { offset: 4, size: 4, alignment: 4, type: "u32" },
      value: { offset: 8, size: 4, alignment: 4, type: "f32" },
      reserved: { offset: 12, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_session_options: {
    size: 32,
    alignment: 8,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      chunk_size: { offset: 8, size: 4, alignment: 4, type: "u32" },
      span_capacity: { offset: 12, size: 4, alignment: 4, type: "u32" },
      max_bytes: { offset: 16, size: 8, alignment: 8, type: "u64" },
      control_capacity: { offset: 24, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 28, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_output_ticket: {
    size: 32,
    alignment: 8,
    fields: {
      session: { offset: 0, size: 16, alignment: 8, type: "ot_handle" },
      request_id: { offset: 16, size: 8, alignment: 8, type: "u64" },
      byte_count: { offset: 24, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 28, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_session_renderer_options: {
    size: 24,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      width: { offset: 8, size: 4, alignment: 4, type: "u32" },
      height: { offset: 12, size: 4, alignment: 4, type: "u32" },
      remote: { offset: 16, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 20, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_session_renderer_env_options: {
    size: 32,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      width: { offset: 8, size: 4, alignment: 4, type: "u32" },
      height: { offset: 12, size: 4, alignment: 4, type: "u32" },
      remote_mode: { offset: 16, size: 4, alignment: 4, type: "u32" },
      entry_count: { offset: 20, size: 4, alignment: 4, type: "u32" },
      byte_count: { offset: 24, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 28, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_split_snapshot: {
    size: 24,
    alignment: 8,
    fields: {
      buffer: { offset: 0, size: 16, alignment: 8, type: "ot_handle" },
      row_columns: { offset: 16, size: 4, alignment: 4, type: "u32" },
      flags: { offset: 20, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_split_control: {
    size: 36,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      command: { offset: 8, size: 4, alignment: 4, type: "u32" },
      arguments: { offset: 12, size: 24, alignment: 4, type: "[6]u32" }
    }
  },
  ot_session_renderer_state: {
    size: 32,
    alignment: 8,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      width: { offset: 8, size: 4, alignment: 4, type: "u32" },
      height: { offset: 12, size: 4, alignment: 4, type: "u32" },
      frame_count: { offset: 16, size: 8, alignment: 8, type: "u64" },
      frame_pending: { offset: 24, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 28, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_buffer_options: {
    size: 24,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      width: { offset: 8, size: 4, alignment: 4, type: "u32" },
      height: { offset: 12, size: 4, alignment: 4, type: "u32" },
      width_method: { offset: 16, size: 4, alignment: 4, type: "u32" },
      flags: { offset: 20, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_unicode_char: {
    size: 8,
    alignment: 4,
    fields: {
      width: { offset: 0, size: 4, alignment: 4, type: "u32" },
      character: { offset: 4, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_embedded_terminal_options: {
    size: 24,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      cols: { offset: 8, size: 4, alignment: 4, type: "u32" },
      rows: { offset: 12, size: 4, alignment: 4, type: "u32" },
      max_scrollback: { offset: 16, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 20, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_embedded_terminal_cursor: {
    size: 56,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      x: { offset: 8, size: 4, alignment: 4, type: "u32" },
      y: { offset: 12, size: 4, alignment: 4, type: "u32" },
      has_value: { offset: 16, size: 4, alignment: 4, type: "u32" },
      visible: { offset: 20, size: 4, alignment: 4, type: "u32" },
      blinking: { offset: 24, size: 4, alignment: 4, type: "u32" },
      wide_tail: { offset: 28, size: 4, alignment: 4, type: "u32" },
      style: { offset: 32, size: 4, alignment: 4, type: "u32" },
      color_has_value: { offset: 36, size: 4, alignment: 4, type: "u32" },
      color_r: { offset: 40, size: 4, alignment: 4, type: "u32" },
      color_g: { offset: 44, size: 4, alignment: 4, type: "u32" },
      color_b: { offset: 48, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 52, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_embedded_terminal_key: {
    size: 32,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      action: { offset: 8, size: 4, alignment: 4, type: "u32" },
      composing: { offset: 12, size: 4, alignment: 4, type: "u32" },
      mods: { offset: 16, size: 4, alignment: 4, type: "u32" },
      consumed_mods: { offset: 20, size: 4, alignment: 4, type: "u32" },
      unshifted_codepoint: { offset: 24, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 28, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_embedded_terminal_mouse: {
    size: 32,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      action: { offset: 8, size: 4, alignment: 4, type: "u32" },
      button: { offset: 12, size: 4, alignment: 4, type: "i32" },
      mods: { offset: 16, size: 4, alignment: 4, type: "u32" },
      any_button_pressed: { offset: 20, size: 4, alignment: 4, type: "u32" },
      x: { offset: 24, size: 4, alignment: 4, type: "f32" },
      y: { offset: 28, size: 4, alignment: 4, type: "f32" }
    }
  },
  ot_edit_buffer_options: {
    size: 16,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      width_method: { offset: 8, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 12, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_edit_buffer_info: {
    size: 48,
    alignment: 8,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      content_epoch: { offset: 8, size: 8, alignment: 8, type: "u64" },
      byte_count: { offset: 16, size: 4, alignment: 4, type: "u32" },
      line_count: { offset: 20, size: 4, alignment: 4, type: "u32" },
      cursor_row: { offset: 24, size: 4, alignment: 4, type: "u32" },
      cursor_col: { offset: 28, size: 4, alignment: 4, type: "u32" },
      cursor_offset: { offset: 32, size: 4, alignment: 4, type: "u32" },
      can_undo: { offset: 36, size: 4, alignment: 4, type: "u32" },
      can_redo: { offset: 40, size: 4, alignment: 4, type: "u32" },
      tab_width: { offset: 44, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_scene_editor_options: {
    size: 40,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      show_cursor: { offset: 8, size: 4, alignment: 4, type: "u32" },
      style: { offset: 12, size: 4, alignment: 4, type: "u32" },
      blinking: { offset: 16, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 20, size: 4, alignment: 4, type: "u32" },
      color: { offset: 24, size: 8, alignment: 2, type: "[4]u16" },
      mouse_pointer: { offset: 32, size: 4, alignment: 4, type: "u32" },
      reserved2: { offset: 36, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_edit_position: {
    size: 24,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      valid: { offset: 8, size: 4, alignment: 4, type: "u32" },
      row: { offset: 12, size: 4, alignment: 4, type: "u32" },
      col: { offset: 16, size: 4, alignment: 4, type: "u32" },
      offset: { offset: 20, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_editor_style: {
    size: 32,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      flags: { offset: 8, size: 4, alignment: 4, type: "u32" },
      attributes: { offset: 12, size: 4, alignment: 4, type: "u32" },
      foreground: { offset: 16, size: 8, alignment: 2, type: "[4]u16" },
      background: { offset: 24, size: 8, alignment: 2, type: "[4]u16" }
    }
  },
  ot_edit_highlight: {
    size: 20,
    alignment: 4,
    fields: {
      start: { offset: 0, size: 4, alignment: 4, type: "u32" },
      end: { offset: 4, size: 4, alignment: 4, type: "u32" },
      style_id: { offset: 8, size: 4, alignment: 4, type: "u32" },
      priority: { offset: 12, size: 4, alignment: 4, type: "u32" },
      ref: { offset: 16, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_editor_viewport: {
    size: 24,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      x: { offset: 8, size: 4, alignment: 4, type: "u32" },
      y: { offset: 12, size: 4, alignment: 4, type: "u32" },
      width: { offset: 16, size: 4, alignment: 4, type: "u32" },
      height: { offset: 20, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_editor_selection: {
    size: 72,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      operation: { offset: 8, size: 4, alignment: 4, type: "u32" },
      behavior: { offset: 12, size: 4, alignment: 4, type: "u32" },
      start: { offset: 16, size: 4, alignment: 4, type: "u32" },
      end: { offset: 20, size: 4, alignment: 4, type: "u32" },
      anchor_x: { offset: 24, size: 4, alignment: 4, type: "i32" },
      anchor_y: { offset: 28, size: 4, alignment: 4, type: "i32" },
      focus_x: { offset: 32, size: 4, alignment: 4, type: "i32" },
      focus_y: { offset: 36, size: 4, alignment: 4, type: "i32" },
      update_cursor: { offset: 40, size: 4, alignment: 4, type: "u32" },
      follow_cursor: { offset: 44, size: 4, alignment: 4, type: "u32" },
      flags: { offset: 48, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 52, size: 4, alignment: 4, type: "u32" },
      foreground: { offset: 56, size: 8, alignment: 2, type: "[4]u16" },
      background: { offset: 64, size: 8, alignment: 2, type: "[4]u16" }
    }
  },
  ot_editor_view_info: {
    size: 32,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      virtual_line_count: { offset: 8, size: 4, alignment: 4, type: "u32" },
      total_virtual_line_count: { offset: 12, size: 4, alignment: 4, type: "u32" },
      selection_present: { offset: 16, size: 4, alignment: 4, type: "u32" },
      selection_start: { offset: 20, size: 4, alignment: 4, type: "u32" },
      selection_end: { offset: 24, size: 4, alignment: 4, type: "u32" },
      selection_occupancy: { offset: 28, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_editor_position: {
    size: 28,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      visual_row: { offset: 8, size: 4, alignment: 4, type: "u32" },
      visual_col: { offset: 12, size: 4, alignment: 4, type: "u32" },
      logical_row: { offset: 16, size: 4, alignment: 4, type: "u32" },
      logical_col: { offset: 20, size: 4, alignment: 4, type: "u32" },
      offset: { offset: 24, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_editor_measure: {
    size: 16,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      line_count: { offset: 8, size: 4, alignment: 4, type: "u32" },
      width_cols_max: { offset: 12, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_image_info: {
    size: 32,
    alignment: 4,
    fields: {
      width: { offset: 0, size: 4, alignment: 4, type: "u32" },
      height: { offset: 4, size: 4, alignment: 4, type: "u32" },
      source_width: { offset: 8, size: 4, alignment: 4, type: "u32" },
      source_height: { offset: 12, size: 4, alignment: 4, type: "u32" },
      format: { offset: 16, size: 4, alignment: 4, type: "u32" },
      color_status: { offset: 20, size: 4, alignment: 4, type: "u32" },
      orientation: { offset: 24, size: 4, alignment: 4, type: "u32" },
      has_alpha: { offset: 28, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_image_pixels: {
    size: 32,
    alignment: 8,
    fields: {
      lease: { offset: 0, size: 16, alignment: 8, type: "ot_handle" },
      pixels: { offset: 16, size: 8, alignment: 8, type: "u64" },
      byte_count: { offset: 24, size: 8, alignment: 8, type: "u64" }
    }
  },
  ot_image_draw_options: {
    size: 64,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      flags: { offset: 8, size: 4, alignment: 4, type: "u32" },
      protocol: { offset: 12, size: 4, alignment: 4, type: "u32" },
      x: { offset: 16, size: 4, alignment: 4, type: "i32" },
      y: { offset: 20, size: 4, alignment: 4, type: "i32" },
      width: { offset: 24, size: 4, alignment: 4, type: "u32" },
      height: { offset: 28, size: 4, alignment: 4, type: "u32" },
      pixel_width: { offset: 32, size: 4, alignment: 4, type: "u32" },
      pixel_height: { offset: 36, size: 4, alignment: 4, type: "u32" },
      source_x: { offset: 40, size: 4, alignment: 4, type: "u32" },
      source_y: { offset: 44, size: 4, alignment: 4, type: "u32" },
      source_width: { offset: 48, size: 4, alignment: 4, type: "u32" },
      source_height: { offset: 52, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 56, size: 8, alignment: 4, type: "[2]u32" }
    }
  },
  ot_session_kitty_image_transport: {
    size: 32,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      requested: { offset: 8, size: 4, alignment: 4, type: "u32" },
      effective: { offset: 12, size: 4, alignment: 4, type: "u32" },
      file_state: { offset: 16, size: 4, alignment: 4, type: "u32" },
      fallback: { offset: 20, size: 4, alignment: 4, type: "u32" },
      pending_files: { offset: 24, size: 4, alignment: 4, type: "u32" },
      pending_bytes: { offset: 28, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_text_buffer_info: {
    size: 40,
    alignment: 8,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      content_epoch: { offset: 8, size: 8, alignment: 8, type: "u64" },
      byte_count: { offset: 16, size: 4, alignment: 4, type: "u32" },
      text_length: { offset: 20, size: 4, alignment: 4, type: "u32" },
      line_count: { offset: 24, size: 4, alignment: 4, type: "u32" },
      highlight_count: { offset: 28, size: 4, alignment: 4, type: "u32" },
      tab_width: { offset: 32, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 36, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_text_buffer_replacement: {
    size: 56,
    alignment: 8,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      buffer: { offset: 8, size: 16, alignment: 8, type: "ot_handle" },
      view: { offset: 24, size: 16, alignment: 8, type: "ot_handle" },
      byte_offset: { offset: 40, size: 4, alignment: 4, type: "u32" },
      byte_count: { offset: 44, size: 4, alignment: 4, type: "u32" },
      chunk_offset: { offset: 48, size: 4, alignment: 4, type: "u32" },
      chunk_count: { offset: 52, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_text_buffer_replacement_info: {
    size: 8,
    alignment: 4,
    fields: {
      text_length: { offset: 0, size: 4, alignment: 4, type: "u32" },
      byte_count: { offset: 4, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_buffer_draw_header: {
    size: 16,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      operation: { offset: 8, size: 4, alignment: 4, type: "u32" },
      flags: { offset: 12, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_buffer_draw_clear: {
    size: 24,
    alignment: 4,
    fields: {
      header: { offset: 0, size: 16, alignment: 4, type: "ot_buffer_draw_header" },
      background: { offset: 16, size: 8, alignment: 2, type: "[4]u16" }
    }
  },
  ot_buffer_draw_fill: {
    size: 40,
    alignment: 4,
    fields: {
      header: { offset: 0, size: 16, alignment: 4, type: "ot_buffer_draw_header" },
      x: { offset: 16, size: 4, alignment: 4, type: "i32" },
      y: { offset: 20, size: 4, alignment: 4, type: "i32" },
      width: { offset: 24, size: 4, alignment: 4, type: "u32" },
      height: { offset: 28, size: 4, alignment: 4, type: "u32" },
      background: { offset: 32, size: 8, alignment: 2, type: "[4]u16" }
    }
  },
  ot_buffer_draw_text_record: {
    size: 44,
    alignment: 4,
    fields: {
      header: { offset: 0, size: 16, alignment: 4, type: "ot_buffer_draw_header" },
      x: { offset: 16, size: 4, alignment: 4, type: "i32" },
      y: { offset: 20, size: 4, alignment: 4, type: "i32" },
      attributes: { offset: 24, size: 4, alignment: 4, type: "u32" },
      foreground: { offset: 28, size: 8, alignment: 2, type: "[4]u16" },
      background: { offset: 36, size: 8, alignment: 2, type: "[4]u16" }
    }
  },
  ot_buffer_draw_cell: {
    size: 48,
    alignment: 4,
    fields: {
      header: { offset: 0, size: 16, alignment: 4, type: "ot_buffer_draw_header" },
      x: { offset: 16, size: 4, alignment: 4, type: "i32" },
      y: { offset: 20, size: 4, alignment: 4, type: "i32" },
      character: { offset: 24, size: 4, alignment: 4, type: "u32" },
      attributes: { offset: 28, size: 4, alignment: 4, type: "u32" },
      foreground: { offset: 32, size: 8, alignment: 2, type: "[4]u16" },
      background: { offset: 40, size: 8, alignment: 2, type: "[4]u16" }
    }
  },
  ot_buffer_draw_box: {
    size: 104,
    alignment: 4,
    fields: {
      header: { offset: 0, size: 16, alignment: 4, type: "ot_buffer_draw_header" },
      x: { offset: 16, size: 4, alignment: 4, type: "i32" },
      y: { offset: 20, size: 4, alignment: 4, type: "i32" },
      width: { offset: 24, size: 4, alignment: 4, type: "u32" },
      height: { offset: 28, size: 4, alignment: 4, type: "u32" },
      packed_options: { offset: 32, size: 4, alignment: 4, type: "u32" },
      foreground: { offset: 36, size: 8, alignment: 2, type: "[4]u16" },
      background: { offset: 44, size: 8, alignment: 2, type: "[4]u16" },
      title_color: { offset: 52, size: 8, alignment: 2, type: "[4]u16" },
      border_chars: { offset: 60, size: 44, alignment: 4, type: "[11]u32" }
    }
  },
  ot_buffer_draw_compose: {
    size: 40,
    alignment: 4,
    fields: {
      header: { offset: 0, size: 16, alignment: 4, type: "ot_buffer_draw_header" },
      x: { offset: 16, size: 4, alignment: 4, type: "i32" },
      y: { offset: 20, size: 4, alignment: 4, type: "i32" },
      source_x: { offset: 24, size: 4, alignment: 4, type: "u32" },
      source_y: { offset: 28, size: 4, alignment: 4, type: "u32" },
      source_width: { offset: 32, size: 4, alignment: 4, type: "u32" },
      source_height: { offset: 36, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_buffer_draw_alpha: {
    size: 20,
    alignment: 4,
    fields: {
      header: { offset: 0, size: 16, alignment: 4, type: "ot_buffer_draw_header" },
      enabled: { offset: 16, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_buffer_grid_options: {
    size: 76,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      flags: { offset: 8, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 12, size: 4, alignment: 4, type: "u32" },
      foreground: { offset: 16, size: 8, alignment: 2, type: "[4]u16" },
      background: { offset: 24, size: 8, alignment: 2, type: "[4]u16" },
      border_chars: { offset: 32, size: 44, alignment: 4, type: "[11]u32" }
    }
  },
  ot_buffer_lease_snapshot: {
    size: 80,
    alignment: 8,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      lease: { offset: 8, size: 16, alignment: 8, type: "ot_handle" },
      width: { offset: 24, size: 4, alignment: 4, type: "u32" },
      height: { offset: 28, size: 4, alignment: 4, type: "u32" },
      generation: { offset: 32, size: 8, alignment: 8, type: "u64" },
      char_ptr: { offset: 40, size: 8, alignment: 8, type: "u64" },
      fg_ptr: { offset: 48, size: 8, alignment: 8, type: "u64" },
      bg_ptr: { offset: 56, size: 8, alignment: 8, type: "u64" },
      attributes_ptr: { offset: 64, size: 8, alignment: 8, type: "u64" },
      reserved: { offset: 72, size: 8, alignment: 8, type: "u64" }
    }
  },
  ot_session_terminal_options: {
    size: 16,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      flags: { offset: 8, size: 4, alignment: 4, type: "u32" },
      kitty_keyboard_flags: { offset: 12, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_session_control_options: {
    size: 20,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      kind: { offset: 8, size: 4, alignment: 4, type: "u32" },
      argument: { offset: 12, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 16, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_session_cursor_update: {
    size: 24,
    alignment: 4,
    fields: {
      fields: { offset: 0, size: 4, alignment: 4, type: "u32" },
      x: { offset: 4, size: 4, alignment: 4, type: "i32" },
      y: { offset: 8, size: 4, alignment: 4, type: "i32" },
      visible: { offset: 12, size: 1, alignment: 1, type: "u8" },
      style: { offset: 13, size: 1, alignment: 1, type: "u8" },
      blinking: { offset: 14, size: 1, alignment: 1, type: "u8" },
      mouse_pointer: { offset: 15, size: 1, alignment: 1, type: "u8" },
      color: { offset: 16, size: 8, alignment: 2, type: "[4]u16" }
    }
  },
  ot_session_program_status: {
    size: 32,
    alignment: 4,
    fields: {
      state: { offset: 0, size: 4, alignment: 4, type: "u32" },
      kind: { offset: 4, size: 4, alignment: 4, type: "u32" },
      fields: { offset: 8, size: 4, alignment: 4, type: "u32" },
      progress: { offset: 12, size: 4, alignment: 4, type: "u32" },
      id_len: { offset: 16, size: 4, alignment: 4, type: "u32" },
      app_len: { offset: 20, size: 4, alignment: 4, type: "u32" },
      title_len: { offset: 24, size: 4, alignment: 4, type: "u32" },
      message_len: { offset: 28, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_session_capabilities: {
    size: 144,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      flags: { offset: 8, size: 4, alignment: 4, type: "u32" },
      width_method: { offset: 12, size: 4, alignment: 4, type: "u32" },
      multiplexer: { offset: 16, size: 4, alignment: 4, type: "u32" },
      image_protocol: { offset: 20, size: 4, alignment: 4, type: "u32" },
      osc52_support: { offset: 24, size: 4, alignment: 4, type: "u32" },
      kitty_keyboard_flags: { offset: 28, size: 4, alignment: 4, type: "u32" },
      term_name_len: { offset: 32, size: 4, alignment: 4, type: "u32" },
      term_version_len: { offset: 36, size: 4, alignment: 4, type: "u32" },
      term_from_xtversion: { offset: 40, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 44, size: 4, alignment: 4, type: "u32" },
      term_name: { offset: 48, size: 64, alignment: 1, type: "[64]u8" },
      term_version: { offset: 112, size: 32, alignment: 1, type: "[32]u8" }
    }
  },
  ot_session_pump_result: {
    size: 24,
    alignment: 8,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      status: { offset: 8, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 12, size: 4, alignment: 4, type: "u32" },
      deadline_ns: { offset: 16, size: 8, alignment: 8, type: "u64" }
    }
  },
  ot_context_options: {
    size: 32,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      flags: { offset: 8, size: 4, alignment: 4, type: "u32" },
      object_capacity: { offset: 12, size: 4, alignment: 4, type: "u32" },
      render_cells_max: { offset: 16, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 20, size: 12, alignment: 4, type: "[3]u32" }
    }
  },
  ot_context_error: {
    size: 16,
    alignment: 4,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      status: { offset: 8, size: 4, alignment: 4, type: "i32" },
      reserved: { offset: 12, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_diagnostic: {
    size: 4112,
    alignment: 4,
    fields: {
      level: { offset: 0, size: 4, alignment: 4, type: "u32" },
      message_len: { offset: 4, size: 4, alignment: 4, type: "u32" },
      flags: { offset: 8, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 12, size: 4, alignment: 4, type: "u32" },
      message: { offset: 16, size: 4096, alignment: 1, type: "[4096]u8" }
    }
  },
  ot_diagnostic_drain: {
    size: 24,
    alignment: 8,
    fields: {
      struct_size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      abi_version: { offset: 4, size: 4, alignment: 4, type: "u32" },
      count: { offset: 8, size: 4, alignment: 4, type: "u32" },
      remaining: { offset: 12, size: 4, alignment: 4, type: "u32" },
      dropped: { offset: 16, size: 8, alignment: 8, type: "u64" }
    }
  },
  ot_scene_record_header: {
    size: 8,
    alignment: 4,
    fields: {
      size: { offset: 0, size: 4, alignment: 4, type: "u32" },
      operation: { offset: 4, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_scene_record_slot: {
    size: 16,
    alignment: 4,
    fields: {
      header: { offset: 0, size: 8, alignment: 4, type: "ot_scene_record_header" },
      slot: { offset: 8, size: 4, alignment: 4, type: "u32" },
      phase: { offset: 12, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_scene_record_draw: {
    size: 32,
    alignment: 8,
    fields: {
      header: { offset: 0, size: 8, alignment: 4, type: "ot_scene_record_header" },
      source: { offset: 8, size: 16, alignment: 8, type: "ot_handle" },
      text_length: { offset: 24, size: 4, alignment: 4, type: "u32" },
      bottom_length: { offset: 28, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_scene_record_stack: {
    size: 32,
    alignment: 4,
    fields: {
      header: { offset: 0, size: 8, alignment: 4, type: "ot_scene_record_header" },
      operation: { offset: 8, size: 4, alignment: 4, type: "u32" },
      x: { offset: 12, size: 4, alignment: 4, type: "i32" },
      y: { offset: 16, size: 4, alignment: 4, type: "i32" },
      width: { offset: 20, size: 4, alignment: 4, type: "u32" },
      height: { offset: 24, size: 4, alignment: 4, type: "u32" },
      opacity: { offset: 28, size: 4, alignment: 4, type: "f32" }
    }
  },
  ot_scene_record_grid: {
    size: 92,
    alignment: 4,
    fields: {
      header: { offset: 0, size: 8, alignment: 4, type: "ot_scene_record_header" },
      options: { offset: 8, size: 76, alignment: 4, type: "ot_buffer_grid_options" },
      column_count: { offset: 84, size: 4, alignment: 4, type: "u32" },
      row_count: { offset: 88, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_scene_record_packed: {
    size: 32,
    alignment: 4,
    fields: {
      header: { offset: 0, size: 8, alignment: 4, type: "ot_scene_record_header" },
      x: { offset: 8, size: 4, alignment: 4, type: "i32" },
      y: { offset: 12, size: 4, alignment: 4, type: "i32" },
      width: { offset: 16, size: 4, alignment: 4, type: "u32" },
      height: { offset: 20, size: 4, alignment: 4, type: "u32" },
      byte_count: { offset: 24, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 28, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_scene_record_supersample: {
    size: 32,
    alignment: 4,
    fields: {
      header: { offset: 0, size: 8, alignment: 4, type: "ot_scene_record_header" },
      x: { offset: 8, size: 4, alignment: 4, type: "i32" },
      y: { offset: 12, size: 4, alignment: 4, type: "i32" },
      format: { offset: 16, size: 4, alignment: 4, type: "u32" },
      stride: { offset: 20, size: 4, alignment: 4, type: "u32" },
      byte_count: { offset: 24, size: 4, alignment: 4, type: "u32" },
      reserved: { offset: 28, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_scene_record_grayscale: {
    size: 48,
    alignment: 4,
    fields: {
      header: { offset: 0, size: 8, alignment: 4, type: "ot_scene_record_header" },
      x: { offset: 8, size: 4, alignment: 4, type: "i32" },
      y: { offset: 12, size: 4, alignment: 4, type: "i32" },
      width: { offset: 16, size: 4, alignment: 4, type: "u32" },
      height: { offset: 20, size: 4, alignment: 4, type: "u32" },
      flags: { offset: 24, size: 4, alignment: 4, type: "u32" },
      sample_count: { offset: 28, size: 4, alignment: 4, type: "u32" },
      foreground: { offset: 32, size: 8, alignment: 2, type: "[4]u16" },
      background: { offset: 40, size: 8, alignment: 2, type: "[4]u16" }
    }
  },
  ot_scene_record_color_matrix: {
    size: 88,
    alignment: 4,
    fields: {
      header: { offset: 0, size: 8, alignment: 4, type: "ot_scene_record_header" },
      matrix: { offset: 8, size: 64, alignment: 4, type: "[16]f32" },
      strength: { offset: 72, size: 4, alignment: 4, type: "f32" },
      channel: { offset: 76, size: 4, alignment: 4, type: "u32" },
      has_mask: { offset: 80, size: 4, alignment: 4, type: "u32" },
      mask_count: { offset: 84, size: 4, alignment: 4, type: "u32" }
    }
  },
  ot_scene_record_view: {
    size: 32,
    alignment: 8,
    fields: {
      header: { offset: 0, size: 8, alignment: 4, type: "ot_scene_record_header" },
      source: { offset: 8, size: 16, alignment: 8, type: "ot_handle" },
      x: { offset: 24, size: 4, alignment: 4, type: "i32" },
      y: { offset: 28, size: 4, alignment: 4, type: "i32" }
    }
  },
  ot_scene_record_image: {
    size: 88,
    alignment: 8,
    fields: {
      header: { offset: 0, size: 8, alignment: 4, type: "ot_scene_record_header" },
      image: { offset: 8, size: 16, alignment: 8, type: "ot_handle" },
      options: { offset: 24, size: 64, alignment: 4, type: "ot_image_draw_options" }
    }
  },
  ot_scene_record_unicode: {
    size: 56,
    alignment: 8,
    fields: {
      header: { offset: 0, size: 8, alignment: 4, type: "ot_scene_record_header" },
      unicode: { offset: 8, size: 16, alignment: 8, type: "ot_handle" },
      index: { offset: 24, size: 4, alignment: 4, type: "u32" },
      x: { offset: 28, size: 4, alignment: 4, type: "i32" },
      y: { offset: 32, size: 4, alignment: 4, type: "i32" },
      attributes: { offset: 36, size: 4, alignment: 4, type: "u32" },
      foreground: { offset: 40, size: 8, alignment: 2, type: "[4]u16" },
      background: { offset: 48, size: 8, alignment: 2, type: "[4]u16" }
    }
  }
};
var nativeConstants = {
  OT_CONTEXT_ABI_VERSION: 1,
  OT_OK: 0,
  OT_INVALID_ARGUMENT: -1,
  OT_UNSUPPORTED_VERSION: -2,
  OT_OUT_OF_MEMORY: -3,
  OT_WRONG_THREAD: -4,
  OT_INTERNAL_ERROR: -5,
  OT_CONTEXT_BUSY: -6,
  OT_WRONG_CONTEXT: -7,
  OT_WRONG_KIND: -8,
  OT_STALE_HANDLE: -9,
  OT_WRONG_SESSION: -10,
  OT_OUTPUT_BACKPRESSURE: -11,
  OT_SESSION_CLOSED: -12,
  OT_OUTPUT_BUSY: -13,
  OT_STALE_OUTPUT: -14,
  OT_OUTPUT_FAILED: -15,
  OT_OBJECT_LIMIT: -16,
  OT_RENDERER_ATTACHED: -17,
  OT_RENDERER_NOT_ATTACHED: -18,
  OT_INVALID_PHASE: -19,
  OT_CONTROL_PACKET_LIMIT: -20,
  OT_LEASE_LIMIT: -21,
  OT_LEASE_BYTES_LIMIT: -22,
  OT_STALE_LEASE: -23,
  OT_UNSUPPORTED_RESOURCE: -24,
  OT_STALE_FRAME: -25,
  OT_LAYOUT_LIMIT: -26,
  OT_FRAME_BUSY: -27,
  OT_FRAME_REQUEST_LIMIT: -28,
  OT_IMAGE_UNSUPPORTED_FORMAT: -40,
  OT_IMAGE_UNSUPPORTED_COLOR_SPACE: -41,
  OT_IMAGE_MALFORMED_DATA: -42,
  OT_IMAGE_DIMENSION_LIMIT: -43,
  OT_IMAGE_MEMORY_LIMIT: -44,
  OT_IMAGE_OUTPUT_TOO_SMALL: -45,
  OT_IMAGE_UNSUPPORTED_FEATURE: -46,
  OT_IMAGE_BUSY: -47,
  OT_SCENE_ROOT: 0,
  OT_SCENE_BOX: 1,
  OT_SCENE_TEXT: 2,
  OT_SCENE_SLIDER: 3,
  OT_SCENE_ARROW: 4,
  OT_SCENE_EDITOR: 5,
  OT_SCENE_CUSTOM: 6,
  OT_SCENE_TEXT_VIEW: 7,
  OT_SCENE_IMAGE: 8,
  OT_SCENE_WRAP_NONE: 0,
  OT_SCENE_WRAP_CHAR: 1,
  OT_SCENE_WRAP_WORD: 2,
  OT_SCENE_ALIGN_LEFT: 0,
  OT_SCENE_ALIGN_CENTER: 1,
  OT_SCENE_ALIGN_RIGHT: 2,
  OT_STYLE_ENUM: 0,
  OT_STYLE_FLOAT: 1,
  OT_STYLE_VALUE: 2,
  OT_STYLE_BORDER: 3,
  OT_STYLE_DIMENSION: 4,
  OT_STYLE_BORDER_WIDTH: 0,
  OT_STYLE_FLAGS_NONE: 0,
  OT_STYLE_DISABLE_FLEX_SHRINK: 1,
  OT_STYLE_ENUM_DIRECTION: 0,
  OT_STYLE_ENUM_FLEX_DIRECTION: 1,
  OT_STYLE_ENUM_JUSTIFY_CONTENT: 2,
  OT_STYLE_ENUM_ALIGN_CONTENT: 3,
  OT_STYLE_ENUM_ALIGN_ITEMS: 4,
  OT_STYLE_ENUM_ALIGN_SELF: 5,
  OT_STYLE_ENUM_POSITION_TYPE: 6,
  OT_STYLE_ENUM_FLEX_WRAP: 7,
  OT_STYLE_ENUM_OVERFLOW: 8,
  OT_STYLE_ENUM_DISPLAY: 9,
  OT_STYLE_ENUM_BOX_SIZING: 10,
  OT_STYLE_FLOAT_FLEX: 0,
  OT_STYLE_FLOAT_FLEX_GROW: 1,
  OT_STYLE_FLOAT_FLEX_SHRINK: 2,
  OT_STYLE_FLOAT_ASPECT_RATIO: 3,
  OT_STYLE_VALUE_WIDTH: 0,
  OT_STYLE_VALUE_HEIGHT: 1,
  OT_STYLE_VALUE_MIN_WIDTH: 2,
  OT_STYLE_VALUE_MIN_HEIGHT: 3,
  OT_STYLE_VALUE_MAX_WIDTH: 4,
  OT_STYLE_VALUE_MAX_HEIGHT: 5,
  OT_STYLE_VALUE_FLEX_BASIS: 6,
  OT_STYLE_VALUE_MARGIN: 7,
  OT_STYLE_VALUE_PADDING: 8,
  OT_STYLE_VALUE_POSITION: 9,
  OT_STYLE_VALUE_GAP: 10,
  OT_DIMENSION_WIDTH: 0,
  OT_DIMENSION_HEIGHT: 1,
  OT_UNIT_UNDEFINED: 0,
  OT_UNIT_POINT: 1,
  OT_UNIT_PERCENT: 2,
  OT_UNIT_AUTO: 3,
  OT_EDGE_NONE: 0,
  OT_EDGE_LEFT: 0,
  OT_EDGE_TOP: 1,
  OT_EDGE_RIGHT: 2,
  OT_EDGE_BOTTOM: 3,
  OT_EDGE_START: 4,
  OT_EDGE_END: 5,
  OT_EDGE_HORIZONTAL: 6,
  OT_EDGE_VERTICAL: 7,
  OT_EDGE_ALL: 8,
  OT_GUTTER_COLUMN: 0,
  OT_GUTTER_ROW: 1,
  OT_GUTTER_ALL: 2,
  OT_DIRECTION_INHERIT: 0,
  OT_DIRECTION_LTR: 1,
  OT_DIRECTION_RTL: 2,
  OT_FLEX_DIRECTION_COLUMN: 0,
  OT_FLEX_DIRECTION_COLUMN_REVERSE: 1,
  OT_FLEX_DIRECTION_ROW: 2,
  OT_FLEX_DIRECTION_ROW_REVERSE: 3,
  OT_JUSTIFY_FLEX_START: 0,
  OT_JUSTIFY_CENTER: 1,
  OT_JUSTIFY_FLEX_END: 2,
  OT_JUSTIFY_SPACE_BETWEEN: 3,
  OT_JUSTIFY_SPACE_AROUND: 4,
  OT_JUSTIFY_SPACE_EVENLY: 5,
  OT_ALIGN_AUTO: 0,
  OT_ALIGN_FLEX_START: 1,
  OT_ALIGN_CENTER: 2,
  OT_ALIGN_FLEX_END: 3,
  OT_ALIGN_STRETCH: 4,
  OT_ALIGN_BASELINE: 5,
  OT_ALIGN_SPACE_BETWEEN: 6,
  OT_ALIGN_SPACE_AROUND: 7,
  OT_ALIGN_SPACE_EVENLY: 8,
  OT_POSITION_STATIC: 0,
  OT_POSITION_RELATIVE: 1,
  OT_POSITION_ABSOLUTE: 2,
  OT_FLEX_WRAP_NONE: 0,
  OT_FLEX_WRAP_WRAP: 1,
  OT_FLEX_WRAP_REVERSE: 2,
  OT_OVERFLOW_VISIBLE: 0,
  OT_OVERFLOW_HIDDEN: 1,
  OT_OVERFLOW_SCROLL: 2,
  OT_DISPLAY_FLEX: 0,
  OT_DISPLAY_NONE: 1,
  OT_BOX_SIZING_BORDER_BOX: 0,
  OT_BOX_SIZING_CONTENT_BOX: 1,
  OT_STYLE_ENUM_DIRECTION_MAX: 2,
  OT_STYLE_ENUM_FLEX_DIRECTION_MAX: 3,
  OT_STYLE_ENUM_JUSTIFY_CONTENT_MAX: 5,
  OT_STYLE_ENUM_ALIGN_CONTENT_MAX: 8,
  OT_STYLE_ENUM_ALIGN_ITEMS_MAX: 8,
  OT_STYLE_ENUM_ALIGN_SELF_MAX: 8,
  OT_STYLE_ENUM_POSITION_TYPE_MAX: 2,
  OT_STYLE_ENUM_FLEX_WRAP_MAX: 2,
  OT_STYLE_ENUM_OVERFLOW_MAX: 2,
  OT_STYLE_ENUM_DISPLAY_MAX: 1,
  OT_STYLE_ENUM_BOX_SIZING_MAX: 1,
  OT_MEASURE_UNDEFINED: 0,
  OT_MEASURE_EXACTLY: 1,
  OT_MEASURE_AT_MOST: 2,
  OT_LAYOUT_PUBLIC: 0,
  OT_LAYOUT_YOGA: 1,
  OT_LAYOUT_PAINT: 2,
  OT_BORDER_NONE: 0,
  OT_BORDER_LEFT: 1,
  OT_BORDER_BOTTOM: 2,
  OT_BORDER_RIGHT: 4,
  OT_BORDER_TOP: 8,
  OT_BORDER_ALL: 15,
  OT_BORDER_SINGLE: 0,
  OT_BORDER_DOUBLE: 1,
  OT_BORDER_ROUNDED: 2,
  OT_BORDER_HEAVY: 3,
  OT_COLOR_RGB: 0,
  OT_COLOR_INDEXED: 1,
  OT_COLOR_DEFAULT: 2,
  OT_COLOR_CHANNEL_MASK: 255,
  OT_COLOR_META_SHIFT: 8,
  OT_SCENE_TEXT_SELECTION_RESET: 0,
  OT_SCENE_TEXT_SELECTION_SET: 1,
  OT_SCENE_TEXT_SELECTION_UPDATE: 2,
  OT_SCENE_TEXT_SELECTION_CELL: 0,
  OT_SCENE_TEXT_SELECTION_WORD: 1,
  OT_SCENE_TEXT_SELECTION_LINE: 2,
  OT_SCENE_TEXT_SELECTION_BACKGROUND: 1,
  OT_SCENE_TEXT_SELECTION_FOREGROUND: 2,
  OT_SCENE_TEXT_FOREGROUND: 1,
  OT_SCENE_TEXT_BACKGROUND: 2,
  OT_SCENE_TEXT_LINK: 4,
  OT_SCENE_MUTATIONS_MAX: 4096,
  OT_SCENE_HOOK_UPDATE: 1,
  OT_SCENE_HOOK_RESIZE: 2,
  OT_SCENE_HOOK_LAYOUT_CHANGED: 4,
  OT_SCENE_HOOK_RENDER_BEFORE: 8,
  OT_SCENE_HOOK_RENDER_AFTER: 16,
  OT_SCENE_HOOK_RENDER_SELF: 32,
  OT_SCENE_HOOK_IDLE_UPDATE: 64,
  OT_SCENE_FRAME_DONE: 0,
  OT_SCENE_FRAME_UPDATE: 1,
  OT_SCENE_FRAME_RESIZE: 2,
  OT_SCENE_FRAME_LAYOUT_CHANGED: 3,
  OT_SCENE_FRAME_RECORD: 4,
  OT_SCENE_FRAME_YIELD: 5,
  OT_SCENE_GEOMETRY_PAINT: 1,
  OT_SCENE_GEOMETRY_PUBLIC: 2,
  OT_SCENE_PROPERTY_Z_INDEX: 1,
  OT_SCENE_PROPERTY_OPACITY: 2,
  OT_SCENE_PROPERTY_TRANSLATE_X: 4,
  OT_SCENE_PROPERTY_TRANSLATE_Y: 8,
  OT_SCENE_PROPERTY_BORDER: 16,
  OT_SCENE_PROPERTY_SHOULD_FILL: 32,
  OT_SCENE_PROPERTY_BACKGROUND: 64,
  OT_SCENE_PROPERTY_BORDER_COLOR: 128,
  OT_SCENE_PROPERTY_BORDER_STYLE: 256,
  OT_SCENE_PROPERTY_FOCUSABLE: 512,
  OT_SCENE_PROPERTY_FOCUSED_BORDER_COLOR: 1024,
  OT_SCENE_PROPERTY_STYLE: 2048,
  OT_SCENE_PROPERTY_RESET_BORDER_CHARACTERS: 4096,
  OT_SCENE_PROPERTY_RECORD_MAX: 88,
  OT_SCENE_PROPERTY_BYTES_MAX: 360448,
  OT_SESSION_OPEN: 0,
  OT_SESSION_CLOSING: 1,
  OT_SESSION_CLOSED_STATE: 2,
  OT_SESSION_FAILED: 3,
  OT_SESSION_CANCELLED_STATE: 4,
  OT_SESSION_REMOTE_AUTO: 0,
  OT_SESSION_REMOTE_LOCAL: 1,
  OT_SESSION_REMOTE_REMOTE: 2,
  OT_SESSION_ENV_ENTRIES_MAX: 256,
  OT_SESSION_ENV_BYTES_MAX: 65536,
  OT_RENDER_PRESENTED: 0,
  OT_RENDER_PENDING: 1,
  OT_RENDER_SKIPPED: 2,
  OT_RENDER_FAILED: 3,
  OT_SESSION_BUFFER_CURRENT: 0,
  OT_SESSION_BUFFER_NEXT: 1,
  OT_WIDTH_METHOD_WCWIDTH: 0,
  OT_WIDTH_METHOD_UNICODE: 1,
  OT_WIDTH_METHOD_NO_ZWJ: 2,
  OT_WIDTH_METHOD_UNICODE_WIDE: 3,
  OT_BUFFER_RESPECT_ALPHA: 1,
  OT_EMBEDDED_TERMINAL_INVALIDATE: 0,
  OT_EMBEDDED_TERMINAL_SCROLL: 1,
  OT_EMBEDDED_TERMINAL_CLEAR_SELECTION: 2,
  OT_EMBEDDED_TERMINAL_SET_TRANSPARENT_BACKGROUND: 3,
  OT_EDIT_CURSOR_CHANGED: 1,
  OT_EDIT_CONTENT_CHANGED: 2,
  OT_EDIT_HISTORY_CURSOR_CHANGED: 4,
  OT_MOUSE_POINTER_AUTO: 0,
  OT_MOUSE_POINTER_DEFAULT: 1,
  OT_MOUSE_POINTER_NONE: 2,
  OT_MOUSE_POINTER_CONTEXT_MENU: 3,
  OT_MOUSE_POINTER_HELP: 4,
  OT_MOUSE_POINTER_POINTER: 5,
  OT_MOUSE_POINTER_PROGRESS: 6,
  OT_MOUSE_POINTER_WAIT: 7,
  OT_MOUSE_POINTER_CELL: 8,
  OT_MOUSE_POINTER_CROSSHAIR: 9,
  OT_MOUSE_POINTER_TEXT: 10,
  OT_MOUSE_POINTER_VERTICAL_TEXT: 11,
  OT_MOUSE_POINTER_ALIAS: 12,
  OT_MOUSE_POINTER_COPY: 13,
  OT_MOUSE_POINTER_MOVE: 14,
  OT_MOUSE_POINTER_NO_DROP: 15,
  OT_MOUSE_POINTER_NOT_ALLOWED: 16,
  OT_MOUSE_POINTER_GRAB: 17,
  OT_MOUSE_POINTER_GRABBING: 18,
  OT_MOUSE_POINTER_ALL_SCROLL: 19,
  OT_MOUSE_POINTER_COL_RESIZE: 20,
  OT_MOUSE_POINTER_ROW_RESIZE: 21,
  OT_MOUSE_POINTER_N_RESIZE: 22,
  OT_MOUSE_POINTER_E_RESIZE: 23,
  OT_MOUSE_POINTER_S_RESIZE: 24,
  OT_MOUSE_POINTER_W_RESIZE: 25,
  OT_MOUSE_POINTER_NE_RESIZE: 26,
  OT_MOUSE_POINTER_NW_RESIZE: 27,
  OT_MOUSE_POINTER_SE_RESIZE: 28,
  OT_MOUSE_POINTER_SW_RESIZE: 29,
  OT_MOUSE_POINTER_EW_RESIZE: 30,
  OT_MOUSE_POINTER_NS_RESIZE: 31,
  OT_MOUSE_POINTER_NESW_RESIZE: 32,
  OT_MOUSE_POINTER_NWSE_RESIZE: 33,
  OT_MOUSE_POINTER_ZOOM_IN: 34,
  OT_MOUSE_POINTER_ZOOM_OUT: 35,
  OT_MOUSE_POINTER_MAX: 35,
  OT_MOUSE_POINTER_UNCHANGED: 4294967295,
  OT_EDIT_DELETE_FORWARD: 0,
  OT_EDIT_BACKSPACE: 1,
  OT_EDIT_NEW_LINE: 2,
  OT_EDIT_DELETE_LINE: 3,
  OT_EDIT_MOVE_LEFT: 4,
  OT_EDIT_MOVE_RIGHT: 5,
  OT_EDIT_MOVE_UP: 6,
  OT_EDIT_MOVE_DOWN: 7,
  OT_EDIT_GOTO_LINE: 8,
  OT_EDIT_CURSOR_OFFSET: 9,
  OT_EDIT_CLEAR: 10,
  OT_EDIT_CLEAR_HISTORY: 11,
  OT_EDIT_DEBUG_ROPE: 12,
  OT_EDIT_POSITION_CURSOR: 0,
  OT_EDIT_POSITION_NEXT_WORD: 1,
  OT_EDIT_POSITION_PREV_WORD: 2,
  OT_EDIT_POSITION_EOL: 3,
  OT_EDIT_POSITION_OFFSET: 4,
  OT_EDIT_POSITION_COORDS: 5,
  OT_EDIT_POSITION_LINE_START: 6,
  OT_EDITOR_STYLE_FOREGROUND: 1,
  OT_EDITOR_STYLE_BACKGROUND: 2,
  OT_EDITOR_STYLE_ATTRIBUTES: 4,
  OT_EDIT_HIGHLIGHT_ADD_LINE: 0,
  OT_EDIT_HIGHLIGHT_ADD_RANGE: 1,
  OT_EDIT_HIGHLIGHT_REMOVE_REF: 2,
  OT_EDIT_HIGHLIGHT_CLEAR_LINE: 3,
  OT_EDIT_HIGHLIGHT_CLEAR_ALL: 4,
  OT_EDITOR_MOVE_UP: 0,
  OT_EDITOR_MOVE_DOWN: 1,
  OT_EDITOR_GOTO_LINE_END: 2,
  OT_EDITOR_DELETE_SELECTION: 3,
  OT_EDITOR_CURSOR_OFFSET: 4,
  OT_EDITOR_WRAP_MODE: 5,
  OT_EDITOR_TAB_INDICATOR: 6,
  OT_EDITOR_SELECT_SET: 0,
  OT_EDITOR_SELECT_UPDATE: 1,
  OT_EDITOR_SELECT_RESET: 2,
  OT_EDITOR_SELECT_LOCAL: 3,
  OT_EDITOR_SELECT_LOCAL_UPDATE: 4,
  OT_EDITOR_SELECT_LOCAL_RESET: 5,
  OT_EDITOR_SELECT_CELL: 6,
  OT_EDITOR_SELECT_OCCUPANCY: 7,
  OT_EDITOR_SELECT_INCLUSIVE: 8,
  OT_EDITOR_SELECT_COLORS: 9,
  OT_SELECT_DOCUMENT_SET: 0,
  OT_SELECT_DOCUMENT_UPDATE: 1,
  OT_SELECT_DOCUMENT_RESET: 2,
  OT_SELECT_VIEWPORT_SET: 3,
  OT_SELECT_VIEWPORT_UPDATE: 4,
  OT_SELECT_VIEWPORT_RESET: 5,
  OT_SELECTION_CELL: 0,
  OT_SELECTION_WORD: 1,
  OT_SELECTION_LINE: 2,
  OT_SELECTION_OCCUPANCY_CELL: 0,
  OT_SELECTION_OCCUPANCY_BOUNDARY: 1,
  OT_EDITOR_POSITION_CURSOR: 0,
  OT_EDITOR_POSITION_NEXT_WORD: 1,
  OT_EDITOR_POSITION_PREV_WORD: 2,
  OT_EDITOR_POSITION_EOL: 3,
  OT_EDITOR_POSITION_VISUAL_SOL: 4,
  OT_EDITOR_POSITION_VISUAL_EOL: 5,
  OT_IMAGE_FIT: 0,
  OT_IMAGE_COVER: 1,
  OT_IMAGE_FILL: 2,
  OT_IMAGE_PROTOCOL_AUTO: 0,
  OT_IMAGE_PROTOCOL_KITTY: 1,
  OT_IMAGE_PROTOCOL_SIXEL: 2,
  OT_IMAGE_PROTOCOL_BLOCKS: 3,
  OT_IMAGE_DRAW_SOURCE_WIDTH: 1,
  OT_IMAGE_DRAW_SOURCE_HEIGHT: 2,
  OT_IMAGE_FORMAT_UNKNOWN: 0,
  OT_IMAGE_FORMAT_PNG: 1,
  OT_IMAGE_FORMAT_RGBA: 2,
  OT_IMAGE_FORMAT_JPEG: 3,
  OT_IMAGE_FORMAT_WEBP: 4,
  OT_IMAGE_FORMAT_GIF: 5,
  OT_IMAGE_ASSUMED_SRGB: 0,
  OT_IMAGE_EXPLICIT_SRGB: 1,
  OT_IMAGE_RGBA8: 0,
  OT_IMAGE_BGRA8: 1,
  OT_IMAGE_ALPHA_STRAIGHT: 0,
  OT_IMAGE_ALPHA_OPAQUE: 1,
  OT_IMAGE_FILTER_DEFAULT: 0,
  OT_IMAGE_FILTER_AREA: 1,
  OT_IMAGE_FILTER_TRIANGLE: 2,
  OT_IMAGE_FILTER_CUBIC_BSPLINE: 3,
  OT_IMAGE_FILTER_CATMULL_ROM: 4,
  OT_IMAGE_FILTER_MITCHELL: 5,
  OT_IMAGE_FILTER_NEAREST: 6,
  OT_IMAGE_ROTATE_90: 0,
  OT_IMAGE_ROTATE_180: 1,
  OT_IMAGE_ROTATE_270: 2,
  OT_IMAGE_FLIP: 3,
  OT_IMAGE_FLOP: 4,
  OT_IMAGE_BLEND_SOURCE_OVER: 0,
  OT_IMAGE_BLEND_SOURCE: 1,
  OT_IMAGE_BLEND_DESTINATION_OVER: 2,
  OT_TEXT_VIEW_WRAP_WIDTH: 0,
  OT_TEXT_VIEW_WRAP_MODE: 1,
  OT_TEXT_VIEW_FIRST_LINE_OFFSET: 2,
  OT_TEXT_VIEW_TAB_INDICATOR: 3,
  OT_TEXT_VIEW_TRUNCATE: 4,
  OT_TEXT_VIEW_TEXT_ALIGN: 5,
  OT_TEXT_REPLACEMENT_COUNT_MAX: 256,
  OT_TEXT_REPLACEMENT_CHUNKS_MAX: 4096,
  OT_TEXT_REPLACEMENT_BYTES_MAX: 4194304,
  OT_TEXT_REPLACEMENT_URL_BYTES_MAX: 1048576,
  OT_BUFFER_TEXT_BYTES_MAX: 65536,
  OT_BUFFER_DRAW_CLEAR: 0,
  OT_BUFFER_DRAW_FILL: 1,
  OT_BUFFER_DRAW_TEXT: 2,
  OT_BUFFER_DRAW_CELL: 3,
  OT_BUFFER_DRAW_CELL_BLEND: 4,
  OT_BUFFER_DRAW_CHAR: 5,
  OT_BUFFER_DRAW_BOX: 6,
  OT_BUFFER_DRAW_COMPOSE: 7,
  OT_BUFFER_DRAW_RESPECT_ALPHA: 8,
  OT_BUFFER_DRAW_HAS_BACKGROUND: 1,
  OT_BUFFER_DRAW_HAS_SOURCE_WIDTH: 2,
  OT_BUFFER_DRAW_HAS_SOURCE_HEIGHT: 4,
  OT_BUFFER_STACK_DEPTH_MAX: 256,
  OT_BUFFER_STACK_GET_OPACITY: 0,
  OT_BUFFER_STACK_PUSH_SCISSOR: 1,
  OT_BUFFER_STACK_POP_SCISSOR: 2,
  OT_BUFFER_STACK_CLEAR_SCISSORS: 3,
  OT_BUFFER_STACK_PUSH_OPACITY: 4,
  OT_BUFFER_STACK_POP_OPACITY: 5,
  OT_BUFFER_STACK_CLEAR_OPACITY: 6,
  OT_BUFFER_GRID_INNER: 1,
  OT_BUFFER_GRID_OUTER: 2,
  OT_SESSION_CONTROL_PACKET_BYTES: 4096,
  OT_TERMINAL_ALTERNATE_SCREEN: 1,
  OT_TERMINAL_MOUSE: 2,
  OT_TERMINAL_MOUSE_MOVEMENT: 4,
  OT_TERMINAL_CLEAR_ON_CLOSE: 8,
  OT_CONTROL_CAPABILITY_RESPONSE: 1,
  OT_CONTROL_TITLE: 2,
  OT_CONTROL_MOUSE: 3,
  OT_CONTROL_KITTY_KEYBOARD_FLAGS: 4,
  OT_CONTROL_RESTORE_MODES: 5,
  OT_CONTROL_QUERY_PIXEL_RESOLUTION: 6,
  OT_CONTROL_QUERY_THEME_COLORS: 7,
  OT_CONTROL_CURSOR: 8,
  OT_CONTROL_RESET_BACKGROUND: 9,
  OT_CONTROL_PALETTE_QUERY: 10,
  OT_CONTROL_PROGRAM_STATUS: 11,
  OT_CURSOR_POSITION: 1,
  OT_CURSOR_STYLE: 2,
  OT_CURSOR_BLINKING: 4,
  OT_CURSOR_COLOR: 8,
  OT_CURSOR_MOUSE_POINTER: 16,
  OT_PROGRAM_STATE_IDLE: 1,
  OT_PROGRAM_STATE_WORKING: 2,
  OT_PROGRAM_STATE_DONE: 3,
  OT_PROGRAM_STATE_BLOCKED: 4,
  OT_PROGRAM_STATE_ERROR: 5,
  OT_PROGRAM_STATE_CLEAR: 6,
  OT_PROGRAM_KIND_PERMISSION: 1,
  OT_PROGRAM_KIND_QUESTION: 2,
  OT_PROGRAM_KIND_AUTH: 3,
  OT_PROGRAM_STATUS_PROGRESS: 1,
  OT_CAP_KITTY_KEYBOARD: 1,
  OT_CAP_KITTY_GRAPHICS: 2,
  OT_CAP_RGB: 4,
  OT_CAP_ANSI256: 8,
  OT_CAP_SGR_PIXELS: 16,
  OT_CAP_COLOR_SCHEME_UPDATES: 32,
  OT_CAP_EXPLICIT_WIDTH: 64,
  OT_CAP_SCALED_TEXT: 128,
  OT_CAP_SIXEL: 256,
  OT_CAP_FOCUS_TRACKING: 512,
  OT_CAP_SYNC: 1024,
  OT_CAP_BRACKETED_PASTE: 2048,
  OT_CAP_HYPERLINKS: 4096,
  OT_CAP_OSC52: 8192,
  OT_CAP_NOTIFICATIONS: 16384,
  OT_CAP_EXPLICIT_CURSOR_POSITIONING: 32768,
  OT_CAP_REMOTE: 65536,
  OT_CAP_PROGRAM_STATUS: 131072,
  OT_TERMINAL_UNINITIALIZED: 0,
  OT_TERMINAL_SETTING_UP: 1,
  OT_TERMINAL_ACTIVE: 2,
  OT_TERMINAL_SUSPENDING: 3,
  OT_TERMINAL_SUSPENDED: 4,
  OT_TERMINAL_RESUMING: 5,
  OT_TERMINAL_CLOSING: 6,
  OT_TERMINAL_RESTORED: 7,
  OT_TERMINAL_FAILED: 8,
  OT_TERMINAL_CANCELLED: 9,
  OT_PUMP_IDLE: 0,
  OT_PUMP_AGAIN: 1,
  OT_PUMP_OUTPUT_PENDING: 2,
  OT_PUMP_WAIT_UNTIL: 3,
  OT_PUMP_CLOSED: 4,
  OT_DIAGNOSTIC_MESSAGE_BYTES: 4096,
  OT_DIAGNOSTIC_TRUNCATED: 1,
  OT_SCENE_RECORD_BYTES_MAX: 67108864,
  OT_SCENE_RECORD_PHASE_BEFORE: 0,
  OT_SCENE_RECORD_PHASE_SELF: 1,
  OT_SCENE_RECORD_PHASE_AFTER: 2,
  OT_SCENE_RECORD_SLOT: 0,
  OT_SCENE_RECORD_DRAW: 1,
  OT_SCENE_RECORD_STACK: 2,
  OT_SCENE_RECORD_GRID: 3,
  OT_SCENE_RECORD_PACKED: 4,
  OT_SCENE_RECORD_SUPERSAMPLE: 5,
  OT_SCENE_RECORD_GRAYSCALE: 6,
  OT_SCENE_RECORD_COLOR_MATRIX: 7,
  OT_SCENE_RECORD_TEXT_VIEW: 8,
  OT_SCENE_RECORD_EDITOR_VIEW: 9,
  OT_SCENE_RECORD_SCENE_TEXT: 10,
  OT_SCENE_RECORD_IMAGE: 11,
  OT_SCENE_RECORD_UNICODE: 12,
  OT_SCENE_RECORD_GRAYSCALE_FOREGROUND: 1,
  OT_SCENE_RECORD_GRAYSCALE_BACKGROUND: 2,
  OT_SCENE_RECORD_GRAYSCALE_SUPERSAMPLED: 4,
  OT_CLIPBOARD_OPERATION_PENDING: 0,
  OT_CLIPBOARD_OPERATION_READ: 1,
  OT_CLIPBOARD_OPERATION_EMPTY: 2,
  OT_CLIPBOARD_OPERATION_WRITTEN: 3,
  OT_CLIPBOARD_OPERATION_CLEARED: 4,
  OT_CLIPBOARD_OPERATION_UNSUPPORTED: 5,
  OT_CLIPBOARD_OPERATION_CANCELLED: 6,
  OT_CLIPBOARD_OPERATION_TIMED_OUT: 7,
  OT_CLIPBOARD_OPERATION_LIMIT_EXCEEDED: 8,
  OT_CLIPBOARD_OPERATION_FAILED: 9,
  OT_CLIPBOARD_OPERATION_INVALID_HANDLE: 10,
  OT_CLIPBOARD_START_OK: 0,
  OT_CLIPBOARD_START_INVALID_SERVICE: 1,
  OT_CLIPBOARD_START_SHUTTING_DOWN: 2,
  OT_CLIPBOARD_START_LIMIT_EXCEEDED: 3,
  OT_CLIPBOARD_START_INVALID_ARGUMENT: 4,
  OT_CLIPBOARD_START_OUT_OF_MEMORY: 5,
  OT_CLIPBOARD_CANCEL_REQUESTED: 0,
  OT_CLIPBOARD_CANCEL_ALREADY_TERMINAL: 1,
  OT_CLIPBOARD_CANCEL_INVALID_HANDLE: 2,
  OT_CLIPBOARD_COPY_OK: 0,
  OT_CLIPBOARD_COPY_BUFFER_TOO_SMALL: 1,
  OT_CLIPBOARD_COPY_INVALID_HANDLE: 2,
  OT_CLIPBOARD_COPY_INVALID_STATE: 3,
  OT_CLIPBOARD_COPY_INVALID_ARGUMENT: 4,
  OT_CLIPBOARD_DESTROY_DESTROYED: 0,
  OT_CLIPBOARD_DESTROY_NOT_READY: 1,
  OT_CLIPBOARD_DESTROY_INVALID_HANDLE: 2,
  OT_CLIPBOARD_SHUTDOWN_PENDING: 0,
  OT_CLIPBOARD_SHUTDOWN_READY: 1,
  OT_CLIPBOARD_SHUTDOWN_INVALID_HANDLE: 2
};
var nativeStyleEnumMaxima = [2, 3, 5, 8, 8, 8, 2, 2, 2, 1, 1];

// src/platform/ffi.ts
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
var FFIType = {
  char: "char",
  int8_t: "int8_t",
  i8: "i8",
  uint8_t: "uint8_t",
  u8: "u8",
  int16_t: "int16_t",
  i16: "i16",
  uint16_t: "uint16_t",
  u16: "u16",
  int32_t: "int32_t",
  i32: "i32",
  int: "int",
  uint32_t: "uint32_t",
  u32: "u32",
  int64_t: "int64_t",
  i64: "i64",
  uint64_t: "uint64_t",
  u64: "u64",
  double: "double",
  f64: "f64",
  float: "float",
  f32: "f32",
  bool: "bool",
  ptr: "ptr",
  pointer: "pointer",
  void: "void",
  cstring: "cstring",
  function: "function",
  usize: "usize",
  callback: "callback",
  napi_env: "napi_env",
  napi_value: "napi_value",
  buffer: "buffer"
};
var FFI_UNAVAILABLE = "OpenTUI native FFI is not available for this runtime yet";
var BUN_DLOPEN_NULL = "Bun FFI backend does not support dlopen(null)";
var LIBRARY_CLOSED = "Cannot create FFI callback after library.close() has been called";
var NODE_CALLBACK_THREADSAFE = "Node FFI callbacks are same-thread only and do not support threadsafe callbacks";
var NODE_NAPI_UNSUPPORTED = "Node FFI backend does not support Bun N-API FFI types";
var NODE_POINTER_OVERRIDE = "Node FFI backend does not support FFIFunction.ptr overrides";
var NODE_POINTER_ARGUMENT = "Node FFI pointer arguments must be a Pointer, ArrayBuffer, or ArrayBufferView";
var NODE_PTR_VALUE = "node:ffi ptr() only supports ArrayBuffer and ArrayBufferView values backed by ArrayBuffer";
var NODE_STRING_RETURN = "Node FFI backend does not normalize string return values (yet)";
var NODE_USIZE_UNSUPPORTED = "Node FFI backend does not support usize yet";
var POINTER_NEGATIVE = "Pointer must be non-negative";
var POINTER_OFFSET_NEGATIVE = "Pointer offset must be non-negative";
var POINTER_OFFSET_UNSAFE = "Pointer offset must be a safe integer";
var POINTER_UNSAFE = "Pointer exceeds safe integer range";
var arrayBufferByteLength = Object.getOwnPropertyDescriptor(ArrayBuffer.prototype, "byteLength")?.get;
function isArrayBuffer(value) {
  if (value === null || typeof value !== "object" || arrayBufferByteLength == null)
    return false;
  try {
    arrayBufferByteLength.call(value);
    return true;
  } catch {
    return false;
  }
}
function unavailable(cause) {
  throw new Error(FFI_UNAVAILABLE, { cause });
}
function createUnsupportedBackend(cause) {
  return {
    dlopen() {
      return unavailable(cause);
    },
    ptr() {
      return unavailable(cause);
    },
    suffix: "",
    toArrayBuffer() {
      return unavailable(cause);
    }
  };
}
var isBun = typeof process !== "undefined" && typeof process.versions === "object" && process.versions !== null && typeof process.versions.bun === "string";
var requireModule = createRequire(import.meta.url);
var backend = loadBackend();
function loadBackend() {
  if (isBun) {
    return createBunBackend(requireModule("bun:ffi"));
  }
  try {
    const nodeFfi = requireModule("node:ffi");
    return createNodeBackend(nodeFfi.default ?? nodeFfi);
  } catch (error) {
    return createUnsupportedBackend(error);
  }
}
function toPointer(value) {
  if (isBun && typeof value === "bigint") {
    return toSafeNumberPointer(value);
  }
  if (!isBun && typeof value === "number") {
    return toSafeBigIntPointer(value);
  }
  return value;
}
function ffiBool(value) {
  return value ? 1 : 0;
}
function toSafeNumberPointer(pointer) {
  if (pointer < 0n) {
    throw new Error(POINTER_NEGATIVE);
  }
  if (pointer > BigInt(Number.MAX_SAFE_INTEGER)) {
    throw new Error(POINTER_UNSAFE);
  }
  return Number(pointer);
}
function toSafeBigIntPointer(pointer) {
  if (pointer < 0) {
    throw new Error(POINTER_NEGATIVE);
  }
  if (!Number.isSafeInteger(pointer)) {
    throw new Error(POINTER_UNSAFE);
  }
  return BigInt(pointer);
}
function createManagedCallback(raw, callbacks) {
  let ptr = raw.ptr;
  let closed = false;
  const instance = {
    get ptr() {
      return ptr;
    },
    get threadsafe() {
      return raw.threadsafe;
    },
    close() {
      if (closed) {
        return;
      }
      closed = true;
      callbacks.delete(instance);
      try {
        raw.close();
      } finally {
        ptr = null;
      }
    }
  };
  callbacks.add(instance);
  return instance;
}
function normalizeBunDefinitions(definitions) {
  return Object.fromEntries(Object.entries(definitions).map(([name, definition]) => [name, normalizeBunDefinition(definition)]));
}
function normalizeBunDefinition(definition) {
  return {
    args: definition.args,
    returns: definition.returns,
    ptr: definition.ptr == null ? undefined : toBunPointer(definition.ptr),
    threadsafe: definition.threadsafe
  };
}
function toBunPointer(pointer) {
  return typeof pointer === "bigint" ? toSafeNumberPointer(pointer) : pointer;
}
function createBunBackend(bun) {
  return {
    dlopen(path, symbols) {
      if (path === null) {
        throw new Error(BUN_DLOPEN_NULL);
      }
      const library = bun.dlopen(path, normalizeBunDefinitions(symbols));
      const callbacks = new Set;
      let closed = false;
      return {
        symbols: library.symbols,
        createCallback(callback, definition) {
          if (closed) {
            throw new Error(LIBRARY_CLOSED);
          }
          const raw = new bun.JSCallback(callback, normalizeBunDefinition(definition));
          return createManagedCallback(raw, callbacks);
        },
        close() {
          if (closed) {
            return;
          }
          closed = true;
          try {
            library.close();
          } finally {
            for (const callback of [...callbacks]) {
              callback.close();
            }
          }
        }
      };
    },
    ptr: bun.ptr,
    suffix: bun.suffix,
    toArrayBuffer(pointer, offset, length) {
      return bun.toArrayBuffer(toBunPointer(pointer), offset, length);
    }
  };
}
function createNodeBackend(nodeFfi) {
  return {
    dlopen(path, symbols) {
      const { lib, functions } = nodeFfi.dlopen(toNodeLibraryPath(path), normalizeNodeDefinitions(symbols));
      const callbacks = new Set;
      let closed = false;
      let libraryClosed = false;
      return {
        symbols: wrapNodeSymbols(functions, symbols),
        createCallback(callback, definition) {
          if (closed) {
            throw new Error(LIBRARY_CLOSED);
          }
          if (definition.threadsafe) {
            throw new Error(NODE_CALLBACK_THREADSAFE);
          }
          const callbackPointer = lib.registerCallback(normalizeNodeDefinition(definition), callback);
          const raw = {
            ptr: callbackPointer,
            threadsafe: false,
            close() {
              if (!libraryClosed) {
                lib.unregisterCallback(callbackPointer);
              }
            }
          };
          return createManagedCallback(raw, callbacks);
        },
        close() {
          if (closed) {
            return;
          }
          closed = true;
          try {
            libraryClosed = true;
            lib.close();
          } finally {
            for (const callback of [...callbacks]) {
              callback.close();
            }
          }
        }
      };
    },
    ptr(value) {
      return toNodeSourcePointer(nodeFfi, value);
    },
    suffix: nodeFfi.suffix,
    toArrayBuffer(pointer, offset, length) {
      return nodeFfi.toArrayBuffer(toBigIntPointer(pointer) + toNodePointerOffset(offset), length, false);
    }
  };
}
function toNodeLibraryPath(path) {
  return path instanceof URL ? fileURLToPath(path) : path;
}
function normalizeNodeDefinitions(definitions) {
  return Object.fromEntries(Object.entries(definitions).map(([name, definition]) => [name, normalizeNodeDefinition(definition)]));
}
function wrapNodeSymbols(functions, definitions) {
  return Object.fromEntries(Object.entries(functions).map(([name, fn]) => [name, wrapNodeSymbol(fn, definitions[name])]));
}
function wrapNodeSymbol(fn, definition) {
  const pointerArgIndexes = (definition.args ?? []).flatMap((type, index) => isNodePointerArgumentType(type) ? [index] : []);
  if (pointerArgIndexes.length === 0) {
    return fn;
  }
  if (definition.args?.length === 7 && pointerArgIndexes.length >= 2) {
    return wrapNodeSymbol7(fn, pointerArgIndexes);
  }
  if (definition.args?.length === 8) {
    return wrapNodeSymbol8(fn, pointerArgIndexes);
  }
  const pointerArgs = new Set(pointerArgIndexes);
  const normalize = (value, index) => pointerArgs.has(index) ? toNodePointerArgumentFast(value) : value;
  switch (definition.args?.length) {
    case 1:
      return function(arg0) {
        if (arguments.length !== 1)
          return Reflect.apply(fn, undefined, arguments);
        return fn(normalize(arg0, 0));
      };
    case 2:
      return function(arg0, arg1) {
        if (arguments.length !== 2)
          return Reflect.apply(fn, undefined, arguments);
        return fn(normalize(arg0, 0), normalize(arg1, 1));
      };
    case 3:
      return function(arg0, arg1, arg2) {
        if (arguments.length !== 3)
          return Reflect.apply(fn, undefined, arguments);
        return fn(normalize(arg0, 0), normalize(arg1, 1), normalize(arg2, 2));
      };
  }
  return (...args) => {
    const normalizedArgs = args.slice();
    for (const index of pointerArgIndexes) {
      normalizedArgs[index] = toNodePointerArgument(normalizedArgs[index]);
    }
    return fn(...normalizedArgs);
  };
}
function wrapNodeSymbol7(fn, pointerArgIndexes) {
  const pointer0 = pointerArgIndexes.includes(0);
  const pointer1 = pointerArgIndexes.includes(1);
  const pointer2 = pointerArgIndexes.includes(2);
  const pointer3 = pointerArgIndexes.includes(3);
  const pointer4 = pointerArgIndexes.includes(4);
  const pointer5 = pointerArgIndexes.includes(5);
  const pointer6 = pointerArgIndexes.includes(6);
  const normalize = (value, pointer) => pointer ? toNodePointerArgumentFast(value) : value;
  return function(arg0, arg1, arg2, arg3, arg4, arg5, arg6) {
    if (arguments.length !== 7)
      return Reflect.apply(fn, undefined, arguments);
    return fn(normalize(arg0, pointer0), normalize(arg1, pointer1), normalize(arg2, pointer2), normalize(arg3, pointer3), normalize(arg4, pointer4), normalize(arg5, pointer5), normalize(arg6, pointer6));
  };
}
function wrapNodeSymbol8(fn, pointerArgIndexes) {
  const pointer0 = pointerArgIndexes.includes(0);
  const pointer1 = pointerArgIndexes.includes(1);
  const pointer2 = pointerArgIndexes.includes(2);
  const pointer3 = pointerArgIndexes.includes(3);
  const pointer4 = pointerArgIndexes.includes(4);
  const pointer5 = pointerArgIndexes.includes(5);
  const pointer6 = pointerArgIndexes.includes(6);
  const pointer7 = pointerArgIndexes.includes(7);
  const normalize = (value, pointer) => pointer ? toNodePointerArgumentFast(value) : value;
  return function(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7) {
    if (arguments.length !== 8)
      return Reflect.apply(fn, undefined, arguments);
    return fn(normalize(arg0, pointer0), normalize(arg1, pointer1), normalize(arg2, pointer2), normalize(arg3, pointer3), normalize(arg4, pointer4), normalize(arg5, pointer5), normalize(arg6, pointer6), normalize(arg7, pointer7));
  };
}
function toNodePointerArgumentFast(value) {
  if (typeof value === "bigint") {
    return value >= 0n ? value : toNodePointerArgument(value);
  }
  if (ArrayBuffer.isView(value) && value.byteLength > 0 && value.buffer instanceof ArrayBuffer) {
    return value;
  }
  if (value instanceof ArrayBuffer && value.byteLength > 0) {
    return value;
  }
  return toNodePointerArgument(value);
}
function isNodePointerArgumentType(type) {
  return type === FFIType.ptr || type === FFIType.pointer || type === FFIType.function || type === FFIType.callback;
}
function toNodePointerArgument(value) {
  if (value == null) {
    return 0n;
  }
  if (typeof value === "number" || typeof value === "bigint") {
    return toBigIntPointer(value);
  }
  if (ArrayBuffer.isView(value)) {
    if (!isArrayBuffer(value.buffer)) {
      throw new TypeError(NODE_PTR_VALUE);
    }
    if (value.byteLength === 0) {
      return 0n;
    }
    return value;
  }
  if (isArrayBuffer(value)) {
    if (value.byteLength === 0) {
      return 0n;
    }
    return value;
  }
  throw new TypeError(NODE_POINTER_ARGUMENT);
}
function toNodeSourcePointer(nodeFfi, value) {
  if (ArrayBuffer.isView(value)) {
    if (!isArrayBuffer(value.buffer)) {
      throw new TypeError(NODE_PTR_VALUE);
    }
    return nodeFfi.getRawPointer(value.buffer) + BigInt(value.byteOffset);
  }
  if (isArrayBuffer(value)) {
    return nodeFfi.getRawPointer(value);
  }
  throw new TypeError(NODE_PTR_VALUE);
}
function toNodePointerOffset(offset) {
  if (offset == null) {
    return 0n;
  }
  if (offset < 0) {
    throw new Error(POINTER_OFFSET_NEGATIVE);
  }
  if (!Number.isSafeInteger(offset)) {
    throw new Error(POINTER_OFFSET_UNSAFE);
  }
  return BigInt(offset);
}
function normalizeNodeDefinition(definition) {
  if (definition.ptr != null) {
    throw new Error(NODE_POINTER_OVERRIDE);
  }
  return {
    arguments: (definition.args ?? []).map((type) => toNodeFFIType(type, "parameter")),
    return: toNodeFFIType(definition.returns ?? FFIType.void, "result")
  };
}
function toNodeFFIType(type, position) {
  switch (type) {
    case FFIType.char:
      return "char";
    case FFIType.int8_t:
    case FFIType.i8:
      return "i8";
    case FFIType.uint8_t:
    case FFIType.u8:
      return "u8";
    case FFIType.int16_t:
    case FFIType.i16:
      return "i16";
    case FFIType.uint16_t:
    case FFIType.u16:
      return "u16";
    case FFIType.int32_t:
    case FFIType.int:
    case FFIType.i32:
      return "i32";
    case FFIType.uint32_t:
    case FFIType.u32:
      return "u32";
    case FFIType.int64_t:
    case FFIType.i64:
      return "i64";
    case FFIType.uint64_t:
    case FFIType.u64:
      return "u64";
    case FFIType.double:
    case FFIType.f64:
      return "f64";
    case FFIType.float:
    case FFIType.f32:
      return "f32";
    case FFIType.bool:
      return "bool";
    case FFIType.ptr:
    case FFIType.pointer:
      return "pointer";
    case FFIType.void:
      return "void";
    case FFIType.cstring:
      if (position === "result") {
        throw new Error(NODE_STRING_RETURN);
      }
      return "string";
    case FFIType.function:
    case FFIType.callback:
      return "pointer";
    case FFIType.usize:
      throw new Error(NODE_USIZE_UNSUPPORTED);
    case FFIType.napi_env:
    case FFIType.napi_value:
      throw new Error(NODE_NAPI_UNSUPPORTED);
    case FFIType.buffer:
      return "pointer";
    default:
      return unsupportedNodeFFIType(type);
  }
}
function unsupportedNodeFFIType(type) {
  throw new Error(`Unsupported FFIType for node:ffi: ${String(type)}`);
}
function toBigIntPointer(pointer) {
  if (typeof pointer === "bigint") {
    if (pointer < 0n) {
      throw new Error(POINTER_NEGATIVE);
    }
    return pointer;
  }
  return toSafeBigIntPointer(pointer);
}
var dlopen = backend.dlopen;
var ptr = backend.ptr;
var suffix = backend.suffix;
var toArrayBuffer = backend.toArrayBuffer;

// src/platform/runtime.ts
import { existsSync } from "node:fs";
import { mkdir, writeFile as writeFileNode } from "node:fs/promises";
import { dirname, isAbsolute as isAbsolute2, resolve } from "node:path";
import { fileURLToPath as fileURLToPath3 } from "node:url";

// ../../node_modules/.bun/ansi-regex@6.2.2/node_modules/ansi-regex/index.js
function ansiRegex({ onlyFirst = false } = {}) {
  const ST = "(?:\\u0007|\\u001B\\u005C|\\u009C)";
  const osc = `(?:\\u001B\\][\\s\\S]*?${ST})`;
  const csi = "[\\u001B\\u009B][[\\]()#;?]*(?:\\d{1,4}(?:[;:]\\d{0,4})*)?[\\dA-PR-TZcf-nq-uy=><~]";
  const pattern = `${osc}|${csi}`;
  return new RegExp(pattern, onlyFirst ? undefined : "g");
}

// ../../node_modules/.bun/strip-ansi@7.1.2/node_modules/strip-ansi/index.js
var regex = ansiRegex();
function stripAnsi(string) {
  if (typeof string !== "string") {
    throw new TypeError(`Expected a \`string\`, got \`${typeof string}\``);
  }
  return string.replace(regex, "");
}

// ../../node_modules/.bun/get-east-asian-width@1.4.0/node_modules/get-east-asian-width/lookup.js
function isAmbiguous(x) {
  return x === 161 || x === 164 || x === 167 || x === 168 || x === 170 || x === 173 || x === 174 || x >= 176 && x <= 180 || x >= 182 && x <= 186 || x >= 188 && x <= 191 || x === 198 || x === 208 || x === 215 || x === 216 || x >= 222 && x <= 225 || x === 230 || x >= 232 && x <= 234 || x === 236 || x === 237 || x === 240 || x === 242 || x === 243 || x >= 247 && x <= 250 || x === 252 || x === 254 || x === 257 || x === 273 || x === 275 || x === 283 || x === 294 || x === 295 || x === 299 || x >= 305 && x <= 307 || x === 312 || x >= 319 && x <= 322 || x === 324 || x >= 328 && x <= 331 || x === 333 || x === 338 || x === 339 || x === 358 || x === 359 || x === 363 || x === 462 || x === 464 || x === 466 || x === 468 || x === 470 || x === 472 || x === 474 || x === 476 || x === 593 || x === 609 || x === 708 || x === 711 || x >= 713 && x <= 715 || x === 717 || x === 720 || x >= 728 && x <= 731 || x === 733 || x === 735 || x >= 768 && x <= 879 || x >= 913 && x <= 929 || x >= 931 && x <= 937 || x >= 945 && x <= 961 || x >= 963 && x <= 969 || x === 1025 || x >= 1040 && x <= 1103 || x === 1105 || x === 8208 || x >= 8211 && x <= 8214 || x === 8216 || x === 8217 || x === 8220 || x === 8221 || x >= 8224 && x <= 8226 || x >= 8228 && x <= 8231 || x === 8240 || x === 8242 || x === 8243 || x === 8245 || x === 8251 || x === 8254 || x === 8308 || x === 8319 || x >= 8321 && x <= 8324 || x === 8364 || x === 8451 || x === 8453 || x === 8457 || x === 8467 || x === 8470 || x === 8481 || x === 8482 || x === 8486 || x === 8491 || x === 8531 || x === 8532 || x >= 8539 && x <= 8542 || x >= 8544 && x <= 8555 || x >= 8560 && x <= 8569 || x === 8585 || x >= 8592 && x <= 8601 || x === 8632 || x === 8633 || x === 8658 || x === 8660 || x === 8679 || x === 8704 || x === 8706 || x === 8707 || x === 8711 || x === 8712 || x === 8715 || x === 8719 || x === 8721 || x === 8725 || x === 8730 || x >= 8733 && x <= 8736 || x === 8739 || x === 8741 || x >= 8743 && x <= 8748 || x === 8750 || x >= 8756 && x <= 8759 || x === 8764 || x === 8765 || x === 8776 || x === 8780 || x === 8786 || x === 8800 || x === 8801 || x >= 8804 && x <= 8807 || x === 8810 || x === 8811 || x === 8814 || x === 8815 || x === 8834 || x === 8835 || x === 8838 || x === 8839 || x === 8853 || x === 8857 || x === 8869 || x === 8895 || x === 8978 || x >= 9312 && x <= 9449 || x >= 9451 && x <= 9547 || x >= 9552 && x <= 9587 || x >= 9600 && x <= 9615 || x >= 9618 && x <= 9621 || x === 9632 || x === 9633 || x >= 9635 && x <= 9641 || x === 9650 || x === 9651 || x === 9654 || x === 9655 || x === 9660 || x === 9661 || x === 9664 || x === 9665 || x >= 9670 && x <= 9672 || x === 9675 || x >= 9678 && x <= 9681 || x >= 9698 && x <= 9701 || x === 9711 || x === 9733 || x === 9734 || x === 9737 || x === 9742 || x === 9743 || x === 9756 || x === 9758 || x === 9792 || x === 9794 || x === 9824 || x === 9825 || x >= 9827 && x <= 9829 || x >= 9831 && x <= 9834 || x === 9836 || x === 9837 || x === 9839 || x === 9886 || x === 9887 || x === 9919 || x >= 9926 && x <= 9933 || x >= 9935 && x <= 9939 || x >= 9941 && x <= 9953 || x === 9955 || x === 9960 || x === 9961 || x >= 9963 && x <= 9969 || x === 9972 || x >= 9974 && x <= 9977 || x === 9979 || x === 9980 || x === 9982 || x === 9983 || x === 10045 || x >= 10102 && x <= 10111 || x >= 11094 && x <= 11097 || x >= 12872 && x <= 12879 || x >= 57344 && x <= 63743 || x >= 65024 && x <= 65039 || x === 65533 || x >= 127232 && x <= 127242 || x >= 127248 && x <= 127277 || x >= 127280 && x <= 127337 || x >= 127344 && x <= 127373 || x === 127375 || x === 127376 || x >= 127387 && x <= 127404 || x >= 917760 && x <= 917999 || x >= 983040 && x <= 1048573 || x >= 1048576 && x <= 1114109;
}
function isFullWidth(x) {
  return x === 12288 || x >= 65281 && x <= 65376 || x >= 65504 && x <= 65510;
}
function isWide(x) {
  return x >= 4352 && x <= 4447 || x === 8986 || x === 8987 || x === 9001 || x === 9002 || x >= 9193 && x <= 9196 || x === 9200 || x === 9203 || x === 9725 || x === 9726 || x === 9748 || x === 9749 || x >= 9776 && x <= 9783 || x >= 9800 && x <= 9811 || x === 9855 || x >= 9866 && x <= 9871 || x === 9875 || x === 9889 || x === 9898 || x === 9899 || x === 9917 || x === 9918 || x === 9924 || x === 9925 || x === 9934 || x === 9940 || x === 9962 || x === 9970 || x === 9971 || x === 9973 || x === 9978 || x === 9981 || x === 9989 || x === 9994 || x === 9995 || x === 10024 || x === 10060 || x === 10062 || x >= 10067 && x <= 10069 || x === 10071 || x >= 10133 && x <= 10135 || x === 10160 || x === 10175 || x === 11035 || x === 11036 || x === 11088 || x === 11093 || x >= 11904 && x <= 11929 || x >= 11931 && x <= 12019 || x >= 12032 && x <= 12245 || x >= 12272 && x <= 12287 || x >= 12289 && x <= 12350 || x >= 12353 && x <= 12438 || x >= 12441 && x <= 12543 || x >= 12549 && x <= 12591 || x >= 12593 && x <= 12686 || x >= 12688 && x <= 12773 || x >= 12783 && x <= 12830 || x >= 12832 && x <= 12871 || x >= 12880 && x <= 42124 || x >= 42128 && x <= 42182 || x >= 43360 && x <= 43388 || x >= 44032 && x <= 55203 || x >= 63744 && x <= 64255 || x >= 65040 && x <= 65049 || x >= 65072 && x <= 65106 || x >= 65108 && x <= 65126 || x >= 65128 && x <= 65131 || x >= 94176 && x <= 94180 || x >= 94192 && x <= 94198 || x >= 94208 && x <= 101589 || x >= 101631 && x <= 101662 || x >= 101760 && x <= 101874 || x >= 110576 && x <= 110579 || x >= 110581 && x <= 110587 || x === 110589 || x === 110590 || x >= 110592 && x <= 110882 || x === 110898 || x >= 110928 && x <= 110930 || x === 110933 || x >= 110948 && x <= 110951 || x >= 110960 && x <= 111355 || x >= 119552 && x <= 119638 || x >= 119648 && x <= 119670 || x === 126980 || x === 127183 || x === 127374 || x >= 127377 && x <= 127386 || x >= 127488 && x <= 127490 || x >= 127504 && x <= 127547 || x >= 127552 && x <= 127560 || x === 127568 || x === 127569 || x >= 127584 && x <= 127589 || x >= 127744 && x <= 127776 || x >= 127789 && x <= 127797 || x >= 127799 && x <= 127868 || x >= 127870 && x <= 127891 || x >= 127904 && x <= 127946 || x >= 127951 && x <= 127955 || x >= 127968 && x <= 127984 || x === 127988 || x >= 127992 && x <= 128062 || x === 128064 || x >= 128066 && x <= 128252 || x >= 128255 && x <= 128317 || x >= 128331 && x <= 128334 || x >= 128336 && x <= 128359 || x === 128378 || x === 128405 || x === 128406 || x === 128420 || x >= 128507 && x <= 128591 || x >= 128640 && x <= 128709 || x === 128716 || x >= 128720 && x <= 128722 || x >= 128725 && x <= 128728 || x >= 128732 && x <= 128735 || x === 128747 || x === 128748 || x >= 128756 && x <= 128764 || x >= 128992 && x <= 129003 || x === 129008 || x >= 129292 && x <= 129338 || x >= 129340 && x <= 129349 || x >= 129351 && x <= 129535 || x >= 129648 && x <= 129660 || x >= 129664 && x <= 129674 || x >= 129678 && x <= 129734 || x === 129736 || x >= 129741 && x <= 129756 || x >= 129759 && x <= 129770 || x >= 129775 && x <= 129784 || x >= 131072 && x <= 196605 || x >= 196608 && x <= 262141;
}

// ../../node_modules/.bun/get-east-asian-width@1.4.0/node_modules/get-east-asian-width/index.js
function validate(codePoint) {
  if (!Number.isSafeInteger(codePoint)) {
    throw new TypeError(`Expected a code point, got \`${typeof codePoint}\`.`);
  }
}
function eastAsianWidth(codePoint, { ambiguousAsWide = false } = {}) {
  validate(codePoint);
  if (isFullWidth(codePoint) || isWide(codePoint) || ambiguousAsWide && isAmbiguous(codePoint)) {
    return 2;
  }
  return 1;
}

// ../../node_modules/.bun/string-width@7.2.0/node_modules/string-width/index.js
var import_emoji_regex = __toESM(require_emoji_regex(), 1);
var segmenter = new Intl.Segmenter;
var defaultIgnorableCodePointRegex = /^\p{Default_Ignorable_Code_Point}$/u;
function stringWidth2(string, options = {}) {
  if (typeof string !== "string" || string.length === 0) {
    return 0;
  }
  const {
    ambiguousIsNarrow = true,
    countAnsiEscapeCodes = false
  } = options;
  if (!countAnsiEscapeCodes) {
    string = stripAnsi(string);
  }
  if (string.length === 0) {
    return 0;
  }
  let width = 0;
  const eastAsianWidthOptions = { ambiguousAsWide: !ambiguousIsNarrow };
  for (const { segment: character } of segmenter.segment(string)) {
    const codePoint = character.codePointAt(0);
    if (codePoint <= 31 || codePoint >= 127 && codePoint <= 159) {
      continue;
    }
    if (codePoint >= 8203 && codePoint <= 8207 || codePoint === 65279) {
      continue;
    }
    if (codePoint >= 768 && codePoint <= 879 || codePoint >= 6832 && codePoint <= 6911 || codePoint >= 7616 && codePoint <= 7679 || codePoint >= 8400 && codePoint <= 8447 || codePoint >= 65056 && codePoint <= 65071) {
      continue;
    }
    if (codePoint >= 55296 && codePoint <= 57343) {
      continue;
    }
    if (codePoint >= 65024 && codePoint <= 65039) {
      continue;
    }
    if (defaultIgnorableCodePointRegex.test(character)) {
      continue;
    }
    if (import_emoji_regex.default().test(character)) {
      width += 2;
      continue;
    }
    width += eastAsianWidth(codePoint, eastAsianWidthOptions);
  }
  return width;
}

// src/platform/assets.ts
import { statSync } from "node:fs";
import { isAbsolute, join } from "node:path";
import { fileURLToPath as fileURLToPath2 } from "node:url";

// src/lib/singleton.ts
var singletonCacheSymbol = Symbol.for("@opentui/core/singleton");
function singleton(key, factory) {
  const bag = globalThis[singletonCacheSymbol] ??= {};
  if (!(key in bag)) {
    bag[key] = factory();
  }
  return bag[key];
}
function getSingleton(key) {
  const bag = globalThis[singletonCacheSymbol];
  return bag?.[key];
}
function destroySingleton(key) {
  const bag = globalThis[singletonCacheSymbol];
  if (bag && key in bag) {
    delete bag[key];
  }
}

// src/lib/env.ts
var envRegistry2 = singleton("env-registry", () => ({}));
function registerEnvVar2(config) {
  const existing = envRegistry2[config.name];
  if (existing) {
    if (existing.description !== config.description || existing.type !== config.type || existing.default !== config.default || existing.required !== config.required) {
      throw new Error(`Environment variable "${config.name}" is already registered with different configuration. ` + `Existing: ${JSON.stringify(existing)}, New: ${JSON.stringify(config)}`);
    }
    return;
  }
  envRegistry2[config.name] = config;
}
function normalizeBoolean(value) {
  const lowerValue = value.toLowerCase();
  return ["true", "1", "on", "yes"].includes(lowerValue);
}
function parseEnvValue(config) {
  const envValue = process.env[config.name];
  if (envValue === undefined && config.default !== undefined) {
    return config.default;
  }
  if (envValue === undefined && config.required === false) {
    return;
  }
  if (envValue === undefined) {
    throw new Error(`Required environment variable ${config.name} is not set. ${config.description}`);
  }
  switch (config.type) {
    case "boolean":
      return typeof envValue === "boolean" ? envValue : normalizeBoolean(envValue);
    case "number":
      const numValue = Number(envValue);
      if (isNaN(numValue)) {
        throw new Error(`Environment variable ${config.name} must be a valid number, got: ${envValue}`);
      }
      return numValue;
    case "string":
    default:
      return envValue;
  }
}

class EnvStore {
  parsedValues = new Map;
  get(key) {
    if (this.parsedValues.has(key)) {
      return this.parsedValues.get(key);
    }
    if (!(key in envRegistry2)) {
      throw new Error(`Environment variable ${key} is not registered.`);
    }
    try {
      const value = parseEnvValue(envRegistry2[key]);
      this.parsedValues.set(key, value);
      return value;
    } catch (error) {
      throw new Error(`Failed to parse env var ${key}: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  has(key) {
    return key in envRegistry2;
  }
  clearCache() {
    this.parsedValues.clear();
  }
}
var envStore = singleton("env-store", () => new EnvStore);
function clearEnvCache2() {
  envStore.clearCache();
}
function generateEnvMarkdown2() {
  const configs = Object.values(envRegistry2);
  if (configs.length === 0) {
    return `# Environment Variables

No environment variables registered.
`;
  }
  let markdown = `# Environment Variables

`;
  for (const config of configs) {
    markdown += `## ${config.name}

`;
    markdown += `${config.description}

`;
    markdown += `**Type:** \`${config.type || "string"}\`  
`;
    if (config.default !== undefined) {
      const defaultValue = typeof config.default === "string" ? `"${config.default}"` : String(config.default);
      markdown += `**Default:** \`${defaultValue}\`
`;
    } else if (config.required === false) {
      markdown += `**Default:** *unset*
`;
    } else {
      markdown += `**Default:** *Required*
`;
    }
    markdown += `
`;
  }
  return markdown;
}
function generateEnvColored2() {
  const configs = Object.values(envRegistry2);
  if (configs.length === 0) {
    return `\x1B[1;36mEnvironment Variables\x1B[0m

No environment variables registered.
`;
  }
  let output = `\x1B[1;36mEnvironment Variables\x1B[0m

`;
  for (const config of configs) {
    output += `\x1B[1;33m${config.name}\x1B[0m
`;
    output += `${config.description}
`;
    output += `\x1B[32mType:\x1B[0m \x1B[36m${config.type || "string"}\x1B[0m
`;
    if (config.default !== undefined) {
      const defaultValue = typeof config.default === "string" ? `"${config.default}"` : String(config.default);
      output += `\x1B[32mDefault:\x1B[0m \x1B[35m${defaultValue}\x1B[0m
`;
    } else if (config.required === false) {
      output += `\x1B[32mDefault:\x1B[0m \x1B[35munset\x1B[0m
`;
    } else {
      output += `\x1B[32mDefault:\x1B[0m \x1B[31mRequired\x1B[0m
`;
    }
    output += `
`;
  }
  return output;
}
var env2 = new Proxy({}, {
  get(target, prop) {
    if (typeof prop !== "string") {
      return;
    }
    return envStore.get(prop);
  },
  has(target, prop) {
    return envStore.has(prop);
  },
  ownKeys() {
    return Object.keys(envRegistry2);
  },
  getOwnPropertyDescriptor(target, prop) {
    if (envStore.has(prop)) {
      return {
        enumerable: true,
        configurable: true,
        get: () => envStore.get(prop)
      };
    }
    return;
  }
});

// src/platform/assets.ts
registerEnvVar2({
  name: "OTUI_ASSET_ROOT",
  description: "Absolute directory containing relocatable OpenTUI runtime assets",
  type: "string",
  default: ""
});
function resolveAssetPath(key, fallback) {
  validateAssetKey(key);
  const configuredPath = resolveAssetRootPath(key);
  if (configuredPath !== undefined) {
    return configuredPath;
  }
  if (fallback === undefined) {
    throw new Error(`OpenTUI asset ${JSON.stringify(key)} has no package-relative fallback`);
  }
  const value = typeof fallback === "function" ? fallback() : fallback;
  return value instanceof URL ? fileURLToPath2(value) : value;
}
function resolveAssetRootPath(key) {
  validateAssetKey(key);
  const root = process.env.OTUI_ASSET_ROOT;
  if (!root) {
    return;
  }
  if (!isAbsolute(root)) {
    throw new Error(`OTUI_ASSET_ROOT must be an absolute directory, got ${JSON.stringify(root)}`);
  }
  const assetPath = join(root, key);
  let isFile = false;
  try {
    isFile = statSync(assetPath).isFile();
  } catch {}
  if (!isFile) {
    throw new Error(`Missing OpenTUI asset ${JSON.stringify(key)} at ${JSON.stringify(assetPath)}`);
  }
  return assetPath;
}
function validateAssetKey(key) {
  if (key.length === 0 || isAbsolute(key) || key.includes("\\") || key.split("/").includes("..")) {
    throw new Error(`Invalid OpenTUI asset key: ${JSON.stringify(key)}`);
  }
}

// src/platform/runtime.ts
var TEXT_ENCODER = new TextEncoder;
var bun = globalThis.Bun;
var sleep = bun?.sleep ?? standardSleep;
var stringWidth = bun?.stringWidth ?? stringWidth2;
var writeFile = bun?.write ?? writeFilePortable;
async function resolveBundledFilePath2(key, loadBundledFile, fallbackPath, metaUrl, options = {}) {
  if (options.useAssetRoot ?? true) {
    const configuredPath = resolveAssetRootPath(key);
    if (configuredPath !== undefined) {
      return configuredPath;
    }
  }
  if (!bun) {
    const path = resolveFallbackFilePath(fallbackPath, metaUrl);
    if (existsSync(path)) {
      return path;
    }
    return await loadBundledFilePath(loadBundledFile, metaUrl, options.loadBundledFileFallback ?? false) ?? path;
  }
  const loaded = (await loadBundledFile()).default;
  if (typeof loaded !== "string") {
    return resolveFallbackFilePath(fallbackPath, metaUrl);
  }
  return normalizeLoadedFilePath(loaded, metaUrl);
}
function resolveFallbackFilePath(fallbackPath, metaUrl) {
  const path = typeof fallbackPath === "function" ? fallbackPath() : fallbackPath;
  return fileURLToPath3(path instanceof URL ? path : new URL(path, metaUrl));
}
function normalizeLoadedFilePath(loadedPath, baseUrl) {
  if (loadedPath.startsWith("file:")) {
    return fileURLToPath3(loadedPath);
  }
  if (isAbsolute2(loadedPath)) {
    return loadedPath;
  }
  return resolve(dirname(fileURLToPath3(baseUrl)), loadedPath);
}
async function loadBundledFilePath(loadBundledFile, metaUrl, loadBundledFileFallback) {
  const specifier = extractBundledImportSpecifier(loadBundledFile);
  if (!specifier) {
    if (!loadBundledFileFallback) {
      return;
    }
    try {
      return normalizeLoadedFilePath((await loadBundledFile()).default, metaUrl);
    } catch {
      return;
    }
  }
  try {
    const moduleUrl = new URL(specifier, metaUrl);
    const loaded = await import(moduleUrl.href);
    return normalizeLoadedFilePath(loaded.default, moduleUrl.href);
  } catch {
    return;
  }
}
function extractBundledImportSpecifier(loadBundledFile) {
  const match = String(loadBundledFile).match(/\bimport\(\s*(["'`])([^"'`]+)\1/);
  return match?.[2];
}
function standardSleep(msOrDate) {
  const ms = msOrDate instanceof Date ? msOrDate.getTime() - Date.now() : msOrDate;
  return new Promise((resolve) => setTimeout(resolve, ms));
}
async function writeFilePortable(destination, data, options) {
  const destinationPath = destination instanceof URL ? fileURLToPath3(destination) : destination;
  if (options?.createPath) {
    await mkdir(dirname(destinationPath), { recursive: true });
  }
  const bytes = typeof data === "string" ? TEXT_ENCODER.encode(data) : new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  await writeFileNode(destinationPath, bytes, { mode: options?.mode });
  return bytes.byteLength;
}

// src/platform/worker.ts
var WORKER_UNAVAILABLE = "OpenTUI tree-sitter workers are not available for this runtime yet.";
var globalWithWorker = globalThis;
var nodeWorkerThreads = getBuiltinModule("node:worker_threads");
var runtimeBridge = loadWorkerRuntime(nodeWorkerThreads);

class UnsupportedWorker {
  onmessage = null;
  onerror = null;
  constructor() {
    throw new Error(WORKER_UNAVAILABLE);
  }
  postMessage() {
    throw new Error(WORKER_UNAVAILABLE);
  }
  terminate() {
    throw new Error(WORKER_UNAVAILABLE);
  }
  addEventListener() {
    throw new Error(WORKER_UNAVAILABLE);
  }
  removeEventListener() {
    throw new Error(WORKER_UNAVAILABLE);
  }
}
var Worker = loadWorkerConstructor();
var isWorkerRuntime = runtimeBridge !== undefined;
function getBuiltinModule(id) {
  if (typeof process === "undefined") {
    return;
  }
  const loader = process.getBuiltinModule;
  if (typeof loader !== "function") {
    return;
  }
  try {
    return loader(id);
  } catch {
    return;
  }
}
function loadWorkerConstructor() {
  if (typeof globalWithWorker.Worker === "function") {
    return globalWithWorker.Worker;
  }
  if (nodeWorkerThreads) {
    return createNodeWorkerConstructor(nodeWorkerThreads);
  }
  return UnsupportedWorker;
}
function createNodeWorkerConstructor(node) {
  return class NodeWorkerShim {
    onmessage = null;
    onerror = null;
    errorListeners = new Set;
    messageListeners = new Set;
    worker;
    terminationPromise;
    constructor(specifier, options = {}) {
      const resolvedSpecifier = resolveWorkerImportSpecifier(specifier);
      this.worker = new node.Worker(createWorkerBootstrapSource(resolvedSpecifier), {
        eval: true,
        type: "module",
        name: options.name
      });
      this.worker.on("message", this.handleMessage);
      this.worker.on("error", this.handleError);
    }
    postMessage(value) {
      this.worker.postMessage(value);
    }
    terminate() {
      if (this.terminationPromise) {
        return this.terminationPromise;
      }
      this.worker.off("message", this.handleMessage);
      const termination = this.worker.terminate().catch((error) => {
        this.terminationPromise = undefined;
        this.worker.on("message", this.handleMessage);
        throw error;
      });
      this.terminationPromise = termination;
      return termination;
    }
    addEventListener(type, listener) {
      if (type === "message") {
        this.messageListeners.add(listener);
        return;
      }
      this.errorListeners.add(listener);
    }
    removeEventListener(type, listener) {
      if (type === "message") {
        this.messageListeners.delete(listener);
        return;
      }
      this.errorListeners.delete(listener);
    }
    handleMessage = (data) => {
      const event = { data };
      this.onmessage?.(event);
      for (const listener of this.messageListeners) {
        listener(event);
      }
    };
    handleError = (error) => {
      const event = {
        error,
        message: error.message
      };
      this.onerror?.(event);
      for (const listener of this.errorListeners) {
        listener(event);
      }
    };
  };
}
function createWorkerBootstrapSource(specifier) {
  return `
    import { parentPort } from "node:worker_threads"

    const pendingMessages = []
    let messageHandler = null

    globalThis.self ??= globalThis
    globalThis.postMessage ??= (value) => parentPort?.postMessage(value)
    globalThis.__opentuiWorkerMessageBridge = true
    Object.defineProperty(globalThis, "onmessage", {
      configurable: true,
      get: () => messageHandler,
      set: (handler) => {
        messageHandler = typeof handler === "function" ? handler : null
        if (!messageHandler) return

        const messages = pendingMessages.splice(0)
        for (const data of messages) {
          messageHandler({ data })
        }
      },
    })
    parentPort?.on("message", (data) => {
      if (messageHandler) {
        messageHandler({ data })
      } else {
        pendingMessages.push(data)
      }
    })

    await import(${JSON.stringify(specifier)})
  `;
}
function resolveWorkerImportSpecifier(specifier) {
  if (specifier instanceof URL) {
    return specifier.href;
  }
  if (isRuntimeSpecifier(specifier)) {
    return specifier;
  }
  const nodePath = getBuiltinModule("node:path");
  const nodeUrl = getBuiltinModule("node:url");
  if (!nodePath || !nodeUrl) {
    throw new Error(WORKER_UNAVAILABLE);
  }
  const absolutePath = nodePath.isAbsolute(specifier) ? specifier : nodePath.resolve(specifier);
  return nodeUrl.pathToFileURL(absolutePath).href;
}
function isRuntimeSpecifier(specifier) {
  return specifier.startsWith("file:") || specifier.startsWith("data:") || specifier.startsWith("node:") || specifier.startsWith("http:") || specifier.startsWith("https:");
}
function loadWorkerRuntime(node) {
  if (node?.parentPort && node.isMainThread === false) {
    if (globalWithWorker.__opentuiWorkerMessageBridge) {
      return createGlobalWorkerRuntimeBridge();
    }
    return {
      postMessage(value) {
        node.parentPort?.postMessage(value);
      },
      setMessageHandler(handler) {
        const listener = (data) => {
          handler({ data });
        };
        node.parentPort?.on("message", listener);
        return () => {
          node.parentPort?.off("message", listener);
        };
      }
    };
  }
  if (!isGlobalWorkerRuntime()) {
    return;
  }
  return createGlobalWorkerRuntimeBridge();
}
function createGlobalWorkerRuntimeBridge() {
  let currentRegistration;
  return {
    postMessage(value) {
      globalWithWorker.postMessage?.(value);
    },
    setMessageHandler(handler) {
      const previousHandler = getGlobalWorkerMessageHandler();
      if (currentRegistration && previousHandler !== currentRegistration.listener) {
        currentRegistration = undefined;
      }
      const listener = (event) => {
        const normalizedEvent = normalizeWorkerMessageEvent(event);
        handler(normalizedEvent);
      };
      const registration = {
        active: true,
        fallbackHandler: currentRegistration ? currentRegistration.fallbackHandler : previousHandler,
        listener,
        previous: currentRegistration
      };
      currentRegistration = registration;
      setGlobalWorkerMessageHandler(listener);
      return () => {
        registration.active = false;
        if (currentRegistration !== registration || getGlobalWorkerMessageHandler() !== listener) {
          return;
        }
        let previous = registration.previous;
        while (previous && !previous.active) {
          previous = previous.previous;
        }
        currentRegistration = previous;
        setGlobalWorkerMessageHandler(previous?.listener ?? registration.fallbackHandler);
      };
    }
  };
}
function isGlobalWorkerRuntime() {
  if (typeof globalWithWorker.postMessage !== "function") {
    return false;
  }
  return typeof document === "undefined" && typeof globalWithWorker.close === "function" && "onmessage" in globalThis;
}
function normalizeWorkerMessageEvent(event) {
  if (event && typeof event === "object" && "data" in event) {
    return event;
  }
  return { data: event };
}
function getGlobalWorkerMessageHandler() {
  return globalThis.onmessage ?? null;
}
function setGlobalWorkerMessageHandler(handler) {
  globalThis.onmessage = handler;
}

// src/zig.ts
import { existsSync as existsSync2, writeFileSync } from "fs";

// src/types.ts
var TextAttributes2 = {
  NONE: 0,
  BOLD: 1 << 0,
  DIM: 1 << 1,
  ITALIC: 1 << 2,
  UNDERLINE: 1 << 3,
  BLINK: 1 << 4,
  INVERSE: 1 << 5,
  HIDDEN: 1 << 6,
  STRIKETHROUGH: 1 << 7
};
var ATTRIBUTE_BASE_BITS2 = 8;
var ATTRIBUTE_BASE_MASK2 = 255;
function getBaseAttributes2(attr) {
  return attr & ATTRIBUTE_BASE_MASK2;
}
var DebugOverlayCorner2;
((DebugOverlayCorner) => {
  DebugOverlayCorner[DebugOverlayCorner["topLeft"] = 0] = "topLeft";
  DebugOverlayCorner[DebugOverlayCorner["topRight"] = 1] = "topRight";
  DebugOverlayCorner[DebugOverlayCorner["bottomLeft"] = 2] = "bottomLeft";
  DebugOverlayCorner[DebugOverlayCorner["bottomRight"] = 3] = "bottomRight";
})(DebugOverlayCorner2 ||= {});
var TargetChannel2;
((TargetChannel) => {
  TargetChannel[TargetChannel["FG"] = 1] = "FG";
  TargetChannel[TargetChannel["BG"] = 2] = "BG";
  TargetChannel[TargetChannel["Both"] = 3] = "Both";
})(TargetChannel2 ||= {});

// src/lib/RGBA.ts
var DEFAULT_FOREGROUND_RGB2 = [255, 255, 255];
var DEFAULT_BACKGROUND_RGB2 = [0, 0, 0];
var INTENT_RGB = 0;
var INTENT_INDEXED = 1;
var INTENT_DEFAULT = 2;
var ZERO_RGBA_BUFFER = new Uint16Array(4);
var ANSI16_RGB = [
  [0, 0, 0],
  [128, 0, 0],
  [0, 128, 0],
  [128, 128, 0],
  [0, 0, 128],
  [128, 0, 128],
  [0, 128, 128],
  [192, 192, 192],
  [128, 128, 128],
  [255, 0, 0],
  [0, 255, 0],
  [255, 255, 0],
  [0, 0, 255],
  [255, 0, 255],
  [0, 255, 255],
  [255, 255, 255]
];
var ANSI_256_CUBE_LEVELS = [0, 95, 135, 175, 215, 255];
function packMeta(intent, slot = 0) {
  return (slot & 255 | (intent & 255) << 8) >>> 0;
}
function toU8(value) {
  return Math.round(Math.max(0, Math.min(1, Number.isFinite(value) ? value : 0)) * 255);
}
function toByte(value) {
  return Math.round(Math.max(0, Math.min(255, Number.isFinite(value) ? value : 0)));
}
function packRGBA8(r, g, b, a, meta) {
  const rgba = new RGBA2(ZERO_RGBA_BUFFER);
  rgba.buffer[0] = toByte(r) & 255 | (meta >>> 0 & 255) << 8;
  rgba.buffer[1] = toByte(g) & 255 | (meta >>> 8 & 255) << 8;
  rgba.buffer[2] = toByte(b) & 255 | (meta >>> 16 & 255) << 8;
  rgba.buffer[3] = toByte(a) & 255 | (meta >>> 24 & 255) << 8;
  return rgba;
}
function rgbaForAnsi256Index(index) {
  const [r, g, b] = ansi256IndexToRgb2(index);
  return RGBA2.fromInts(r, g, b);
}
function normalizeIndexedColorIndex2(index) {
  if (!Number.isInteger(index) || index < 0 || index > 255) {
    throw new RangeError(`Indexed color must be an integer in the range 0..255, got ${index}`);
  }
  return index;
}
function ansi256IndexToRgb2(index) {
  const normalizedIndex = normalizeIndexedColorIndex2(index);
  if (normalizedIndex < ANSI16_RGB.length) {
    return ANSI16_RGB[normalizedIndex];
  }
  if (normalizedIndex < 232) {
    const cubeIndex = normalizedIndex - 16;
    const r = Math.floor(cubeIndex / 36);
    const g = Math.floor(cubeIndex / 6) % 6;
    const b = cubeIndex % 6;
    return [ANSI_256_CUBE_LEVELS[r], ANSI_256_CUBE_LEVELS[g], ANSI_256_CUBE_LEVELS[b]];
  }
  const value = 8 + (normalizedIndex - 232) * 10;
  return [value, value, value];
}

class RGBA2 {
  buffer;
  constructor(buffer) {
    const copy = new Uint16Array(4);
    if (buffer.length === 4) {
      copy[0] = buffer[0];
      copy[1] = buffer[1];
      copy[2] = buffer[2];
      copy[3] = buffer[3];
    } else {
      copy.set(buffer.subarray(0, 4));
    }
    this.buffer = copy;
  }
  static fromArray(array) {
    return new RGBA2(array);
  }
  static fromValues(r, g, b, a = 1) {
    return packRGBA8(toU8(r), toU8(g), toU8(b), toU8(a), packMeta(INTENT_RGB));
  }
  static clone(rgba) {
    return new RGBA2(rgba.buffer);
  }
  static fromInts(r, g, b, a = 255) {
    return packRGBA8(r, g, b, a, packMeta(INTENT_RGB));
  }
  static fromHex(hex) {
    return hexToRgb2(hex);
  }
  static fromIndex(index, snapshot) {
    const normalized = normalizeIndexedColorIndex2(index);
    const rgba = snapshot ? parseColor2(snapshot) : rgbaForAnsi256Index(normalized);
    const [r, g, b, a] = rgba.toInts();
    return packRGBA8(r, g, b, a, packMeta(INTENT_INDEXED, normalized));
  }
  static defaultForeground(snapshot) {
    const rgba = snapshot ? parseColor2(snapshot) : RGBA2.fromInts(...DEFAULT_FOREGROUND_RGB2);
    const [r, g, b, a] = rgba.toInts();
    return packRGBA8(r, g, b, a, packMeta(INTENT_DEFAULT));
  }
  static defaultBackground(snapshot) {
    const rgba = snapshot ? parseColor2(snapshot) : RGBA2.fromInts(...DEFAULT_BACKGROUND_RGB2);
    const [r, g, b, a] = rgba.toInts();
    return packRGBA8(r, g, b, a, packMeta(INTENT_DEFAULT));
  }
  toInts() {
    return [this.buffer[0] & 255, this.buffer[1] & 255, this.buffer[2] & 255, this.buffer[3] & 255];
  }
  get r() {
    return (this.buffer[0] & 255) / 255;
  }
  set r(value) {
    this.buffer[0] = this.buffer[0] & 65280 | toU8(value);
  }
  get g() {
    return (this.buffer[1] & 255) / 255;
  }
  set g(value) {
    this.buffer[1] = this.buffer[1] & 65280 | toU8(value);
  }
  get b() {
    return (this.buffer[2] & 255) / 255;
  }
  set b(value) {
    this.buffer[2] = this.buffer[2] & 65280 | toU8(value);
  }
  get a() {
    return (this.buffer[3] & 255) / 255;
  }
  set a(value) {
    this.buffer[3] = this.buffer[3] & 65280 | toU8(value);
  }
  get meta() {
    return (this.buffer[0] >>> 8 | this.buffer[1] >>> 8 << 8 | this.buffer[2] >>> 8 << 16 | this.buffer[3] >>> 8 << 24) >>> 0;
  }
  get intent() {
    switch (this.meta >>> 8 & 255) {
      case INTENT_INDEXED:
        return "indexed";
      case INTENT_DEFAULT:
        return "default";
      default:
        return "rgb";
    }
  }
  get slot() {
    return this.meta & 255;
  }
  map(fn) {
    return [fn(this.r), fn(this.g), fn(this.b), fn(this.a)];
  }
  toString() {
    return `rgba(${this.r.toFixed(2)}, ${this.g.toFixed(2)}, ${this.b.toFixed(2)}, ${this.a.toFixed(2)})`;
  }
  equals(other) {
    if (!other)
      return false;
    return this.buffer[0] === other.buffer[0] && this.buffer[1] === other.buffer[1] && this.buffer[2] === other.buffer[2] && this.buffer[3] === other.buffer[3];
  }
}
function normalizeColorValue2(value) {
  if (value == null)
    return null;
  return { rgba: parseColor2(value) };
}
function hexToRgb2(hex) {
  hex = hex.replace(/^#/, "");
  if (hex.length === 3) {
    hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
  } else if (hex.length === 4) {
    hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2] + hex[3] + hex[3];
  }
  if (!/^[0-9A-Fa-f]{6}$/.test(hex) && !/^[0-9A-Fa-f]{8}$/.test(hex)) {
    console.warn(`Invalid hex color: ${hex}, defaulting to magenta`);
    return RGBA2.fromValues(1, 0, 1, 1);
  }
  const r = parseInt(hex.substring(0, 2), 16);
  const g = parseInt(hex.substring(2, 4), 16);
  const b = parseInt(hex.substring(4, 6), 16);
  const a = hex.length === 8 ? parseInt(hex.substring(6, 8), 16) : 255;
  return RGBA2.fromInts(r, g, b, a);
}
function rgbToHex2(rgb) {
  const [r, g, b, a] = rgb.toInts();
  const components = a === 255 ? [r, g, b] : [r, g, b, a];
  return "#" + components.map((x) => x.toString(16).padStart(2, "0")).join("");
}
function hsvToRgb2(h, s, v) {
  let r = 0, g = 0, b = 0;
  const i = Math.floor(h / 60) % 6;
  const f = h / 60 - Math.floor(h / 60);
  const p = v * (1 - s);
  const q = v * (1 - f * s);
  const t = v * (1 - (1 - f) * s);
  switch (i) {
    case 0:
      r = v;
      g = t;
      b = p;
      break;
    case 1:
      r = q;
      g = v;
      b = p;
      break;
    case 2:
      r = p;
      g = v;
      b = t;
      break;
    case 3:
      r = p;
      g = q;
      b = v;
      break;
    case 4:
      r = t;
      g = p;
      b = v;
      break;
    case 5:
      r = v;
      g = p;
      b = q;
      break;
  }
  return RGBA2.fromValues(r, g, b, 1);
}
var CSS_COLOR_NAMES = {
  black: "#000000",
  white: "#FFFFFF",
  red: "#FF0000",
  green: "#008000",
  blue: "#0000FF",
  yellow: "#FFFF00",
  cyan: "#00FFFF",
  magenta: "#FF00FF",
  silver: "#C0C0C0",
  gray: "#808080",
  grey: "#808080",
  maroon: "#800000",
  olive: "#808000",
  lime: "#00FF00",
  aqua: "#00FFFF",
  teal: "#008080",
  navy: "#000080",
  fuchsia: "#FF00FF",
  purple: "#800080",
  orange: "#FFA500",
  brightblack: "#666666",
  brightred: "#FF6666",
  brightgreen: "#66FF66",
  brightblue: "#6666FF",
  brightyellow: "#FFFF66",
  brightcyan: "#66FFFF",
  brightmagenta: "#FF66FF",
  brightwhite: "#FFFFFF"
};
function parseColor2(color) {
  if (typeof color === "string") {
    const lowerColor = color.toLowerCase();
    if (lowerColor === "transparent") {
      return RGBA2.fromValues(0, 0, 0, 0);
    }
    if (CSS_COLOR_NAMES[lowerColor]) {
      return hexToRgb2(CSS_COLOR_NAMES[lowerColor]);
    }
    return hexToRgb2(color);
  }
  return color;
}

// src/utils.ts
function createTextAttributes2({
  bold = false,
  italic = false,
  underline = false,
  dim = false,
  blink = false,
  inverse = false,
  reverse = false,
  hidden = false,
  strikethrough = false
} = {}) {
  let attributes = TextAttributes2.NONE;
  if (bold)
    attributes |= TextAttributes2.BOLD;
  if (italic)
    attributes |= TextAttributes2.ITALIC;
  if (underline)
    attributes |= TextAttributes2.UNDERLINE;
  if (dim)
    attributes |= TextAttributes2.DIM;
  if (blink)
    attributes |= TextAttributes2.BLINK;
  if (inverse || reverse)
    attributes |= TextAttributes2.INVERSE;
  if (hidden)
    attributes |= TextAttributes2.HIDDEN;
  if (strikethrough)
    attributes |= TextAttributes2.STRIKETHROUGH;
  return attributes;
}
var ATTRIBUTE_BASE_MASK = 255;
var LINK_ID_SHIFT = 8;
var LINK_ID_PAYLOAD_MASK = 16777215;
function attributesWithLink2(baseAttributes, linkId) {
  const base = baseAttributes & ATTRIBUTE_BASE_MASK;
  const linkBits = (linkId & LINK_ID_PAYLOAD_MASK) << LINK_ID_SHIFT;
  return base | linkBits;
}
function getLinkId2(attributes) {
  return attributes >>> LINK_ID_SHIFT & LINK_ID_PAYLOAD_MASK;
}
function visualizeRenderableTree2(renderable, maxDepth = 10) {
  function buildTreeLines(node, prefix = "", parentPrefix = "", isLastChild = true, depth = 0) {
    if (depth >= maxDepth) {
      return [`${prefix}${node.id} ... (max depth reached)`];
    }
    const lines = [];
    const children = node.getChildren();
    lines.push(`${prefix}${node.id}`);
    if (children.length > 0) {
      const lastChildIndex = children.length - 1;
      children.forEach((child, index) => {
        const childIsLast = index === lastChildIndex;
        const connector = childIsLast ? "└── " : "├── ";
        const childPrefix = parentPrefix + (isLastChild ? "    " : "│   ");
        const childLines = buildTreeLines(child, childPrefix + connector, childPrefix, childIsLast, depth + 1);
        lines.push(...childLines);
      });
    }
    return lines;
  }
  const treeLines = buildTreeLines(renderable);
  console.log(`Renderable Tree:
` + treeLines.join(`
`));
}

// src/lib/styled-text.ts
var BrandedStyledText = Symbol.for("@opentui/core/StyledText");
function isStyledText2(obj) {
  return obj && obj[BrandedStyledText];
}

class StyledText2 {
  [BrandedStyledText] = true;
  chunks;
  constructor(chunks) {
    this.chunks = chunks;
  }
}
function stringToStyledText2(content) {
  const chunk = {
    __isChunk: true,
    text: content
  };
  return new StyledText2([chunk]);
}
function applyStyle(input, style) {
  if (typeof input === "object" && "__isChunk" in input) {
    const existingChunk = input;
    const fg = style.fg ? parseColor2(style.fg) : existingChunk.fg;
    const bg = style.bg ? parseColor2(style.bg) : existingChunk.bg;
    const newAttrs = createTextAttributes2(style);
    const mergedAttrs = existingChunk.attributes ? existingChunk.attributes | newAttrs : newAttrs;
    return {
      __isChunk: true,
      text: existingChunk.text,
      fg,
      bg,
      attributes: mergedAttrs,
      link: existingChunk.link
    };
  } else {
    const plainTextStr = String(input);
    const fg = style.fg ? parseColor2(style.fg) : undefined;
    const bg = style.bg ? parseColor2(style.bg) : undefined;
    const attributes = createTextAttributes2(style);
    return {
      __isChunk: true,
      text: plainTextStr,
      fg,
      bg,
      attributes
    };
  }
}
var black2 = (input) => applyStyle(input, { fg: "black" });
var red2 = (input) => applyStyle(input, { fg: "red" });
var green2 = (input) => applyStyle(input, { fg: "green" });
var yellow2 = (input) => applyStyle(input, { fg: "yellow" });
var blue2 = (input) => applyStyle(input, { fg: "blue" });
var magenta2 = (input) => applyStyle(input, { fg: "magenta" });
var cyan2 = (input) => applyStyle(input, { fg: "cyan" });
var white2 = (input) => applyStyle(input, { fg: "white" });
var brightBlack2 = (input) => applyStyle(input, { fg: "brightBlack" });
var brightRed2 = (input) => applyStyle(input, { fg: "brightRed" });
var brightGreen2 = (input) => applyStyle(input, { fg: "brightGreen" });
var brightYellow2 = (input) => applyStyle(input, { fg: "brightYellow" });
var brightBlue2 = (input) => applyStyle(input, { fg: "brightBlue" });
var brightMagenta2 = (input) => applyStyle(input, { fg: "brightMagenta" });
var brightCyan2 = (input) => applyStyle(input, { fg: "brightCyan" });
var brightWhite2 = (input) => applyStyle(input, { fg: "brightWhite" });
var bgBlack2 = (input) => applyStyle(input, { bg: "black" });
var bgRed2 = (input) => applyStyle(input, { bg: "red" });
var bgGreen2 = (input) => applyStyle(input, { bg: "green" });
var bgYellow2 = (input) => applyStyle(input, { bg: "yellow" });
var bgBlue2 = (input) => applyStyle(input, { bg: "blue" });
var bgMagenta2 = (input) => applyStyle(input, { bg: "magenta" });
var bgCyan2 = (input) => applyStyle(input, { bg: "cyan" });
var bgWhite2 = (input) => applyStyle(input, { bg: "white" });
var bold2 = (input) => applyStyle(input, { bold: true });
var italic2 = (input) => applyStyle(input, { italic: true });
var underline2 = (input) => applyStyle(input, { underline: true });
var strikethrough2 = (input) => applyStyle(input, { strikethrough: true });
var dim2 = (input) => applyStyle(input, { dim: true });
var reverse2 = (input) => applyStyle(input, { reverse: true });
var blink2 = (input) => applyStyle(input, { blink: true });
var fg2 = (color) => (input) => applyStyle(input, { fg: color });
var bg2 = (color) => (input) => applyStyle(input, { bg: color });
var link2 = (url) => (input) => {
  const chunk = typeof input === "object" && "__isChunk" in input ? input : {
    __isChunk: true,
    text: String(input)
  };
  return {
    ...chunk,
    link: { url }
  };
};
function t2(strings, ...values) {
  const chunks = [];
  for (let i = 0;i < strings.length; i++) {
    const raw = strings[i];
    if (raw) {
      chunks.push({
        __isChunk: true,
        text: raw,
        attributes: 0
      });
    }
    const val = values[i];
    if (typeof val === "object" && "__isChunk" in val) {
      chunks.push(val);
    } else if (val !== undefined) {
      const plainTextStr = String(val);
      chunks.push({
        __isChunk: true,
        text: plainTextStr,
        attributes: 0
      });
    }
  }
  return new StyledText2(chunks);
}

// src/yoga.internal.ts
var YogaEnumKind = {
  Direction: nativeConstants.OT_STYLE_ENUM_DIRECTION,
  FlexDirection: nativeConstants.OT_STYLE_ENUM_FLEX_DIRECTION,
  JustifyContent: nativeConstants.OT_STYLE_ENUM_JUSTIFY_CONTENT,
  AlignContent: nativeConstants.OT_STYLE_ENUM_ALIGN_CONTENT,
  AlignItems: nativeConstants.OT_STYLE_ENUM_ALIGN_ITEMS,
  AlignSelf: nativeConstants.OT_STYLE_ENUM_ALIGN_SELF,
  PositionType: nativeConstants.OT_STYLE_ENUM_POSITION_TYPE,
  FlexWrap: nativeConstants.OT_STYLE_ENUM_FLEX_WRAP,
  Overflow: nativeConstants.OT_STYLE_ENUM_OVERFLOW,
  Display: nativeConstants.OT_STYLE_ENUM_DISPLAY,
  BoxSizing: nativeConstants.OT_STYLE_ENUM_BOX_SIZING
};
var YogaFloatKind = {
  Flex: nativeConstants.OT_STYLE_FLOAT_FLEX,
  FlexGrow: nativeConstants.OT_STYLE_FLOAT_FLEX_GROW,
  FlexShrink: nativeConstants.OT_STYLE_FLOAT_FLEX_SHRINK,
  AspectRatio: nativeConstants.OT_STYLE_FLOAT_ASPECT_RATIO
};
var YogaValueKind = {
  Width: nativeConstants.OT_STYLE_VALUE_WIDTH,
  Height: nativeConstants.OT_STYLE_VALUE_HEIGHT,
  MinWidth: nativeConstants.OT_STYLE_VALUE_MIN_WIDTH,
  MinHeight: nativeConstants.OT_STYLE_VALUE_MIN_HEIGHT,
  MaxWidth: nativeConstants.OT_STYLE_VALUE_MAX_WIDTH,
  MaxHeight: nativeConstants.OT_STYLE_VALUE_MAX_HEIGHT,
  FlexBasis: nativeConstants.OT_STYLE_VALUE_FLEX_BASIS,
  Margin: nativeConstants.OT_STYLE_VALUE_MARGIN,
  Padding: nativeConstants.OT_STYLE_VALUE_PADDING,
  Position: nativeConstants.OT_STYLE_VALUE_POSITION,
  Gap: nativeConstants.OT_STYLE_VALUE_GAP
};
function sceneSetEnum(scene, node, kind, value) {
  scene.setStyle(node, NativeStyleGroup.Enum, kind, NATIVE_EDGE_NONE2, Unit2.Undefined, value);
}
function sceneGetEnum(scene, node, kind) {
  return scene.getStyle(node, NativeStyleGroup.Enum, kind, NATIVE_EDGE_NONE2).value;
}
function sceneSetFloat(scene, node, kind, value) {
  scene.setStyle(node, NativeStyleGroup.Float, kind, NATIVE_EDGE_NONE2, Unit2.Undefined, value ?? NaN);
}
function sceneGetFloat(scene, node, kind) {
  return scene.getStyle(node, NativeStyleGroup.Float, kind, NATIVE_EDGE_NONE2).value;
}
function sceneSetValue(scene, node, kind, edge, valueInput) {
  const value = parseYogaValue(valueInput);
  scene.setStyle(node, NativeStyleGroup.Value, kind, edge, value.unit, value.value);
}
function sceneGetValue(scene, node, kind, edge) {
  return scene.getStyle(node, NativeStyleGroup.Value, kind, edge);
}
function sceneSetDimension(scene, node, dimension, input, disableFlexShrink = false) {
  const value = parseYogaValue(input);
  scene.setStyle(node, NativeStyleGroup.Dimension, dimension, NATIVE_EDGE_NONE2, value.unit, value.value, disableFlexShrink ? NativeStyleFlags.DisableFlexShrink : NativeStyleFlags.None);
}
var UNDEFINED_VALUE = { unit: nativeConstants.OT_UNIT_UNDEFINED, value: NaN };

class YogaHost {
  renderLib;
  configs = new Map;
  pendingScenes = new Set;
  defaultConfig;
  callbackDepth = 0;
  mutationDepth = 0;
  callbackError;
  constructor(renderLib) {
    this.renderLib = renderLib;
  }
  getDefaultConfig() {
    if (!this.defaultConfig || this.configs.get(this.defaultConfig.ptr) !== this.defaultConfig) {
      this.defaultConfig = Config2.create(this.renderLib);
    }
    return this.defaultConfig;
  }
  assertMutable() {
    if (this.callbackDepth !== 0)
      throw new Error("Cannot mutate Yoga during a callback");
  }
  stageScene(scene) {
    this.pendingScenes.add(scene);
  }
  forgetScene(scene) {
    this.pendingScenes.delete(scene);
  }
  flushSceneMutations() {
    this.assertMutable();
    for (const scene of this.pendingScenes)
      scene.flushStaged();
  }
  get inCallback() {
    return this.callbackDepth !== 0;
  }
  invokeCallback(callback) {
    this.callbackDepth++;
    try {
      rejectAsyncCallback(callback());
    } catch (error) {
      this.callbackError ??= { value: error };
    } finally {
      this.callbackDepth--;
    }
  }
  runMutation(operation) {
    this.assertMutable();
    this.mutationDepth++;
    let result;
    let failure;
    try {
      result = operation();
    } catch (error) {
      failure = { value: error };
    } finally {
      this.mutationDepth--;
    }
    this.throwCallbackError(failure);
    return result;
  }
  throwCallbackError(failure) {
    if (this.callbackDepth !== 0 || this.mutationDepth !== 0) {
      if (failure)
        throw failure.value;
      return;
    }
    const callbackError = this.callbackError;
    this.callbackError = undefined;
    if (failure && callbackError) {
      throw new AggregateError([failure.value, callbackError.value], "Yoga operation and callback both failed");
    }
    if (failure)
      throw failure.value;
    if (callbackError)
      throw callbackError.value;
  }
  dispose() {
    this.assertMutable();
    for (const config of this.configs.values())
      config.assertUnused();
    for (const config of this.configs.values())
      config.free();
    this.defaultConfig = undefined;
    this.pendingScenes.clear();
  }
}
function rejectAsyncCallback(value) {
  if (value !== null && (typeof value === "object" || typeof value === "function") && "then" in value && typeof value.then === "function") {
    Promise.resolve(value).catch(() => {});
    throw new TypeError("Yoga callbacks must be synchronous", { cause: value });
  }
}
function isValueObject(value) {
  return typeof value === "object" && value !== null && "unit" in value && "value" in value;
}
function parseYogaValue(value) {
  if (isValueObject(value)) {
    return value;
  }
  if (value === undefined) {
    return UNDEFINED_VALUE;
  }
  if (value === "auto") {
    return { unit: Unit2.Auto, value: NaN };
  }
  if (typeof value === "string") {
    if (!value.endsWith("%")) {
      throw new Error(`Invalid Yoga value: ${value}`);
    }
    const numberValue = Number.parseFloat(value);
    if (Number.isNaN(numberValue)) {
      throw new Error(`Invalid Yoga percentage value: ${value}`);
    }
    return { unit: Unit2.Percent, value: numberValue };
  }
  return { unit: Unit2.Point, value };
}

// ../../node_modules/.bun/bun-ffi-structs@0.3.1+1fb4c65d43e298b9/node_modules/bun-ffi-structs/dist/index.js
var FFI_LOAD_ERROR = "bun-ffi-structs pointer operations require Bun or Node.js 26.1+ with node:ffi enabled (--experimental-ffi).";
var backend2 = await loadBackend2();
function unavailable2(cause) {
  throw new Error(FFI_LOAD_ERROR, {
    cause: cause instanceof Error ? cause : undefined
  });
}
function createUnsupportedBackend2(cause) {
  return {
    ptr() {
      return unavailable2(cause);
    },
    toArrayBuffer() {
      return unavailable2(cause);
    }
  };
}
async function loadBackend2() {
  if (typeof process !== "undefined" && "bun" in process.versions) {
    return createBunBackend2(await importModule("bun:ffi"));
  }
  try {
    return createNodeBackend2(await importModule("node:ffi"));
  } catch (error) {
    return createUnsupportedBackend2(error);
  }
}
function importModule(specifier) {
  return import(specifier).then((module) => module.default ?? module);
}
function createBunBackend2(bun) {
  return {
    ptr: bun.ptr,
    toArrayBuffer(pointer, offset, length) {
      return bun.toArrayBuffer(toBunPointer2(pointer), offset, length);
    }
  };
}
function createNodeBackend2(nodeFfi) {
  return {
    ptr(value) {
      if (ArrayBuffer.isView(value)) {
        const pointer = nodeFfi.getRawPointer(value.buffer);
        return value.byteOffset === 0 ? pointer : pointer + BigInt(value.byteOffset);
      }
      if (value instanceof ArrayBuffer) {
        return nodeFfi.getRawPointer(value);
      }
      throw new TypeError("node:ffi ptr() only supports ArrayBuffer and ArrayBufferView values.");
    },
    toArrayBuffer(pointer, offset, length) {
      return nodeFfi.toArrayBuffer(toBigIntPointer2(pointer) + BigInt(offset ?? 0), length, false);
    }
  };
}
function toBigIntPointer2(pointer) {
  return typeof pointer === "bigint" ? pointer : BigInt(pointer);
}
function toBunPointer2(pointer) {
  return typeof pointer === "bigint" ? Number(pointer) : pointer;
}
var ptr2 = backend2.ptr;
var toArrayBuffer2 = backend2.toArrayBuffer;
function fatalError(...args) {
  const message = args.join(" ");
  console.error("FATAL ERROR:", message);
  throw new Error(message);
}
var pointerSize = process.arch === "x64" || process.arch === "arm64" ? 8 : 4;
var isBun2 = typeof process !== "undefined" && "bun" in process.versions;
var typeSizes = {
  u8: 1,
  bool_u8: 1,
  bool_u32: 4,
  u16: 2,
  i16: 2,
  u32: 4,
  u64: 8,
  f32: 4,
  f64: 8,
  pointer: pointerSize,
  i32: 4,
  i64: 8
};
var primitiveKeys = Object.keys(typeSizes);
function isPrimitiveType(type) {
  return typeof type === "string" && primitiveKeys.includes(type);
}
var typeAlignments = { ...typeSizes };
var typeGetters = {
  u8: (view, offset) => view.getUint8(offset),
  bool_u8: (view, offset) => Boolean(view.getUint8(offset)),
  bool_u32: (view, offset) => Boolean(view.getUint32(offset, true)),
  u16: (view, offset) => view.getUint16(offset, true),
  i16: (view, offset) => view.getInt16(offset, true),
  u32: (view, offset) => view.getUint32(offset, true),
  u64: (view, offset) => view.getBigUint64(offset, true),
  f32: (view, offset) => view.getFloat32(offset, true),
  f64: (view, offset) => view.getFloat64(offset, true),
  i32: (view, offset) => view.getInt32(offset, true),
  i64: (view, offset) => view.getBigInt64(offset, true),
  pointer: (view, offset) => pointerSize === 8 ? view.getBigUint64(offset, true) : BigInt(view.getUint32(offset, true))
};
function isObjectPointerDef(type) {
  return typeof type === "object" && type !== null && type.__type === "objectPointer";
}
function allocStruct(structDef, options) {
  const buffer = new ArrayBuffer(structDef.size);
  const view = new DataView(buffer);
  const result = { buffer, view };
  if (options?.lengths) {
    const subBuffers = {};
    for (const [arrayFieldName, length] of Object.entries(options.lengths)) {
      const arrayMeta = structDef.arrayFields.get(arrayFieldName);
      if (!arrayMeta) {
        throw new Error(`Field '${arrayFieldName}' is not an array field with a lengthOf field`);
      }
      const subBuffer = new ArrayBuffer(length * arrayMeta.elementSize);
      subBuffers[arrayFieldName] = subBuffer;
      const pointer = length > 0 ? ptr2(subBuffer) : null;
      pointerPacker(view, arrayMeta.arrayOffset, pointer);
      retainPointerTarget(buffer, subBuffer);
      arrayMeta.lengthPack(view, arrayMeta.lengthOffset, length);
    }
    if (Object.keys(subBuffers).length > 0) {
      result.subBuffers = subBuffers;
    }
  }
  return result;
}
function alignOffset(offset, align) {
  return offset + (align - 1) & ~(align - 1);
}
function enumTypeError(value) {
  throw new TypeError(`Invalid enum value: ${value}`);
}
function defineEnum(mapping, base = "u32") {
  const reverse = Object.fromEntries(Object.entries(mapping).map(([k, v]) => [v, k]));
  return {
    __type: "enum",
    type: base,
    to(value) {
      return typeof value === "number" ? value : mapping[value] ?? enumTypeError(String(value));
    },
    from(value) {
      return reverse[value] ?? enumTypeError(String(value));
    },
    enum: mapping
  };
}
function isEnum(type) {
  return typeof type === "object" && type.__type === "enum";
}
function hasPlainPrimitiveRuntimeOptions(options) {
  return options.optional === true || options.unpackTransform !== undefined || options.packTransform !== undefined || options.lengthOf !== undefined || options.default !== undefined || options.validate !== undefined;
}
function isStruct(type) {
  return typeof type === "object" && type.__type === "struct";
}
var structInternals = new WeakMap;
var freshPackBuffers = new WeakSet;
function packInlineStruct(internals, view, baseOffset, obj, options) {
  let mappedObj = internals.options?.mapValue ? internals.options.mapValue(obj) : obj;
  if (internals.materializeArrayIterables)
    mappedObj = internals.materializeArrayIterables(mappedObj);
  for (const field of internals.layout) {
    const value = mappedObj[field.name] ?? field.default;
    if (!field.optional && value === undefined) {
      fatalError(`Packing non-optional field '${field.name}' but value is undefined (and no default provided)`);
    }
    if (field.validate) {
      for (const validateFn of field.validate) {
        validateFn(value, field.name, {
          hints: options?.validationHints,
          input: mappedObj
        });
      }
    }
    field.pack(view, baseOffset + field.offset, value, mappedObj, options);
  }
}
function unpackInlineStruct(internals, view, baseOffset) {
  const result = internals.options?.default ? { ...internals.options.default } : {};
  for (const field of internals.layout) {
    if (!field.unpack)
      continue;
    try {
      result[field.name] = field.unpack(view, baseOffset + field.offset);
    } catch (error) {
      console.error(`Error unpacking field '${field.name}' at offset ${field.offset}:`, error);
      throw error;
    }
  }
  return internals.options?.reduceValue ? internals.options.reduceValue(result) : result;
}
function primitivePackers(type) {
  let pack;
  let unpack;
  switch (type) {
    case "u8":
      pack = (view, off, val) => view.setUint8(off, val);
      unpack = (view, off) => view.getUint8(off);
      break;
    case "bool_u8":
      pack = (view, off, val) => view.setUint8(off, val ? 1 : 0);
      unpack = (view, off) => Boolean(view.getUint8(off));
      break;
    case "bool_u32":
      pack = (view, off, val) => view.setUint32(off, val ? 1 : 0, true);
      unpack = (view, off) => Boolean(view.getUint32(off, true));
      break;
    case "u16":
      pack = (view, off, val) => view.setUint16(off, val, true);
      unpack = (view, off) => view.getUint16(off, true);
      break;
    case "i16":
      pack = (view, off, val) => view.setInt16(off, val, true);
      unpack = (view, off) => view.getInt16(off, true);
      break;
    case "u32":
      pack = (view, off, val) => view.setUint32(off, val, true);
      unpack = (view, off) => view.getUint32(off, true);
      break;
    case "i32":
      pack = (view, off, val) => view.setInt32(off, val, true);
      unpack = (view, off) => view.getInt32(off, true);
      break;
    case "i64":
      pack = (view, off, val) => view.setBigInt64(off, BigInt(val), true);
      unpack = (view, off) => view.getBigInt64(off, true);
      break;
    case "u64":
      pack = (view, off, val) => view.setBigUint64(off, BigInt(val), true);
      unpack = (view, off) => view.getBigUint64(off, true);
      break;
    case "f32":
      pack = (view, off, val) => view.setFloat32(off, val, true);
      unpack = (view, off) => view.getFloat32(off, true);
      break;
    case "f64":
      pack = (view, off, val) => view.setFloat64(off, val, true);
      unpack = (view, off) => view.getFloat64(off, true);
      break;
    case "pointer":
      if (pointerSize === 8 && isBun2) {
        pack = (view, off, val) => {
          if (!val) {
            view.setUint32(off, 0, true);
            view.setUint32(off + 4, 0, true);
          } else if (typeof val === "number" && Number.isInteger(val)) {
            view.setUint32(off, val, true);
            view.setUint32(off + 4, Math.floor(val / 4294967296), true);
          } else {
            view.setBigUint64(off, BigInt(val), true);
          }
        };
        unpack = (view, off) => view.getUint32(off, true) + view.getUint32(off + 4, true) * 4294967296;
      } else {
        pack = (view, off, val) => {
          pointerSize === 8 ? view.setBigUint64(off, val ? BigInt(val) : 0n, true) : view.setUint32(off, val ? Number(val) : 0, true);
        };
        unpack = (view, off) => {
          if (pointerSize === 8) {
            const value = view.getBigUint64(off, true);
            return isBun2 ? Number(value) : value;
          }
          return view.getUint32(off, true);
        };
      }
      break;
    default:
      fatalError(`Unsupported primitive type: ${type}`);
  }
  return { pack, unpack };
}
function primitiveSetterSource(type, offset, value) {
  const target = `baseOffset + ${offset}`;
  switch (type) {
    case "u8":
      return `view.setUint8(${target}, ${value})`;
    case "bool_u8":
      return `view.setUint8(${target}, ${value} ? 1 : 0)`;
    case "bool_u32":
      return `view.setUint32(${target}, ${value} ? 1 : 0, true)`;
    case "u16":
      return `view.setUint16(${target}, ${value}, true)`;
    case "i16":
      return `view.setInt16(${target}, ${value}, true)`;
    case "u32":
      return `view.setUint32(${target}, ${value}, true)`;
    case "i32":
      return `view.setInt32(${target}, ${value}, true)`;
    case "i64":
      return `view.setBigInt64(${target}, BigInt(${value}), true)`;
    case "u64":
      return `view.setBigUint64(${target}, BigInt(${value}), true)`;
    case "f32":
      return `view.setFloat32(${target}, ${value}, true)`;
    case "f64":
      return `view.setFloat64(${target}, ${value}, true)`;
  }
}
function primitiveGetterSource(type, offset) {
  const target = `baseOffset + ${offset}`;
  switch (type) {
    case "u8":
      return `view.getUint8(${target})`;
    case "bool_u8":
      return `Boolean(view.getUint8(${target}))`;
    case "bool_u32":
      return `Boolean(view.getUint32(${target}, true))`;
    case "u16":
      return `view.getUint16(${target}, true)`;
    case "i16":
      return `view.getInt16(${target}, true)`;
    case "u32":
      return `view.getUint32(${target}, true)`;
    case "i32":
      return `view.getInt32(${target}, true)`;
    case "i64":
      return `view.getBigInt64(${target}, true)`;
    case "u64":
      return `view.getBigUint64(${target}, true)`;
    case "f32":
      return `view.getFloat32(${target}, true)`;
    case "f64":
      return `view.getFloat64(${target}, true)`;
    case "pointer":
      if (pointerSize === 8 && isBun2) {
        return `view.getUint32(${target}, true) + view.getUint32(${target} + 4, true) * 0x100000000`;
      }
      return pointerSize === 8 ? `view.getBigUint64(${target}, true)` : `view.getUint32(${target}, true)`;
  }
}
function compilePlainPrimitivePackList(fields, totalSize) {
  const writes = fields.map((field, index) => {
    const value = `value${index}`;
    const missing = `Packing non-optional field '${field.name}' at index `;
    return `
        const ${value} = obj[${JSON.stringify(field.name)}] ?? undefined
        if (${value} === undefined) fatalError(${JSON.stringify(missing)} + index + ${JSON.stringify(" but value is undefined (and no default provided)")})
        ${primitiveSetterSource(field.type, field.offset, value)}
      `;
  }).join(`
`);
  return new Function("fatalError", `return function packPlainPrimitiveList(objects) {
      const buffer = new ArrayBuffer(${totalSize} * objects.length)
      const view = new DataView(buffer)
      for (let index = 0, baseOffset = 0; index < objects.length; index++, baseOffset += ${totalSize}) {
        const obj = objects[index]
        ${writes}
      }
      return buffer
    }`)(fatalError);
}
function compilePlainPrimitivePack(fields, totalSize) {
  const writes = fields.map((field, index) => {
    const value = `value${index}`;
    return `
        const ${value} = obj[${JSON.stringify(field.name)}] ?? undefined
        if (${value} === undefined) fatalError(${JSON.stringify(`Packing non-optional field '${field.name}' but value is undefined (and no default provided)`)})
        ${primitiveSetterSource(field.type, field.offset, value)}
      `;
  }).join(`
`);
  return new Function("fatalError", `return function packPlainPrimitive(obj) {
      const buffer = new ArrayBuffer(${totalSize})
      const view = new DataView(buffer)
      let baseOffset = 0
      ${writes}
      return buffer
    }`)(fatalError);
}
function compilePlainPrimitivePackInto(fields) {
  const writes = fields.map((field, index) => {
    const value = `value${index}`;
    return `
        const ${value} = obj[${JSON.stringify(field.name)}] ?? undefined
        if (${value} === undefined) {
          console.warn(${JSON.stringify(`packInto missing value for non-optional field '${field.name}' at offset `)} + (baseOffset + ${field.offset}) + ${JSON.stringify(". Writing default or zero.")})
        }
        ${primitiveSetterSource(field.type, field.offset, value)}
      `;
  }).join(`
`);
  return new Function(`return function packPlainPrimitiveInto(obj, view, baseOffset) {
      ${writes}
    }`)();
}
function compilePlainPrimitivePackListInto(fields, totalSize) {
  const writes = fields.map((field, index) => {
    const value = `value${index}`;
    return `
        const ${value} = obj[${JSON.stringify(field.name)}] ?? undefined
        if (${value} === undefined) {
          console.warn(${JSON.stringify(`packInto missing value for non-optional field '${field.name}' at offset `)} + (baseOffset + ${field.offset}) + ${JSON.stringify(". Writing default or zero.")})
        }
        ${primitiveSetterSource(field.type, field.offset, value)}
      `;
  }).join(`
`);
  return new Function(`return function packPlainPrimitiveListInto(objects, view, initialOffset) {
      for (let index = 0, baseOffset = initialOffset; index < objects.length; index++, baseOffset += ${totalSize}) {
        const obj = objects[index]
        ${writes}
      }
    }`)();
}
function compilePlainPrimitiveUnpackList(fields, totalSize) {
  const reads = fields.map((field, index) => `
        let value${index}
        try {
          value${index} = ${primitiveGetterSource(field.type, field.offset)}
        } catch (error) {
          console.error(${JSON.stringify(`Error unpacking field '${field.name}' at index `)} + index + ${JSON.stringify(", offset ")} + (baseOffset + ${field.offset}) + ":", error)
          throw error
        }
      `).join(`
`);
  const properties = fields.map((field, index) => `${JSON.stringify(field.name)}: value${index}`).join(",");
  return new Function(`return function unpackPlainPrimitiveList(view, count) {
      const preallocated = Number.isSafeInteger(count) && count >= ${arrayPreallocationThreshold} && count <= ${maxArrayLength}
      const results = preallocated ? new Array(count) : []
      for (let index = 0, baseOffset = 0; index < count; index++, baseOffset += ${totalSize}) {
        ${reads}
        const value = { ${properties} }
        if (preallocated) results[index] = value
        else results.push(value)
      }
      return results
    }`)();
}
function compileReducedPrimitiveUnpackList(fields, totalSize, options) {
  const reads = fields.map((field, index) => `
        let value${index}
        try {
          value${index} = ${primitiveGetterSource(field.type, field.offset)}
        } catch (error) {
          console.error(${JSON.stringify(`Error unpacking field '${field.name}' at index `)} + index + ${JSON.stringify(", offset ")} + (baseOffset + ${field.offset}) + ":", error)
          throw error
        }
      `).join(`
`);
  const properties = fields.map((field, index) => `${JSON.stringify(field.name)}: value${index}`).join(",");
  return new Function("options", `return function unpackReducedPrimitiveList(view, count) {
      const preallocated = Number.isSafeInteger(count) && count >= ${arrayPreallocationThreshold} && count <= ${maxArrayLength}
      const results = preallocated ? new Array(count) : []
      for (let index = 0, baseOffset = 0; index < count; index++, baseOffset += ${totalSize}) {
        ${reads}
        const raw = { ${properties} }
        const value = options.reduceValue ? options.reduceValue(raw) : raw
        if (preallocated) results[index] = value
        else results.push(value)
      }
      return results
    }`)(options);
}
function compilePlainPrimitiveUnpack(fields) {
  const reads = fields.map((field, index) => `
        let value${index}
        try {
          value${index} = ${primitiveGetterSource(field.type, field.offset)}
        } catch (error) {
          console.error(${JSON.stringify(`Error unpacking field '${field.name}' at offset ${field.offset}:`)}, error)
          throw error
        }
      `).join(`
`);
  const properties = fields.map((field, index) => `${JSON.stringify(field.name)}: value${index}`).join(",");
  return new Function(`return function unpackPlainPrimitive(view) {
      let baseOffset = 0
      ${reads}
      return { ${properties} }
    }`)();
}
function compilePlainPrimitiveUnpackInto(fields) {
  const reads = fields.map((field) => `
        try {
          target[${JSON.stringify(field.name)}] = ${primitiveGetterSource(field.type, field.offset)}
        } catch (error) {
          console.error(${JSON.stringify(`Error unpacking field '${field.name}' at offset ${field.offset}:`)}, error)
          throw error
        }
      `).join(`
`);
  return new Function(`return function unpackPlainPrimitiveInto(view, target, baseOffset) {
      ${reads}
      return target
    }`)();
}
var { pack: pointerPacker, unpack: pointerUnpacker } = primitivePackers("pointer");
var foreignMemoryPointerUnpacker = pointerSize === 8 && isBun2 ? (view, off) => Number(view.getBigUint64(off, true)) : pointerUnpacker;
var retainedPointerTargets = new WeakMap;
function retainPointerTarget(owner, target) {
  const retained = retainedPointerTargets.get(owner);
  if (retained) {
    retained.push(target);
  } else {
    retainedPointerTargets.set(owner, [target]);
  }
}
function retainIfPointerTargets(owner, target) {
  if (retainedPointerTargets.has(target))
    retainPointerTarget(owner, target);
}
function isNullPointer(pointer) {
  return pointer == null || pointer === 0 || pointer === 0n;
}
function toItemCount(length) {
  return typeof length === "bigint" ? Number(length) : length;
}
var arrayPreallocationThreshold = 256;
var plainPrimitiveSpecializationThreshold = 256;
var maxArrayLength = 4294967295;
function packObjectArray(val) {
  const buffer = new ArrayBuffer(val.length * pointerSize);
  const bufferView = new DataView(buffer);
  for (let i = 0;i < val.length; i++) {
    const instance = val[i];
    const ptrValue = instance?.ptr ?? null;
    pointerPacker(bufferView, i * pointerSize, ptrValue);
  }
  return bufferView;
}
var encoder = new TextEncoder;
var decoder = new TextDecoder;
function defineStruct(fields, structDefOptions) {
  let offset = 0;
  let maxAlign = 1;
  let hasDirectInlinePack = false;
  let directInlineUnpackSafe = !structDefOptions?.default && !structDefOptions?.reduceValue;
  let plainPrimitiveFields = structDefOptions?.mapValue || structDefOptions?.default || structDefOptions?.reduceValue ? null : [];
  let primitiveDecodeFields = structDefOptions?.reduceValue && !structDefOptions.default ? [] : null;
  const layout = [];
  const lengthOfFields = {};
  const lengthOfRequested = [];
  const arrayFieldsMetadata = {};
  const arrayElementSizes = {};
  for (const [name, typeOrStruct, options = {}] of fields) {
    if (options.condition && !options.condition()) {
      continue;
    }
    let size = 0, align = 0;
    let pack;
    let unpack;
    let needsLengthOf = false;
    let lengthOfDef = null;
    let plainPrimitiveType = null;
    if (isPrimitiveType(typeOrStruct)) {
      size = typeSizes[typeOrStruct];
      align = typeAlignments[typeOrStruct];
      ({ pack, unpack } = primitivePackers(typeOrStruct));
      if (typeOrStruct === "pointer") {
        pack = (view, off, val) => {
          if (val instanceof ArrayBuffer || ArrayBuffer.isView(val)) {
            if (val.byteLength === 0) {
              pointerPacker(view, off, null);
              return;
            }
            pointerPacker(view, off, ptr2(val));
            retainPointerTarget(view.buffer, val);
            return;
          }
          pointerPacker(view, off, val);
        };
      }
      if (plainPrimitiveFields) {
        if (typeOrStruct === "pointer" || hasPlainPrimitiveRuntimeOptions(options))
          plainPrimitiveFields = null;
        else
          plainPrimitiveType = typeOrStruct;
      }
    } else if (typeof typeOrStruct === "string" && typeOrStruct === "cstring") {
      plainPrimitiveFields = null;
      size = pointerSize;
      align = pointerSize;
      pack = (view, off, val) => {
        if (!val) {
          pointerPacker(view, off, null);
          return;
        }
        const bytes = encoder.encode(val + "\x00");
        const bufPtr = ptr2(bytes);
        pointerPacker(view, off, bufPtr);
        retainPointerTarget(view.buffer, bytes);
      };
      unpack = (view, off) => {
        const ptrVal = pointerUnpacker(view, off);
        return ptrVal;
      };
    } else if (typeof typeOrStruct === "string" && typeOrStruct === "char*") {
      plainPrimitiveFields = null;
      size = pointerSize;
      align = pointerSize;
      pack = (view, off, val) => {
        if (!val) {
          pointerPacker(view, off, null);
          return;
        }
        const bytes = encoder.encode(val);
        const bufPtr = ptr2(bytes);
        pointerPacker(view, off, bufPtr);
        retainPointerTarget(view.buffer, bytes);
      };
      unpack = (view, off) => {
        const ptrVal = pointerUnpacker(view, off);
        return ptrVal;
      };
      needsLengthOf = true;
    } else if (isEnum(typeOrStruct)) {
      plainPrimitiveFields = null;
      directInlineUnpackSafe = false;
      const base = typeOrStruct.type;
      size = typeSizes[base];
      align = typeAlignments[base];
      const { pack: packEnum } = primitivePackers(base);
      pack = (view, off, val) => {
        const num = typeOrStruct.to(val);
        packEnum(view, off, num);
      };
      unpack = (view, off) => {
        const raw = typeGetters[base](view, off);
        return typeOrStruct.from(raw);
      };
    } else if (isStruct(typeOrStruct)) {
      plainPrimitiveFields = null;
      if (options.asPointer === true) {
        directInlineUnpackSafe = false;
        size = pointerSize;
        align = pointerSize;
        pack = (view, off, val, obj, options2) => {
          if (!val) {
            pointerPacker(view, off, null);
            return;
          }
          const nestedBuf = typeOrStruct.pack(val, options2);
          pointerPacker(view, off, ptr2(nestedBuf));
          retainPointerTarget(view.buffer, nestedBuf);
        };
        unpack = (view, off) => {
          throw new Error("Not implemented yet");
        };
      } else {
        size = typeOrStruct.size;
        align = typeOrStruct.align;
        const internals = structInternals.get(typeOrStruct);
        directInlineUnpackSafe &&= !!internals?.directInlineUnpackSafe;
        hasDirectInlinePack ||= !!internals && !options.optional;
        pack = (view, off, val, obj, packOptions) => {
          const publicPack = typeOrStruct.pack;
          if (internals && freshPackBuffers.has(view.buffer) && publicPack === internals.publicPack) {
            packInlineStruct(internals, view, off, val, packOptions);
            return;
          }
          const nestedBuf = Reflect.apply(publicPack, typeOrStruct, [val, packOptions]);
          const nestedView = new Uint8Array(nestedBuf);
          const dView = new Uint8Array(view.buffer, view.byteOffset, view.byteLength);
          dView.set(nestedView, off);
          retainIfPointerTargets(view.buffer, nestedBuf);
        };
        unpack = (view, off) => {
          const publicUnpack = Object.getOwnPropertyDescriptor(typeOrStruct, "unpack")?.value;
          if (internals?.directInlineUnpackSafe && publicUnpack === internals.publicUnpack && !(view.buffer instanceof SharedArrayBuffer)) {
            return unpackInlineStruct(internals, view, off);
          }
          const start = view.byteOffset + off;
          const slice = view.buffer.slice(start, start + size);
          return typeOrStruct.unpack(slice);
        };
      }
    } else if (isObjectPointerDef(typeOrStruct)) {
      plainPrimitiveFields = null;
      size = pointerSize;
      align = pointerSize;
      pack = (view, off, value) => {
        const ptrValue = value?.ptr ?? null;
        if (ptrValue === undefined) {
          console.warn(`Field '${name}' expected object with '.ptr' property, but got undefined pointer value from:`, value);
          pointerPacker(view, off, null);
        } else {
          pointerPacker(view, off, ptrValue);
        }
      };
      unpack = (view, off) => {
        return pointerUnpacker(view, off);
      };
    } else if (Array.isArray(typeOrStruct) && typeOrStruct.length === 1 && typeOrStruct[0] !== undefined) {
      plainPrimitiveFields = null;
      const [def] = typeOrStruct;
      size = pointerSize;
      align = pointerSize;
      let arrayElementSize;
      if (isEnum(def)) {
        directInlineUnpackSafe = false;
        arrayElementSize = typeSizes[def.type];
        const { pack: enumPack } = primitivePackers(def.type);
        pack = (view, off, val, obj) => {
          if (!val || val.length === 0) {
            pointerPacker(view, off, null);
            return;
          }
          const buffer = new ArrayBuffer(val.length * arrayElementSize);
          const bufferView = new DataView(buffer);
          for (let i = 0;i < val.length; i++) {
            const num = def.to(val[i]);
            enumPack(bufferView, i * arrayElementSize, num);
          }
          pointerPacker(view, off, ptr2(buffer));
          retainPointerTarget(view.buffer, buffer);
        };
        unpack = null;
        needsLengthOf = true;
        lengthOfDef = def;
      } else if (isStruct(def)) {
        directInlineUnpackSafe = false;
        arrayElementSize = def.size;
        const defInternals = structInternals.get(def);
        pack = (view, off, val, obj, options2) => {
          if (!val || val.length === 0) {
            pointerPacker(view, off, null);
            return;
          }
          const buffer = new ArrayBuffer(val.length * arrayElementSize);
          const bufferView = new DataView(buffer);
          if (defInternals?.hasDirectInlinePack) {
            freshPackBuffers.add(buffer);
            try {
              for (let i = 0;i < val.length; i++) {
                def.packInto(val[i], bufferView, i * arrayElementSize, options2);
              }
            } finally {
              freshPackBuffers.delete(buffer);
            }
          } else {
            for (let i = 0;i < val.length; i++) {
              def.packInto(val[i], bufferView, i * arrayElementSize, options2);
            }
          }
          pointerPacker(view, off, ptr2(buffer));
          retainPointerTarget(view.buffer, buffer);
        };
        unpack = (view, off) => {
          throw new Error("Not implemented yet");
        };
      } else if (isPrimitiveType(def)) {
        arrayElementSize = typeSizes[def];
        const { pack: primitivePack } = primitivePackers(def);
        pack = (view, off, val) => {
          if (!val || val.length === 0) {
            pointerPacker(view, off, null);
            return;
          }
          const buffer = new ArrayBuffer(val.length * arrayElementSize);
          const bufferView = new DataView(buffer);
          for (let i = 0;i < val.length; i++) {
            primitivePack(bufferView, i * arrayElementSize, val[i]);
          }
          pointerPacker(view, off, ptr2(buffer));
          retainPointerTarget(view.buffer, buffer);
        };
        unpack = null;
        needsLengthOf = true;
        lengthOfDef = def;
      } else if (isObjectPointerDef(def)) {
        directInlineUnpackSafe = false;
        arrayElementSize = pointerSize;
        pack = (view, off, val) => {
          if (!val || val.length === 0) {
            pointerPacker(view, off, null);
            return;
          }
          const packedView = packObjectArray(val);
          pointerPacker(view, off, ptr2(packedView.buffer));
          retainPointerTarget(view.buffer, packedView.buffer);
        };
        unpack = () => {
          throw new Error("not implemented yet");
        };
      } else {
        throw new Error(`Unsupported array element type for ${name}: ${JSON.stringify(def)}`);
      }
      arrayElementSizes[name] = arrayElementSize;
    } else {
      throw new Error(`Unsupported field type for ${name}: ${JSON.stringify(typeOrStruct)}`);
    }
    offset = alignOffset(offset, align);
    if (plainPrimitiveFields && plainPrimitiveType) {
      plainPrimitiveFields.push({ name, offset, type: plainPrimitiveType });
    }
    if (primitiveDecodeFields) {
      if (isPrimitiveType(typeOrStruct) && !options.unpackTransform) {
        primitiveDecodeFields.push({ name, offset, type: typeOrStruct });
      } else {
        primitiveDecodeFields = null;
      }
    }
    if (options.unpackTransform) {
      directInlineUnpackSafe = false;
      const originalUnpack = unpack;
      unpack = (view, off) => options.unpackTransform(originalUnpack(view, off));
    }
    if (options.packTransform) {
      const originalPack = pack;
      pack = (view, off, val, obj, packOptions) => originalPack(view, off, options.packTransform(val), obj, packOptions);
    }
    if (options.optional) {
      const originalPack = pack;
      if (isStruct(typeOrStruct) && !options.asPointer) {
        pack = (view, off, val, obj, packOptions) => {
          if (val || options.mapOptionalInline) {
            originalPack(view, off, val, obj, packOptions);
          }
        };
      } else {
        pack = (view, off, val, obj, packOptions) => originalPack(view, off, val ?? 0, obj, packOptions);
      }
    }
    if (options.lengthOf) {
      const originalPack = pack;
      pack = (view, off, val, obj, packOptions) => {
        const targetValue = obj[options.lengthOf];
        let length = 0;
        if (targetValue) {
          if (typeof targetValue === "string") {
            length = Buffer.byteLength(targetValue);
          } else {
            length = targetValue.length;
          }
        }
        return originalPack(view, off, length, obj, packOptions);
      };
    }
    let validateFunctions;
    if (options.validate) {
      validateFunctions = Array.isArray(options.validate) ? options.validate : [options.validate];
    }
    const layoutField = {
      name,
      offset,
      size,
      align,
      validate: validateFunctions,
      optional: !!options.optional || !!options.lengthOf || options.default !== undefined,
      default: options.default,
      pack,
      unpack,
      unpackTransform: options.unpackTransform,
      type: typeOrStruct,
      lengthOf: options.lengthOf
    };
    layout.push(layoutField);
    if (options.lengthOf) {
      lengthOfFields[options.lengthOf] = layoutField;
    }
    if (needsLengthOf) {
      const def = typeof typeOrStruct === "string" && typeOrStruct === "char*" ? "char*" : lengthOfDef;
      if (!def)
        fatalError(`Internal error: needsLengthOf=true but def is null for ${name}`);
      lengthOfRequested.push({ requester: layoutField, def });
    }
    offset += size;
    maxAlign = Math.max(maxAlign, align);
  }
  for (const [arrayName, lengthOfField] of Object.entries(lengthOfFields)) {
    const arrayField = layout.find((field) => field.name === arrayName);
    const elementSize = arrayElementSizes[arrayName];
    if (!arrayField || elementSize === undefined || !isPrimitiveType(lengthOfField.type))
      continue;
    const { pack: lengthPack } = primitivePackers(lengthOfField.type);
    arrayFieldsMetadata[arrayName] = {
      elementSize,
      arrayOffset: arrayField.offset,
      lengthOffset: lengthOfField.offset,
      lengthPack
    };
  }
  for (const { requester, def } of lengthOfRequested) {
    const lengthOfField = lengthOfFields[requester.name];
    if (!lengthOfField) {
      if (def === "char*") {
        continue;
      }
      throw new Error(`lengthOf field not found for array field ${requester.name}`);
    }
    if (def === "char*") {
      const relativeOffset = lengthOfField.offset - requester.offset;
      requester.unpack = (view, off) => {
        const ptrAddress = foreignMemoryPointerUnpacker(view, off);
        const length = lengthOfField.unpack(view, off + relativeOffset);
        if (isNullPointer(ptrAddress)) {
          return null;
        }
        const byteLength = toItemCount(length);
        if (byteLength === 0) {
          return "";
        }
        const buffer = toArrayBuffer2(ptrAddress, 0, byteLength);
        return decoder.decode(buffer);
      };
    } else if (isPrimitiveType(def)) {
      const elemSize = typeSizes[def];
      const { unpack: primitiveUnpack } = primitivePackers(def);
      const relativeOffset = lengthOfField.offset - requester.offset;
      requester.unpack = (view, off) => {
        const length = lengthOfField.unpack(view, off + relativeOffset);
        const itemCount = toItemCount(length);
        const ptrAddress = foreignMemoryPointerUnpacker(view, off);
        if (isNullPointer(ptrAddress) && itemCount > 0) {
          throw new Error(`Array field ${requester.name} has null pointer but length ${length}.`);
        }
        if (isNullPointer(ptrAddress) || itemCount === 0) {
          return [];
        }
        const buffer = toArrayBuffer2(ptrAddress, 0, itemCount * elemSize);
        const bufferView = new DataView(buffer);
        if (Number.isSafeInteger(itemCount) && itemCount >= arrayPreallocationThreshold && itemCount <= maxArrayLength) {
          const result2 = new Array(itemCount);
          for (let i = 0;i < itemCount; i++) {
            result2[i] = primitiveUnpack(bufferView, i * elemSize);
          }
          return result2;
        }
        const result = [];
        for (let i = 0;i < itemCount; i++)
          result.push(primitiveUnpack(bufferView, i * elemSize));
        return result;
      };
    } else {
      const elemSize = typeSizes[def.type];
      const { unpack: enumUnpack } = primitivePackers(def.type);
      const relativeOffset = lengthOfField.offset - requester.offset;
      requester.unpack = (view, off) => {
        const length = lengthOfField.unpack(view, off + relativeOffset);
        const itemCount = toItemCount(length);
        const ptrAddress = foreignMemoryPointerUnpacker(view, off);
        if (isNullPointer(ptrAddress) && itemCount > 0) {
          throw new Error(`Array field ${requester.name} has null pointer but length ${length}.`);
        }
        if (isNullPointer(ptrAddress) || itemCount === 0) {
          return [];
        }
        const buffer = toArrayBuffer2(ptrAddress, 0, itemCount * elemSize);
        const bufferView = new DataView(buffer);
        if (Number.isSafeInteger(itemCount) && itemCount >= arrayPreallocationThreshold && itemCount <= maxArrayLength) {
          const result2 = new Array(itemCount);
          for (let i = 0;i < itemCount; i++) {
            result2[i] = def.from(enumUnpack(bufferView, i * elemSize));
          }
          return result2;
        }
        const result = [];
        for (let i = 0;i < itemCount; i++)
          result.push(def.from(enumUnpack(bufferView, i * elemSize)));
        return result;
      };
    }
    if (requester.unpackTransform) {
      const originalUnpack = requester.unpack;
      requester.unpack = (view, off) => requester.unpackTransform(originalUnpack(view, off));
    }
  }
  const totalSize = alignOffset(offset, maxAlign);
  const description = layout.map((f) => ({
    name: f.name,
    offset: f.offset,
    size: f.size,
    align: f.align,
    optional: f.optional,
    type: f.type,
    lengthOf: f.lengthOf
  }));
  const layoutByName = new Map(description.map((f) => [f.name, f]));
  const arrayFields = new Map(Object.entries(arrayFieldsMetadata));
  const iterableArrayFields = layout.filter((field) => Array.isArray(field.type));
  if (plainPrimitiveFields?.length !== layout.length || plainPrimitiveFields.length === 0)
    plainPrimitiveFields = null;
  const supportsPackListInto = !!plainPrimitiveFields;
  if (primitiveDecodeFields?.length !== layout.length || primitiveDecodeFields.length === 0) {
    primitiveDecodeFields = null;
  }
  let plainPrimitivePackList;
  let plainPrimitiveUnpackList;
  let reducedPrimitiveUnpackList;
  let plainPrimitivePack;
  let plainPrimitivePackInto;
  let plainPrimitivePackListInto;
  let plainPrimitiveUnpack;
  let plainPrimitiveUnpackInto;
  let plainPrimitivePackListItems = 0;
  let plainPrimitivePackListIntoItems = 0;
  let plainPrimitiveUnpackListItems = 0;
  let reducedPrimitiveUnpackListItems = 0;
  let plainPrimitivePackCalls = 0;
  let plainPrimitivePackIntoCalls = 0;
  let plainPrimitiveUnpackCalls = 0;
  let plainPrimitiveUnpackIntoCalls = 0;
  const compilePlainPrimitive = (compile) => {
    try {
      return compile();
    } catch (error) {
      if (!(error instanceof EvalError))
        throw error;
      plainPrimitiveFields = null;
      primitiveDecodeFields = null;
      return;
    }
  };
  const validateDecodeRange = (view, decodeOffset) => {
    if (!Number.isSafeInteger(decodeOffset) || decodeOffset < 0) {
      throw new RangeError(`Decode offset must be a non-negative safe integer, got ${decodeOffset}`);
    }
    if (decodeOffset > view.byteLength - totalSize) {
      throw new RangeError(`DataView range (${view.byteLength} bytes) is too small for a struct at offset ${decodeOffset}`);
    }
  };
  const decodeFieldsInto = (target, view, baseOffset) => {
    if (structDefOptions?.default)
      Object.assign(target, structDefOptions.default);
    for (const field of layout) {
      if (!field.unpack)
        continue;
      try {
        target[field.name] = field.unpack(view, baseOffset + field.offset);
      } catch (error) {
        console.error(`Error unpacking field '${field.name}' at offset ${field.offset}:`, error);
        throw error;
      }
    }
  };
  const unpackInto = (view, target, decodeOffset = 0) => {
    validateDecodeRange(view, decodeOffset);
    if (plainPrimitiveFields && (plainPrimitiveUnpackInto || ++plainPrimitiveUnpackIntoCalls >= plainPrimitiveSpecializationThreshold)) {
      plainPrimitiveUnpackInto ??= compilePlainPrimitive(() => compilePlainPrimitiveUnpackInto(plainPrimitiveFields));
      if (plainPrimitiveUnpackInto)
        return plainPrimitiveUnpackInto(view, target, decodeOffset);
    }
    decodeFieldsInto(target, view, decodeOffset);
    return target;
  };
  const materializeArrayIterables = iterableArrayFields.length === 0 ? null : (obj) => {
    let normalized = obj;
    for (const field of iterableArrayFields) {
      const value = obj[field.name];
      if (value == null || Array.isArray(value) || ArrayBuffer.isView(value))
        continue;
      if (typeof value[Symbol.iterator] !== "function")
        continue;
      if (normalized === obj)
        normalized = { ...obj };
      normalized[field.name] = Array.from(value);
    }
    return normalized;
  };
  const definition = {
    __type: "struct",
    size: totalSize,
    align: maxAlign,
    hasMapValue: !!structDefOptions?.mapValue,
    layoutByName,
    arrayFields,
    pack(obj, options) {
      if (plainPrimitiveFields && (plainPrimitivePack || ++plainPrimitivePackCalls >= plainPrimitiveSpecializationThreshold)) {
        plainPrimitivePack ??= compilePlainPrimitive(() => compilePlainPrimitivePack(plainPrimitiveFields, totalSize));
        if (plainPrimitivePack)
          return plainPrimitivePack(obj);
      }
      const buf = new ArrayBuffer(totalSize);
      const view = new DataView(buf);
      let mappedObj = obj;
      if (structDefOptions?.mapValue) {
        mappedObj = structDefOptions.mapValue(obj);
      }
      if (materializeArrayIterables)
        mappedObj = materializeArrayIterables(mappedObj);
      if (hasDirectInlinePack)
        freshPackBuffers.add(buf);
      try {
        for (const field of layout) {
          const value = mappedObj[field.name] ?? field.default;
          if (!field.optional && value === undefined) {
            fatalError(`Packing non-optional field '${field.name}' but value is undefined (and no default provided)`);
          }
          if (field.validate) {
            for (const validateFn of field.validate) {
              validateFn(value, field.name, {
                hints: options?.validationHints,
                input: mappedObj
              });
            }
          }
          field.pack(view, field.offset, value, mappedObj, options);
        }
      } finally {
        if (hasDirectInlinePack)
          freshPackBuffers.delete(buf);
      }
      return view.buffer;
    },
    packInto(obj, view, offset2, options) {
      if (plainPrimitiveFields && (plainPrimitivePackInto || ++plainPrimitivePackIntoCalls >= plainPrimitiveSpecializationThreshold)) {
        plainPrimitivePackInto ??= compilePlainPrimitive(() => compilePlainPrimitivePackInto(plainPrimitiveFields));
        if (plainPrimitivePackInto) {
          plainPrimitivePackInto(obj, view, offset2);
          return;
        }
      }
      let mappedObj = obj;
      if (structDefOptions?.mapValue) {
        mappedObj = structDefOptions.mapValue(obj);
      }
      if (materializeArrayIterables)
        mappedObj = materializeArrayIterables(mappedObj);
      for (const field of layout) {
        const value = mappedObj[field.name] ?? field.default;
        if (!field.optional && value === undefined) {
          console.warn(`packInto missing value for non-optional field '${field.name}' at offset ${offset2 + field.offset}. Writing default or zero.`);
        }
        if (field.validate) {
          for (const validateFn of field.validate) {
            validateFn(value, field.name, {
              hints: options?.validationHints,
              input: mappedObj
            });
          }
        }
        field.pack(view, offset2 + field.offset, value, mappedObj, options);
      }
    },
    unpack(buf) {
      if (buf.byteLength < totalSize) {
        fatalError(`Buffer size (${buf.byteLength}) is smaller than struct size (${totalSize}) for unpacking.`);
      }
      const view = new DataView(buf);
      if (plainPrimitiveFields && (plainPrimitiveUnpack || ++plainPrimitiveUnpackCalls >= plainPrimitiveSpecializationThreshold)) {
        plainPrimitiveUnpack ??= compilePlainPrimitive(() => compilePlainPrimitiveUnpack(plainPrimitiveFields));
        if (plainPrimitiveUnpack)
          return plainPrimitiveUnpack(view);
      }
      const result = structDefOptions?.default ? { ...structDefOptions.default } : {};
      for (const field of layout) {
        if (!field.unpack) {
          continue;
        }
        try {
          result[field.name] = field.unpack(view, field.offset);
        } catch (e) {
          console.error(`Error unpacking field '${field.name}' at offset ${field.offset}:`, e);
          throw e;
        }
      }
      if (structDefOptions?.reduceValue) {
        return structDefOptions.reduceValue(result);
      }
      return result;
    },
    packList(objects, options) {
      if (objects.length === 0) {
        return new ArrayBuffer(0);
      }
      if (plainPrimitiveFields) {
        plainPrimitivePackListItems += objects.length;
        if (plainPrimitivePackList || objects.length > 1 && plainPrimitivePackListItems >= plainPrimitiveSpecializationThreshold) {
          plainPrimitivePackList ??= compilePlainPrimitive(() => compilePlainPrimitivePackList(plainPrimitiveFields, totalSize));
          if (plainPrimitivePackList)
            return plainPrimitivePackList(objects);
        }
      }
      const buffer = new ArrayBuffer(totalSize * objects.length);
      const view = new DataView(buffer);
      if (hasDirectInlinePack)
        freshPackBuffers.add(buffer);
      try {
        for (let i = 0;i < objects.length; i++) {
          let mappedObj = objects[i];
          if (structDefOptions?.mapValue) {
            mappedObj = structDefOptions.mapValue(objects[i]);
          }
          if (materializeArrayIterables)
            mappedObj = materializeArrayIterables(mappedObj);
          for (const field of layout) {
            const value = mappedObj[field.name] ?? field.default;
            if (!field.optional && value === undefined) {
              fatalError(`Packing non-optional field '${field.name}' at index ${i} but value is undefined (and no default provided)`);
            }
            if (field.validate) {
              for (const validateFn of field.validate) {
                validateFn(value, field.name, {
                  hints: options?.validationHints,
                  input: mappedObj
                });
              }
            }
            field.pack(view, i * totalSize + field.offset, value, mappedObj, options);
          }
        }
      } finally {
        if (hasDirectInlinePack)
          freshPackBuffers.delete(buffer);
      }
      return buffer;
    },
    packListInto(objects, view, offset2, options) {
      if (objects.length === 0)
        return;
      if (!supportsPackListInto)
        throw new Error("packListInto only supports required primitive fields");
      if (plainPrimitiveFields) {
        plainPrimitivePackListIntoItems += objects.length;
        if (plainPrimitivePackListInto || objects.length > 1 && plainPrimitivePackListIntoItems >= plainPrimitiveSpecializationThreshold) {
          plainPrimitivePackListInto ??= compilePlainPrimitive(() => compilePlainPrimitivePackListInto(plainPrimitiveFields, totalSize));
          if (plainPrimitivePackListInto) {
            plainPrimitivePackListInto(objects, view, offset2);
            return;
          }
        }
      }
      for (let index = 0;index < objects.length; index += 1) {
        definition.packInto(objects[index], view, offset2 + index * totalSize, options);
      }
    },
    unpackList(buf, count) {
      if (count === 0) {
        return [];
      }
      const expectedSize = totalSize * count;
      if (buf.byteLength < expectedSize) {
        fatalError(`Buffer size (${buf.byteLength}) is smaller than expected size (${expectedSize}) for unpacking ${count} structs.`);
      }
      const view = new DataView(buf);
      if (plainPrimitiveFields && Number.isSafeInteger(count) && count > 1) {
        plainPrimitiveUnpackListItems += count;
        if (plainPrimitiveUnpackList || plainPrimitiveUnpackListItems >= plainPrimitiveSpecializationThreshold) {
          plainPrimitiveUnpackList ??= compilePlainPrimitive(() => compilePlainPrimitiveUnpackList(plainPrimitiveFields, totalSize));
          if (plainPrimitiveUnpackList)
            return plainPrimitiveUnpackList(view, count);
        }
      }
      if (!plainPrimitiveFields && primitiveDecodeFields && Number.isSafeInteger(count) && count > 1) {
        reducedPrimitiveUnpackListItems += count;
        if (reducedPrimitiveUnpackList || reducedPrimitiveUnpackListItems >= plainPrimitiveSpecializationThreshold) {
          reducedPrimitiveUnpackList ??= compilePlainPrimitive(() => compileReducedPrimitiveUnpackList(primitiveDecodeFields, totalSize, structDefOptions));
          if (reducedPrimitiveUnpackList)
            return reducedPrimitiveUnpackList(view, count);
        }
      }
      const preallocated = Number.isSafeInteger(count) && count >= arrayPreallocationThreshold && count <= maxArrayLength;
      const results = preallocated ? new Array(count) : [];
      for (let i = 0;i < count; i++) {
        const offset2 = i * totalSize;
        const result = structDefOptions?.default ? { ...structDefOptions.default } : {};
        for (const field of layout) {
          if (!field.unpack) {
            continue;
          }
          try {
            result[field.name] = field.unpack(view, offset2 + field.offset);
          } catch (e) {
            console.error(`Error unpacking field '${field.name}' at index ${i}, offset ${offset2 + field.offset}:`, e);
            throw e;
          }
        }
        if (structDefOptions?.reduceValue) {
          const value = structDefOptions.reduceValue(result);
          if (preallocated)
            results[i] = value;
          else
            results.push(value);
        } else {
          if (preallocated)
            results[i] = result;
          else
            results.push(result);
        }
      }
      return results;
    },
    describe() {
      return description;
    }
  };
  if (!structDefOptions?.reduceValue)
    Object.assign(definition, { unpackInto });
  structInternals.set(definition, {
    layout,
    options: structDefOptions,
    publicPack: definition.pack,
    publicUnpack: definition.unpack,
    hasDirectInlinePack,
    directInlineUnpackSafe,
    materializeArrayIterables
  });
  return definition;
}

// src/zig-structs.ts
var BuildOptionsStruct = defineStruct([
  ["gpaSafeStats", "bool_u8"],
  ["gpaMemoryLimitTracking", "bool_u8"]
]);
var AllocatorStatsStruct = defineStruct([
  ["totalRequestedBytes", "u64"],
  ["activeAllocations", "u64"],
  ["smallAllocations", "u64"],
  ["largeAllocations", "u64"],
  ["requestedBytesValid", "bool_u8"]
]);
var GrowthPolicyEnum = defineEnum({ grow: 0, block: 1 }, "u8");
var NativeSpanFeedOptionsStruct = defineStruct([
  ["chunkSize", "u32", { default: 64 * 1024 }],
  ["initialChunks", "u32", { default: 2 }],
  ["maxBytes", "u64", { default: 0n }],
  ["growthPolicy", GrowthPolicyEnum, { default: "grow" }],
  ["autoCommitOnFull", "bool_u8", { default: true }],
  ["spanQueueCapacity", "u32", { default: 0 }]
]);
var NativeSpanFeedStatsStruct = defineStruct([
  ["bytesWritten", "u64"],
  ["spansCommitted", "u64"],
  ["chunks", "u32"],
  ["pendingSpans", "u32"],
  ["outstandingSpans", "u32"],
  ["reserved", "u32", { default: 0 }],
  ["outstandingBytes", "u64"]
]);
var SpanInfoStruct = defineStruct([
  ["chunkPtr", "pointer"],
  ["offset", "u32"],
  ["len", "u32"],
  ["chunkIndex", "u32"],
  ["slotIndex", "u32", { default: 0 }],
  ["releaseId", "u64", { default: 0n }]
], {
  reduceValue: (value) => value
});
var ReserveInfoStruct = defineStruct([
  ["ptr", "pointer"],
  ["len", "u32"],
  ["reserved", "u32", { default: 0 }]
], {
  reduceValue: (value) => ({
    ptr: value.ptr,
    len: value.len
  })
});
var NativeAudioStreamFormat2 = {
  Mp3: 1,
  Flac: 2,
  Pcm: 3
};
var NativeAudioStreamState2 = {
  Initializing: 0,
  Buffering: 1,
  Playing: 2,
  Ended: 3,
  Failed: 4,
  Cancelled: 5,
  Reconnecting: 6
};
var NativeAudioStreamStateNames = [
  "initializing",
  "buffering",
  "playing",
  "ended",
  "errored",
  "disposed",
  "reconnecting"
];
var NativeAudioStreamCloseReason2 = {
  PreserveNativeTerminal: 0,
  TransportError: 1,
  Disposed: 2
};
var AudioCreateOptionsStruct = defineStruct([
  ["sampleRate", "u32", { default: 48000 }],
  ["playbackChannels", "u32", { default: 2 }]
]);
var AudioStartOptionsStruct = defineStruct([
  ["periodSizeInFrames", "u32", { default: 0 }],
  ["periodSizeInMilliseconds", "u32", { default: 0 }],
  ["periods", "u32", { default: 0 }],
  ["performanceProfile", "u8", { default: 0 }],
  ["shareMode", "u8", { default: 0 }],
  ["noPreSilencedOutputBuffer", "bool_u8", { default: false }],
  ["noClip", "bool_u8", { default: false }],
  ["noDisableDenormals", "bool_u8", { default: false }],
  ["noFixedSizedCallback", "bool_u8", { default: false }],
  ["wasapiNoAutoConvertSrc", "bool_u8", { default: false }],
  ["wasapiNoDefaultQualitySrc", "bool_u8", { default: false }],
  ["alsaNoMMap", "bool_u8", { default: false }],
  ["alsaNoAutoFormat", "bool_u8", { default: false }],
  ["alsaNoAutoChannels", "bool_u8", { default: false }],
  ["alsaNoAutoResample", "bool_u8", { default: false }]
]);
var AudioVoiceOptionsStruct = defineStruct([
  ["volume", "f32", { default: 1 }],
  ["pan", "f32", { default: 0 }],
  ["loop", "bool_u8", { default: false }],
  ["groupId", "u32", { default: 0 }]
]);
var AudioStreamCreateOptionsStruct = defineStruct([
  ["capacityMs", "u32"],
  ["startupMs", "u32"],
  ["resumeMs", "u32"],
  ["volume", "f32"],
  ["pan", "f32"],
  ["groupId", "u32"],
  ["maxProbeBytes", "u32"],
  ["format", "u32"],
  ["sampleRate", "u32", { default: 0 }],
  ["channels", "u32", { default: 0 }]
]);
var AudioStreamStatsStruct = defineStruct([
  ["bytesReceived", "u64"],
  ["framesDecoded", "u64"],
  ["framesPlayed", "u64"],
  ["state", "u32"],
  ["sampleRate", "u32"],
  ["channels", "u32"],
  ["bufferedFrames", "u32"],
  ["capacityFrames", "u32"],
  ["underruns", "u32"],
  ["errorCode", "i32"],
  ["readyGeneration", "u32"]
]);
var AudioCaptureStatsStruct = defineStruct([
  ["framesReceived", "u64"],
  ["framesRead", "u64"],
  ["framesDropped", "u64"],
  ["sampleRate", "u32"],
  ["channels", "u32"],
  ["bufferedFrames", "u32"],
  ["capacityFrames", "u32"]
]);
var AudioStatsStruct = defineStruct([
  ["soundsLoaded", "u32"],
  ["voicesActive", "u32"],
  ["framesMixed", "u64"],
  ["lockMisses", "u32"],
  ["lastPeak", "f32"],
  ["lastRms", "f32"]
]);

// src/lib/bunfs.ts
import { basename, join as join2 } from "node:path";
function isBunfsPath(path) {
  return path.includes("$bunfs") || /^B:[\\/]~BUN/i.test(path);
}
function getBunfsRootPath() {
  return process.platform === "win32" ? "B:\\~BUN\\root" : "/$bunfs/root";
}
function normalizeBunfsPath(fileName) {
  return join2(getBunfsRootPath(), basename(fileName));
}

// src/node-asset-target.ts
var NATIVE_FILE_NAMES = {
  darwin: "libopentui.dylib",
  linux: "libopentui.so",
  win32: "opentui.dll"
};
function getNativeAssetDescriptor(target) {
  if (!Object.hasOwn(NATIVE_FILE_NAMES, target.platform) || target.arch !== "arm64" && target.arch !== "x64") {
    throw new Error(`Unsupported OpenTUI Node asset target: ${String(target.platform)}-${String(target.arch)}`);
  }
  if (target.libc !== undefined && target.libc !== "glibc" && target.libc !== "musl") {
    throw new Error(`Unsupported libc for OpenTUI Node assets: ${String(target.libc)}`);
  }
  if (target.platform !== "linux" && target.libc !== undefined) {
    throw new Error(`OpenTUI Node asset target libc is only supported on Linux, got ${target.platform}`);
  }
  const libcSuffix = target.platform === "linux" && target.libc === "musl" ? "-musl" : "";
  const packageName = `@opentui/core-${target.platform}-${target.arch}${libcSuffix}`;
  const fileName = NATIVE_FILE_NAMES[target.platform];
  return {
    key: `${packageName}/${fileName}`,
    packageName,
    fileName
  };
}
function getCurrentNodeAssetTarget() {
  const libc = process.env.OPENTUI_LIBC;
  if (process.platform === "linux" && libc !== undefined && libc !== "" && libc !== "glibc" && libc !== "musl") {
    throw new Error(`On Linux, OPENTUI_LIBC must be unset, empty, "glibc", or "musl", got ${JSON.stringify(libc)}`);
  }
  return {
    platform: process.platform,
    arch: process.arch,
    ...process.platform === "linux" && libc === "musl" ? { libc } : {}
  };
}

// src/platform/runtime-assets.node.ts
var CORE_ASSET_PREFIX = "@opentui/core/";
var PARSER_WORKER_ASSET_KEY = `${CORE_ASSET_PREFIX}parser.worker.js`;
var TREE_SITTER_WASM_ASSET_KEY = "web-tree-sitter/tree-sitter.wasm";
function resolveDefaultParserAsset(relativePath, fallbackPath) {
  return Promise.resolve(resolveAssetPath(`${CORE_ASSET_PREFIX}${relativePath}`, fallbackPath));
}
function resolveDefaultTreeSitterWorkerPath(fallbackPath) {
  return resolveAssetPath(PARSER_WORKER_ASSET_KEY, fallbackPath);
}
function resolveTreeSitterWasm() {
  return Promise.resolve(resolveAssetPath(TREE_SITTER_WASM_ASSET_KEY, () => new URL(import.meta.resolve(TREE_SITTER_WASM_ASSET_KEY))));
}
async function resolveNativeLibraryPath() {
  const asset = getNativeAssetDescriptor(getCurrentNodeAssetTarget());
  const configuredPath = resolveAssetRootPath(asset.key);
  if (configuredPath !== undefined) {
    return configuredPath;
  }
  const specifier = asset.packageName;
  return (await import(specifier)).default;
}

// src/zig.ts
var NativeAudioStreamState3 = NativeAudioStreamState2;
var NativeAudioStreamCloseReason3 = NativeAudioStreamCloseReason2;
var NativeAudioStreamFormat3 = NativeAudioStreamFormat2;
registerEnvVar2({
  name: "OPENTUI_LIBC",
  description: "Select Linux native libc package. Supported values: glibc, musl.",
  type: "string",
  default: ""
});
var lastStandaloneHandle = 0;
function nextStandaloneHandle() {
  if (lastStandaloneHandle === Number.MAX_SAFE_INTEGER)
    throw new RangeError("Native handle limit reached");
  return ++lastStandaloneHandle;
}
var MAX_LINK_URL_BYTES2 = 512;
function allocFFIStruct(structDefinition) {
  const storage = allocStruct(structDefinition);
  return { ...storage, ffiView: new Uint8Array(storage.buffer) };
}
var NativeTextViewCommand2;
((NativeTextViewCommand) => {
  NativeTextViewCommand[NativeTextViewCommand["WrapWidth"] = 0] = "WrapWidth";
  NativeTextViewCommand[NativeTextViewCommand["WrapMode"] = 1] = "WrapMode";
  NativeTextViewCommand[NativeTextViewCommand["FirstLineOffset"] = 2] = "FirstLineOffset";
  NativeTextViewCommand[NativeTextViewCommand["TabIndicator"] = 3] = "TabIndicator";
  NativeTextViewCommand[NativeTextViewCommand["Truncate"] = 4] = "Truncate";
  NativeTextViewCommand[NativeTextViewCommand["TextAlign"] = 5] = "TextAlign";
})(NativeTextViewCommand2 ||= {});
var NativeEditCommand2;
((NativeEditCommand) => {
  NativeEditCommand[NativeEditCommand["DeleteForward"] = 0] = "DeleteForward";
  NativeEditCommand[NativeEditCommand["Backspace"] = 1] = "Backspace";
  NativeEditCommand[NativeEditCommand["NewLine"] = 2] = "NewLine";
  NativeEditCommand[NativeEditCommand["DeleteLine"] = 3] = "DeleteLine";
  NativeEditCommand[NativeEditCommand["MoveLeft"] = 4] = "MoveLeft";
  NativeEditCommand[NativeEditCommand["MoveRight"] = 5] = "MoveRight";
  NativeEditCommand[NativeEditCommand["MoveUp"] = 6] = "MoveUp";
  NativeEditCommand[NativeEditCommand["MoveDown"] = 7] = "MoveDown";
  NativeEditCommand[NativeEditCommand["GotoLine"] = 8] = "GotoLine";
  NativeEditCommand[NativeEditCommand["CursorOffset"] = 9] = "CursorOffset";
  NativeEditCommand[NativeEditCommand["Clear"] = 10] = "Clear";
  NativeEditCommand[NativeEditCommand["ClearHistory"] = 11] = "ClearHistory";
  NativeEditCommand[NativeEditCommand["DebugRope"] = 12] = "DebugRope";
})(NativeEditCommand2 ||= {});
var NativeEditPositionQuery2;
((NativeEditPositionQuery) => {
  NativeEditPositionQuery[NativeEditPositionQuery["Cursor"] = 0] = "Cursor";
  NativeEditPositionQuery[NativeEditPositionQuery["NextWord"] = 1] = "NextWord";
  NativeEditPositionQuery[NativeEditPositionQuery["PrevWord"] = 2] = "PrevWord";
  NativeEditPositionQuery[NativeEditPositionQuery["Eol"] = 3] = "Eol";
  NativeEditPositionQuery[NativeEditPositionQuery["Offset"] = 4] = "Offset";
  NativeEditPositionQuery[NativeEditPositionQuery["Coords"] = 5] = "Coords";
  NativeEditPositionQuery[NativeEditPositionQuery["LineStart"] = 6] = "LineStart";
})(NativeEditPositionQuery2 ||= {});
var NativeEditorStyleMask2;
((NativeEditorStyleMask) => {
  NativeEditorStyleMask[NativeEditorStyleMask["Foreground"] = 1] = "Foreground";
  NativeEditorStyleMask[NativeEditorStyleMask["Background"] = 2] = "Background";
  NativeEditorStyleMask[NativeEditorStyleMask["Attributes"] = 4] = "Attributes";
  NativeEditorStyleMask[NativeEditorStyleMask["All"] = 7] = "All";
})(NativeEditorStyleMask2 ||= {});
var NativeEditHighlightOperation2;
((NativeEditHighlightOperation) => {
  NativeEditHighlightOperation[NativeEditHighlightOperation["AddLine"] = 0] = "AddLine";
  NativeEditHighlightOperation[NativeEditHighlightOperation["AddRange"] = 1] = "AddRange";
  NativeEditHighlightOperation[NativeEditHighlightOperation["RemoveRef"] = 2] = "RemoveRef";
  NativeEditHighlightOperation[NativeEditHighlightOperation["ClearLine"] = 3] = "ClearLine";
  NativeEditHighlightOperation[NativeEditHighlightOperation["ClearAll"] = 4] = "ClearAll";
})(NativeEditHighlightOperation2 ||= {});
var NativeEditorCommand2;
((NativeEditorCommand) => {
  NativeEditorCommand[NativeEditorCommand["MoveUp"] = 0] = "MoveUp";
  NativeEditorCommand[NativeEditorCommand["MoveDown"] = 1] = "MoveDown";
  NativeEditorCommand[NativeEditorCommand["GotoLineEnd"] = 2] = "GotoLineEnd";
  NativeEditorCommand[NativeEditorCommand["DeleteSelection"] = 3] = "DeleteSelection";
  NativeEditorCommand[NativeEditorCommand["CursorOffset"] = 4] = "CursorOffset";
  NativeEditorCommand[NativeEditorCommand["WrapMode"] = 5] = "WrapMode";
  NativeEditorCommand[NativeEditorCommand["TabIndicator"] = 6] = "TabIndicator";
})(NativeEditorCommand2 ||= {});
var NativeEditorSelectionOperation2;
((NativeEditorSelectionOperation) => {
  NativeEditorSelectionOperation[NativeEditorSelectionOperation["Set"] = 0] = "Set";
  NativeEditorSelectionOperation[NativeEditorSelectionOperation["Update"] = 1] = "Update";
  NativeEditorSelectionOperation[NativeEditorSelectionOperation["Reset"] = 2] = "Reset";
  NativeEditorSelectionOperation[NativeEditorSelectionOperation["Local"] = 3] = "Local";
  NativeEditorSelectionOperation[NativeEditorSelectionOperation["LocalUpdate"] = 4] = "LocalUpdate";
  NativeEditorSelectionOperation[NativeEditorSelectionOperation["LocalReset"] = 5] = "LocalReset";
  NativeEditorSelectionOperation[NativeEditorSelectionOperation["Cell"] = 6] = "Cell";
  NativeEditorSelectionOperation[NativeEditorSelectionOperation["Occupancy"] = 7] = "Occupancy";
  NativeEditorSelectionOperation[NativeEditorSelectionOperation["Inclusive"] = 8] = "Inclusive";
  NativeEditorSelectionOperation[NativeEditorSelectionOperation["Colors"] = 9] = "Colors";
})(NativeEditorSelectionOperation2 ||= {});
var NativeEditorPositionQuery2;
((NativeEditorPositionQuery) => {
  NativeEditorPositionQuery[NativeEditorPositionQuery["Cursor"] = 0] = "Cursor";
  NativeEditorPositionQuery[NativeEditorPositionQuery["NextWord"] = 1] = "NextWord";
  NativeEditorPositionQuery[NativeEditorPositionQuery["PrevWord"] = 2] = "PrevWord";
  NativeEditorPositionQuery[NativeEditorPositionQuery["Eol"] = 3] = "Eol";
  NativeEditorPositionQuery[NativeEditorPositionQuery["VisualSol"] = 4] = "VisualSol";
  NativeEditorPositionQuery[NativeEditorPositionQuery["VisualEol"] = 5] = "VisualEol";
})(NativeEditorPositionQuery2 ||= {});
var NativeEditEvent2;
((NativeEditEvent) => {
  NativeEditEvent[NativeEditEvent["CursorChanged"] = 1] = "CursorChanged";
  NativeEditEvent[NativeEditEvent["ContentChanged"] = 2] = "ContentChanged";
  NativeEditEvent[NativeEditEvent["HistoryCursorChanged"] = 4] = "HistoryCursorChanged";
})(NativeEditEvent2 ||= {});
var NATIVE_SCENE_MUTATIONS_MAX = nativeConstants.OT_SCENE_MUTATIONS_MAX;
var NativeStyleGroup;
((NativeStyleGroup) => {
  NativeStyleGroup[NativeStyleGroup["Enum"] = nativeConstants.OT_STYLE_ENUM] = "Enum";
  NativeStyleGroup[NativeStyleGroup["Float"] = nativeConstants.OT_STYLE_FLOAT] = "Float";
  NativeStyleGroup[NativeStyleGroup["Value"] = nativeConstants.OT_STYLE_VALUE] = "Value";
  NativeStyleGroup[NativeStyleGroup["Border"] = nativeConstants.OT_STYLE_BORDER] = "Border";
  NativeStyleGroup[NativeStyleGroup["Dimension"] = nativeConstants.OT_STYLE_DIMENSION] = "Dimension";
})(NativeStyleGroup ||= {});
var NativeStyleFlags;
((NativeStyleFlags) => {
  NativeStyleFlags[NativeStyleFlags["None"] = nativeConstants.OT_STYLE_FLAGS_NONE] = "None";
  NativeStyleFlags[NativeStyleFlags["DisableFlexShrink"] = nativeConstants.OT_STYLE_DISABLE_FLEX_SHRINK] = "DisableFlexShrink";
})(NativeStyleFlags ||= {});
var NATIVE_EDGE_NONE2 = nativeConstants.OT_EDGE_NONE;
var NativeBorder2;
((NativeBorder) => {
  NativeBorder[NativeBorder["None"] = nativeConstants.OT_BORDER_NONE] = "None";
  NativeBorder[NativeBorder["Left"] = nativeConstants.OT_BORDER_LEFT] = "Left";
  NativeBorder[NativeBorder["Bottom"] = nativeConstants.OT_BORDER_BOTTOM] = "Bottom";
  NativeBorder[NativeBorder["Right"] = nativeConstants.OT_BORDER_RIGHT] = "Right";
  NativeBorder[NativeBorder["Top"] = nativeConstants.OT_BORDER_TOP] = "Top";
  NativeBorder[NativeBorder["All"] = nativeConstants.OT_BORDER_ALL] = "All";
})(NativeBorder2 ||= {});
var NativeSceneHook2;
((NativeSceneHook) => {
  NativeSceneHook[NativeSceneHook["Update"] = nativeConstants.OT_SCENE_HOOK_UPDATE] = "Update";
  NativeSceneHook[NativeSceneHook["Resize"] = nativeConstants.OT_SCENE_HOOK_RESIZE] = "Resize";
  NativeSceneHook[NativeSceneHook["LayoutChanged"] = nativeConstants.OT_SCENE_HOOK_LAYOUT_CHANGED] = "LayoutChanged";
  NativeSceneHook[NativeSceneHook["RenderBefore"] = nativeConstants.OT_SCENE_HOOK_RENDER_BEFORE] = "RenderBefore";
  NativeSceneHook[NativeSceneHook["RenderAfter"] = nativeConstants.OT_SCENE_HOOK_RENDER_AFTER] = "RenderAfter";
  NativeSceneHook[NativeSceneHook["RenderSelf"] = nativeConstants.OT_SCENE_HOOK_RENDER_SELF] = "RenderSelf";
  NativeSceneHook[NativeSceneHook["IdleUpdate"] = nativeConstants.OT_SCENE_HOOK_IDLE_UPDATE] = "IdleUpdate";
})(NativeSceneHook2 ||= {});
var NativeSceneFrame2;
((NativeSceneFrame) => {
  NativeSceneFrame[NativeSceneFrame["Done"] = nativeConstants.OT_SCENE_FRAME_DONE] = "Done";
  NativeSceneFrame[NativeSceneFrame["Update"] = nativeConstants.OT_SCENE_FRAME_UPDATE] = "Update";
  NativeSceneFrame[NativeSceneFrame["Resize"] = nativeConstants.OT_SCENE_FRAME_RESIZE] = "Resize";
  NativeSceneFrame[NativeSceneFrame["LayoutChanged"] = nativeConstants.OT_SCENE_FRAME_LAYOUT_CHANGED] = "LayoutChanged";
  NativeSceneFrame[NativeSceneFrame["Record"] = nativeConstants.OT_SCENE_FRAME_RECORD] = "Record";
  NativeSceneFrame[NativeSceneFrame["Yield"] = nativeConstants.OT_SCENE_FRAME_YIELD] = "Yield";
})(NativeSceneFrame2 ||= {});
var NativeScenePaintPhase2;
((NativeScenePaintPhase) => {
  NativeScenePaintPhase[NativeScenePaintPhase["Before"] = nativeConstants.OT_SCENE_RECORD_PHASE_BEFORE] = "Before";
  NativeScenePaintPhase[NativeScenePaintPhase["Self"] = nativeConstants.OT_SCENE_RECORD_PHASE_SELF] = "Self";
  NativeScenePaintPhase[NativeScenePaintPhase["After"] = nativeConstants.OT_SCENE_RECORD_PHASE_AFTER] = "After";
})(NativeScenePaintPhase2 ||= {});
var NATIVE_BUFFER_TEXT_BYTES_MAX2 = nativeConstants.OT_BUFFER_TEXT_BYTES_MAX;
var NativeSessionState2;
((NativeSessionState) => {
  NativeSessionState[NativeSessionState["Open"] = 0] = "Open";
  NativeSessionState[NativeSessionState["Closing"] = 1] = "Closing";
  NativeSessionState[NativeSessionState["Closed"] = 2] = "Closed";
  NativeSessionState[NativeSessionState["Failed"] = 3] = "Failed";
  NativeSessionState[NativeSessionState["Cancelled"] = 4] = "Cancelled";
})(NativeSessionState2 ||= {});
var NativeSessionRenderStatus2;
((NativeSessionRenderStatus) => {
  NativeSessionRenderStatus[NativeSessionRenderStatus["Presented"] = 0] = "Presented";
  NativeSessionRenderStatus[NativeSessionRenderStatus["Pending"] = 1] = "Pending";
  NativeSessionRenderStatus[NativeSessionRenderStatus["Skipped"] = 2] = "Skipped";
  NativeSessionRenderStatus[NativeSessionRenderStatus["Failed"] = 3] = "Failed";
})(NativeSessionRenderStatus2 ||= {});
var NATIVE_SESSION_CONTROL_PACKET_BYTES2 = nativeConstants.OT_SESSION_CONTROL_PACKET_BYTES;
var NativeSessionTerminalPhase2;
((NativeSessionTerminalPhase) => {
  NativeSessionTerminalPhase[NativeSessionTerminalPhase["Uninitialized"] = 0] = "Uninitialized";
  NativeSessionTerminalPhase[NativeSessionTerminalPhase["SettingUp"] = 1] = "SettingUp";
  NativeSessionTerminalPhase[NativeSessionTerminalPhase["Active"] = 2] = "Active";
  NativeSessionTerminalPhase[NativeSessionTerminalPhase["Suspending"] = 3] = "Suspending";
  NativeSessionTerminalPhase[NativeSessionTerminalPhase["Suspended"] = 4] = "Suspended";
  NativeSessionTerminalPhase[NativeSessionTerminalPhase["Resuming"] = 5] = "Resuming";
  NativeSessionTerminalPhase[NativeSessionTerminalPhase["Closing"] = 6] = "Closing";
  NativeSessionTerminalPhase[NativeSessionTerminalPhase["Restored"] = 7] = "Restored";
  NativeSessionTerminalPhase[NativeSessionTerminalPhase["Failed"] = 8] = "Failed";
  NativeSessionTerminalPhase[NativeSessionTerminalPhase["Cancelled"] = 9] = "Cancelled";
})(NativeSessionTerminalPhase2 ||= {});
var NativeSessionPumpStatus2;
((NativeSessionPumpStatus) => {
  NativeSessionPumpStatus[NativeSessionPumpStatus["Idle"] = 0] = "Idle";
  NativeSessionPumpStatus[NativeSessionPumpStatus["Again"] = 1] = "Again";
  NativeSessionPumpStatus[NativeSessionPumpStatus["OutputPending"] = 2] = "OutputPending";
  NativeSessionPumpStatus[NativeSessionPumpStatus["WaitUntil"] = 3] = "WaitUntil";
  NativeSessionPumpStatus[NativeSessionPumpStatus["Closed"] = 4] = "Closed";
})(NativeSessionPumpStatus2 ||= {});
var NativeStatus2;
((NativeStatus) => {
  NativeStatus[NativeStatus["Ok"] = 0] = "Ok";
  NativeStatus[NativeStatus["InvalidArgument"] = -1] = "InvalidArgument";
  NativeStatus[NativeStatus["UnsupportedVersion"] = -2] = "UnsupportedVersion";
  NativeStatus[NativeStatus["OutOfMemory"] = -3] = "OutOfMemory";
  NativeStatus[NativeStatus["WrongThread"] = -4] = "WrongThread";
  NativeStatus[NativeStatus["InternalError"] = -5] = "InternalError";
  NativeStatus[NativeStatus["ContextBusy"] = -6] = "ContextBusy";
  NativeStatus[NativeStatus["WrongContext"] = -7] = "WrongContext";
  NativeStatus[NativeStatus["WrongKind"] = -8] = "WrongKind";
  NativeStatus[NativeStatus["StaleHandle"] = -9] = "StaleHandle";
  NativeStatus[NativeStatus["WrongSession"] = -10] = "WrongSession";
  NativeStatus[NativeStatus["OutputBackpressure"] = -11] = "OutputBackpressure";
  NativeStatus[NativeStatus["SessionClosed"] = -12] = "SessionClosed";
  NativeStatus[NativeStatus["OutputBusy"] = -13] = "OutputBusy";
  NativeStatus[NativeStatus["StaleOutput"] = -14] = "StaleOutput";
  NativeStatus[NativeStatus["OutputFailed"] = -15] = "OutputFailed";
  NativeStatus[NativeStatus["ObjectLimit"] = -16] = "ObjectLimit";
  NativeStatus[NativeStatus["RendererAttached"] = -17] = "RendererAttached";
  NativeStatus[NativeStatus["RendererNotAttached"] = -18] = "RendererNotAttached";
  NativeStatus[NativeStatus["InvalidPhase"] = -19] = "InvalidPhase";
  NativeStatus[NativeStatus["ControlPacketLimit"] = -20] = "ControlPacketLimit";
  NativeStatus[NativeStatus["LeaseLimit"] = -21] = "LeaseLimit";
  NativeStatus[NativeStatus["LeaseBytesLimit"] = -22] = "LeaseBytesLimit";
  NativeStatus[NativeStatus["StaleLease"] = -23] = "StaleLease";
  NativeStatus[NativeStatus["UnsupportedResource"] = -24] = "UnsupportedResource";
  NativeStatus[NativeStatus["StaleFrame"] = -25] = "StaleFrame";
  NativeStatus[NativeStatus["LayoutLimit"] = -26] = "LayoutLimit";
  NativeStatus[NativeStatus["FrameBusy"] = -27] = "FrameBusy";
  NativeStatus[NativeStatus["FrameRequestLimit"] = -28] = "FrameRequestLimit";
})(NativeStatus2 ||= {});

class NativeError2 extends Error {
  operation;
  status;
  constructor(operation, status, reason = NativeStatus2[status] ?? `status ${status}`) {
    super(`${operation} failed: ${reason}`);
    this.operation = operation;
    this.status = status;
    this.name = "NativeError";
  }
}
var imageStatusCodes = new Map([
  [nativeConstants.OT_OK, 0],
  [nativeConstants.OT_STALE_HANDLE, 1],
  [nativeConstants.OT_IMAGE_UNSUPPORTED_FORMAT, 2],
  [nativeConstants.OT_IMAGE_UNSUPPORTED_COLOR_SPACE, 3],
  [nativeConstants.OT_IMAGE_MALFORMED_DATA, 4],
  [nativeConstants.OT_IMAGE_DIMENSION_LIMIT, 5],
  [nativeConstants.OT_IMAGE_MEMORY_LIMIT, 6],
  [nativeConstants.OT_INVALID_ARGUMENT, 7],
  [nativeConstants.OT_OUT_OF_MEMORY, 8],
  [nativeConstants.OT_IMAGE_OUTPUT_TOO_SMALL, 9],
  [nativeConstants.OT_INTERNAL_ERROR, 10],
  [nativeConstants.OT_IMAGE_UNSUPPORTED_FEATURE, 11],
  [nativeConstants.OT_IMAGE_BUSY, 12]
]);
var NativeClipboardOperationStatus2;
((NativeClipboardOperationStatus) => {
  NativeClipboardOperationStatus[NativeClipboardOperationStatus["Pending"] = nativeConstants.OT_CLIPBOARD_OPERATION_PENDING] = "Pending";
  NativeClipboardOperationStatus[NativeClipboardOperationStatus["Read"] = nativeConstants.OT_CLIPBOARD_OPERATION_READ] = "Read";
  NativeClipboardOperationStatus[NativeClipboardOperationStatus["Empty"] = nativeConstants.OT_CLIPBOARD_OPERATION_EMPTY] = "Empty";
  NativeClipboardOperationStatus[NativeClipboardOperationStatus["Written"] = nativeConstants.OT_CLIPBOARD_OPERATION_WRITTEN] = "Written";
  NativeClipboardOperationStatus[NativeClipboardOperationStatus["Cleared"] = nativeConstants.OT_CLIPBOARD_OPERATION_CLEARED] = "Cleared";
  NativeClipboardOperationStatus[NativeClipboardOperationStatus["Unsupported"] = nativeConstants.OT_CLIPBOARD_OPERATION_UNSUPPORTED] = "Unsupported";
  NativeClipboardOperationStatus[NativeClipboardOperationStatus["Cancelled"] = nativeConstants.OT_CLIPBOARD_OPERATION_CANCELLED] = "Cancelled";
  NativeClipboardOperationStatus[NativeClipboardOperationStatus["TimedOut"] = nativeConstants.OT_CLIPBOARD_OPERATION_TIMED_OUT] = "TimedOut";
  NativeClipboardOperationStatus[NativeClipboardOperationStatus["LimitExceeded"] = nativeConstants.OT_CLIPBOARD_OPERATION_LIMIT_EXCEEDED] = "LimitExceeded";
  NativeClipboardOperationStatus[NativeClipboardOperationStatus["Failed"] = nativeConstants.OT_CLIPBOARD_OPERATION_FAILED] = "Failed";
  NativeClipboardOperationStatus[NativeClipboardOperationStatus["InvalidHandle"] = nativeConstants.OT_CLIPBOARD_OPERATION_INVALID_HANDLE] = "InvalidHandle";
})(NativeClipboardOperationStatus2 ||= {});
var NativeClipboardStartStatus2;
((NativeClipboardStartStatus) => {
  NativeClipboardStartStatus[NativeClipboardStartStatus["Ok"] = nativeConstants.OT_CLIPBOARD_START_OK] = "Ok";
  NativeClipboardStartStatus[NativeClipboardStartStatus["InvalidService"] = nativeConstants.OT_CLIPBOARD_START_INVALID_SERVICE] = "InvalidService";
  NativeClipboardStartStatus[NativeClipboardStartStatus["ShuttingDown"] = nativeConstants.OT_CLIPBOARD_START_SHUTTING_DOWN] = "ShuttingDown";
  NativeClipboardStartStatus[NativeClipboardStartStatus["LimitExceeded"] = nativeConstants.OT_CLIPBOARD_START_LIMIT_EXCEEDED] = "LimitExceeded";
  NativeClipboardStartStatus[NativeClipboardStartStatus["InvalidArgument"] = nativeConstants.OT_CLIPBOARD_START_INVALID_ARGUMENT] = "InvalidArgument";
  NativeClipboardStartStatus[NativeClipboardStartStatus["OutOfMemory"] = nativeConstants.OT_CLIPBOARD_START_OUT_OF_MEMORY] = "OutOfMemory";
})(NativeClipboardStartStatus2 ||= {});
var NativeClipboardCancelStatus2;
((NativeClipboardCancelStatus) => {
  NativeClipboardCancelStatus[NativeClipboardCancelStatus["Requested"] = nativeConstants.OT_CLIPBOARD_CANCEL_REQUESTED] = "Requested";
  NativeClipboardCancelStatus[NativeClipboardCancelStatus["AlreadyTerminal"] = nativeConstants.OT_CLIPBOARD_CANCEL_ALREADY_TERMINAL] = "AlreadyTerminal";
  NativeClipboardCancelStatus[NativeClipboardCancelStatus["InvalidHandle"] = nativeConstants.OT_CLIPBOARD_CANCEL_INVALID_HANDLE] = "InvalidHandle";
})(NativeClipboardCancelStatus2 ||= {});
var NativeClipboardCopyStatus2;
((NativeClipboardCopyStatus) => {
  NativeClipboardCopyStatus[NativeClipboardCopyStatus["Ok"] = nativeConstants.OT_CLIPBOARD_COPY_OK] = "Ok";
  NativeClipboardCopyStatus[NativeClipboardCopyStatus["BufferTooSmall"] = nativeConstants.OT_CLIPBOARD_COPY_BUFFER_TOO_SMALL] = "BufferTooSmall";
  NativeClipboardCopyStatus[NativeClipboardCopyStatus["InvalidHandle"] = nativeConstants.OT_CLIPBOARD_COPY_INVALID_HANDLE] = "InvalidHandle";
  NativeClipboardCopyStatus[NativeClipboardCopyStatus["InvalidState"] = nativeConstants.OT_CLIPBOARD_COPY_INVALID_STATE] = "InvalidState";
  NativeClipboardCopyStatus[NativeClipboardCopyStatus["InvalidArgument"] = nativeConstants.OT_CLIPBOARD_COPY_INVALID_ARGUMENT] = "InvalidArgument";
})(NativeClipboardCopyStatus2 ||= {});
var NativeClipboardDestroyStatus2;
((NativeClipboardDestroyStatus) => {
  NativeClipboardDestroyStatus[NativeClipboardDestroyStatus["Destroyed"] = nativeConstants.OT_CLIPBOARD_DESTROY_DESTROYED] = "Destroyed";
  NativeClipboardDestroyStatus[NativeClipboardDestroyStatus["NotReady"] = nativeConstants.OT_CLIPBOARD_DESTROY_NOT_READY] = "NotReady";
  NativeClipboardDestroyStatus[NativeClipboardDestroyStatus["InvalidHandle"] = nativeConstants.OT_CLIPBOARD_DESTROY_INVALID_HANDLE] = "InvalidHandle";
})(NativeClipboardDestroyStatus2 ||= {});
var NativeClipboardShutdownStatus2;
((NativeClipboardShutdownStatus) => {
  NativeClipboardShutdownStatus[NativeClipboardShutdownStatus["Pending"] = nativeConstants.OT_CLIPBOARD_SHUTDOWN_PENDING] = "Pending";
  NativeClipboardShutdownStatus[NativeClipboardShutdownStatus["Ready"] = nativeConstants.OT_CLIPBOARD_SHUTDOWN_READY] = "Ready";
  NativeClipboardShutdownStatus[NativeClipboardShutdownStatus["InvalidHandle"] = nativeConstants.OT_CLIPBOARD_SHUTDOWN_INVALID_HANDLE] = "InvalidHandle";
})(NativeClipboardShutdownStatus2 ||= {});
var targetLibPath;
var targetLibError;
try {
  targetLibPath = await resolveNativeLibraryPath();
  if (isBunfsPath(targetLibPath)) {
    targetLibPath = targetLibPath.replace("../", "");
  }
  if (!existsSync2(targetLibPath)) {
    throw new Error(`OpenTUI native library does not exist at ${JSON.stringify(targetLibPath)}`);
  }
} catch (error) {
  targetLibError = error instanceof Error ? error : new Error(String(error));
}
registerEnvVar2({
  name: "OTUI_DEBUG_FFI",
  description: "Enable debug logging for the FFI bindings.",
  type: "boolean",
  default: false
});
registerEnvVar2({
  name: "OTUI_TRACE_FFI",
  description: "Enable tracing for the FFI bindings.",
  type: "boolean",
  default: false
});
registerEnvVar2({
  name: "OPENTUI_FORCE_WCWIDTH",
  description: "Use wcwidth for character width calculations when the variable is present",
  type: "string",
  required: false
});
registerEnvVar2({
  name: "OPENTUI_FORCE_UNICODE",
  description: "Use the Unicode width method (mode 2027) when the variable is present",
  type: "string",
  required: false
});
registerEnvVar2({
  name: "OPENTUI_GRAPHICS",
  description: "Control Kitty and Sixel graphics detection with the exact value true, 1, false, or 0",
  type: "string",
  required: false
});
registerEnvVar2({
  name: "OPENTUI_IMAGE_PROTOCOL",
  description: "Override image rendering protocol: auto, kitty, sixel, or blocks",
  type: "string",
  default: "auto"
});
registerEnvVar2({
  name: "OPENTUI_FORCE_NOZWJ",
  description: "Use no_zwj width mode when the variable is present",
  type: "string",
  required: false
});
var CURSOR_STYLE_TO_ID = { block: 0, line: 1, underline: 2, default: 3 };
var CURSOR_ID_TO_STYLE = ["block", "line", "underline", "default"];
var PROGRAM_STATE_TO_ID = {
  idle: nativeConstants.OT_PROGRAM_STATE_IDLE,
  working: nativeConstants.OT_PROGRAM_STATE_WORKING,
  done: nativeConstants.OT_PROGRAM_STATE_DONE,
  blocked: nativeConstants.OT_PROGRAM_STATE_BLOCKED,
  error: nativeConstants.OT_PROGRAM_STATE_ERROR,
  clear: nativeConstants.OT_PROGRAM_STATE_CLEAR
};
var PROGRAM_KIND_TO_ID = {
  permission: nativeConstants.OT_PROGRAM_KIND_PERMISSION,
  question: nativeConstants.OT_PROGRAM_KIND_QUESTION,
  auth: nativeConstants.OT_PROGRAM_KIND_AUTH
};
var MOUSE_STYLE_TO_ID = {
  auto: nativeConstants.OT_MOUSE_POINTER_AUTO,
  default: nativeConstants.OT_MOUSE_POINTER_DEFAULT,
  none: nativeConstants.OT_MOUSE_POINTER_NONE,
  "context-menu": nativeConstants.OT_MOUSE_POINTER_CONTEXT_MENU,
  help: nativeConstants.OT_MOUSE_POINTER_HELP,
  pointer: nativeConstants.OT_MOUSE_POINTER_POINTER,
  progress: nativeConstants.OT_MOUSE_POINTER_PROGRESS,
  wait: nativeConstants.OT_MOUSE_POINTER_WAIT,
  cell: nativeConstants.OT_MOUSE_POINTER_CELL,
  crosshair: nativeConstants.OT_MOUSE_POINTER_CROSSHAIR,
  text: nativeConstants.OT_MOUSE_POINTER_TEXT,
  "vertical-text": nativeConstants.OT_MOUSE_POINTER_VERTICAL_TEXT,
  alias: nativeConstants.OT_MOUSE_POINTER_ALIAS,
  copy: nativeConstants.OT_MOUSE_POINTER_COPY,
  move: nativeConstants.OT_MOUSE_POINTER_MOVE,
  "no-drop": nativeConstants.OT_MOUSE_POINTER_NO_DROP,
  "not-allowed": nativeConstants.OT_MOUSE_POINTER_NOT_ALLOWED,
  grab: nativeConstants.OT_MOUSE_POINTER_GRAB,
  grabbing: nativeConstants.OT_MOUSE_POINTER_GRABBING,
  "all-scroll": nativeConstants.OT_MOUSE_POINTER_ALL_SCROLL,
  "col-resize": nativeConstants.OT_MOUSE_POINTER_COL_RESIZE,
  "row-resize": nativeConstants.OT_MOUSE_POINTER_ROW_RESIZE,
  "n-resize": nativeConstants.OT_MOUSE_POINTER_N_RESIZE,
  "e-resize": nativeConstants.OT_MOUSE_POINTER_E_RESIZE,
  "s-resize": nativeConstants.OT_MOUSE_POINTER_S_RESIZE,
  "w-resize": nativeConstants.OT_MOUSE_POINTER_W_RESIZE,
  "ne-resize": nativeConstants.OT_MOUSE_POINTER_NE_RESIZE,
  "nw-resize": nativeConstants.OT_MOUSE_POINTER_NW_RESIZE,
  "se-resize": nativeConstants.OT_MOUSE_POINTER_SE_RESIZE,
  "sw-resize": nativeConstants.OT_MOUSE_POINTER_SW_RESIZE,
  "ew-resize": nativeConstants.OT_MOUSE_POINTER_EW_RESIZE,
  "ns-resize": nativeConstants.OT_MOUSE_POINTER_NS_RESIZE,
  "nesw-resize": nativeConstants.OT_MOUSE_POINTER_NESW_RESIZE,
  "nwse-resize": nativeConstants.OT_MOUSE_POINTER_NWSE_RESIZE,
  "zoom-in": nativeConstants.OT_MOUSE_POINTER_ZOOM_IN,
  "zoom-out": nativeConstants.OT_MOUSE_POINTER_ZOOM_OUT
};
var SCENE_BORDER_STYLES = ["single", "double", "rounded", "heavy"];
var SCENE_TEXT_WRAP_MODES = ["none", "char", "word"];
var SCENE_TEXT_ALIGNS = ["left", "center", "right"];
var SCENE_NODE_KINDS = ["root", "box", "text", "slider", "arrow", "editor", "custom", "text_view", "image"];
var IMAGE_PROTOCOL_TO_ID = { auto: 0, kitty: 1, sixel: 2, blocks: 3 };
var IMAGE_FITS = ["fit", "cover", "fill"];
var BUFFER_DRAW_OPERATIONS = new Map([
  ["clear", { id: nativeConstants.OT_BUFFER_DRAW_CLEAR, size: nativeLayouts.ot_buffer_draw_clear.size }],
  ["fill", { id: nativeConstants.OT_BUFFER_DRAW_FILL, size: nativeLayouts.ot_buffer_draw_fill.size }],
  ["text", { id: nativeConstants.OT_BUFFER_DRAW_TEXT, size: nativeLayouts.ot_buffer_draw_text_record.size }],
  ["cell", { id: nativeConstants.OT_BUFFER_DRAW_CELL, size: nativeLayouts.ot_buffer_draw_cell.size }],
  ["cellBlend", { id: nativeConstants.OT_BUFFER_DRAW_CELL_BLEND, size: nativeLayouts.ot_buffer_draw_cell.size }],
  ["char", { id: nativeConstants.OT_BUFFER_DRAW_CHAR, size: nativeLayouts.ot_buffer_draw_cell.size }],
  ["box", { id: nativeConstants.OT_BUFFER_DRAW_BOX, size: nativeLayouts.ot_buffer_draw_box.size }],
  ["compose", { id: nativeConstants.OT_BUFFER_DRAW_COMPOSE, size: nativeLayouts.ot_buffer_draw_compose.size }],
  ["respectAlpha", { id: nativeConstants.OT_BUFFER_DRAW_RESPECT_ALPHA, size: nativeLayouts.ot_buffer_draw_alpha.size }]
]);
var BUFFER_STACK_OPERATIONS = [
  "getOpacity",
  "pushScissor",
  "popScissor",
  "clearScissors",
  "pushOpacity",
  "popOpacity",
  "clearOpacity"
];
var SCENE_ARROW_DIRECTIONS = ["up", "down", "left", "right"];
var MAX_FFI_U32 = 4294967295;
var processLogLibraries = [];
var globalTraceSymbols = null;
var globalFFILogPath = null;
var exitHandlerRegistered = false;
function toNumber(value) {
  return typeof value === "bigint" ? Number(value) : value;
}
function toSafeByteCount(value, label) {
  if (typeof value !== "bigint") {
    return value;
  }
  if (value > BigInt(Number.MAX_SAFE_INTEGER)) {
    throw new RangeError(`${label} exceeds JavaScript safe integer range`);
  }
  return Number(value);
}
function toSafeFFIU32Length(value, label) {
  if (!Number.isInteger(value) || value < 0)
    throw new RangeError(`${label} must be a non-negative integer`);
  if (value > MAX_FFI_U32)
    throw new RangeError(`${label} exceeds native u32 length limit`);
  return value;
}
function isFFIU32(value) {
  return Number.isInteger(value) && value >= 0 && value <= MAX_FFI_U32;
}
function toFFII32(value, label) {
  if (!Number.isInteger(value) || value < -2147483648 || value > 2147483647) {
    throw new RangeError(`${label} must be a signed 32-bit integer`);
  }
  return value;
}
function toFFIU64(value, label) {
  if (typeof value !== "bigint" || value < 0n || value > 0xffffffffffffffffn) {
    throw new RangeError(`${label} must be an unsigned 64-bit bigint`);
  }
  return value;
}
function toFFIBool(value, label) {
  if (typeof value !== "boolean")
    throw new TypeError(`${label} must be a boolean`);
  return ffiBool(value);
}
function toFFIF32(value, label, allowNaN = false) {
  if (allowNaN && Number.isNaN(value))
    return value;
  if (!Number.isFinite(value) || Math.abs(value) > 340282346638528860000000000000000000000) {
    throw new RangeError(`${label} must be a finite 32-bit float${allowNaN ? " or NaN" : ""}`);
  }
  return value;
}
function nativeResult(operation, status) {
  if (status !== 0 /* Ok */)
    throw new NativeError2(operation, status);
}
function createContextRecord(layout) {
  const record = new Uint32Array(layout.size / 4);
  record[layout.fields.struct_size.offset / 4] = layout.size;
  record[layout.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
  return record;
}
var typedArrayAccessors = Object.getOwnPropertyDescriptors(Object.getPrototypeOf(Uint8Array.prototype));
function sessionBytes(bytes, label) {
  const length = toSafeFFIU32Length(bytes.byteLength, label);
  if (typedArrayAccessors.byteLength.get.call(bytes) !== length) {
    throw new RangeError(`${label} does not match the supplied typed-array view`);
  }
  return new Uint8Array(typedArrayAccessors.buffer.get.call(bytes), typedArrayAccessors.byteOffset.get.call(bytes), length);
}
function programStatusPayload(status, encoder) {
  const layout = nativeLayouts.ot_session_program_status;
  const { state, kind, progress, id, app, title, message } = status;
  const stateId = typeof state === "string" ? PROGRAM_STATE_TO_ID[state] : undefined;
  if (typeof stateId !== "number")
    throw new TypeError("Unknown program status state");
  const header = new Uint32Array(layout.size / 4);
  header[layout.fields.state.offset / 4] = stateId;
  if (kind != null) {
    const kindId = typeof kind === "string" ? PROGRAM_KIND_TO_ID[kind] : undefined;
    if (typeof kindId !== "number")
      throw new TypeError("Unknown program status kind");
    header[layout.fields.kind.offset / 4] = kindId;
  }
  if (progress != null) {
    if (typeof progress !== "number")
      throw new TypeError("Program status progress must be a number");
    if (!isFFIU32(progress))
      throw new RangeError("Program status progress must be an integer percentage");
    header[layout.fields.fields.offset / 4] = nativeConstants.OT_PROGRAM_STATUS_PROGRESS;
    header[layout.fields.progress.offset / 4] = progress;
  }
  if (id === "")
    throw new RangeError("Program status id must not be empty; omit it for the root record");
  const text = { id, app, title, message };
  const parts = ["id", "app", "title", "message"].map((name) => {
    const value = text[name];
    if (value == null)
      return new Uint8Array(0);
    if (typeof value !== "string")
      throw new TypeError(`Program status ${name} must be a string`);
    const bytes = encoder.encode(value.slice(0, NATIVE_SESSION_CONTROL_PACKET_BYTES2 + 1));
    header[layout.fields[`${name}_len`].offset / 4] = bytes.byteLength;
    return bytes;
  });
  const payload = new Uint8Array(layout.size + parts.reduce((total, part) => total + part.byteLength, 0));
  payload.set(new Uint8Array(header.buffer));
  let offset = layout.size;
  for (const part of parts) {
    payload.set(part, offset);
    offset += part.byteLength;
  }
  return payload;
}
function pixelInput(data, length) {
  if (typeof data === "number" || typeof data === "bigint")
    return toPointer(data);
  const input = sessionBytes(data, "Pixel buffer byte length");
  if (length > input.byteLength)
    throw new RangeError("Pixel byte count exceeds the supplied view");
  return input;
}
var handleWords = nativeLayouts.ot_handle.size / 4;
var handleSlotWord = nativeLayouts.ot_handle.fields.slot.offset / 4;
var handleGenerationWord = nativeLayouts.ot_handle.fields.generation.offset / 4;
var handleContextLowWord = nativeLayouts.ot_handle.fields.context_id.offset / 4 + (new Uint8Array(new Uint32Array([1]).buffer)[0] === 1 ? 0 : 1);
var handleContextHighWord = handleContextLowWord ^ 1;

class IssuedContextHandle {
  context;
  contextId;
  slot;
  generation;
  #words;
  constructor(context, contextId, slot, generation, words) {
    this.context = context;
    this.contextId = contextId;
    this.slot = slot;
    this.generation = generation;
    this.#words = words;
  }
  static wordsOf(handle) {
    return #words in handle ? handle.#words : undefined;
  }
}
function encodedContextHandle(context, handle) {
  if (handle.context !== context)
    throw new NativeError2("Context handle", -7 /* WrongContext */);
  const issued = IssuedContextHandle.wordsOf(handle);
  if (issued !== undefined)
    return issued;
  const contextId = toFFIU64(handle.contextId, "Handle contextId");
  const words = new Uint32Array(handleWords);
  words[handleContextLowWord] = Number(contextId & 0xffffffffn);
  words[handleContextHighWord] = Number(contextId >> 32n);
  words[handleSlotWord] = toSafeFFIU32Length(handle.slot, "Handle slot");
  words[handleGenerationWord] = toSafeFFIU32Length(handle.generation, "Handle generation");
  return words;
}
function encodeContextHandle(context, handle, record, words) {
  const encoded = encodedContextHandle(context, handle);
  if (record === undefined)
    return encoded;
  words ??= new Uint32Array(record.buffer, record.byteOffset, handleWords);
  for (let index = 0;index < handleWords; index++)
    words[index] = encoded[index];
  return record;
}
function createContextHandleRecord(record = new BigUint64Array(nativeLayouts.ot_handle.size / 8)) {
  return { record, words: new Uint32Array(record.buffer, record.byteOffset, nativeLayouts.ot_handle.size / 4) };
}
function createSceneNodeRecord() {
  return { handle: createContextHandleRecord(), target: createContextHandleRecord() };
}
function createSceneHooksRecord() {
  const record = new BigUint64Array(nativeLayouts.ot_scene_hooks.size / 8);
  return {
    record,
    words: new Uint32Array(record.buffer),
    dimensions: new Float64Array(record.buffer),
    handle: createContextHandleRecord()
  };
}
function decodeContextHandle(context, record, words) {
  const source = record instanceof Uint32Array ? record : words ?? new Uint32Array(record.buffer, record.byteOffset, handleWords);
  const encoded = new Uint32Array(handleWords);
  for (let index = 0;index < handleWords; index++)
    encoded[index] = source[index];
  return new IssuedContextHandle(context, BigInt(encoded[handleContextLowWord]) | BigInt(encoded[handleContextHighWord]) << 32n, encoded[handleSlotWord], encoded[handleGenerationWord], encoded);
}
function createSceneFrameRecord() {
  const layout = nativeLayouts.ot_scene_frame_request;
  const output = new BigUint64Array(layout.size / 8);
  const config = createContextRecord(nativeLayouts.ot_scene_frame_options);
  const geometry = createContextRecord(nativeLayouts.ot_scene_frame_geometry);
  return {
    output,
    words: new Uint32Array(output.buffer),
    config,
    colors: new Uint16Array(config.buffer),
    geometry,
    geometryValues: new Float32Array(geometry.buffer),
    geometryCoordinates: new Float64Array(geometry.buffer),
    handle: createContextHandleRecord(),
    session: createContextHandleRecord(new BigUint64Array(output.buffer, layout.fields.session.offset, nativeLayouts.ot_handle.size / 8)),
    root: createContextHandleRecord(new BigUint64Array(output.buffer, layout.fields.root.offset, nativeLayouts.ot_handle.size / 8)),
    node: createContextHandleRecord(new BigUint64Array(output.buffer, layout.fields.node.offset, nativeLayouts.ot_handle.size / 8))
  };
}
function createBufferDrawRecord() {
  const buffer = new ArrayBuffer(nativeLayouts.ot_buffer_draw_box.size);
  const records = [];
  for (const { id, size } of BUFFER_DRAW_OPERATIONS.values())
    records[id] = new Uint32Array(buffer, 0, size / 4);
  return {
    words: new Uint32Array(buffer),
    records,
    signed: new Int32Array(buffer),
    colors: new Uint16Array(buffer),
    source: createContextHandleRecord()
  };
}
function encodeDrawPosition(signed, fields, options, base = 0) {
  signed[(base + fields.x.offset) / 4] = toFFII32(options.x ?? 0, "Buffer x");
  signed[(base + fields.y.offset) / 4] = toFFII32(options.y ?? 0, "Buffer y");
}
function encodeDrawColors(colors, fields, options, base = 0) {
  const { foreground, background } = options;
  if (foreground !== undefined)
    contextBufferColor(foreground, colors, (base + fields.foreground.offset) / 2);
  if (background !== undefined)
    contextBufferColor(background, colors, (base + fields.background.offset) / 2);
  return background !== undefined;
}
var DIAGNOSTIC_QUEUE_MAX = 64;
var DIAGNOSTIC_BATCH = 8;
function createDiagnosticDrainRecord() {
  const layout = nativeLayouts.ot_diagnostic_drain;
  const output = new BigUint64Array(layout.size / 8);
  const words = new Uint32Array(output.buffer);
  words[layout.fields.struct_size.offset / 4] = layout.size;
  words[layout.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
  return { records: new Uint32Array(DIAGNOSTIC_BATCH * nativeLayouts.ot_diagnostic.size / 4), output, words };
}
function createSceneLayoutRecord() {
  const output = createContextRecord(nativeLayouts.ot_scene_layout);
  return {
    output,
    values: new Float32Array(output.buffer),
    coordinates: new Float64Array(output.buffer),
    handle: createContextHandleRecord()
  };
}
function decodeSceneLayout(values, coordinates, offset = 0) {
  const fields = nativeLayouts.ot_scene_layout.fields;
  return {
    left: values[(offset + fields.left.offset) / 4],
    top: values[(offset + fields.top.offset) / 4],
    right: values[(offset + fields.right.offset) / 4],
    bottom: values[(offset + fields.bottom.offset) / 4],
    width: values[(offset + fields.width.offset) / 4],
    height: values[(offset + fields.height.offset) / 4],
    screenX: coordinates[(offset + fields.screen_x.offset) / 8],
    screenY: coordinates[(offset + fields.screen_y.offset) / 8]
  };
}
var encodedSceneFrameRequests = new WeakMap;
function encodeSceneFrameRequest(context, frame, scratch) {
  if (scratch === undefined && frame !== null) {
    const cached = encodedSceneFrameRequests.get(frame);
    if (cached !== undefined && frame.session.context === context && frame.root.context === context && frame.node.context === context) {
      return cached;
    }
    const encoded = writeSceneFrameRequest(context, frame);
    encodedSceneFrameRequests.set(frame, encoded);
    return encoded;
  }
  return writeSceneFrameRequest(context, frame, scratch);
}
function writeSceneFrameRequest(context, frame, scratch) {
  const layout = nativeLayouts.ot_scene_frame_request;
  const record = scratch?.output ?? new BigUint64Array(layout.size / 8);
  const words = scratch?.words ?? new Uint32Array(record.buffer);
  record.fill(0n);
  words[layout.fields.struct_size.offset / 4] = layout.size;
  words[layout.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
  if (frame !== null) {
    encodeContextHandle(context, frame.session, scratch?.session.record ?? new BigUint64Array(record.buffer, layout.fields.session.offset, nativeLayouts.ot_handle.size / 8), scratch?.session.words);
    encodeContextHandle(context, frame.root, scratch?.root.record ?? new BigUint64Array(record.buffer, layout.fields.root.offset, nativeLayouts.ot_handle.size / 8), scratch?.root.words);
    encodeContextHandle(context, frame.node, scratch?.node.record ?? new BigUint64Array(record.buffer, layout.fields.node.offset, nativeLayouts.ot_handle.size / 8), scratch?.node.words);
    record[layout.fields.frame_id.offset / 8] = toFFIU64(frame.frameId, "Scene frame ID");
    record[layout.fields.request_id.offset / 8] = toFFIU64(frame.requestId, "Scene request ID");
    record[layout.fields.layout_epoch.offset / 8] = toFFIU64(frame.layoutEpoch, "Scene layout epoch");
    record[layout.fields.hook_generation.offset / 8] = toFFIU64(frame.hookGeneration, "Scene hook generation");
    words[layout.fields.kind.offset / 4] = toSafeFFIU32Length(frame.kind, "Scene request kind");
    words[layout.fields.num.offset / 4] = toSafeFFIU32Length(frame.num, "Scene node number");
    words[layout.fields.width.offset / 4] = toSafeFFIU32Length(frame.width, "Scene request width");
    words[layout.fields.height.offset / 4] = toSafeFFIU32Length(frame.height, "Scene request height");
  }
  return record;
}
function encodeBufferDrawRecord(context, options, words, signed, colors, base, sourceRecord = createContextHandleRecord()) {
  const { operation } = options;
  const encoding = BUFFER_DRAW_OPERATIONS.get(operation);
  if (encoding === undefined)
    throw new TypeError("Invalid checked buffer drawing operation");
  const { id: operationId, size } = encoding;
  const word = base / 4;
  const half = base / 2;
  const header = nativeLayouts.ot_buffer_draw_header.fields;
  words.fill(0, word, word + size / 4);
  words[word + header.struct_size.offset / 4] = size;
  words[word + header.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
  words[word + header.operation.offset / 4] = operationId;
  let source = null;
  switch (operation) {
    case "clear": {
      const { background } = options;
      if (background !== undefined)
        contextBufferColor(background, colors, half + nativeLayouts.ot_buffer_draw_clear.fields.background.offset / 2);
      break;
    }
    case "fill": {
      const fields = nativeLayouts.ot_buffer_draw_fill.fields;
      encodeDrawPosition(signed, fields, options, base);
      words[word + fields.width.offset / 4] = toSafeFFIU32Length(options.width ?? 0, "Buffer width");
      words[word + fields.height.offset / 4] = toSafeFFIU32Length(options.height ?? 0, "Buffer height");
      const { background } = options;
      if (background !== undefined)
        contextBufferColor(background, colors, half + fields.background.offset / 2);
      break;
    }
    case "text": {
      const fields = nativeLayouts.ot_buffer_draw_text_record.fields;
      encodeDrawPosition(signed, fields, options, base);
      words[word + fields.attributes.offset / 4] = toSafeFFIU32Length(options.attributes ?? 0, "Buffer attributes");
      if (encodeDrawColors(colors, fields, options, base))
        words[word + header.flags.offset / 4] = nativeConstants.OT_BUFFER_DRAW_HAS_BACKGROUND;
      break;
    }
    case "cell":
    case "cellBlend":
    case "char": {
      const fields = nativeLayouts.ot_buffer_draw_cell.fields;
      encodeDrawPosition(signed, fields, options, base);
      words[word + fields.character.offset / 4] = toSafeFFIU32Length(options.char ?? 32, "Buffer character");
      words[word + fields.attributes.offset / 4] = toSafeFFIU32Length(options.attributes ?? 0, "Buffer attributes");
      encodeDrawColors(colors, fields, options, base);
      break;
    }
    case "box": {
      const fields = nativeLayouts.ot_buffer_draw_box.fields;
      encodeDrawPosition(signed, fields, options, base);
      words[word + fields.width.offset / 4] = toSafeFFIU32Length(options.width ?? 0, "Buffer width");
      words[word + fields.height.offset / 4] = toSafeFFIU32Length(options.height ?? 0, "Buffer height");
      words[word + fields.packed_options.offset / 4] = toSafeFFIU32Length(options.packedOptions ?? 0, "Buffer box options");
      encodeDrawColors(colors, fields, options, base);
      const { titleColor, borderChars } = options;
      if (titleColor !== undefined)
        contextBufferColor(titleColor, colors, half + fields.title_color.offset / 2);
      if (borderChars !== undefined) {
        if (borderChars.length !== 11)
          throw new RangeError("Border characters must contain 11 Unicode scalars");
        words.set(borderChars, word + fields.border_chars.offset / 4);
      }
      break;
    }
    case "compose": {
      const fields = nativeLayouts.ot_buffer_draw_compose.fields;
      source = encodeContextHandle(context, options.source, sourceRecord.record, sourceRecord.words);
      encodeDrawPosition(signed, fields, options, base);
      const { sourceX, sourceY, sourceWidth, sourceHeight } = options;
      words[word + fields.source_x.offset / 4] = toSafeFFIU32Length(sourceX ?? 0, "Buffer source x");
      words[word + fields.source_y.offset / 4] = toSafeFFIU32Length(sourceY ?? 0, "Buffer source y");
      words[word + fields.source_width.offset / 4] = toSafeFFIU32Length(sourceWidth ?? 0, "Buffer source width");
      words[word + fields.source_height.offset / 4] = toSafeFFIU32Length(sourceHeight ?? 0, "Buffer source height");
      words[word + header.flags.offset / 4] = (sourceWidth === undefined ? 0 : nativeConstants.OT_BUFFER_DRAW_HAS_SOURCE_WIDTH) | (sourceHeight === undefined ? 0 : nativeConstants.OT_BUFFER_DRAW_HAS_SOURCE_HEIGHT);
      break;
    }
    case "respectAlpha":
      words[word + nativeLayouts.ot_buffer_draw_alpha.fields.enabled.offset / 4] = toFFIBool(options.enabled, "Buffer respect alpha");
      break;
  }
  return { operation: operationId, size, source };
}
function encodeImageDrawOptions(options, words, signed, base) {
  const fields = nativeLayouts.ot_image_draw_options.fields;
  const word = base / 4;
  words[word + fields.struct_size.offset / 4] = nativeLayouts.ot_image_draw_options.size;
  words[word + fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
  const protocolId = IMAGE_PROTOCOL_TO_ID[options.protocol ?? "auto"];
  if (!Number.isInteger(protocolId))
    throw new TypeError("Unknown image protocol");
  words[word + fields.protocol.offset / 4] = protocolId;
  signed[word + fields.x.offset / 4] = toFFII32(options.x ?? 0, "Image x");
  signed[word + fields.y.offset / 4] = toFFII32(options.y ?? 0, "Image y");
  const sourceWidth = options.sourceWidth;
  const sourceHeight = options.sourceHeight;
  words[word + fields.flags.offset / 4] = (sourceWidth === undefined ? 0 : 1) | (sourceHeight === undefined ? 0 : 2);
  for (const [field, value] of [
    ["width", options.width],
    ["height", options.height],
    ["pixel_width", options.pixelWidth ?? 0],
    ["pixel_height", options.pixelHeight ?? 0],
    ["source_x", options.sourceX ?? 0],
    ["source_y", options.sourceY ?? 0],
    ["source_width", sourceWidth ?? 0],
    ["source_height", sourceHeight ?? 0]
  ]) {
    words[word + fields[field].offset / 4] = toSafeFFIU32Length(value, "Image drawing dimension");
  }
}
function viewOrNull(value) {
  return value.byteLength === 0 ? null : value;
}
var EMBEDDED_TERMINAL_IO_BYTES_MAX = 1024 * 1024;
function embeddedTerminalDimension(value, name) {
  if (!Number.isInteger(value) || value < 1 || value > 65535) {
    throw new RangeError(`Embedded terminal ${name} must be an integer between 1 and 65535`);
  }
  return value;
}
function rgbaBuffer(value) {
  return value.buffer;
}
function contextBufferColor(value, color = new Uint16Array(4), offset = 0) {
  const source = rgbaBuffer(value);
  for (let index = 0;index < 4; index++) {
    const channel = source[index];
    if (!Number.isInteger(channel) || channel < 0 || channel > 65535) {
      throw new RangeError("Context buffer colors require four integer RGBA channels in 0..65535");
    }
    color[offset + index] = channel;
  }
  const intent = color[offset + 1] >>> 8;
  if (color[offset + 2] > 255 || color[offset + 3] > 255 || intent > 2 || intent !== 1 && color[offset] > 255) {
    throw new RangeError("Invalid terminal color intent");
  }
  return color;
}
function createScenePaintRecord() {
  const { fields } = nativeLayouts.ot_scene_paint_options;
  const record = createContextRecord(nativeLayouts.ot_scene_paint_options);
  return {
    record,
    payload: new Uint32Array(record.buffer, fields.z_index.offset, (fields.reserved.offset - fields.z_index.offset) / 4),
    background: new Uint16Array(record.buffer, fields.background.offset, 4),
    floats: new Float32Array(record.buffer),
    doubles: new Float64Array(record.buffer),
    colors: new Uint16Array(record.buffer)
  };
}
function encodeScenePaint(paint, scratch) {
  const layout = nativeLayouts.ot_scene_paint_options;
  const { record, floats, doubles, colors } = scratch;
  const zIndex = paint.zIndex;
  let fields = 0;
  if (zIndex !== undefined) {
    record[layout.fields.z_index.offset / 4] = toFFII32(zIndex, "Scene zIndex");
    fields |= nativeConstants.OT_SCENE_PROPERTY_Z_INDEX;
  }
  const requestedOpacity = paint.opacity;
  if (requestedOpacity !== undefined) {
    const opacity = toFFIF32(requestedOpacity, "Scene opacity");
    if (opacity < 0 || opacity > 1)
      throw new RangeError("Scene opacity must be within 0..1");
    floats[layout.fields.opacity.offset / 4] = opacity;
    fields |= nativeConstants.OT_SCENE_PROPERTY_OPACITY;
  }
  const translateX = paint.translateX;
  const translateY = paint.translateY;
  if (translateX !== undefined) {
    if (!Number.isFinite(translateX)) {
      throw new RangeError("Scene translations must be finite numbers");
    }
    doubles[layout.fields.translate_x.offset / 8] = translateX;
    fields |= nativeConstants.OT_SCENE_PROPERTY_TRANSLATE_X;
  }
  if (translateY !== undefined) {
    if (!Number.isFinite(translateY))
      throw new RangeError("Scene translations must be finite numbers");
    doubles[layout.fields.translate_y.offset / 8] = translateY;
    fields |= nativeConstants.OT_SCENE_PROPERTY_TRANSLATE_Y;
  }
  const requestedBorder = paint.border;
  if (requestedBorder !== undefined) {
    const borderSides = toSafeFFIU32Length(requestedBorder, "Scene border");
    if (borderSides > 15)
      throw new RangeError("Scene border sides must use four edge bits");
    record[layout.fields.border_sides.offset / 4] = borderSides;
    fields |= nativeConstants.OT_SCENE_PROPERTY_BORDER;
  }
  const shouldFill = paint.shouldFill;
  if (shouldFill !== undefined) {
    record[layout.fields.should_fill.offset / 4] = toFFIBool(shouldFill, "Scene shouldFill");
    fields |= nativeConstants.OT_SCENE_PROPERTY_SHOULD_FILL;
  }
  const background = paint.backgroundColor;
  if (background !== undefined) {
    contextBufferColor(background, colors, layout.fields.background.offset / 2);
    fields |= nativeConstants.OT_SCENE_PROPERTY_BACKGROUND;
  }
  const borderColor = paint.borderColor;
  if (borderColor !== undefined) {
    contextBufferColor(borderColor, colors, layout.fields.border_color.offset / 2);
    fields |= nativeConstants.OT_SCENE_PROPERTY_BORDER_COLOR;
  }
  const requestedStyle = paint.borderStyle;
  if (requestedStyle !== undefined) {
    const borderStyle = SCENE_BORDER_STYLES.indexOf(requestedStyle);
    if (borderStyle < 0)
      throw new TypeError("Unknown scene border style");
    record[layout.fields.border_style.offset / 4] = borderStyle;
    fields |= nativeConstants.OT_SCENE_PROPERTY_BORDER_STYLE;
  }
  const focusable = paint.focusable;
  if (focusable !== undefined) {
    record[layout.fields.focusable.offset / 4] = toFFIBool(focusable, "Scene focusable");
    fields |= nativeConstants.OT_SCENE_PROPERTY_FOCUSABLE;
  }
  const focusedBorderColor = paint.focusedBorderColor;
  if (focusedBorderColor !== undefined) {
    contextBufferColor(focusedBorderColor, colors, layout.fields.focused_border_color.offset / 2);
    fields |= nativeConstants.OT_SCENE_PROPERTY_FOCUSED_BORDER_COLOR;
  }
  const resetBorderCharacters = paint.resetBorderCharacters;
  if (resetBorderCharacters !== undefined) {
    if (resetBorderCharacters !== true || requestedStyle === undefined)
      throw new TypeError("Border character reset requires a border style");
    fields |= nativeConstants.OT_SCENE_PROPERTY_RESET_BORDER_CHARACTERS;
  }
  return fields;
}
function validateSceneStyle(group, kind, edge, unit, value, flags) {
  const c = nativeConstants;
  if (group > c.OT_STYLE_DIMENSION || group === c.OT_STYLE_BORDER || group !== c.OT_STYLE_DIMENSION && flags !== 0 || flags > c.OT_STYLE_DISABLE_FLEX_SHRINK) {
    throw new NativeError2("ot_scene_set_style", -1 /* InvalidArgument */);
  }
  if ((group === c.OT_STYLE_ENUM || group === c.OT_STYLE_FLOAT) && (edge !== c.OT_EDGE_NONE || unit !== c.OT_UNIT_UNDEFINED)) {
    throw new NativeError2("ot_scene_set_style", -1 /* InvalidArgument */);
  }
  if (group === c.OT_STYLE_DIMENSION && edge !== c.OT_EDGE_NONE)
    throw new NativeError2("ot_scene_set_style", -1 /* InvalidArgument */);
  let valid = false;
  switch (group) {
    case c.OT_STYLE_ENUM:
      valid = kind < nativeStyleEnumMaxima.length && value <= nativeStyleEnumMaxima[kind];
      break;
    case c.OT_STYLE_FLOAT:
      valid = kind <= c.OT_STYLE_FLOAT_ASPECT_RATIO;
      break;
    case c.OT_STYLE_VALUE:
      valid = kind <= c.OT_STYLE_VALUE_GAP && unit <= c.OT_UNIT_AUTO && (kind < c.OT_STYLE_VALUE_MARGIN || edge <= (kind === c.OT_STYLE_VALUE_GAP ? c.OT_GUTTER_ALL : c.OT_EDGE_ALL)) && !(unit === c.OT_UNIT_AUTO && (kind >= c.OT_STYLE_VALUE_MIN_WIDTH && kind <= c.OT_STYLE_VALUE_MAX_HEIGHT || kind === c.OT_STYLE_VALUE_PADDING || kind === c.OT_STYLE_VALUE_GAP));
      break;
    case c.OT_STYLE_DIMENSION:
      valid = kind <= c.OT_DIMENSION_HEIGHT && unit <= c.OT_UNIT_AUTO;
      break;
  }
  if (!valid)
    throw new NativeError2("ot_scene_set_style", -1 /* InvalidArgument */);
}
var scenePropertyWords = [
  ["z_index", nativeConstants.OT_SCENE_PROPERTY_Z_INDEX],
  ["opacity", nativeConstants.OT_SCENE_PROPERTY_OPACITY],
  ["translate_x", nativeConstants.OT_SCENE_PROPERTY_TRANSLATE_X],
  ["translate_y", nativeConstants.OT_SCENE_PROPERTY_TRANSLATE_Y],
  ["border_sides", nativeConstants.OT_SCENE_PROPERTY_BORDER],
  ["should_fill", nativeConstants.OT_SCENE_PROPERTY_SHOULD_FILL],
  ["background", nativeConstants.OT_SCENE_PROPERTY_BACKGROUND],
  ["border_color", nativeConstants.OT_SCENE_PROPERTY_BORDER_COLOR],
  ["border_style", nativeConstants.OT_SCENE_PROPERTY_BORDER_STYLE],
  ["focusable", nativeConstants.OT_SCENE_PROPERTY_FOCUSABLE],
  ["focused_border_color", nativeConstants.OT_SCENE_PROPERTY_FOCUSED_BORDER_COLOR]
].map(([name, bit], index) => {
  if (bit !== 1 << index)
    throw new Error(`Scene property ${name} is out of header bit order`);
  const field = nativeLayouts.ot_scene_paint_options.fields[name];
  return { offset: field.offset / 4, length: field.size / 4 };
});
var propertyHeaderWords = nativeLayouts.ot_scene_property_update.size / 4;
var propertySlotWords = nativeConstants.OT_SCENE_PROPERTY_RECORD_MAX / 4;
var propertyStyle = nativeConstants.OT_SCENE_PROPERTY_STYLE;
var propertyStyleWords = propertyHeaderWords + nativeLayouts.ot_scene_style_property.size / 4;
function propertyWordLength(fields) {
  if (fields === propertyStyle)
    return propertyStyleWords;
  let words = propertyHeaderWords;
  for (let index = 0;index < scenePropertyWords.length; index++) {
    if (fields & 1 << index)
      words += scenePropertyWords[index].length;
  }
  return words + 1 & ~1;
}
if (Math.max(propertyStyleWords, propertyWordLength((1 << scenePropertyWords.length) - 1)) > propertySlotWords) {
  throw new Error("Scene property records exceed OT_SCENE_PROPERTY_RECORD_MAX");
}

class SceneStaging {
  static limit = nativeConstants.OT_SCENE_MUTATIONS_MAX;
  words;
  paintBySlot = new Map;
  packScratch = new Uint32Array(16);
  styleValue = new Float32Array(1);
  styleValueWords = new Uint32Array(this.styleValue.buffer);
  context;
  contextId = new BigUint64Array(1);
  contextWords = new Uint32Array(this.contextId.buffer);
  borrowed = false;
  entryCount = 0;
  encodedWords = 0;
  lastBase = 0;
  runBase = -1;
  paintScratch = createScenePaintRecord();
  constructor(initialCapacity = 64) {
    if (!Number.isInteger(initialCapacity) || initialCapacity < 1 || initialCapacity > SceneStaging.limit) {
      throw new RangeError("Scene staging capacity must be within the native mutation limit");
    }
    this.words = new Uint32Array(propertySlotWords * initialCapacity);
  }
  get pending() {
    return this.entryCount !== 0;
  }
  get count() {
    return this.entryCount;
  }
  get byteLength() {
    return this.encodedWords * 4;
  }
  get full() {
    return this.entryCount === SceneStaging.limit;
  }
  static checkStyleValue(group, value) {
    return group === nativeConstants.OT_STYLE_ENUM ? toSafeFFIU32Length(value, "Scene enum value") : toFFIF32(value, "Scene style value", true);
  }
  assertWritable() {
    if (this.borrowed)
      throw new Error("Cannot change staged scene inputs during a native flush");
  }
  checkHandle(context, handle) {
    this.assertWritable();
    if (this.context !== undefined && (this.context !== context || this.contextWords[0] !== handle[0] || this.contextWords[1] !== handle[1])) {
      throw new NativeError2("Context handle", -7 /* WrongContext */);
    }
    const entry = this.paintBySlot.get(handle[2]);
    if (entry !== undefined && this.words[entry + 3] !== handle[3]) {
      throw new NativeError2("Context handle", -9 /* StaleHandle */);
    }
    return entry;
  }
  bind(context, handle) {
    if (this.context !== undefined)
      return false;
    this.context = context;
    this.contextWords[0] = handle[0];
    this.contextWords[1] = handle[1];
    return true;
  }
  ensureWords(need) {
    if (need <= this.words.length)
      return;
    const next = new Uint32Array(Math.min(SceneStaging.limit * propertySlotWords, Math.max(need, this.words.length * 2)));
    next.set(this.words.subarray(0, this.encodedWords));
    this.words = next;
  }
  reserve(handle, fields) {
    if (this.full)
      throw new NativeError2("ot_scene_flush", -16 /* ObjectLimit */);
    const length = propertyWordLength(fields);
    this.ensureWords(this.encodedWords + length);
    const base = this.encodedWords;
    const words = this.words;
    words[base + length - 1] = 0;
    words[base] = handle[0];
    words[base + 1] = handle[1];
    words[base + 2] = handle[2];
    words[base + 3] = handle[3];
    words[base + 4] = fields;
    words[base + 5] = length * 4;
    this.encodedWords += length;
    this.entryCount++;
    this.lastBase = base;
    this.runBase = -1;
    return base;
  }
  stageStyle(context, node, group, kind, edge, unit, value, flags) {
    this.assertWritable();
    group = toSafeFFIU32Length(group, "Scene style group");
    kind = toSafeFFIU32Length(kind, "Scene style kind");
    edge = toSafeFFIU32Length(edge, "Scene style edge");
    unit = toSafeFFIU32Length(unit, "Scene style unit");
    value = SceneStaging.checkStyleValue(group, value);
    flags = toSafeFFIU32Length(flags, "Scene style flags");
    validateSceneStyle(group, kind, edge, unit, value, flags);
    if (group === nativeConstants.OT_STYLE_VALUE && kind < nativeConstants.OT_STYLE_VALUE_MARGIN)
      edge = 0;
    const handle = encodedContextHandle(context, node);
    this.checkHandle(context, handle);
    const target = group | kind << 8 | edge << 16;
    const packed = target | unit << 24;
    this.styleValue[0] = value;
    const valueWord = this.styleValueWords[0];
    const last = this.lastBase;
    if (this.entryCount !== 0 && this.words[last + 4] === propertyStyle && this.words[last + 2] === handle[2] && this.words[last + 3] === handle[3] && (this.words[last + 6] & 16777215) === target && this.words[last + 7] === flags) {
      const words = this.words;
      if (words[last + 6] === packed && words[last + 8] === valueWord)
        return false;
      if (this.rewriteStyleRun(last, packed, valueWord))
        return false;
      const previous = last;
      const base = this.reserve(handle, propertyStyle);
      this.writeStyle(base, packed, flags, valueWord);
      if (this.stylesDiffer(words[previous + 6], words[previous + 8], packed, valueWord))
        this.runBase = previous;
      return false;
    }
    const base = this.reserve(handle, propertyStyle);
    this.writeStyle(base, packed, flags, valueWord);
    return this.bind(context, handle);
  }
  writeStyle(base, packed, flags, valueWord) {
    this.words[base + 6] = packed;
    this.words[base + 7] = flags;
    this.words[base + 8] = valueWord;
  }
  stylesDiffer(packedA, valueA, packedB, valueB) {
    if ((valueA & 2139095040) === 2139095040 && (valueA & 8388607) !== 0)
      return false;
    if ((valueB & 2139095040) === 2139095040 && (valueB & 8388607) !== 0)
      return false;
    const group = packedA & 255;
    if (group === nativeConstants.OT_STYLE_VALUE || group === nativeConstants.OT_STYLE_DIMENSION) {
      const unitA = packedA >>> 24;
      const unitB = packedB >>> 24;
      if (unitA === nativeConstants.OT_UNIT_UNDEFINED || unitB === nativeConstants.OT_UNIT_UNDEFINED)
        return false;
      if (unitA !== unitB)
        return true;
      if (unitA === nativeConstants.OT_UNIT_AUTO)
        return false;
    }
    return valueA !== valueB && ((valueA | valueB) & 2147483647) !== 0;
  }
  rewriteStyleRun(last, packed, valueWord) {
    const run = this.runBase;
    if (run < 0)
      return false;
    const words = this.words;
    if (!this.stylesDiffer(words[last + 6], words[last + 8], packed, valueWord))
      return false;
    if (words[run + 6] === packed && words[run + 8] === valueWord) {
      words[run + 6] = words[last + 6];
      words[run + 8] = words[last + 8];
    } else if (!this.stylesDiffer(words[run + 6], words[run + 8], packed, valueWord)) {
      return false;
    }
    words[last + 6] = packed;
    words[last + 8] = valueWord;
    return true;
  }
  stageBackground(context, node, color, owner) {
    this.assertWritable();
    const scratch = this.paintScratch ?? createScenePaintRecord();
    this.paintScratch = undefined;
    try {
      const handle = encodedContextHandle(context, node);
      contextBufferColor(color, scratch.background);
      owner?.assertMutable();
      return this.publishPaint(context, handle, nativeConstants.OT_SCENE_PROPERTY_BACKGROUND, scratch);
    } finally {
      this.paintScratch ??= scratch;
    }
  }
  stagePaint(context, node, paint, owner) {
    this.assertWritable();
    const scratch = this.paintScratch ?? createScenePaintRecord();
    this.paintScratch = undefined;
    try {
      const handle = encodedContextHandle(context, node);
      const fields = encodeScenePaint(paint, scratch);
      owner?.assertMutable();
      return this.publishPaint(context, handle, fields, scratch);
    } finally {
      this.paintScratch ??= scratch;
    }
  }
  publishPaint(context, handle, fields, scratch) {
    let entry = this.checkHandle(context, handle);
    if (fields === 0)
      return false;
    const slot = handle[2];
    const translation = fields & (nativeConstants.OT_SCENE_PROPERTY_TRANSLATE_X | nativeConstants.OT_SCENE_PROPERTY_TRANSLATE_Y);
    if (entry !== undefined && translation !== 0 && entry !== this.lastBase) {
      const existing = this.words[entry + 4];
      for (let index = 2;index < 4; index++) {
        const bit = 1 << index;
        if (!(translation & bit))
          continue;
        if (!(existing & bit) || !this.packedFieldEquals(entry, existing, index, scratch.record)) {
          entry = undefined;
          break;
        }
      }
    }
    let base;
    if (entry === undefined) {
      base = this.reserve(handle, fields);
      this.paintBySlot.set(slot, base);
      this.writePackedFields(base, fields, fields, scratch, null, 0);
    } else {
      base = entry;
      this.mergePackedPaint(base, fields, scratch);
    }
    return this.bind(context, handle);
  }
  packedFieldEquals(base, fields, bitIndex, record) {
    let packed = 0;
    for (let index = 0;index < bitIndex; index++) {
      if (fields & 1 << index)
        packed += scenePropertyWords[index].length;
    }
    const field = scenePropertyWords[bitIndex];
    for (let word = 0;word < field.length; word++) {
      if (this.words[base + propertyHeaderWords + packed + word] !== record[field.offset + word])
        return false;
    }
    return true;
  }
  writePackedFields(base, recordFields, writeMask, scratch, oldPayload, oldFields) {
    if ((writeMask & propertyStyle - 1) === propertyStyle - 1) {
      this.words.set(scratch.payload, base + propertyHeaderWords);
      return;
    }
    const words = this.words;
    const record = scratch.record;
    let dest = base + propertyHeaderWords;
    let oldOff = 0;
    for (let index = 0;index < scenePropertyWords.length && recordFields >>> index !== 0; index++) {
      const bit = 1 << index;
      if (!(recordFields & bit))
        continue;
      const field = scenePropertyWords[index];
      if (writeMask & bit) {
        for (let word = 0;word < field.length; word++)
          words[dest + word] = record[field.offset + word];
      } else if (oldPayload) {
        for (let word = 0;word < field.length; word++)
          words[dest + word] = oldPayload[oldOff + word];
      }
      dest += field.length;
      if (oldFields & bit)
        oldOff += field.length;
    }
  }
  mergePackedPaint(base, fields, scratch) {
    const oldFields = this.words[base + 4];
    const merged = oldFields | fields;
    if (merged === oldFields) {
      this.writePackedFields(base, merged, fields, scratch, null, 0);
      return;
    }
    const oldLen = this.words[base + 5] / 4;
    const newLen = propertyWordLength(merged);
    this.packScratch.set(this.words.subarray(base + propertyHeaderWords, base + oldLen));
    const delta = newLen - oldLen;
    this.ensureWords(this.encodedWords + delta);
    if (base + oldLen < this.encodedWords) {
      this.words.copyWithin(base + newLen, base + oldLen, this.encodedWords);
      for (const [slot, offset] of this.paintBySlot) {
        if (offset >= base + oldLen)
          this.paintBySlot.set(slot, offset + delta);
      }
    }
    this.encodedWords += delta;
    if (this.lastBase >= base + oldLen)
      this.lastBase += delta;
    if (this.runBase >= base + oldLen)
      this.runBase += delta;
    this.words.fill(0, base + propertyHeaderWords, base + newLen);
    this.words[base + 4] = merged;
    this.words[base + 5] = newLen * 4;
    this.writePackedFields(base, merged, fields, scratch, this.packScratch, oldFields);
  }
  _views(context) {
    this.assertWritable();
    if (this.context !== context)
      throw new NativeError2("ot_scene_flush", -7 /* WrongContext */);
    this.borrowed = true;
    return this.words;
  }
  clear() {
    this.assertWritable();
    this.entryCount = 0;
    this.encodedWords = 0;
    this.lastBase = 0;
    this.runBase = -1;
    this.paintBySlot.clear();
    this.context = undefined;
  }
  consume(applied) {
    if (!this.borrowed)
      throw new Error("Scene flush inputs were not borrowed");
    this.borrowed = false;
    if (!Number.isInteger(applied) || applied < 0 || applied > this.entryCount)
      throw new Error("Invalid scene flush prefix");
    if (applied === this.entryCount)
      return this.clear();
    if (applied === 0)
      return;
    let source = 0;
    for (let index = 0;index < applied; index++)
      source += this.words[source + 5] / 4;
    this.words.copyWithin(0, source, this.encodedWords);
    this.encodedWords -= source;
    this.entryCount -= applied;
    this.reindex();
  }
  discard(node) {
    this.assertWritable();
    if (!this.pending || node.context !== this.context || node.contextId !== this.contextId[0])
      return;
    let count = 0;
    let dest = 0;
    let offset = 0;
    for (let index = 0;index < this.entryCount; index++) {
      const length = this.words[offset + 5] / 4;
      if (this.words[offset + 2] === node.slot && this.words[offset + 3] === node.generation) {
        offset += length;
        continue;
      }
      if (dest !== offset)
        this.words.copyWithin(dest, offset, offset + length);
      dest += length;
      offset += length;
      count++;
    }
    this.entryCount = count;
    this.encodedWords = dest;
    if (!this.pending)
      this.clear();
    else
      this.reindex();
  }
  reindex() {
    this.paintBySlot.clear();
    let offset = 0;
    let last = 0;
    for (let index = 0;index < this.entryCount; index++) {
      last = offset;
      if (this.words[offset + 4] !== propertyStyle)
        this.paintBySlot.set(this.words[offset + 2], offset);
      offset += this.words[offset + 5] / 4;
    }
    this.lastBase = last;
    this.runBase = -1;
  }
}
var sceneRecordRejections = new Set([-1 /* InvalidArgument */, -8 /* WrongKind */, -9 /* StaleHandle */]);
var recordHeader = nativeLayouts.ot_scene_record_header.fields;
var recordBytesMax = nativeConstants.OT_SCENE_RECORD_BYTES_MAX;
var stackDepthMax = nativeConstants.OT_BUFFER_STACK_DEPTH_MAX;
function viewOf(value, Type) {
  return new Type(typedArrayAccessors.buffer.get.call(value), typedArrayAccessors.byteOffset.get.call(value), typedArrayAccessors.length.get.call(value));
}
var releaseWindows = new WeakMap;

class NativePaintRecorder {
  buffer = new ArrayBuffer(16384);
  bytes = new Uint8Array(this.buffer);
  words = new Uint32Array(this.buffer);
  signed = new Int32Array(this.buffer);
  floats = new Float32Array(this.buffer);
  colors = new Uint16Array(this.buffer);
  length = 0;
  context = null;
  window = null;
  releases = [];
  pendingSlot = -1;
  pendingPhase = 0;
  opacity = [1];
  scissors = 0;
  textBytes;
  bottomBytes;
  handleRecord = createContextHandleRecord();
  begin(context) {
    this.settle();
    this.context = context;
    if (!releaseWindows.has(context)) {
      releaseWindows.set(context, this.releases);
      this.window = context;
    }
    this.length = 0;
    this.pendingSlot = -1;
  }
  end() {
    this.context = null;
    this.pendingSlot = -1;
  }
  settle() {
    if (this.window === null)
      return;
    releaseWindows.delete(this.window);
    this.window = null;
    for (const release of this.releases.splice(0)) {
      try {
        release();
      } catch {}
    }
  }
  get recording() {
    return this.length === 0 ? null : this.bytes.subarray(0, this.length);
  }
  slot(slot, phase, opacity) {
    this.activeContext();
    this.pendingSlot = slot;
    this.pendingPhase = phase;
    this.opacity.length = 1;
    this.opacity[0] = opacity;
    this.scissors = 0;
  }
  get currentOpacity() {
    return this.opacity[this.opacity.length - 1];
  }
  draw(options) {
    const text = drawRecordText(options);
    const bottom = drawRecordBottomTitle(options);
    this.transaction(() => {
      if (options.operation === "respectAlpha")
        throw new Error("Paint hooks cannot change the frame alpha mode");
      const textBytes = this.textBytes ??= new Uint8Array(NATIVE_BUFFER_TEXT_BYTES_MAX2);
      const bottomBytes = this.bottomBytes ??= new Uint8Array(NATIVE_BUFFER_TEXT_BYTES_MAX2);
      const textLength = encodeDrawText(text, textBytes);
      const bottomLength = encodeDrawText(bottom, bottomBytes);
      const layout = nativeLayouts.ot_scene_record_draw;
      const record = layout.size + nativeLayouts.ot_buffer_draw_box.size;
      const base = this.reserve(nativeConstants.OT_SCENE_RECORD_DRAW, record + textLength + bottomLength);
      const encoded = encodeBufferDrawRecord(this.activeContext(), options, this.words, this.signed, this.colors, base + layout.size, this.handleRecord);
      if (encoded.source) {
        this.bytes.set(new Uint8Array(encoded.source.buffer, encoded.source.byteOffset, 16), base + layout.fields.source.offset);
      }
      const end = base + layout.size + encoded.size;
      this.bytes.set(textBytes.subarray(0, textLength), end);
      this.bytes.set(bottomBytes.subarray(0, bottomLength), end + textLength);
      this.words[(base + layout.fields.text_length.offset) / 4] = textLength;
      this.words[(base + layout.fields.bottom_length.offset) / 4] = bottomLength;
      this.finish(base, end + textLength + bottomLength);
    });
  }
  stack(options) {
    const operation = BUFFER_STACK_OPERATIONS.indexOf(options.operation);
    if (operation < 0)
      throw new TypeError("Invalid checked buffer stack operation");
    const x = toFFII32(options.x ?? 0, "Buffer scissor x");
    const y = toFFII32(options.y ?? 0, "Buffer scissor y");
    const width = toSafeFFIU32Length(options.width ?? 0, "Buffer scissor width");
    const height = toSafeFFIU32Length(options.height ?? 0, "Buffer scissor height");
    const opacity = options.opacity ?? 1;
    if (!Number.isFinite(opacity))
      throw new RangeError("Buffer opacity must be finite");
    const clamped = Math.max(0, Math.min(1, opacity));
    switch (options.operation) {
      case "getOpacity":
        this.activeContext();
        return this.currentOpacity;
      case "pushScissor":
        if (width > 2147483647 || height > 2147483647 || x + width > 2147483647 || y + height > 2147483647) {
          throw new NativeError2("ot_buffer_stack", -1 /* InvalidArgument */);
        }
        if (this.scissors >= stackDepthMax)
          throw new NativeError2("ot_buffer_stack", -16 /* ObjectLimit */);
        break;
      case "pushOpacity":
        if (this.opacity.length - 1 >= stackDepthMax)
          throw new NativeError2("ot_buffer_stack", -16 /* ObjectLimit */);
        break;
    }
    this.transaction(() => {
      const layout = nativeLayouts.ot_scene_record_stack;
      const base = this.reserve(nativeConstants.OT_SCENE_RECORD_STACK, layout.size);
      const fields = layout.fields;
      this.words[(base + fields.operation.offset) / 4] = operation;
      this.signed[(base + fields.x.offset) / 4] = x;
      this.signed[(base + fields.y.offset) / 4] = y;
      this.words[(base + fields.width.offset) / 4] = width;
      this.words[(base + fields.height.offset) / 4] = height;
      this.floats[(base + fields.opacity.offset) / 4] = clamped;
    });
    switch (options.operation) {
      case "pushScissor":
        this.scissors++;
        break;
      case "popScissor":
        this.scissors = Math.max(0, this.scissors - 1);
        break;
      case "clearScissors":
        this.scissors = 0;
        break;
      case "pushOpacity":
        this.opacity.push(Math.fround(this.currentOpacity * Math.fround(clamped)));
        break;
      case "popOpacity":
        if (this.opacity.length > 1)
          this.opacity.pop();
        break;
      case "clearOpacity":
        this.opacity.length = 1;
        break;
    }
    return this.currentOpacity;
  }
  grid(options) {
    this.transaction(() => {
      const layout = nativeLayouts.ot_scene_record_grid;
      const optionsLayout = nativeLayouts.ot_buffer_grid_options;
      const { borderChars, borderFg, borderBg, columnOffsets, rowOffsets, drawInner, drawOuter } = options;
      if (borderChars.length !== 11)
        throw new RangeError("Border characters must contain 11 Unicode scalars");
      const columns = viewOf(columnOffsets, Int32Array);
      const rows = viewOf(rowOffsets, Int32Array);
      const base = this.reserve(nativeConstants.OT_SCENE_RECORD_GRID, layout.size + (columns.length + rows.length) * 4);
      const record = base + layout.fields.options.offset;
      const fields = optionsLayout.fields;
      this.words[(record + fields.struct_size.offset) / 4] = optionsLayout.size;
      this.words[(record + fields.abi_version.offset) / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
      this.words[(record + fields.flags.offset) / 4] = toFFIBool(drawInner, "Grid inner borders") | toFFIBool(drawOuter, "Grid outer borders") << 1;
      contextBufferColor(borderFg, this.colors, (record + fields.foreground.offset) / 2);
      contextBufferColor(borderBg, this.colors, (record + fields.background.offset) / 2);
      this.words.set(borderChars, (record + fields.border_chars.offset) / 4);
      this.words[(base + layout.fields.column_count.offset) / 4] = columns.length;
      this.words[(base + layout.fields.row_count.offset) / 4] = rows.length;
      this.signed.set(columns, (base + layout.size) / 4);
      this.signed.set(rows, (base + layout.size) / 4 + columns.length);
    });
  }
  packed(data, byteLength, x, y, width, height) {
    this.transaction(() => {
      const layout = nativeLayouts.ot_scene_record_packed;
      const input = recordedPixels(data, byteLength);
      const base = this.reserve(nativeConstants.OT_SCENE_RECORD_PACKED, layout.size + input.byteLength);
      const fields = layout.fields;
      this.signed[(base + fields.x.offset) / 4] = toFFII32(x, "Packed buffer x");
      this.signed[(base + fields.y.offset) / 4] = toFFII32(y, "Packed buffer y");
      this.words[(base + fields.width.offset) / 4] = toSafeFFIU32Length(width, "Packed buffer dimension");
      this.words[(base + fields.height.offset) / 4] = toSafeFFIU32Length(height, "Packed buffer dimension");
      this.words[(base + fields.byte_count.offset) / 4] = input.byteLength;
      this.bytes.set(input, base + layout.size);
    });
  }
  supersample(data, byteLength, x, y, format, stride) {
    this.transaction(() => {
      if (format !== "rgba8unorm" && format !== "bgra8unorm")
        throw new TypeError("Unknown pixel format");
      const layout = nativeLayouts.ot_scene_record_supersample;
      const input = recordedPixels(data, byteLength);
      const base = this.reserve(nativeConstants.OT_SCENE_RECORD_SUPERSAMPLE, layout.size + input.byteLength);
      const fields = layout.fields;
      this.signed[(base + fields.x.offset) / 4] = toFFII32(x, "Supersample buffer x");
      this.signed[(base + fields.y.offset) / 4] = toFFII32(y, "Supersample buffer y");
      this.words[(base + fields.format.offset) / 4] = format === "bgra8unorm" ? 0 : 1;
      this.words[(base + fields.stride.offset) / 4] = toSafeFFIU32Length(stride, "Supersample buffer dimension");
      this.words[(base + fields.byte_count.offset) / 4] = input.byteLength;
      this.bytes.set(input, base + layout.size);
    });
  }
  grayscale(data, x, y, width, height, foreground, background, supersampled) {
    this.transaction(() => {
      if (!(data instanceof Float32Array))
        throw new TypeError("Grayscale input must be a Float32Array");
      const samples = viewOf(data, Float32Array);
      const layout = nativeLayouts.ot_scene_record_grayscale;
      const fields = layout.fields;
      const base = this.reserve(nativeConstants.OT_SCENE_RECORD_GRAYSCALE, layout.size + samples.length * 4);
      this.signed[(base + fields.x.offset) / 4] = toFFII32(x, "Grayscale x");
      this.signed[(base + fields.y.offset) / 4] = toFFII32(y, "Grayscale y");
      this.words[(base + fields.width.offset) / 4] = toSafeFFIU32Length(width, "Grayscale source width");
      this.words[(base + fields.height.offset) / 4] = toSafeFFIU32Length(height, "Grayscale source height");
      this.words[(base + fields.flags.offset) / 4] = (foreground === null ? 0 : nativeConstants.OT_SCENE_RECORD_GRAYSCALE_FOREGROUND) | (background === null ? 0 : nativeConstants.OT_SCENE_RECORD_GRAYSCALE_BACKGROUND) | (toFFIBool(supersampled, "Grayscale supersampling") ? nativeConstants.OT_SCENE_RECORD_GRAYSCALE_SUPERSAMPLED : 0);
      this.words[(base + fields.sample_count.offset) / 4] = samples.length;
      if (foreground !== null)
        contextBufferColor(foreground, this.colors, (base + fields.foreground.offset) / 2);
      if (background !== null)
        contextBufferColor(background, this.colors, (base + fields.background.offset) / 2);
      this.floats.set(samples, (base + layout.size) / 4);
    });
  }
  colorMatrix(matrix, mask, strength, channel) {
    this.transaction(() => {
      for (const value of [matrix, mask]) {
        if (value !== null && !(value instanceof Float32Array))
          throw new TypeError("Color matrix input must be a Float32Array");
      }
      if (matrix.length !== 16)
        throw new RangeError("Color matrix must contain 16 floats");
      if (!Number.isFinite(strength))
        throw new RangeError("Color matrix strength must be finite");
      const cells = mask === null ? null : viewOf(mask, Float32Array);
      const layout = nativeLayouts.ot_scene_record_color_matrix;
      const fields = layout.fields;
      const base = this.reserve(nativeConstants.OT_SCENE_RECORD_COLOR_MATRIX, layout.size + (cells?.length ?? 0) * 4);
      this.floats.set(viewOf(matrix, Float32Array), (base + fields.matrix.offset) / 4);
      this.floats[(base + fields.strength.offset) / 4] = strength;
      this.words[(base + fields.channel.offset) / 4] = toSafeFFIU32Length(channel, "Color matrix channel");
      this.words[(base + fields.has_mask.offset) / 4] = cells === null ? 0 : 1;
      this.words[(base + fields.mask_count.offset) / 4] = cells?.length ?? 0;
      if (cells)
        this.floats.set(cells, (base + layout.size) / 4);
    });
  }
  view(operation, source, x, y) {
    this.transaction(() => {
      const layout = nativeLayouts.ot_scene_record_view;
      const base = this.reserve(operation === "text" ? nativeConstants.OT_SCENE_RECORD_TEXT_VIEW : operation === "editor" ? nativeConstants.OT_SCENE_RECORD_EDITOR_VIEW : nativeConstants.OT_SCENE_RECORD_SCENE_TEXT, layout.size);
      this.encodeHandle(source, base + layout.fields.source.offset);
      this.signed[(base + layout.fields.x.offset) / 4] = toFFII32(x, "View x");
      this.signed[(base + layout.fields.y.offset) / 4] = toFFII32(y, "View y");
    });
  }
  image(source, options) {
    this.transaction(() => {
      const layout = nativeLayouts.ot_scene_record_image;
      const base = this.reserve(nativeConstants.OT_SCENE_RECORD_IMAGE, layout.size);
      this.encodeHandle(source, base + layout.fields.image.offset);
      encodeImageDrawOptions(options, this.words, this.signed, base + layout.fields.options.offset);
    });
  }
  unicode(source, index, x, y, foreground, background, attributes) {
    this.transaction(() => {
      const layout = nativeLayouts.ot_scene_record_unicode;
      const fields = layout.fields;
      const base = this.reserve(nativeConstants.OT_SCENE_RECORD_UNICODE, layout.size);
      this.encodeHandle(source, base + fields.unicode.offset);
      this.words[(base + fields.index.offset) / 4] = toSafeFFIU32Length(index, "Unicode character index");
      this.signed[(base + fields.x.offset) / 4] = toFFII32(x, "Unicode x");
      this.signed[(base + fields.y.offset) / 4] = toFFII32(y, "Unicode y");
      this.words[(base + fields.attributes.offset) / 4] = toSafeFFIU32Length(attributes, "Unicode attributes");
      contextBufferColor(foreground, this.colors, (base + fields.foreground.offset) / 2);
      contextBufferColor(background, this.colors, (base + fields.background.offset) / 2);
    });
  }
  transaction(encode) {
    const length = this.length;
    const slot = this.pendingSlot;
    try {
      encode();
    } catch (error) {
      this.length = length;
      this.pendingSlot = slot;
      throw error;
    }
  }
  activeContext() {
    if (this.context === null)
      throw new Error("Paint hooks record only while the frame requests them");
    return this.context;
  }
  encodeHandle(handle, offset) {
    const record = encodeContextHandle(this.activeContext(), handle, this.handleRecord.record, this.handleRecord.words);
    this.bytes.set(new Uint8Array(record.buffer, record.byteOffset, record.byteLength), offset);
  }
  reserve(operation, size) {
    this.activeContext();
    if (this.pendingSlot >= 0) {
      const slot = nativeLayouts.ot_scene_record_slot;
      const base = this.append(nativeConstants.OT_SCENE_RECORD_SLOT, slot.size);
      this.words[(base + slot.fields.slot.offset) / 4] = this.pendingSlot;
      this.words[(base + slot.fields.phase.offset) / 4] = this.pendingPhase;
      this.pendingSlot = -1;
    }
    return this.append(operation, size);
  }
  append(operation, size) {
    const total = size + 7 & ~7;
    const base = this.length;
    const end = base + total;
    if (end > this.bytes.length)
      this.grow(end);
    this.bytes.fill(0, base, end);
    this.words[(base + recordHeader.size.offset) / 4] = total;
    this.words[(base + recordHeader.operation.offset) / 4] = operation;
    this.length = end;
    return base;
  }
  finish(base, end) {
    if (this.length !== base + this.words[(base + recordHeader.size.offset) / 4] || end > this.length) {
      throw new Error("Paint recording changed while a record was encoding");
    }
    const total = end - base + 7 & ~7;
    this.bytes.fill(0, end, base + total);
    this.words[(base + recordHeader.size.offset) / 4] = total;
    this.length = base + total;
  }
  grow(need) {
    if (need > recordBytesMax)
      throw new RangeError(`Paint recording exceeds ${recordBytesMax} bytes`);
    const next = new ArrayBuffer(Math.min(recordBytesMax, Math.max(need, this.bytes.length * 2)));
    const bytes = new Uint8Array(next);
    bytes.set(this.bytes.subarray(0, this.length));
    this.buffer = next;
    this.bytes = bytes;
    this.words = new Uint32Array(next);
    this.signed = new Int32Array(next);
    this.floats = new Float32Array(next);
    this.colors = new Uint16Array(next);
  }
}
function recordedPixels(data, length) {
  if (typeof data === "number" || typeof data === "bigint") {
    throw new TypeError("Paint hooks record pixel data from a Uint8Array, not a native address");
  }
  const input = sessionBytes(data, "Pixel buffer byte length");
  const count = toSafeFFIU32Length(length, "Pixel buffer byte count");
  if (count > input.byteLength)
    throw new RangeError("Pixel byte count exceeds the supplied view");
  return input.subarray(0, count);
}
function encodeEditorStyle(style) {
  const layout = nativeLayouts.ot_editor_style;
  const record = new Uint32Array(layout.size / 4);
  const colors = new Uint16Array(record.buffer);
  const { fg, bg, attributes } = style;
  record[layout.fields.struct_size.offset / 4] = layout.size;
  record[layout.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
  if (fg != null) {
    record[layout.fields.flags.offset / 4] |= 1 /* Foreground */;
    contextBufferColor(fg, colors, layout.fields.foreground.offset / 2);
  }
  if (bg != null) {
    record[layout.fields.flags.offset / 4] |= 2 /* Background */;
    contextBufferColor(bg, colors, layout.fields.background.offset / 2);
  }
  if (attributes != null) {
    record[layout.fields.flags.offset / 4] |= 4 /* Attributes */;
    record[layout.fields.attributes.offset / 4] = toSafeFFIU32Length(attributes, "Editor style attributes");
  }
  return record;
}
function drawTextString(text) {
  return typeof text === "string" ? text : text === undefined ? "" : `${text}`;
}
function drawRecordText(options) {
  if (options.operation === "text")
    return drawTextString(options.text);
  return options.operation === "box" && options.text ? drawTextString(options.text) : "";
}
function drawRecordBottomTitle(options) {
  return options.operation === "box" && options.bottomTitle ? drawTextString(options.bottomTitle) : "";
}
var drawTextEncoder = new TextEncoder;
function encodeDrawText(text, output) {
  if (text === "")
    return 0;
  const { read, written } = drawTextEncoder.encodeInto(text, output);
  if (read !== text.length)
    throw new RangeError("Buffer text exceeds the native byte limit");
  return written;
}
function createEditorSelectionRecord() {
  const record = createContextRecord(nativeLayouts.ot_editor_selection);
  return {
    record,
    coordinates: new Int32Array(record.buffer),
    colors: new Uint16Array(record.buffer),
    changed: new Uint32Array(1)
  };
}
function encodeEditorSelection(selection, scratch = createEditorSelectionRecord()) {
  const layout = nativeLayouts.ot_editor_selection;
  const { record, coordinates, colors } = scratch;
  record.fill(0, layout.fields.operation.offset / 4);
  record[layout.fields.operation.offset / 4] = toSafeFFIU32Length(selection.operation, "Editor selection operation");
  record[layout.fields.behavior.offset / 4] = toSafeFFIU32Length(selection.behavior ?? 0, "Editor selection behavior");
  record[layout.fields.start.offset / 4] = toSafeFFIU32Length(selection.start ?? 0, "Editor selection start");
  record[layout.fields.end.offset / 4] = toSafeFFIU32Length(selection.end ?? 0, "Editor selection end");
  coordinates[layout.fields.anchor_x.offset / 4] = toFFII32(selection.anchorX ?? 0, "Editor selection anchorX");
  coordinates[layout.fields.anchor_y.offset / 4] = toFFII32(selection.anchorY ?? 0, "Editor selection anchorY");
  coordinates[layout.fields.focus_x.offset / 4] = toFFII32(selection.focusX ?? 0, "Editor selection focusX");
  coordinates[layout.fields.focus_y.offset / 4] = toFFII32(selection.focusY ?? 0, "Editor selection focusY");
  record[layout.fields.update_cursor.offset / 4] = toFFIBool(selection.updateCursor ?? false, "Editor selection updateCursor");
  record[layout.fields.follow_cursor.offset / 4] = toFFIBool(selection.followCursor ?? false, "Editor selection followCursor");
  const { fg, bg } = selection;
  if (fg != null) {
    record[layout.fields.flags.offset / 4] |= 1 /* Foreground */;
    contextBufferColor(fg, colors, layout.fields.foreground.offset / 2);
  }
  if (bg != null) {
    record[layout.fields.flags.offset / 4] |= 2 /* Background */;
    contextBufferColor(bg, colors, layout.fields.background.offset / 2);
  }
  return record;
}
function encodeContextHighlight(highlight) {
  if (highlight === undefined)
    return null;
  const layout = nativeLayouts.ot_edit_highlight;
  const record = new Uint32Array(layout.size / 4);
  record[layout.fields.start.offset / 4] = toSafeFFIU32Length(highlight.start, "Highlight start");
  record[layout.fields.end.offset / 4] = toSafeFFIU32Length(highlight.end, "Highlight end");
  record[layout.fields.style_id.offset / 4] = toSafeFFIU32Length(highlight.styleId, "Highlight style ID");
  record[layout.fields.priority.offset / 4] = toSafeFFIU32Length(highlight.priority ?? 0, "Highlight priority");
  record[layout.fields.ref.offset / 4] = toSafeFFIU32Length(highlight.hlRef ?? 0, "Highlight reference");
  return record;
}
function decodeContextHighlights(records) {
  const layout = nativeLayouts.ot_edit_highlight;
  const highlights = [];
  for (let offset = 0;offset < records.length; offset += layout.size / 4) {
    highlights.push({
      start: records[offset + layout.fields.start.offset / 4],
      end: records[offset + layout.fields.end.offset / 4],
      styleId: records[offset + layout.fields.style_id.offset / 4],
      priority: records[offset + layout.fields.priority.offset / 4],
      hlRef: records[offset + layout.fields.ref.offset / 4]
    });
  }
  return highlights;
}
function decodeContextTextLines(lines, widthColsMax) {
  const layout = nativeLayouts.ot_scene_text_line;
  const info = {
    lineStartCols: [],
    lineWidthCols: [],
    lineWidthColsMax: widthColsMax,
    lineSources: [],
    lineWraps: []
  };
  for (let index = 0;index < lines.length; index += layout.size / 4) {
    info.lineStartCols.push(lines[index + layout.fields.start_cols.offset / 4]);
    info.lineWidthCols.push(lines[index + layout.fields.width_cols.offset / 4]);
    info.lineSources.push(lines[index + layout.fields.source_line.offset / 4]);
    info.lineWraps.push(lines[index + layout.fields.wrap_index.offset / 4]);
  }
  return info;
}
var WIDTH_METHOD_IDS = new Map([
  ["wcwidth", nativeConstants.OT_WIDTH_METHOD_WCWIDTH],
  ["unicode", nativeConstants.OT_WIDTH_METHOD_UNICODE],
  ["no-zwj", nativeConstants.OT_WIDTH_METHOD_NO_ZWJ],
  ["unicode-wide", nativeConstants.OT_WIDTH_METHOD_UNICODE_WIDE]
]);
function widthMethodId(widthMethod, label) {
  const id = WIDTH_METHOD_IDS.get(widthMethod);
  if (id === undefined)
    throw new TypeError(`Unknown Context ${label} width method`);
  return id;
}
function widthMethodFromCode(code) {
  if (code === 0)
    return "wcwidth";
  return code === 3 ? "unicode-wide" : "unicode";
}
var yogaSymbols = {
  yogaConfigCreateChecked: { args: ["buffer"], returns: "u32" },
  yogaConfigFreeChecked: { args: ["ptr"], returns: "u32" },
  yogaConfigSetCallbacks: { args: ["ptr", "ptr", "ptr"], returns: "bool" },
  yogaConfigClearCallbacks: { args: ["ptr", "ptr"], returns: "bool" },
  yogaConfigSetUseWebDefaultsChecked: { args: ["ptr", "u32"], returns: "u32" },
  yogaConfigGetUseWebDefaults: { args: ["ptr"], returns: "bool" },
  yogaConfigSetPointScaleFactorChecked: { args: ["ptr", "f32"], returns: "u32" },
  yogaConfigGetPointScaleFactor: { args: ["ptr"], returns: "f32" },
  yogaConfigSetErrataChecked: { args: ["ptr", "u32"], returns: "u32" },
  yogaConfigGetErrata: { args: ["ptr"], returns: "u32" },
  yogaConfigSetExperimentalFeatureEnabledChecked: { args: ["ptr", "u32", "u32"], returns: "u32" },
  yogaConfigIsExperimentalFeatureEnabledChecked: { args: ["ptr", "u32", "buffer"], returns: "u32" },
  yogaNodeCreateForOpenTUIChecked: { args: ["buffer"], returns: "u32" },
  yogaNodeCreateWithConfigChecked: { args: ["ptr", "buffer"], returns: "u32" },
  yogaNodeGetConfig: { args: ["ptr"], returns: "ptr" },
  yogaNodeFreeChecked: { args: ["ptr"], returns: "u32" },
  yogaNodeFreeRecursiveChecked: { args: ["ptr"], returns: "u32" },
  yogaNodeResetChecked: { args: ["ptr"], returns: "u32" },
  yogaNodeCopyStyleChecked: { args: ["ptr", "ptr"], returns: "u32" },
  yogaNodeInsertChildChecked: { args: ["ptr", "ptr", "u32"], returns: "u32" },
  yogaNodeRemoveChildChecked: { args: ["ptr", "ptr"], returns: "u32" },
  yogaNodeRemoveAllChildrenChecked: { args: ["ptr"], returns: "u32" },
  yogaNodeGetChildChecked: { args: ["ptr", "u32", "buffer"], returns: "u32" },
  yogaNodeGetChildCount: { args: ["ptr"], returns: "u32" },
  yogaNodeGetParent: { args: ["ptr"], returns: "ptr" },
  yogaNodeCalculateLayoutChecked: { args: ["ptr", "f32", "f32", "u32"], returns: "u32" },
  yogaNodeIsDirtyChecked: { args: ["ptr", "buffer"], returns: "u32" },
  yogaNodeMarkDirtyChecked: { args: ["ptr"], returns: "u32" },
  yogaNodeGetHasNewLayoutChecked: { args: ["ptr", "buffer"], returns: "u32" },
  yogaNodeSetHasNewLayoutChecked: { args: ["ptr", "u32"], returns: "u32" },
  yogaNodeSetIsReferenceBaselineChecked: { args: ["ptr", "u32"], returns: "u32" },
  yogaNodeIsReferenceBaselineChecked: { args: ["ptr", "buffer"], returns: "u32" },
  yogaNodeSetAlwaysFormsContainingBlockChecked: { args: ["ptr", "u32"], returns: "u32" },
  yogaNodeGetAlwaysFormsContainingBlockChecked: { args: ["ptr", "buffer"], returns: "u32" },
  yogaNodeGetComputedLayoutChecked: { args: ["ptr", "buffer"], returns: "u32" },
  yogaNodeLayoutGetEdgeChecked: { args: ["ptr", "u32", "u32", "buffer"], returns: "u32" },
  yogaNodeStyleSetEnumChecked: { args: ["ptr", "u32", "u32"], returns: "u32" },
  yogaNodeStyleGetEnumChecked: { args: ["ptr", "u32", "buffer"], returns: "u32" },
  yogaNodeStyleSetFloatChecked: { args: ["ptr", "u32", "f32"], returns: "u32" },
  yogaNodeStyleGetFloatChecked: { args: ["ptr", "u32", "buffer"], returns: "u32" },
  yogaNodeStyleSetBorderChecked: { args: ["ptr", "u32", "f32"], returns: "u32" },
  yogaNodeStyleGetBorderChecked: { args: ["ptr", "u32", "buffer"], returns: "u32" },
  yogaNodeStyleSetValueChecked: { args: ["ptr", "u32", "u32", "u32", "f32"], returns: "u32" },
  yogaNodeStyleGetValueChecked: { args: ["ptr", "u32", "u32", "buffer"], returns: "u32" },
  yogaNodeSetMeasureFuncChecked: { args: ["ptr", "u32"], returns: "u32" },
  yogaNodeUnsetMeasureFuncChecked: { args: ["ptr"], returns: "u32" },
  yogaNodeHasMeasureFunc: { args: ["ptr"], returns: "bool" },
  yogaNodeSetDirtiedFuncChecked: { args: ["ptr", "u32"], returns: "u32" },
  yogaNodeUnsetDirtiedFuncChecked: { args: ["ptr"], returns: "u32" },
  yogaStoreMeasureResult: { args: ["ptr", "f32", "f32"], returns: "void" }
};
function getOpenTUILib(libPath) {
  const resolvedLibPath = libPath || targetLibPath;
  if (!resolvedLibPath) {
    throw targetLibError ?? new Error(`OpenTUI is not supported on the current platform: ${process.platform}-${process.arch}`);
  }
  const rawSymbols = dlopen(resolvedLibPath, {
    ...nativeSymbols,
    setLogCallback: {
      args: ["ptr"],
      returns: "void"
    },
    getArenaAllocatedBytes: {
      args: [],
      returns: "u64"
    },
    getBuildOptions: {
      args: ["ptr"],
      returns: "void"
    },
    getAllocatorStats: {
      args: ["ptr"],
      returns: "void"
    },
    imageRetainIccCache: { args: [], returns: "void" },
    imageReleaseIccCache: { args: [], returns: "void" },
    ...yogaSymbols,
    createAudioEngine: {
      args: ["ptr", "ptr"],
      returns: "i32"
    },
    audioRefreshPlaybackDevices: {
      args: ["ptr"],
      returns: "i32"
    },
    audioGetPlaybackDeviceCount: {
      args: ["ptr"],
      returns: "u32"
    },
    audioGetPlaybackDeviceName: {
      args: ["ptr", "u32", "buffer", "u32"],
      returns: "u32"
    },
    audioIsPlaybackDeviceDefault: {
      args: ["ptr", "u32"],
      returns: "bool"
    },
    audioSelectPlaybackDevice: {
      args: ["ptr", "u32"],
      returns: "i32"
    },
    audioClearPlaybackDeviceSelection: {
      args: ["ptr"],
      returns: "void"
    },
    audioRefreshCaptureDevices: {
      args: ["ptr"],
      returns: "i32"
    },
    audioGetCaptureDeviceCount: {
      args: ["ptr"],
      returns: "u32"
    },
    audioGetCaptureDeviceName: {
      args: ["ptr", "u32", "buffer", "u32"],
      returns: "u32"
    },
    audioIsCaptureDeviceDefault: {
      args: ["ptr", "u32"],
      returns: "bool"
    },
    audioSelectCaptureDevice: {
      args: ["ptr", "u32"],
      returns: "i32"
    },
    audioClearCaptureDeviceSelection: {
      args: ["ptr"],
      returns: "void"
    },
    audioStartCapture: {
      args: ["ptr", "ptr", "u32", "u32"],
      returns: "i32"
    },
    audioStopCapture: {
      args: ["ptr"],
      returns: "i32"
    },
    audioIsCaptureRunning: {
      args: ["ptr"],
      returns: "bool"
    },
    audioReadCapture: {
      args: ["ptr", "buffer", "u32", "u32", "ptr"],
      returns: "i32"
    },
    audioGetCaptureStats: {
      args: ["ptr", "ptr"],
      returns: "i32"
    },
    audioStart: {
      args: ["ptr", "ptr"],
      returns: "i32"
    },
    audioStartMixer: {
      args: ["ptr"],
      returns: "i32"
    },
    audioStop: {
      args: ["ptr"],
      returns: "i32"
    },
    audioCreateStream: {
      args: ["ptr", "buffer", "buffer"],
      returns: "i32"
    },
    audioWriteStream: {
      args: ["ptr", "u32", "buffer", "u32"],
      returns: "i32"
    },
    audioEndStream: {
      args: ["ptr", "u32"],
      returns: "i32"
    },
    audioRestartStream: {
      args: ["ptr", "u32"],
      returns: "i32"
    },
    audioSetStreamVolume: {
      args: ["ptr", "u32", "f32"],
      returns: "i32"
    },
    audioSetStreamPan: {
      args: ["ptr", "u32", "f32"],
      returns: "i32"
    },
    audioSetStreamGroup: {
      args: ["ptr", "u32", "u32"],
      returns: "i32"
    },
    audioGetStreamStats: {
      args: ["ptr", "u32", "buffer"],
      returns: "i32"
    },
    audioCloseStream: {
      args: ["ptr", "u32", "u32", "buffer"],
      returns: "i32"
    },
    audioLoad: {
      args: ["ptr", "buffer", "u32", "ptr"],
      returns: "i32"
    },
    audioUnload: {
      args: ["ptr", "u32"],
      returns: "i32"
    },
    audioPlay: {
      args: ["ptr", "u32", "ptr", "ptr"],
      returns: "i32"
    },
    audioStopVoice: {
      args: ["ptr", "u32"],
      returns: "i32"
    },
    audioSetVoiceGroup: {
      args: ["ptr", "u32", "u32"],
      returns: "i32"
    },
    audioCreateGroup: {
      args: ["ptr", "buffer", "u32", "ptr"],
      returns: "i32"
    },
    audioSetGroupVolume: {
      args: ["ptr", "u32", "f32"],
      returns: "i32"
    },
    audioSetMasterVolume: {
      args: ["ptr", "f32"],
      returns: "i32"
    },
    audioMixToBuffer: {
      args: ["ptr", "buffer", "u32", "u8"],
      returns: "i32"
    },
    audioEnableTap: {
      args: ["ptr", "u8", "u32"],
      returns: "i32"
    },
    audioReadTap: {
      args: ["ptr", "buffer", "u32", "u8", "ptr"],
      returns: "i32"
    },
    audioGetStats: {
      args: ["ptr", "ptr"],
      returns: "i32"
    },
    createNativeSpanFeed: {
      args: ["ptr"],
      returns: "ptr"
    },
    attachNativeSpanFeed: {
      args: ["ptr"],
      returns: "i32"
    },
    destroyNativeSpanFeed: {
      args: ["ptr"],
      returns: "i32"
    },
    streamWrite: {
      args: ["ptr", "ptr", "u32"],
      returns: "i32"
    },
    streamCommit: {
      args: ["ptr"],
      returns: "i32"
    },
    streamDrainSpans: {
      args: ["ptr", "buffer", "u32"],
      returns: "u32"
    },
    streamReleaseSpan: {
      args: ["ptr", "u32", "u64"],
      returns: "i32"
    },
    streamClose: {
      args: ["ptr"],
      returns: "i32"
    },
    streamReserve: {
      args: ["ptr", "u32", "ptr"],
      returns: "i32"
    },
    streamCommitReserved: {
      args: ["ptr", "u32"],
      returns: "i32"
    },
    streamGetStats: {
      args: ["ptr", "ptr"],
      returns: "i32"
    },
    streamSetCallback: {
      args: ["ptr", "ptr"],
      returns: "void"
    }
  });
  if (env2.OTUI_DEBUG_FFI || env2.OTUI_TRACE_FFI) {
    return {
      ...rawSymbols,
      symbols: convertToDebugSymbols(rawSymbols.symbols)
    };
  }
  return rawSymbols;
}
function convertToDebugSymbols(symbols) {
  if (!globalTraceSymbols) {
    globalTraceSymbols = {};
  }
  if (env2.OTUI_DEBUG_FFI && !globalFFILogPath) {
    const now = new Date;
    const timestamp = now.toISOString().replace(/[:.]/g, "-").replace(/T/, "_").split("Z")[0];
    globalFFILogPath = `ffi_otui_debug_${timestamp}.log`;
  }
  const debugSymbols = {};
  Object.entries(symbols).forEach(([key, value]) => {
    debugSymbols[key] = value;
  });
  if (env2.OTUI_DEBUG_FFI && globalFFILogPath) {
    const logPath = globalFFILogPath;
    let loggingDisabled = false;
    const writeSync = (msg) => {
      if (loggingDisabled)
        return;
      try {
        writeFileSync(logPath, msg + `
`, { flag: "a" });
      } catch {
        loggingDisabled = true;
      }
    };
    Object.entries(symbols).forEach(([key, value]) => {
      if (typeof value === "function") {
        debugSymbols[key] = (...args) => {
          writeSync(`${key}(${args.map((arg) => String(arg)).join(", ")})`);
          const result = value(...args);
          writeSync(`${key} returned: ${String(result)}`);
          return result;
        };
      }
    });
  }
  if (env2.OTUI_TRACE_FFI) {
    Object.entries(symbols).forEach(([key, value]) => {
      if (typeof value === "function") {
        if (!globalTraceSymbols[key]) {
          globalTraceSymbols[key] = [];
        }
        const originalFunc = debugSymbols[key];
        debugSymbols[key] = (...args) => {
          const start = performance.now();
          const result = originalFunc(...args);
          const end = performance.now();
          globalTraceSymbols[key].push(end - start);
          return result;
        };
      }
    });
  }
  if ((env2.OTUI_DEBUG_FFI || env2.OTUI_TRACE_FFI) && !exitHandlerRegistered) {
    exitHandlerRegistered = true;
    process.on("exit", () => {
      if (globalTraceSymbols) {
        const allStats = [];
        for (const [key, timings] of Object.entries(globalTraceSymbols)) {
          if (!Array.isArray(timings) || timings.length === 0) {
            continue;
          }
          const sortedTimings = [...timings].sort((a, b) => a - b);
          const count = sortedTimings.length;
          const total = sortedTimings.reduce((acc, t) => acc + t, 0);
          const average = total / count;
          const min = sortedTimings[0];
          const max = sortedTimings[count - 1];
          const medianIndex = Math.floor(count / 2);
          const p90Index = Math.floor(count * 0.9);
          const p99Index = Math.floor(count * 0.99);
          const median = sortedTimings[medianIndex];
          const p90 = sortedTimings[Math.min(p90Index, count - 1)];
          const p99 = sortedTimings[Math.min(p99Index, count - 1)];
          allStats.push({
            name: key,
            count,
            total,
            average,
            min,
            max,
            median,
            p90,
            p99
          });
        }
        allStats.sort((a, b) => b.total - a.total);
        const lines = [];
        lines.push(`
--- OpenTUI FFI Call Performance ---`);
        lines.push("Sorted by total time spent (descending)");
        lines.push("-------------------------------------------------------------------------------------------------------------------------");
        if (allStats.length === 0) {
          lines.push("No trace data collected or all symbols had zero calls.");
        } else {
          const nameHeader = "Symbol";
          const callsHeader = "Calls";
          const totalHeader = "Total (ms)";
          const avgHeader = "Avg (ms)";
          const minHeader = "Min (ms)";
          const maxHeader = "Max (ms)";
          const medHeader = "Med (ms)";
          const p90Header = "P90 (ms)";
          const p99Header = "P99 (ms)";
          const nameWidth = Math.max(nameHeader.length, ...allStats.map((s) => s.name.length));
          const countWidth = Math.max(callsHeader.length, ...allStats.map((s) => String(s.count).length));
          const totalWidth = Math.max(totalHeader.length, ...allStats.map((s) => s.total.toFixed(2).length));
          const avgWidth = Math.max(avgHeader.length, ...allStats.map((s) => s.average.toFixed(2).length));
          const statWidthMin = Math.max(minHeader.length, ...allStats.map((s) => s.min.toFixed(2).length));
          const statWidthMax = Math.max(maxHeader.length, ...allStats.map((s) => s.max.toFixed(2).length));
          const medianWidth = Math.max(medHeader.length, ...allStats.map((s) => s.median.toFixed(2).length));
          const p90Width = Math.max(p90Header.length, ...allStats.map((s) => s.p90.toFixed(2).length));
          const p99Width = Math.max(p99Header.length, ...allStats.map((s) => s.p99.toFixed(2).length));
          lines.push(`${nameHeader.padEnd(nameWidth)} | ` + `${callsHeader.padStart(countWidth)} | ` + `${totalHeader.padStart(totalWidth)} | ` + `${avgHeader.padStart(avgWidth)} | ` + `${minHeader.padStart(statWidthMin)} | ` + `${maxHeader.padStart(statWidthMax)} | ` + `${medHeader.padStart(medianWidth)} | ` + `${p90Header.padStart(p90Width)} | ` + `${p99Header.padStart(p99Width)}`);
          lines.push(`${"-".repeat(nameWidth)}-+-${"-".repeat(countWidth)}-+-${"-".repeat(totalWidth)}-+-${"-".repeat(avgWidth)}-+-${"-".repeat(statWidthMin)}-+-${"-".repeat(statWidthMax)}-+-${"-".repeat(medianWidth)}-+-${"-".repeat(p90Width)}-+-${"-".repeat(p99Width)}`);
          allStats.forEach((stat) => {
            lines.push(`${stat.name.padEnd(nameWidth)} | ` + `${String(stat.count).padStart(countWidth)} | ` + `${stat.total.toFixed(2).padStart(totalWidth)} | ` + `${stat.average.toFixed(2).padStart(avgWidth)} | ` + `${stat.min.toFixed(2).padStart(statWidthMin)} | ` + `${stat.max.toFixed(2).padStart(statWidthMax)} | ` + `${stat.median.toFixed(2).padStart(medianWidth)} | ` + `${stat.p90.toFixed(2).padStart(p90Width)} | ` + `${stat.p99.toFixed(2).padStart(p99Width)}`);
          });
        }
        lines.push("-------------------------------------------------------------------------------------------------------------------------");
        const output = lines.join(`
`);
        console.log(output);
        try {
          const now = new Date;
          const timestamp = now.toISOString().replace(/[:.]/g, "-").replace(/T/, "_").split("Z")[0];
          const traceFilePath = `ffi_otui_trace_${timestamp}.log`;
          writeFile(traceFilePath, output).catch((error) => {
            console.error("Failed to write FFI trace file:", error);
          });
        } catch (e) {
          console.error("Failed to write FFI trace file:", e);
        }
      }
    });
  }
  return debugSymbols;
}
var LogLevel2;
((LogLevel) => {
  LogLevel[LogLevel["Error"] = 0] = "Error";
  LogLevel[LogLevel["Warn"] = 1] = "Warn";
  LogLevel[LogLevel["Info"] = 2] = "Info";
  LogLevel[LogLevel["Debug"] = 3] = "Debug";
})(LogLevel2 ||= {});
var LOG_METHODS = ["error", "warn", "info", "debug"];

class FFIRenderLib2 {
  bufferDrawRecord;
  sceneLayoutRecord;
  sceneFrameRecord = createSceneFrameRecord();
  scenePaintSlots = new BigUint64Array(nativeLayouts.ot_scene_paint_slot.size * 16 / 8);
  sceneCreateRecord = createSceneNodeRecord();
  sceneDestroyHandle = createContextHandleRecord();
  sceneMoveRecord = createSceneNodeRecord();
  sceneHooksRecord = createSceneHooksRecord();
  sceneFlushApplied = new Uint32Array(1);
  editorSelectionRecord = createEditorSelectionRecord();
  editorViewInfoRecord = createContextRecord(nativeLayouts.ot_editor_view_info);
  selectionResetRecord = encodeEditorSelection({ operation: 2 /* Reset */ });
  localSelectionResetRecord = encodeEditorSelection({
    operation: 5 /* LocalReset */
  });
  selectionResetChanged = new Uint32Array(1);
  hitTestOutput = new Uint32Array(1);
  bufferStackInput = new Float32Array(1);
  bufferStackOutput = new Float32Array(1);
  drawTextBytes = new Uint8Array(NATIVE_BUFFER_TEXT_BYTES_MAX2);
  drawBottomBytes = new Uint8Array(NATIVE_BUFFER_TEXT_BYTES_MAX2);
  opentui;
  iccCacheClient = false;
  yogaLayout = new Float32Array(6);
  yogaU32 = new Uint32Array(1);
  yogaF32 = new Float32Array(1);
  yogaU64 = new BigUint64Array(1);
  yogaHost;
  ffiStructStorage = {
    audioStreamStats: {
      ...allocFFIStruct(AudioStreamStatsStruct),
      result: {
        bytesReceived: 0n,
        framesDecoded: 0n,
        framesPlayed: 0n,
        state: 0,
        sampleRate: 0,
        channels: 0,
        bufferedFrames: 0,
        capacityFrames: 0,
        underruns: 0,
        errorCode: 0,
        readyGeneration: 0
      }
    }
  };
  disposed = false;
  nativeContexts = new Map;
  contextEditEvents = new Map;
  sceneMeasures = new Map;
  clipboardServices = new Map;
  clipboardOperations = new Map;
  audioEngines = new Map;
  editMeasureContext;
  invalidStandaloneHandle = new BigUint64Array(nativeLayouts.ot_handle.size / 8);
  encoder = new TextEncoder;
  emptyBytes = new Uint8Array(0);
  decoder = new TextDecoder;
  logCallbackWrapper = null;
  diagnosticDrain;
  nativeSpanFeedCallbackWrapper = null;
  nativeSpanFeedHandlers = new Map;
  createContext(options) {
    const layout = nativeLayouts.ot_context_options;
    const record = createContextRecord(layout);
    record[layout.fields.object_capacity.offset / 4] = toSafeFFIU32Length(options.objectCapacity, "Context objectCapacity");
    record[layout.fields.render_cells_max.offset / 4] = toSafeFFIU32Length(options.renderCellsMax, "Context renderCellsMax");
    const output = new BigUint64Array(1);
    const context = Object.freeze({});
    if (this.disposed)
      throw new Error("OpenTUI native library is disposed");
    nativeResult("ot_context_create", this.opentui.symbols.ot_context_create(record, output));
    this.nativeContexts.set(context, toPointer(output[0]));
    return context;
  }
  nativeContextPointer(context, operation) {
    const pointer = this.nativeContexts.get(context);
    if (pointer === undefined)
      throw new NativeError2(operation, -7 /* WrongContext */);
    return pointer;
  }
  destroyContext(context) {
    this.getYogaHost().assertMutable();
    this.releaseContext(context);
  }
  releaseContext(context) {
    const pointer = this.nativeContextPointer(context, "ot_context_destroy");
    nativeResult("ot_context_destroy", this.opentui.symbols.ot_context_destroy(pointer));
    this.nativeContexts.delete(context);
    this.sceneMeasures.get(context)?.callback.close();
    this.sceneMeasures.delete(context);
    const events = this.contextEditEvents.get(context);
    if (events) {
      events.callback.close();
      for (const entry of events.buffers.values())
        entry.listeners.clear();
      events.buffers.clear();
    }
    this.contextEditEvents.delete(context);
  }
  destroyContextObject(context, object, operation) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, object);
    const pointer = this.nativeContextPointer(context, operation);
    nativeResult(operation, this.opentui.symbols[operation](pointer, handle));
  }
  contextGetLinkUrl(context, linkId) {
    const id = toSafeFFIU32Length(linkId, "Link id");
    const bytes = new Uint8Array(MAX_LINK_URL_BYTES2);
    const count = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_context_get_link_url");
    nativeResult("ot_context_get_link_url", this.opentui.symbols.ot_context_get_link_url(pointer, id, bytes, bytes.length, count));
    if (count[0] > bytes.length)
      throw new NativeError2("ot_context_get_link_url", -5 /* InternalError */);
    return count[0] === 0 ? "" : this.decoder.decode(bytes.subarray(0, count[0]));
  }
  createContextTextBuffer(context, options = {}) {
    const layout = nativeLayouts.ot_edit_buffer_options;
    this.getYogaHost().assertMutable();
    const widthMethod = widthMethodId(options.widthMethod ?? "unicode", "text");
    const record = createContextRecord(layout);
    record[layout.fields.width_method.offset / 4] = widthMethod;
    const output = new Uint32Array(handleWords);
    const pointer = this.nativeContextPointer(context, "ot_text_buffer_create");
    nativeResult("ot_text_buffer_create", this.opentui.symbols.ot_text_buffer_create(pointer, record, output));
    try {
      return decodeContextHandle(context, output);
    } catch (error) {
      this.opentui.symbols.ot_text_buffer_destroy(pointer, output);
      throw error;
    }
  }
  createContextUnicode(context, text, widthMethod) {
    this.getYogaHost().assertMutable();
    const method = widthMethodId(widthMethod, "Unicode");
    const bytes = this.encoder.encode(text);
    const count = toSafeFFIU32Length(bytes.byteLength, "Unicode input bytes");
    const output = new Uint32Array(handleWords);
    const pointer = this.nativeContextPointer(context, "ot_unicode_create");
    nativeResult("ot_unicode_create", this.opentui.symbols.ot_unicode_create(pointer, viewOrNull(bytes), count, method, output));
    return decodeContextHandle(context, output);
  }
  sceneMeasureLayout(context, session, root) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, session);
    const node = encodeContextHandle(context, root);
    const measures = this.sceneMeasures.get(context)?.nodes.size;
    if (measures)
      this.getYogaHost().flushSceneMutations();
    const pointer = this.nativeContextPointer(context, "ot_scene_measure_layout");
    if (measures) {
      this.getYogaHost().runMutation(() => {
        nativeResult("ot_scene_measure_layout", this.opentui.symbols.ot_scene_measure_layout(pointer, handle, node));
      });
    } else {
      nativeResult("ot_scene_measure_layout", this.opentui.symbols.ot_scene_measure_layout(pointer, handle, node));
    }
  }
  sceneFrameCopyBuffer(context, session, frame, target) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, session);
    const ticket = encodeSceneFrameRequest(context, frame);
    const buffer = encodeContextHandle(context, target);
    const pointer = this.nativeContextPointer(context, "ot_scene_frame_copy_buffer");
    nativeResult("ot_scene_frame_copy_buffer", this.opentui.symbols.ot_scene_frame_copy_buffer(pointer, handle, ticket, buffer));
  }
  sessionRenderSplit(context, session, frame, snapshots, pinnedRenderOffset, force) {
    const layout = nativeLayouts.ot_split_snapshot;
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, session);
    const ticket = frame ? encodeSceneFrameRequest(context, frame) : null;
    const count = toSafeFFIU32Length(snapshots.length, "Split snapshot count");
    if (count > 64)
      throw new RangeError("At most 64 split snapshots can be submitted together");
    const records = new BigUint64Array(count * (layout.size / 8));
    const fields = new Uint32Array(records.buffer);
    for (let index = 0;index < count; index++) {
      const snapshot = snapshots[index];
      const offset = index * layout.size;
      encodeContextHandle(context, snapshot.snapshot, new BigUint64Array(records.buffer, offset + layout.fields.buffer.offset, nativeLayouts.ot_handle.size / 8));
      fields[(offset + layout.fields.row_columns.offset) / 4] = toSafeFFIU32Length(snapshot.rowColumns, "Split snapshot row columns");
      fields[(offset + layout.fields.flags.offset) / 4] = toFFIBool(snapshot.startOnNewLine, "Split start on new line") | toFFIBool(snapshot.trailingNewline, "Split trailing newline") << 1;
    }
    const offset = toSafeFFIU32Length(pinnedRenderOffset, "Split pinned render offset");
    const forced = toFFIBool(force, "Split force render");
    const output = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_session_render_split");
    nativeResult("ot_session_render_split", this.opentui.symbols.ot_session_render_split(pointer, handle, ticket, count ? records : null, count, offset, forced, output));
    return { status: output[0] };
  }
  sessionSplitControl(context, session, command) {
    const layout = nativeLayouts.ot_split_control;
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, session);
    const record = createContextRecord(layout);
    switch (command.kind) {
      case "reset":
        record[layout.fields.command.offset / 4] = 0;
        record[layout.fields.arguments.offset / 4] = toSafeFFIU32Length(command.seedRows, "Split seed rows");
        record[(layout.fields.arguments.offset + 4) / 4] = toSafeFFIU32Length(command.pinnedRenderOffset, "Split pinned render offset");
        break;
      case "sync":
        record[layout.fields.command.offset / 4] = 1;
        record[layout.fields.arguments.offset / 4] = toSafeFFIU32Length(command.pinnedRenderOffset, "Split pinned render offset");
        break;
      case "output-offset":
        record[layout.fields.command.offset / 4] = 2;
        record[layout.fields.arguments.offset / 4] = toSafeFFIU32Length(command.surfaceOffset, "Split surface offset");
        break;
      case "render-offset":
        record[layout.fields.command.offset / 4] = 3;
        record[layout.fields.arguments.offset / 4] = toSafeFFIU32Length(command.renderOffset, "Split render offset");
        break;
      case "transition": {
        const mode = command.mode;
        if (mode !== "viewport-scroll" && mode !== "clear-stale-rows")
          throw new TypeError("Unknown split transition mode");
        record[layout.fields.command.offset / 4] = 4;
        record[layout.fields.arguments.offset / 4] = mode === "viewport-scroll" ? 1 : 2;
        record[(layout.fields.arguments.offset + 4) / 4] = toSafeFFIU32Length(command.sourceTopLine, "Split source top line");
        record[(layout.fields.arguments.offset + 8) / 4] = toSafeFFIU32Length(command.sourceHeight, "Split source height");
        record[(layout.fields.arguments.offset + 12) / 4] = toSafeFFIU32Length(command.targetTopLine, "Split target top line");
        record[(layout.fields.arguments.offset + 16) / 4] = toSafeFFIU32Length(command.targetHeight, "Split target height");
        record[(layout.fields.arguments.offset + 20) / 4] = toSafeFFIU32Length(command.scrollLines ?? 0, "Split scroll lines");
        break;
      }
      case "clear-transition":
        record[layout.fields.command.offset / 4] = 5;
        break;
      default:
        throw new TypeError("Unknown split control");
    }
    const output = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_session_split_control");
    nativeResult("ot_session_split_control", this.opentui.symbols.ot_session_split_control(pointer, handle, record, output));
    return output[0];
  }
  sessionSetScreen(context, session, alternate, width, height, trailingOutput = new Uint8Array) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, session);
    const value = toFFIBool(alternate, "Session alternate screen");
    const columns = toSafeFFIU32Length(width, "Session screen columns");
    const rows = toSafeFFIU32Length(height, "Session screen rows");
    const input = sessionBytes(trailingOutput, "Session screen output length");
    const pointer = this.nativeContextPointer(context, "ot_session_set_screen");
    nativeResult("ot_session_set_screen", this.opentui.symbols.ot_session_set_screen(pointer, handle, value, columns, rows, input, input.byteLength));
  }
  sessionSyncDetached(context, session, parent) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, session);
    const source = encodeContextHandle(context, parent);
    const pointer = this.nativeContextPointer(context, "ot_session_sync_detached");
    nativeResult("ot_session_sync_detached", this.opentui.symbols.ot_session_sync_detached(pointer, handle, source));
  }
  getContextUnicode(context, unicode) {
    const layout = nativeLayouts.ot_unicode_char;
    const handle = encodeContextHandle(context, unicode);
    const count = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_unicode_get");
    nativeResult("ot_unicode_get", this.opentui.symbols.ot_unicode_get(pointer, handle, null, 0, count));
    const records = new Uint32Array(count[0] * (layout.size / 4));
    if (count[0])
      nativeResult("ot_unicode_get", this.opentui.symbols.ot_unicode_get(pointer, handle, records, count[0], count));
    return Array.from({ length: count[0] }, (_, index) => ({
      width: records[(index * layout.size + layout.fields.width.offset) / 4],
      char: records[(index * layout.size + layout.fields.character.offset) / 4]
    }));
  }
  destroyContextUnicode(context, unicode) {
    this.destroyContextObject(context, unicode, "ot_unicode_destroy");
  }
  contextBufferDrawUnicode({ context, target, frame }, unicode, index, x, y, foreground, background, attributes) {
    const handle = encodeContextHandle(context, target);
    const source = encodeContextHandle(context, unicode);
    const ticket = frame ? encodeSceneFrameRequest(context, frame) : null;
    const item = toSafeFFIU32Length(index, "Unicode character index");
    const column = toFFII32(x, "Unicode x");
    const row = toFFII32(y, "Unicode y");
    const fg = contextBufferColor(foreground);
    const bg = contextBufferColor(background);
    const attrs = toSafeFFIU32Length(attributes, "Unicode attributes");
    this.getYogaHost().assertMutable();
    const pointer = this.nativeContextPointer(context, "ot_buffer_draw_unicode");
    nativeResult("ot_buffer_draw_unicode", this.opentui.symbols.ot_buffer_draw_unicode(pointer, handle, ticket, source, item, column, row, fg, bg, attrs));
  }
  createContextEmbeddedTerminal(context, options) {
    const layout = nativeLayouts.ot_embedded_terminal_options;
    this.getYogaHost().assertMutable();
    const record = createContextRecord(layout);
    record[layout.fields.cols.offset / 4] = embeddedTerminalDimension(options.cols, "columns");
    record[layout.fields.rows.offset / 4] = embeddedTerminalDimension(options.rows, "rows");
    record[layout.fields.max_scrollback.offset / 4] = toSafeFFIU32Length(options.maxScrollback ?? 1e4, "Embedded terminal maxScrollback");
    const output = new Uint32Array(handleWords);
    const pointer = this.nativeContextPointer(context, "ot_embedded_terminal_create");
    nativeResult("ot_embedded_terminal_create", this.opentui.symbols.ot_embedded_terminal_create(pointer, record, output));
    return decodeContextHandle(context, output);
  }
  destroyContextEmbeddedTerminal(context, terminal) {
    this.destroyContextObject(context, terminal, "ot_embedded_terminal_destroy");
  }
  contextEmbeddedTerminalWrite(context, terminal, data) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, terminal);
    const bytes = sessionBytes(typeof data === "string" ? this.encoder.encode(data) : data, "Embedded terminal write bytes");
    const pointer = this.nativeContextPointer(context, "ot_embedded_terminal_write");
    for (let offset = 0;offset === 0 || offset < bytes.byteLength; offset += EMBEDDED_TERMINAL_IO_BYTES_MAX) {
      const chunk = bytes.subarray(offset, offset + EMBEDDED_TERMINAL_IO_BYTES_MAX);
      nativeResult("ot_embedded_terminal_write", this.opentui.symbols.ot_embedded_terminal_write(pointer, handle, viewOrNull(chunk), chunk.byteLength));
    }
  }
  contextEmbeddedTerminalResize(context, terminal, cols, rows) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, terminal);
    const width = embeddedTerminalDimension(cols, "columns");
    const height = embeddedTerminalDimension(rows, "rows");
    const pointer = this.nativeContextPointer(context, "ot_embedded_terminal_resize");
    nativeResult("ot_embedded_terminal_resize", this.opentui.symbols.ot_embedded_terminal_resize(pointer, handle, width, height));
  }
  contextTerminalCommand(context, terminal, command, argument = 0) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, terminal);
    const value = toFFII32(argument, "Embedded terminal command argument");
    const pointer = this.nativeContextPointer(context, "ot_embedded_terminal_command");
    nativeResult("ot_embedded_terminal_command", this.opentui.symbols.ot_embedded_terminal_command(pointer, handle, command, value));
  }
  contextEmbeddedTerminalInvalidate(context, terminal) {
    this.contextTerminalCommand(context, terminal, 0);
  }
  contextEmbeddedTerminalScroll(context, terminal, delta) {
    this.contextTerminalCommand(context, terminal, 1, delta);
  }
  contextEmbeddedTerminalClearSelection(context, terminal) {
    this.contextTerminalCommand(context, terminal, 2);
  }
  contextEmbeddedTerminalSetTransparentBackground(context, terminal, transparent) {
    this.contextTerminalCommand(context, terminal, nativeConstants.OT_EMBEDDED_TERMINAL_SET_TRANSPARENT_BACKGROUND, transparent ? 1 : 0);
  }
  contextEmbeddedTerminalSetSelection(context, terminal, start, end) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, terminal);
    const sx = toSafeFFIU32Length(start.x, "Selection start x");
    const sy = toSafeFFIU32Length(start.y, "Selection start y");
    const ex = toSafeFFIU32Length(end.x, "Selection end x");
    const ey = toSafeFFIU32Length(end.y, "Selection end y");
    const pointer = this.nativeContextPointer(context, "ot_embedded_terminal_set_selection");
    nativeResult("ot_embedded_terminal_set_selection", this.opentui.symbols.ot_embedded_terminal_set_selection(pointer, handle, sx, sy, ex, ey));
  }
  contextTerminalBytes(operation, read) {
    const count = new Uint32Array(1);
    nativeResult(operation, read(null, count));
    const output = new Uint8Array(count[0]);
    if (output.length)
      nativeResult(operation, read(output, count));
    return output.subarray(0, count[0]);
  }
  contextEmbeddedTerminalGetSelectedText(context, terminal) {
    const handle = encodeContextHandle(context, terminal);
    const pointer = this.nativeContextPointer(context, "ot_embedded_terminal_get_selected_text");
    return this.contextTerminalBytes("ot_embedded_terminal_get_selected_text", (output, count) => this.opentui.symbols.ot_embedded_terminal_get_selected_text(pointer, handle, output, output?.length ?? 0, count));
  }
  contextEmbeddedTerminalCompose({ context, target, frame }, terminal, x, y) {
    const handle = encodeContextHandle(context, terminal);
    const destination = encodeContextHandle(context, target);
    const ticket = frame ? encodeSceneFrameRequest(context, frame) : null;
    const column = toFFII32(x, "Terminal composition x");
    const row = toFFII32(y, "Terminal composition y");
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_embedded_terminal_compose");
      nativeResult("ot_embedded_terminal_compose", this.opentui.symbols.ot_embedded_terminal_compose(pointer, handle, destination, ticket, column, row));
    });
  }
  contextEmbeddedTerminalCursor(context, terminal) {
    const layout = nativeLayouts.ot_embedded_terminal_cursor;
    const handle = encodeContextHandle(context, terminal);
    const record = createContextRecord(layout);
    const pointer = this.nativeContextPointer(context, "ot_embedded_terminal_cursor_get");
    nativeResult("ot_embedded_terminal_cursor_get", this.opentui.symbols.ot_embedded_terminal_cursor_get(pointer, handle, record));
    return {
      x: record[layout.fields.x.offset / 4],
      y: record[layout.fields.y.offset / 4],
      hasValue: record[layout.fields.has_value.offset / 4] !== 0,
      visible: record[layout.fields.visible.offset / 4] !== 0,
      blinking: record[layout.fields.blinking.offset / 4] !== 0,
      wideTail: record[layout.fields.wide_tail.offset / 4] !== 0,
      style: ["bar", "block", "underline", "block-hollow"][record[layout.fields.style.offset / 4]] ?? "block",
      ...record[layout.fields.color_has_value.offset / 4] ? {
        color: {
          r: record[layout.fields.color_r.offset / 4],
          g: record[layout.fields.color_g.offset / 4],
          b: record[layout.fields.color_b.offset / 4]
        }
      } : {}
    };
  }
  contextEmbeddedTerminalEncodeKey(context, terminal, key) {
    const layout = nativeLayouts.ot_embedded_terminal_key;
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, terminal);
    const action = key.action ?? "press";
    const actionCode = ["release", "press", "repeat"].indexOf(action);
    if (actionCode < 0)
      throw new TypeError("Unknown embedded terminal key action");
    const record = createContextRecord(layout);
    record[layout.fields.action.offset / 4] = actionCode;
    record[layout.fields.composing.offset / 4] = toFFIBool(key.composing ?? false, "Key composing");
    record[layout.fields.mods.offset / 4] = toSafeFFIU32Length(key.mods ?? 0, "Key modifiers");
    record[layout.fields.consumed_mods.offset / 4] = toSafeFFIU32Length(key.consumedMods ?? 0, "Key consumed modifiers");
    record[layout.fields.unshifted_codepoint.offset / 4] = toSafeFFIU32Length(key.unshiftedCodepoint ?? 0, "Key codepoint");
    const physical = this.encoder.encode(key.key ?? "");
    const text = this.encoder.encode(key.text ?? "");
    const physicalLength = toSafeFFIU32Length(physical.byteLength, "Key name bytes");
    const textLength = toSafeFFIU32Length(text.byteLength, "Key text bytes");
    const pointer = this.nativeContextPointer(context, "ot_embedded_terminal_encode_key");
    return this.contextTerminalBytes("ot_embedded_terminal_encode_key", (output, count) => this.opentui.symbols.ot_embedded_terminal_encode_key(pointer, handle, record, viewOrNull(physical), physicalLength, viewOrNull(text), textLength, output, output?.length ?? 0, count));
  }
  contextEmbeddedTerminalEncodeMouse(context, terminal, mouse) {
    const layout = nativeLayouts.ot_embedded_terminal_mouse;
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, terminal);
    const action = ["press", "release", "motion"].indexOf(mouse.action);
    const buttonName = mouse.button;
    const button = buttonName === undefined ? -1 : ["unknown", "left", "right", "middle", "four", "five", "six", "seven"].indexOf(buttonName);
    if (action < 0 || buttonName !== undefined && button < 0)
      throw new TypeError("Unknown embedded terminal mouse action or button");
    const record = createContextRecord(layout);
    record[layout.fields.action.offset / 4] = action;
    record[layout.fields.button.offset / 4] = button;
    record[layout.fields.mods.offset / 4] = toSafeFFIU32Length(mouse.mods ?? 0, "Mouse modifiers");
    record[layout.fields.any_button_pressed.offset / 4] = toFFIBool(mouse.anyButtonPressed ?? false, "Mouse button pressed");
    const coordinates = new Float32Array(record.buffer);
    coordinates[layout.fields.x.offset / 4] = toFFIF32(mouse.x, "Mouse x");
    coordinates[layout.fields.y.offset / 4] = toFFIF32(mouse.y, "Mouse y");
    const output = new Uint8Array(128);
    const count = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_embedded_terminal_encode_mouse");
    nativeResult("ot_embedded_terminal_encode_mouse", this.opentui.symbols.ot_embedded_terminal_encode_mouse(pointer, handle, record, output, output.length, count));
    return output.slice(0, count[0]);
  }
  contextEmbeddedTerminalEncodePaste(context, terminal, input) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, terminal);
    const bytes = sessionBytes(input, "Terminal paste bytes");
    const pointer = this.nativeContextPointer(context, "ot_embedded_terminal_encode_paste");
    return this.contextTerminalBytes("ot_embedded_terminal_encode_paste", (output, count) => this.opentui.symbols.ot_embedded_terminal_encode_paste(pointer, handle, viewOrNull(bytes), bytes.length, output, output?.length ?? 0, count));
  }
  contextEmbeddedTerminalEncodeFocus(context, terminal, focused) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, terminal);
    const value = toFFIBool(focused, "Terminal focused");
    const pointer = this.nativeContextPointer(context, "ot_embedded_terminal_encode_focus");
    return this.contextTerminalBytes("ot_embedded_terminal_encode_focus", (output, count) => this.opentui.symbols.ot_embedded_terminal_encode_focus(pointer, handle, value, output, output?.length ?? 0, count));
  }
  embeddedTerminalResponses;
  contextEmbeddedTerminalDrainResponses(context, terminal) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, terminal);
    const output = this.embeddedTerminalResponses ??= new Uint8Array(EMBEDDED_TERMINAL_IO_BYTES_MAX);
    const count = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_embedded_terminal_drain_responses");
    let status = this.opentui.symbols.ot_embedded_terminal_drain_responses(pointer, handle, output, output.length, count);
    if (status === -11 /* OutputBackpressure */) {
      status = this.opentui.symbols.ot_embedded_terminal_drain_responses(pointer, handle, output, output.length, count);
    }
    nativeResult("ot_embedded_terminal_drain_responses", status);
    return output.slice(0, count[0]);
  }
  destroyContextTextBuffer(context, text) {
    this.destroyContextObject(context, text, "ot_text_buffer_destroy");
  }
  createContextTextBufferView(context, text) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, text);
    const output = new Uint32Array(handleWords);
    const pointer = this.nativeContextPointer(context, "ot_text_buffer_view_create");
    nativeResult("ot_text_buffer_view_create", this.opentui.symbols.ot_text_buffer_view_create(pointer, handle, output));
    try {
      return decodeContextHandle(context, output);
    } catch (error) {
      this.opentui.symbols.ot_text_buffer_view_destroy(pointer, output);
      throw error;
    }
  }
  destroyContextTextBufferView(context, view) {
    this.destroyContextObject(context, view, "ot_text_buffer_view_destroy");
  }
  contextTextBufferSetText(context, text, bytes) {
    const handle = encodeContextHandle(context, text);
    const input = sessionBytes(bytes, "Text buffer text length");
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_text_buffer_set_text");
      nativeResult("ot_text_buffer_set_text", this.opentui.symbols.ot_text_buffer_set_text(pointer, handle, viewOrNull(input), input.length));
    });
  }
  contextTextBufferAppend(context, text, bytes) {
    const handle = encodeContextHandle(context, text);
    const input = sessionBytes(bytes, "Text buffer append length");
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_text_buffer_append");
      nativeResult("ot_text_buffer_append", this.opentui.symbols.ot_text_buffer_append(pointer, handle, viewOrNull(input), input.length));
    });
  }
  contextTextBufferClear(context, text, reset = false) {
    const handle = encodeContextHandle(context, text);
    const value = toFFIBool(reset, "Text buffer reset");
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_text_buffer_clear");
      nativeResult("ot_text_buffer_clear", this.opentui.symbols.ot_text_buffer_clear(pointer, handle, value));
    });
  }
  contextTextBufferSetStyledText(context, text, content) {
    this.contextTextBufferSetEncodedStyledText(context, text, this.encodeTextBufferStyledText(content));
  }
  encodeTextBufferStyledText(content) {
    return this.encodeStyledText(content, true, true);
  }
  contextTextBufferSetEncodedStyledText(context, text, encoded) {
    const handle = encodeContextHandle(context, text);
    const { bytes, records, count, urlBytes } = encoded;
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_text_buffer_set_styled_text");
      nativeResult("ot_text_buffer_set_styled_text", this.opentui.symbols.ot_text_buffer_set_styled_text(pointer, handle, viewOrNull(bytes), bytes.length, count === 0 ? null : records, count, viewOrNull(urlBytes), urlBytes.length));
    });
  }
  contextTextBufferReplaceStyledBatch(context, replacements, beforeNative) {
    const count = replacements.length;
    if (count > nativeConstants.OT_TEXT_REPLACEMENT_COUNT_MAX)
      return null;
    let byteCount = 0;
    let chunkCount = 0;
    let urlByteCount = 0;
    for (const { text } of replacements) {
      byteCount += text.bytes.length;
      chunkCount += text.count;
      urlByteCount += text.urlBytes.length;
    }
    if (byteCount > nativeConstants.OT_TEXT_REPLACEMENT_BYTES_MAX || chunkCount > nativeConstants.OT_TEXT_REPLACEMENT_CHUNKS_MAX || urlByteCount > nativeConstants.OT_TEXT_REPLACEMENT_URL_BYTES_MAX) {
      return null;
    }
    const layout = nativeLayouts.ot_text_buffer_replacement;
    const chunkLayout = nativeLayouts.ot_styled_text_chunk;
    const records = new Uint32Array(count * layout.size / 4);
    const bytes = new Uint8Array(byteCount);
    const chunks = new Uint32Array(chunkCount * chunkLayout.size / 4);
    const urls = new Uint8Array(urlByteCount);
    const output = new Uint32Array(count * nativeLayouts.ot_text_buffer_replacement_info.size / 4);
    byteCount = 0;
    chunkCount = 0;
    urlByteCount = 0;
    for (let index = 0;index < count; index++) {
      const { buffer, view, text } = replacements[index];
      const offset = index * layout.size / 4;
      records[offset + layout.fields.struct_size.offset / 4] = layout.size;
      records[offset + layout.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
      records.set(encodeContextHandle(context, buffer), offset + layout.fields.buffer.offset / 4);
      records.set(encodeContextHandle(context, view), offset + layout.fields.view.offset / 4);
      records[offset + layout.fields.byte_offset.offset / 4] = byteCount;
      records[offset + layout.fields.byte_count.offset / 4] = text.bytes.length;
      records[offset + layout.fields.chunk_offset.offset / 4] = chunkCount;
      records[offset + layout.fields.chunk_count.offset / 4] = text.count;
      bytes.set(text.bytes, byteCount);
      urls.set(text.urlBytes, urlByteCount);
      const chunkOffset = chunkCount * chunkLayout.size / 4;
      chunks.set(text.records.subarray(0, text.count * chunkLayout.size / 4), chunkOffset);
      for (let chunk = 0;chunk < text.count; chunk++) {
        const start = chunkOffset + chunk * chunkLayout.size / 4;
        if (chunks[start + chunkLayout.fields.flags.offset / 4] & nativeConstants.OT_SCENE_TEXT_LINK) {
          chunks[start + chunkLayout.fields.link_offset.offset / 4] += urlByteCount;
        }
      }
      byteCount += text.bytes.length;
      chunkCount += text.count;
      urlByteCount += text.urlBytes.length;
    }
    return this.getYogaHost().runMutation(() => {
      beforeNative();
      const pointer = this.nativeContextPointer(context, "ot_text_buffer_replace_styled_batch");
      nativeResult("ot_text_buffer_replace_styled_batch", this.opentui.symbols.ot_text_buffer_replace_styled_batch(pointer, records, count, bytes, byteCount, chunks, chunkCount, urls, urlByteCount, output));
      return output;
    });
  }
  contextTextBufferSetSyntaxStyle(context, text, style) {
    const handle = encodeContextHandle(context, text);
    const target = style === null ? null : encodeContextHandle(context, style);
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_text_buffer_set_syntax_style");
      nativeResult("ot_text_buffer_set_syntax_style", this.opentui.symbols.ot_text_buffer_set_syntax_style(pointer, handle, target));
    });
  }
  contextTextBufferGetInfo(context, text) {
    const layout = nativeLayouts.ot_text_buffer_info;
    const handle = encodeContextHandle(context, text);
    const output = new BigUint64Array(layout.size / 8);
    const words = new Uint32Array(output.buffer);
    words[layout.fields.struct_size.offset / 4] = layout.size;
    words[layout.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
    const pointer = this.nativeContextPointer(context, "ot_text_buffer_get_info");
    nativeResult("ot_text_buffer_get_info", this.opentui.symbols.ot_text_buffer_get_info(pointer, handle, output));
    return {
      contentEpoch: output[layout.fields.content_epoch.offset / 8],
      byteLength: words[layout.fields.byte_count.offset / 4],
      textLength: words[layout.fields.text_length.offset / 4],
      lineCount: words[layout.fields.line_count.offset / 4],
      highlightCount: words[layout.fields.highlight_count.offset / 4],
      tabWidth: words[layout.fields.tab_width.offset / 4]
    };
  }
  readText(operation, read) {
    const count = new Uint32Array(1);
    nativeResult(operation, read(null, 0, count));
    if (count[0] === 0)
      return "";
    const bytes = new Uint8Array(count[0]);
    nativeResult(operation, read(viewOrNull(bytes), bytes.length, count));
    if (count[0] !== bytes.length) {
      throw new NativeError2(operation, -5 /* InternalError */);
    }
    return this.decoder.decode(bytes);
  }
  contextTextBufferGetText(context, text) {
    const handle = encodeContextHandle(context, text);
    const pointer = this.nativeContextPointer(context, "ot_text_buffer_get_text");
    return this.readText("ot_text_buffer_get_text", (bytes, capacity, count) => this.opentui.symbols.ot_text_buffer_get_text(pointer, handle, bytes, capacity, count));
  }
  contextTextBufferGetRange(context, text, start, end) {
    const handle = encodeContextHandle(context, text);
    const startOffset = toSafeFFIU32Length(start, "Text range start");
    const endOffset = toSafeFFIU32Length(end, "Text range end");
    const pointer = this.nativeContextPointer(context, "ot_text_buffer_get_range");
    return this.readText("ot_text_buffer_get_range", (bytes, capacity, count) => this.opentui.symbols.ot_text_buffer_get_range(pointer, handle, startOffset, endOffset, bytes, capacity, count));
  }
  contextTextBufferSetDefaults(context, text, mask, style) {
    const handle = encodeContextHandle(context, text);
    const fields = toSafeFFIU32Length(mask, "Text default style mask");
    const record = encodeEditorStyle(style);
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_text_buffer_set_defaults");
      nativeResult("ot_text_buffer_set_defaults", this.opentui.symbols.ot_text_buffer_set_defaults(pointer, handle, fields, record));
    });
  }
  contextTextBufferSetTabWidth(context, text, width) {
    const handle = encodeContextHandle(context, text);
    const value = toSafeFFIU32Length(width, "Text tab width");
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_text_buffer_set_tab_width");
      nativeResult("ot_text_buffer_set_tab_width", this.opentui.symbols.ot_text_buffer_set_tab_width(pointer, handle, value));
    });
  }
  contextTextBufferHighlight(context, text, operation, argument = 0, highlight) {
    const handle = encodeContextHandle(context, text);
    const selector = toSafeFFIU32Length(operation, "Text highlight operation");
    const value = toSafeFFIU32Length(argument, "Text highlight argument");
    const record = encodeContextHighlight(highlight);
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_text_buffer_highlight");
      nativeResult("ot_text_buffer_highlight", this.opentui.symbols.ot_text_buffer_highlight(pointer, handle, selector, value, record));
    });
  }
  contextTextBufferGetHighlights(context, text, line) {
    const handle = encodeContextHandle(context, text);
    const row = toSafeFFIU32Length(line, "Highlight line");
    const count = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_text_buffer_get_highlights");
    nativeResult("ot_text_buffer_get_highlights", this.opentui.symbols.ot_text_buffer_get_highlights(pointer, handle, row, null, 0, count));
    if (count[0] === 0)
      return [];
    const capacity = count[0];
    const records = new Uint32Array(capacity * (nativeLayouts.ot_edit_highlight.size / 4));
    nativeResult("ot_text_buffer_get_highlights", this.opentui.symbols.ot_text_buffer_get_highlights(pointer, handle, row, records, capacity, count));
    if (count[0] !== capacity)
      throw new NativeError2("ot_text_buffer_get_highlights", -5 /* InternalError */);
    return decodeContextHighlights(records);
  }
  contextTextBufferViewSetViewport(context, view, viewport, sizeOnly = false) {
    const layout = nativeLayouts.ot_editor_viewport;
    const handle = encodeContextHandle(context, view);
    const record = createContextRecord(layout);
    record[layout.fields.x.offset / 4] = toSafeFFIU32Length(viewport.x, "Text viewport x");
    record[layout.fields.y.offset / 4] = toSafeFFIU32Length(viewport.y, "Text viewport y");
    record[layout.fields.width.offset / 4] = toSafeFFIU32Length(viewport.width, "Text viewport width");
    record[layout.fields.height.offset / 4] = toSafeFFIU32Length(viewport.height, "Text viewport height");
    const resize = toFFIBool(sizeOnly, "Text viewport sizeOnly");
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_text_buffer_view_set_viewport");
      nativeResult("ot_text_buffer_view_set_viewport", this.opentui.symbols.ot_text_buffer_view_set_viewport(pointer, handle, record, resize));
    });
  }
  contextTextBufferViewCommand(context, view, command, argument) {
    const handle = encodeContextHandle(context, view);
    const operation = toSafeFFIU32Length(command, "Text view command");
    const value = toSafeFFIU32Length(argument, "Text view command argument");
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_text_buffer_view_command");
      nativeResult("ot_text_buffer_view_command", this.opentui.symbols.ot_text_buffer_view_command(pointer, handle, operation, value));
    });
  }
  contextTextBufferViewSetTabColor(context, view, color) {
    const handle = encodeContextHandle(context, view);
    const record = color === null ? null : contextBufferColor(color);
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_text_buffer_view_set_tab_color");
      nativeResult("ot_text_buffer_view_set_tab_color", this.opentui.symbols.ot_text_buffer_view_set_tab_color(pointer, handle, record));
    });
  }
  contextTextBufferViewSelect(context, view, selection) {
    const handle = encodeContextHandle(context, view);
    const scratch = this.editorSelectionRecord ?? createEditorSelectionRecord();
    this.editorSelectionRecord = undefined;
    try {
      const record = encodeEditorSelection(selection, scratch);
      const changed = scratch.changed;
      changed[0] = 0;
      this.getYogaHost().runMutation(() => {
        const pointer = this.nativeContextPointer(context, "ot_text_buffer_view_select");
        nativeResult("ot_text_buffer_view_select", this.opentui.symbols.ot_text_buffer_view_select(pointer, handle, record, changed));
      });
      return changed[0] !== 0;
    } finally {
      this.editorSelectionRecord ??= scratch;
    }
  }
  contextTextBufferViewResetSelection(context, view, local, clear = false) {
    const handle = encodeContextHandle(context, view);
    const record = local ? this.localSelectionResetRecord : this.selectionResetRecord;
    this.getYogaHost().assertMutable();
    const pointer = this.nativeContextPointer(context, "ot_text_buffer_view_select");
    if (clear)
      return;
    nativeResult("ot_text_buffer_view_select", this.opentui.symbols.ot_text_buffer_view_select(pointer, handle, record, this.selectionResetChanged));
  }
  contextTextBufferViewGetInfo(context, view) {
    const layout = nativeLayouts.ot_editor_view_info;
    const handle = encodeContextHandle(context, view);
    const output = this.editorViewInfoRecord;
    output.fill(0);
    output[layout.fields.struct_size.offset / 4] = layout.size;
    output[layout.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
    const pointer = this.nativeContextPointer(context, "ot_text_buffer_view_get_info");
    nativeResult("ot_text_buffer_view_get_info", this.opentui.symbols.ot_text_buffer_view_get_info(pointer, handle, output));
    return {
      virtualLineCount: output[layout.fields.virtual_line_count.offset / 4],
      totalVirtualLineCount: output[layout.fields.total_virtual_line_count.offset / 4],
      selection: output[layout.fields.selection_present.offset / 4] === 0 ? null : {
        start: output[layout.fields.selection_start.offset / 4],
        end: output[layout.fields.selection_end.offset / 4]
      },
      selectionOccupancy: output[layout.fields.selection_occupancy.offset / 4] === 0 ? "cell" : "boundary"
    };
  }
  contextTextBufferViewGetSelectedText(context, view) {
    const handle = encodeContextHandle(context, view);
    const pointer = this.nativeContextPointer(context, "ot_text_buffer_view_get_selected_text");
    return this.readText("ot_text_buffer_view_get_selected_text", (bytes, capacity, count) => this.opentui.symbols.ot_text_buffer_view_get_selected_text(pointer, handle, bytes, capacity, count));
  }
  contextTextBufferViewGetLines(context, view, logical = false, firstLine = 0, lineCount = MAX_FFI_U32) {
    const layout = nativeLayouts.ot_editor_measure;
    const handle = encodeContextHandle(context, view);
    const mode = toFFIBool(logical, "Text logical lines");
    const first = toSafeFFIU32Length(firstLine, "Text first line");
    const capacity = toSafeFFIU32Length(lineCount, "Text line count");
    const output = createContextRecord(layout);
    const pointer = this.nativeContextPointer(context, "ot_text_buffer_view_get_lines");
    nativeResult("ot_text_buffer_view_get_lines", this.opentui.symbols.ot_text_buffer_view_get_lines(pointer, handle, mode, 0, null, 0, output));
    const total = output[layout.fields.line_count.offset / 4];
    const count = Math.min(capacity, Math.max(0, total - first));
    const lines = new Uint32Array(count * (nativeLayouts.ot_scene_text_line.size / 4));
    if (count !== 0) {
      nativeResult("ot_text_buffer_view_get_lines", this.opentui.symbols.ot_text_buffer_view_get_lines(pointer, handle, mode, first, lines, count, output));
      if (output[layout.fields.line_count.offset / 4] !== total)
        throw new NativeError2("ot_text_buffer_view_get_lines", -5 /* InternalError */);
    }
    return decodeContextTextLines(lines, output[layout.fields.width_cols_max.offset / 4]);
  }
  contextTextBufferViewMeasure(context, view, width, height) {
    const layout = nativeLayouts.ot_editor_measure;
    const handle = encodeContextHandle(context, view);
    const columns = toSafeFFIU32Length(width, "Text measure width");
    const rows = toSafeFFIU32Length(height, "Text measure height");
    const output = createContextRecord(layout);
    const pointer = this.nativeContextPointer(context, "ot_text_buffer_view_measure");
    nativeResult("ot_text_buffer_view_measure", this.opentui.symbols.ot_text_buffer_view_measure(pointer, handle, columns, rows, output));
    return {
      lineCount: output[layout.fields.line_count.offset / 4],
      widthColsMax: output[layout.fields.width_cols_max.offset / 4]
    };
  }
  sceneSetTextView(context, node, view) {
    const handle = encodeContextHandle(context, node);
    const source = view === null ? null : encodeContextHandle(context, view);
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_scene_set_text_view");
      nativeResult("ot_scene_set_text_view", this.opentui.symbols.ot_scene_set_text_view(pointer, handle, source));
    });
  }
  sceneSetTextViewPaint(context, node, enabled) {
    const handle = encodeContextHandle(context, node);
    const value = toFFIBool(enabled, "Text view paint enabled");
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_scene_set_text_view_paint");
      nativeResult("ot_scene_set_text_view_paint", this.opentui.symbols.ot_scene_set_text_view_paint(pointer, handle, value));
    });
  }
  contextDrawTextBufferView({ context, target, frame }, view, x, y) {
    this.getYogaHost().assertMutable();
    const destination = encodeContextHandle(context, target);
    const request = frame === null ? null : encodeSceneFrameRequest(context, frame);
    const source = encodeContextHandle(context, view);
    const column = toFFII32(x, "Text view x") || 0;
    const row = toFFII32(y, "Text view y") || 0;
    const pointer = this.nativeContextPointer(context, "ot_buffer_draw_text_view");
    nativeResult("ot_buffer_draw_text_view", this.opentui.symbols.ot_buffer_draw_text_view(pointer, destination, request, source, column, row));
  }
  contextDrawEditorView({ context, target, frame }, view, x, y) {
    this.getYogaHost().assertMutable();
    const destination = encodeContextHandle(context, target);
    const request = frame === null ? null : encodeSceneFrameRequest(context, frame);
    const source = encodeContextHandle(context, view);
    const column = toFFII32(x, "Editor view x") || 0;
    const row = toFFII32(y, "Editor view y") || 0;
    const pointer = this.nativeContextPointer(context, "ot_buffer_draw_editor_view");
    nativeResult("ot_buffer_draw_editor_view", this.opentui.symbols.ot_buffer_draw_editor_view(pointer, destination, request, source, column, row));
  }
  contextDrawSceneText({ context, target, frame }, node, x, y) {
    this.getYogaHost().assertMutable();
    const destination = encodeContextHandle(context, target);
    const request = frame === null ? null : encodeSceneFrameRequest(context, frame);
    const source = encodeContextHandle(context, node);
    const column = toFFII32(x, "Scene text x") || 0;
    const row = toFFII32(y, "Scene text y") || 0;
    const pointer = this.nativeContextPointer(context, "ot_buffer_draw_scene_text");
    nativeResult("ot_buffer_draw_scene_text", this.opentui.symbols.ot_buffer_draw_scene_text(pointer, destination, request, source, column, row));
  }
  createContextEditBuffer(context, options = {}) {
    const layout = nativeLayouts.ot_edit_buffer_options;
    this.getYogaHost().assertMutable();
    const widthMethod = widthMethodId(options.widthMethod ?? "unicode", "editor");
    const record = createContextRecord(layout);
    record[layout.fields.width_method.offset / 4] = widthMethod;
    const output = new Uint32Array(handleWords);
    const pointer = this.nativeContextPointer(context, "ot_edit_buffer_create");
    nativeResult("ot_edit_buffer_create", this.opentui.symbols.ot_edit_buffer_create(pointer, record, output));
    return decodeContextHandle(context, output);
  }
  destroyContextEditBuffer(context, editBuffer) {
    this.destroyContextObject(context, editBuffer, "ot_edit_buffer_destroy");
    const buffers = this.contextEditEvents.get(context)?.buffers;
    buffers?.get(editBuffer.slot)?.listeners.clear();
    buffers?.delete(editBuffer.slot);
  }
  createContextEditorView(context, editBuffer, width, height) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, editBuffer);
    const columns = toSafeFFIU32Length(width, "Editor view width");
    const rows = toSafeFFIU32Length(height, "Editor view height");
    const output = new Uint32Array(handleWords);
    const pointer = this.nativeContextPointer(context, "ot_editor_view_create");
    nativeResult("ot_editor_view_create", this.opentui.symbols.ot_editor_view_create(pointer, handle, columns, rows, output));
    return decodeContextHandle(context, output);
  }
  destroyContextEditorView(context, view) {
    this.destroyContextObject(context, view, "ot_editor_view_destroy");
  }
  createContextSyntaxStyle(context) {
    this.getYogaHost().assertMutable();
    const output = new Uint32Array(handleWords);
    const pointer = this.nativeContextPointer(context, "ot_syntax_style_create");
    nativeResult("ot_syntax_style_create", this.opentui.symbols.ot_syntax_style_create(pointer, output));
    try {
      return decodeContextHandle(context, output);
    } catch (error) {
      this.opentui.symbols.ot_syntax_style_destroy(pointer, output);
      throw error;
    }
  }
  destroyContextSyntaxStyle(context, style) {
    this.destroyContextObject(context, style, "ot_syntax_style_destroy");
  }
  contextEditBufferSetSyntaxStyle(context, editBuffer, style) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, editBuffer);
    const target = style === null ? null : encodeContextHandle(context, style);
    const pointer = this.nativeContextPointer(context, "ot_edit_buffer_set_syntax_style");
    nativeResult("ot_edit_buffer_set_syntax_style", this.opentui.symbols.ot_edit_buffer_set_syntax_style(pointer, handle, target));
  }
  contextEditBufferSetText(context, editBuffer, bytes, preserveHistory = false) {
    const handle = encodeContextHandle(context, editBuffer);
    const input = sessionBytes(bytes, "Edit buffer text length");
    const preserve = toFFIBool(preserveHistory, "Edit buffer preserveHistory");
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_edit_buffer_set_text");
      nativeResult("ot_edit_buffer_set_text", this.opentui.symbols.ot_edit_buffer_set_text(pointer, handle, viewOrNull(input), input.length, preserve));
    });
  }
  contextEditBufferInsertText(context, editBuffer, bytes) {
    const handle = encodeContextHandle(context, editBuffer);
    const input = sessionBytes(bytes, "Edit buffer insert length");
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_edit_buffer_insert_text");
      nativeResult("ot_edit_buffer_insert_text", this.opentui.symbols.ot_edit_buffer_insert_text(pointer, handle, viewOrNull(input), input.length));
    });
  }
  contextEditBufferDeleteRange(context, editBuffer, startRow, startCol, endRow, endCol) {
    const handle = encodeContextHandle(context, editBuffer);
    const rowStart = toSafeFFIU32Length(startRow, "Edit buffer start row");
    const colStart = toSafeFFIU32Length(startCol, "Edit buffer start column");
    const rowEnd = toSafeFFIU32Length(endRow, "Edit buffer end row");
    const colEnd = toSafeFFIU32Length(endCol, "Edit buffer end column");
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_edit_buffer_delete_range");
      nativeResult("ot_edit_buffer_delete_range", this.opentui.symbols.ot_edit_buffer_delete_range(pointer, handle, rowStart, colStart, rowEnd, colEnd));
    });
  }
  contextEditBufferSetCursor(context, editBuffer, row, col) {
    const handle = encodeContextHandle(context, editBuffer);
    const cursorRow = toSafeFFIU32Length(row, "Edit buffer cursor row");
    const cursorCol = toSafeFFIU32Length(col, "Edit buffer cursor column");
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_edit_buffer_set_cursor");
      nativeResult("ot_edit_buffer_set_cursor", this.opentui.symbols.ot_edit_buffer_set_cursor(pointer, handle, cursorRow, cursorCol));
    });
  }
  contextEditBufferGetText(context, editBuffer) {
    const handle = encodeContextHandle(context, editBuffer);
    const pointer = this.nativeContextPointer(context, "ot_edit_buffer_get_text");
    return this.readText("ot_edit_buffer_get_text", (bytes, capacity, count) => this.opentui.symbols.ot_edit_buffer_get_text(pointer, handle, bytes, capacity, count));
  }
  contextEditBufferGetInfo(context, editBuffer) {
    const layout = nativeLayouts.ot_edit_buffer_info;
    const handle = encodeContextHandle(context, editBuffer);
    const output = new BigUint64Array(layout.size / 8);
    const words = new Uint32Array(output.buffer);
    words[layout.fields.struct_size.offset / 4] = layout.size;
    words[layout.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
    const pointer = this.nativeContextPointer(context, "ot_edit_buffer_get_info");
    nativeResult("ot_edit_buffer_get_info", this.opentui.symbols.ot_edit_buffer_get_info(pointer, handle, output));
    return {
      contentEpoch: output[layout.fields.content_epoch.offset / 8],
      byteLength: words[layout.fields.byte_count.offset / 4],
      lineCount: words[layout.fields.line_count.offset / 4],
      cursor: {
        row: words[layout.fields.cursor_row.offset / 4],
        col: words[layout.fields.cursor_col.offset / 4],
        offset: words[layout.fields.cursor_offset.offset / 4]
      },
      canUndo: words[layout.fields.can_undo.offset / 4] !== 0,
      canRedo: words[layout.fields.can_redo.offset / 4] !== 0,
      tabWidth: words[layout.fields.tab_width.offset / 4]
    };
  }
  contextEditBufferSetTabWidth(context, editBuffer, width) {
    const handle = encodeContextHandle(context, editBuffer);
    const value = toSafeFFIU32Length(width, "Edit buffer tab width");
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_edit_buffer_set_tab_width");
      nativeResult("ot_edit_buffer_set_tab_width", this.opentui.symbols.ot_edit_buffer_set_tab_width(pointer, handle, value));
    });
  }
  contextEditBufferCommand(context, editBuffer, command, argument = 0) {
    const handle = encodeContextHandle(context, editBuffer);
    const operation = toSafeFFIU32Length(command, "Edit buffer command");
    const value = toSafeFFIU32Length(argument, "Edit buffer command argument");
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_edit_buffer_command");
      nativeResult("ot_edit_buffer_command", this.opentui.symbols.ot_edit_buffer_command(pointer, handle, operation, value));
    });
  }
  contextEditBufferHistory(context, editBuffer, redo) {
    const handle = encodeContextHandle(context, editBuffer);
    const direction = toFFIBool(redo, "Edit buffer redo");
    const bytes = new Uint8Array(64);
    const count = new Uint32Array(1);
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_edit_buffer_history");
      nativeResult("ot_edit_buffer_history", this.opentui.symbols.ot_edit_buffer_history(pointer, handle, direction, bytes, bytes.length, count));
    });
    if (count[0] > bytes.length)
      throw new NativeError2("ot_edit_buffer_history", -5 /* InternalError */);
    return count[0] === 0 ? null : this.decoder.decode(bytes.subarray(0, count[0]));
  }
  contextEditBufferGetPosition(context, editBuffer, query, a = 0, b = 0) {
    const layout = nativeLayouts.ot_edit_position;
    const handle = encodeContextHandle(context, editBuffer);
    const selector = toSafeFFIU32Length(query, "Edit buffer position query");
    const first = toSafeFFIU32Length(a, "Edit buffer position argument");
    const second = toSafeFFIU32Length(b, "Edit buffer position column");
    const output = createContextRecord(layout);
    const pointer = this.nativeContextPointer(context, "ot_edit_buffer_get_position");
    nativeResult("ot_edit_buffer_get_position", this.opentui.symbols.ot_edit_buffer_get_position(pointer, handle, selector, first, second, output));
    return output[layout.fields.valid.offset / 4] === 0 ? null : {
      row: output[layout.fields.row.offset / 4],
      col: output[layout.fields.col.offset / 4],
      offset: output[layout.fields.offset.offset / 4]
    };
  }
  contextEditBufferGetRange(context, editBuffer, byCoords, startRow, startCol, endRow, endCol) {
    const handle = encodeContextHandle(context, editBuffer);
    const coords = toFFIBool(byCoords, "Edit buffer range byCoords");
    const rowStart = toSafeFFIU32Length(startRow, "Edit buffer range start row");
    const colStart = toSafeFFIU32Length(startCol, "Edit buffer range start column");
    const rowEnd = toSafeFFIU32Length(endRow, "Edit buffer range end row");
    const colEnd = toSafeFFIU32Length(endCol, "Edit buffer range end column");
    const pointer = this.nativeContextPointer(context, "ot_edit_buffer_get_range");
    return this.readText("ot_edit_buffer_get_range", (bytes, capacity, count) => this.opentui.symbols.ot_edit_buffer_get_range(pointer, handle, coords, rowStart, colStart, rowEnd, colEnd, bytes, capacity, count));
  }
  contextEditBufferMeasureText(context, editBuffer, bytes) {
    const handle = encodeContextHandle(context, editBuffer);
    const input = sessionBytes(bytes, "Edit buffer measure length");
    const output = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_edit_buffer_measure_text");
    nativeResult("ot_edit_buffer_measure_text", this.opentui.symbols.ot_edit_buffer_measure_text(pointer, handle, viewOrNull(input), input.length, output));
    return output[0];
  }
  editMeasureText(bytes, widthMethod, tabWidth) {
    const method = widthMethodId(widthMethod, "editor");
    const width = toSafeFFIU32Length(tabWidth, "Edit buffer tab width");
    const input = sessionBytes(bytes, "Edit buffer measure length");
    const output = new Uint32Array(1);
    this.editMeasureContext ??= this.createContext({ objectCapacity: 1, renderCellsMax: 1 });
    const pointer = this.nativeContextPointer(this.editMeasureContext, "ot_edit_measure_text");
    nativeResult("ot_edit_measure_text", this.opentui.symbols.ot_edit_measure_text(pointer, viewOrNull(input), input.length, method, width, output));
    return output[0];
  }
  contextEditBufferSetDefaults(context, editBuffer, mask, style) {
    const handle = encodeContextHandle(context, editBuffer);
    const fields = toSafeFFIU32Length(mask, "Editor default style mask");
    const record = encodeEditorStyle(style);
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_edit_buffer_set_defaults");
      nativeResult("ot_edit_buffer_set_defaults", this.opentui.symbols.ot_edit_buffer_set_defaults(pointer, handle, fields, record));
    });
  }
  contextSyntaxStyleRegister(context, style, name, definition) {
    const handle = encodeContextHandle(context, style);
    if (typeof name !== "string")
      throw new TypeError("Syntax style name must be a string");
    const bytes = this.encoder.encode(name);
    const length = toSafeFFIU32Length(bytes.length, "Syntax style name length");
    const record = encodeEditorStyle(definition);
    const output = new Uint32Array(1);
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_syntax_style_register");
      nativeResult("ot_syntax_style_register", this.opentui.symbols.ot_syntax_style_register(pointer, handle, viewOrNull(bytes), length, record, output));
    });
    return output[0];
  }
  contextSyntaxStyleResolveByName(context, style, name) {
    const handle = encodeContextHandle(context, style);
    if (typeof name !== "string")
      throw new TypeError("Syntax style name must be a string");
    const bytes = sessionBytes(this.encoder.encode(name), "Syntax style name length");
    const output = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_syntax_style_resolve");
    nativeResult("ot_syntax_style_resolve", this.opentui.symbols.ot_syntax_style_resolve(pointer, handle, viewOrNull(bytes), bytes.length, output));
    return output[0] || null;
  }
  contextSyntaxStyleGetStyleCount(context, style) {
    const handle = encodeContextHandle(context, style);
    const output = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_syntax_style_get_count");
    nativeResult("ot_syntax_style_get_count", this.opentui.symbols.ot_syntax_style_get_count(pointer, handle, output));
    return output[0];
  }
  contextEditBufferHighlight(context, editBuffer, operation, argument = 0, highlight) {
    const handle = encodeContextHandle(context, editBuffer);
    const selector = toSafeFFIU32Length(operation, "Edit buffer highlight operation");
    const value = toSafeFFIU32Length(argument, "Edit buffer highlight argument");
    const record = encodeContextHighlight(highlight);
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_edit_buffer_highlight");
      nativeResult("ot_edit_buffer_highlight", this.opentui.symbols.ot_edit_buffer_highlight(pointer, handle, selector, value, record));
    });
  }
  contextEditBufferGetHighlights(context, editBuffer, line) {
    const handle = encodeContextHandle(context, editBuffer);
    const row = toSafeFFIU32Length(line, "Highlight line");
    const count = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_edit_buffer_get_highlights");
    nativeResult("ot_edit_buffer_get_highlights", this.opentui.symbols.ot_edit_buffer_get_highlights(pointer, handle, row, null, 0, count));
    if (count[0] === 0)
      return [];
    const capacity = count[0];
    const records = new Uint32Array(capacity * (nativeLayouts.ot_edit_highlight.size / 4));
    nativeResult("ot_edit_buffer_get_highlights", this.opentui.symbols.ot_edit_buffer_get_highlights(pointer, handle, row, records, capacity, count));
    if (count[0] !== capacity)
      throw new NativeError2("ot_edit_buffer_get_highlights", -5 /* InternalError */);
    return decodeContextHighlights(records);
  }
  contextEditorViewSetViewport(context, view, viewport, sizeOnly = false, moveCursor = false) {
    const layout = nativeLayouts.ot_editor_viewport;
    const handle = encodeContextHandle(context, view);
    const record = createContextRecord(layout);
    record[layout.fields.x.offset / 4] = toSafeFFIU32Length(viewport.x, "Editor viewport x");
    record[layout.fields.y.offset / 4] = toSafeFFIU32Length(viewport.y, "Editor viewport y");
    record[layout.fields.width.offset / 4] = toSafeFFIU32Length(viewport.width, "Editor viewport width");
    record[layout.fields.height.offset / 4] = toSafeFFIU32Length(viewport.height, "Editor viewport height");
    const resize = toFFIBool(sizeOnly, "Editor viewport sizeOnly");
    const move = toFFIBool(moveCursor, "Editor viewport moveCursor");
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_editor_view_set_viewport");
      nativeResult("ot_editor_view_set_viewport", this.opentui.symbols.ot_editor_view_set_viewport(pointer, handle, record, resize, move));
    });
  }
  contextEditorViewGetViewport(context, view) {
    const layout = nativeLayouts.ot_editor_viewport;
    const handle = encodeContextHandle(context, view);
    const output = createContextRecord(layout);
    const pointer = this.nativeContextPointer(context, "ot_editor_view_get_viewport");
    nativeResult("ot_editor_view_get_viewport", this.opentui.symbols.ot_editor_view_get_viewport(pointer, handle, output));
    return {
      x: output[layout.fields.x.offset / 4],
      y: output[layout.fields.y.offset / 4],
      width: output[layout.fields.width.offset / 4],
      height: output[layout.fields.height.offset / 4]
    };
  }
  contextEditorViewSetScrollMargin(context, view, margin) {
    const handle = encodeContextHandle(context, view);
    const value = toFFIF32(margin, "Editor scroll margin");
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_editor_view_set_scroll_margin");
      nativeResult("ot_editor_view_set_scroll_margin", this.opentui.symbols.ot_editor_view_set_scroll_margin(pointer, handle, value));
    });
  }
  contextEditorViewCommand(context, view, command, argument = 0) {
    const handle = encodeContextHandle(context, view);
    const operation = toSafeFFIU32Length(command, "Editor view command");
    const value = toSafeFFIU32Length(argument, "Editor view command argument");
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_editor_view_command");
      nativeResult("ot_editor_view_command", this.opentui.symbols.ot_editor_view_command(pointer, handle, operation, value));
    });
  }
  contextEditorViewReplaceSelection(context, view, bytes) {
    const handle = encodeContextHandle(context, view);
    const input = sessionBytes(bytes, "Editor replacement length");
    const output = new Uint32Array(1);
    return this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_editor_view_replace_selection");
      nativeResult("ot_editor_view_replace_selection", this.opentui.symbols.ot_editor_view_replace_selection(pointer, handle, viewOrNull(input), input.length, output));
      return { deleted: (output[0] & 1) !== 0, inserted: (output[0] & 2) !== 0 };
    });
  }
  contextEditorViewSetTabColor(context, view, color) {
    const handle = encodeContextHandle(context, view);
    const record = color === null ? null : contextBufferColor(color);
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_editor_view_set_tab_color");
      nativeResult("ot_editor_view_set_tab_color", this.opentui.symbols.ot_editor_view_set_tab_color(pointer, handle, record));
    });
  }
  contextEditorViewSelect(context, view, selection) {
    const handle = encodeContextHandle(context, view);
    const scratch = this.editorSelectionRecord ?? createEditorSelectionRecord();
    this.editorSelectionRecord = undefined;
    try {
      const record = encodeEditorSelection(selection, scratch);
      const changed = scratch.changed;
      changed[0] = 0;
      this.getYogaHost().runMutation(() => {
        const pointer = this.nativeContextPointer(context, "ot_editor_view_select");
        nativeResult("ot_editor_view_select", this.opentui.symbols.ot_editor_view_select(pointer, handle, record, changed));
      });
      return changed[0] !== 0;
    } finally {
      this.editorSelectionRecord ??= scratch;
    }
  }
  contextEditorViewGetInfo(context, view, followCursor = false) {
    const layout = nativeLayouts.ot_editor_view_info;
    const handle = encodeContextHandle(context, view);
    const follow = toFFIBool(followCursor, "Editor followCursor");
    const output = createContextRecord(layout);
    const pointer = this.nativeContextPointer(context, "ot_editor_view_get_info");
    nativeResult("ot_editor_view_get_info", this.opentui.symbols.ot_editor_view_get_info(pointer, handle, follow, output));
    return {
      virtualLineCount: output[layout.fields.virtual_line_count.offset / 4],
      totalVirtualLineCount: output[layout.fields.total_virtual_line_count.offset / 4],
      selection: output[layout.fields.selection_present.offset / 4] === 0 ? null : {
        start: output[layout.fields.selection_start.offset / 4],
        end: output[layout.fields.selection_end.offset / 4]
      },
      selectionOccupancy: output[layout.fields.selection_occupancy.offset / 4] === 0 ? "cell" : "boundary"
    };
  }
  contextEditorViewGetSelection(context, view) {
    const layout = nativeLayouts.ot_editor_view_info;
    const handle = encodeContextHandle(context, view);
    const output = createContextRecord(layout);
    const pointer = this.nativeContextPointer(context, "ot_editor_view_get_selection");
    nativeResult("ot_editor_view_get_selection", this.opentui.symbols.ot_editor_view_get_selection(pointer, handle, output));
    return {
      selection: output[layout.fields.selection_present.offset / 4] === 0 ? null : {
        start: output[layout.fields.selection_start.offset / 4],
        end: output[layout.fields.selection_end.offset / 4]
      },
      selectionOccupancy: output[layout.fields.selection_occupancy.offset / 4] === 0 ? "cell" : "boundary"
    };
  }
  contextEditorViewGetSelectedText(context, view) {
    const handle = encodeContextHandle(context, view);
    const pointer = this.nativeContextPointer(context, "ot_editor_view_get_selected_text");
    return this.readText("ot_editor_view_get_selected_text", (bytes, capacity, count) => this.opentui.symbols.ot_editor_view_get_selected_text(pointer, handle, bytes, capacity, count));
  }
  contextEditorViewGetPosition(context, view, query) {
    const layout = nativeLayouts.ot_editor_position;
    const handle = encodeContextHandle(context, view);
    const selector = toSafeFFIU32Length(query, "Editor position query");
    const output = createContextRecord(layout);
    const pointer = this.nativeContextPointer(context, "ot_editor_view_get_position");
    nativeResult("ot_editor_view_get_position", this.opentui.symbols.ot_editor_view_get_position(pointer, handle, selector, output));
    return {
      visualRow: output[layout.fields.visual_row.offset / 4],
      visualCol: output[layout.fields.visual_col.offset / 4],
      logicalRow: output[layout.fields.logical_row.offset / 4],
      logicalCol: output[layout.fields.logical_col.offset / 4],
      offset: output[layout.fields.offset.offset / 4]
    };
  }
  contextEditorViewGetLines(context, view, logical = false) {
    const layout = nativeLayouts.ot_editor_measure;
    const handle = encodeContextHandle(context, view);
    const mode = toFFIBool(logical, "Editor logical lines");
    const output = createContextRecord(layout);
    const pointer = this.nativeContextPointer(context, "ot_editor_view_get_lines");
    nativeResult("ot_editor_view_get_lines", this.opentui.symbols.ot_editor_view_get_lines(pointer, handle, mode, null, 0, output));
    const count = output[layout.fields.line_count.offset / 4];
    const lines = new Uint32Array(count * (nativeLayouts.ot_scene_text_line.size / 4));
    if (count !== 0) {
      nativeResult("ot_editor_view_get_lines", this.opentui.symbols.ot_editor_view_get_lines(pointer, handle, mode, lines, count, output));
      if (output[layout.fields.line_count.offset / 4] !== count)
        throw new NativeError2("ot_editor_view_get_lines", -5 /* InternalError */);
    }
    return decodeContextTextLines(lines, output[layout.fields.width_cols_max.offset / 4]);
  }
  contextEditorViewMeasure(context, view, width, height) {
    const layout = nativeLayouts.ot_editor_measure;
    const handle = encodeContextHandle(context, view);
    const columns = toSafeFFIU32Length(width, "Editor measure width");
    const rows = toSafeFFIU32Length(height, "Editor measure height");
    const output = createContextRecord(layout);
    const pointer = this.nativeContextPointer(context, "ot_editor_view_measure");
    nativeResult("ot_editor_view_measure", this.opentui.symbols.ot_editor_view_measure(pointer, handle, columns, rows, output));
    return {
      lineCount: output[layout.fields.line_count.offset / 4],
      widthColsMax: output[layout.fields.width_cols_max.offset / 4]
    };
  }
  contextEditorViewSetPlaceholder(context, view, content) {
    const handle = encodeContextHandle(context, view);
    const { bytes, records, count } = this.encodeStyledText(content, false);
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_editor_view_set_placeholder");
      nativeResult("ot_editor_view_set_placeholder", this.opentui.symbols.ot_editor_view_set_placeholder(pointer, handle, viewOrNull(bytes), bytes.length, count === 0 ? null : records, count));
    });
  }
  onContextEditEvent(context, editBuffer, handler) {
    this.getYogaHost().assertMutable();
    if (typeof handler !== "function")
      throw new TypeError("Edit event handler must be a function");
    const handle = decodeContextHandle(context, encodeContextHandle(context, editBuffer));
    this.contextEditBufferGetInfo(context, handle);
    let registration = this.contextEditEvents.get(context);
    if (!registration) {
      const buffers = new Map;
      const names = {
        [1 /* CursorChanged */]: "cursor-changed",
        [2 /* ContentChanged */]: "content-changed",
        [4 /* HistoryCursorChanged */]: "cursorChanged"
      };
      const callback = this.opentui.createCallback((contextId, slot, generation, event) => {
        this.getYogaHost().invokeCallback(() => {
          const entry = buffers.get(slot);
          if (!entry || entry.handle.contextId !== contextId || entry.handle.generation !== generation)
            return;
          const name = names[event];
          if (name === undefined)
            throw new Error("Native editor returned an unknown event");
          const listeners = [...entry.listeners];
          queueMicrotask(() => {
            for (const listener of listeners) {
              if (!this.nativeContexts.has(context) || buffers.get(slot) !== entry)
                return;
              if (entry.listeners.has(listener))
                listener.handler(name);
            }
          });
        });
      }, nativeCallbacks.ot_edit_event_callback);
      try {
        if (!callback.ptr)
          throw new Error("Failed to create native edit event callback");
        registration = { callback, buffers };
        this.contextEditEvents.set(context, registration);
        const pointer = this.nativeContextPointer(context, "ot_context_set_edit_event_callback");
        nativeResult("ot_context_set_edit_event_callback", this.opentui.symbols.ot_context_set_edit_event_callback(pointer, callback.ptr));
      } catch (error) {
        this.contextEditEvents.delete(context);
        callback.close();
        throw error;
      }
    }
    let entry = registration.buffers.get(handle.slot);
    if (!entry || entry.handle.contextId !== handle.contextId || entry.handle.generation !== handle.generation) {
      entry = { handle, listeners: new Set };
      registration.buffers.set(handle.slot, entry);
    }
    const listener = { handler };
    entry.listeners.add(listener);
    return () => {
      entry.listeners.delete(listener);
      if (entry.listeners.size === 0 && registration.buffers.get(handle.slot) === entry)
        registration.buffers.delete(handle.slot);
    };
  }
  sceneSetEditorView(context, node, view) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, node);
    const target = view === null ? null : encodeContextHandle(context, view);
    const pointer = this.nativeContextPointer(context, "ot_scene_set_editor_view");
    nativeResult("ot_scene_set_editor_view", this.opentui.symbols.ot_scene_set_editor_view(pointer, handle, target));
  }
  sceneSetEditorOptions(context, node, options) {
    const layout = nativeLayouts.ot_scene_editor_options;
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, node);
    const style = CURSOR_ID_TO_STYLE.indexOf(options.style);
    if (style < 0)
      throw new TypeError("Unknown scene editor cursor style");
    const record = createContextRecord(layout);
    record[layout.fields.show_cursor.offset / 4] = toFFIBool(options.showCursor, "Editor showCursor");
    record[layout.fields.style.offset / 4] = style;
    record[layout.fields.blinking.offset / 4] = toFFIBool(options.blinking, "Editor blinking");
    new Uint16Array(record.buffer, layout.fields.color.offset, layout.fields.color.size / 2).set(contextBufferColor(options.color));
    const cursor = options.cursor === undefined ? nativeConstants.OT_MOUSE_POINTER_UNCHANGED : MOUSE_STYLE_TO_ID[options.cursor];
    if (typeof cursor !== "number") {
      throw new TypeError("Unknown scene editor mouse pointer style");
    }
    record[layout.fields.mouse_pointer.offset / 4] = cursor;
    const pointer = this.nativeContextPointer(context, "ot_scene_set_editor_options");
    nativeResult("ot_scene_set_editor_options", this.opentui.symbols.ot_scene_set_editor_options(pointer, handle, record));
  }
  destroyContextImage(context, image) {
    this.destroyContextObject(context, image, "ot_image_destroy");
  }
  sceneSetImage(context, node, image, fit, protocol, buffer) {
    const handle = encodeContextHandle(context, node);
    const source = image === null ? null : encodeContextHandle(context, image);
    const storage = buffer === null ? null : encodeContextHandle(context, buffer);
    const fitId = IMAGE_FITS.indexOf(fit);
    const protocolId = IMAGE_PROTOCOL_TO_ID[protocol];
    if (fitId < 0 || !Number.isInteger(protocolId))
      throw new TypeError("Unknown image fit or protocol");
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_scene_set_image");
      nativeResult("ot_scene_set_image", this.opentui.symbols.ot_scene_set_image(pointer, handle, source, fitId, protocolId, storage));
    });
  }
  contextDrawImage({ context, target, frame }, image, options) {
    const layout = nativeLayouts.ot_image_draw_options;
    const handle = encodeContextHandle(context, target);
    const ticket = frame === null ? null : encodeSceneFrameRequest(context, frame);
    const source = encodeContextHandle(context, image);
    const record = new Uint32Array(layout.size / 4);
    encodeImageDrawOptions(options, record, new Int32Array(record.buffer), 0);
    const output = new Uint32Array(1);
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_buffer_draw_image");
      nativeResult("ot_buffer_draw_image", this.opentui.symbols.ot_buffer_draw_image(pointer, handle, ticket, source, record, output));
    });
    return output[0] !== 0;
  }
  sessionSetImageResolution(context, session, terminalWidth, terminalHeight, pixelWidth, pixelHeight) {
    const handle = encodeContextHandle(context, session);
    const columns = toSafeFFIU32Length(terminalWidth, "Terminal image columns");
    const rows = toSafeFFIU32Length(terminalHeight, "Terminal image rows");
    const width = toSafeFFIU32Length(pixelWidth, "Terminal image pixel width");
    const height = toSafeFFIU32Length(pixelHeight, "Terminal image pixel height");
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_session_set_image_resolution");
      nativeResult("ot_session_set_image_resolution", this.opentui.symbols.ot_session_set_image_resolution(pointer, handle, columns, rows, width, height));
    });
  }
  sessionSetKittyImageTransport(context, session, mode) {
    const handle = encodeContextHandle(context, session);
    const value = toSafeFFIU32Length(mode, "Session Kitty image transport");
    const pointer = this.nativeContextPointer(context, "ot_session_set_kitty_image_transport");
    nativeResult("ot_session_set_kitty_image_transport", this.opentui.symbols.ot_session_set_kitty_image_transport(pointer, handle, value));
  }
  sessionGetKittyImageTransport(context, session) {
    const layout = nativeLayouts.ot_session_kitty_image_transport;
    const handle = encodeContextHandle(context, session);
    const output = createContextRecord(layout);
    const pointer = this.nativeContextPointer(context, "ot_session_get_kitty_image_transport");
    nativeResult("ot_session_get_kitty_image_transport", this.opentui.symbols.ot_session_get_kitty_image_transport(pointer, handle, output));
    return {
      requested: output[layout.fields.requested.offset / 4],
      effective: output[layout.fields.effective.offset / 4],
      fileState: output[layout.fields.file_state.offset / 4],
      fallback: output[layout.fields.fallback.offset / 4],
      pendingFiles: output[layout.fields.pending_files.offset / 4],
      pendingBytes: output[layout.fields.pending_bytes.offset / 4]
    };
  }
  sessionPollKittyImageTransport(context, session, nowNs) {
    const now = toFFIU64(nowNs, "Session nowNs");
    const handle = encodeContextHandle(context, session);
    const output = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_session_poll_kitty_image_transport");
    nativeResult("ot_session_poll_kitty_image_transport", this.opentui.symbols.ot_session_poll_kitty_image_transport(pointer, handle, now, output));
    return output[0] !== 0;
  }
  sessionCancelKittyImageTransport(context, session, failed) {
    const handle = encodeContextHandle(context, session);
    const value = toFFIBool(failed, "Session Kitty image transport failed");
    const pointer = this.nativeContextPointer(context, "ot_session_cancel_kitty_image_transport");
    nativeResult("ot_session_cancel_kitty_image_transport", this.opentui.symbols.ot_session_cancel_kitty_image_transport(pointer, handle, value));
  }
  sessionProcessKittyImageReply(context, session, bytes) {
    const handle = encodeContextHandle(context, session);
    const input = sessionBytes(bytes, "Session Kitty image reply length");
    const output = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_session_process_kitty_image_reply");
    nativeResult("ot_session_process_kitty_image_reply", this.opentui.symbols.ot_session_process_kitty_image_reply(pointer, handle, viewOrNull(input), input.byteLength, output));
    return output[0];
  }
  sessionStartKittyFileProbe(context, session) {
    const handle = encodeContextHandle(context, session);
    const pointer = this.nativeContextPointer(context, "ot_session_start_kitty_file_probe");
    nativeResult("ot_session_start_kitty_file_probe", this.opentui.symbols.ot_session_start_kitty_file_probe(pointer, handle));
  }
  createContextBuffer(context, options) {
    const layout = nativeLayouts.ot_buffer_options;
    const widthMethod = widthMethodId(options.widthMethod ?? "unicode", "buffer");
    const record = createContextRecord(layout);
    record[layout.fields.width.offset / 4] = toSafeFFIU32Length(options.width, "Context buffer width");
    record[layout.fields.height.offset / 4] = toSafeFFIU32Length(options.height, "Context buffer height");
    record[layout.fields.width_method.offset / 4] = widthMethod;
    record[layout.fields.flags.offset / 4] = toFFIBool(options.respectAlpha ?? false, "Context buffer respectAlpha");
    const output = new Uint32Array(handleWords);
    const pointer = this.nativeContextPointer(context, "ot_buffer_create");
    nativeResult("ot_buffer_create", this.opentui.symbols.ot_buffer_create(pointer, record, output));
    return decodeContextHandle(context, output);
  }
  destroyContextBuffer(context, buffer) {
    const handle = encodeContextHandle(context, buffer);
    const pointer = this.nativeContextPointer(context, "ot_buffer_destroy");
    nativeResult("ot_buffer_destroy", this.opentui.symbols.ot_buffer_destroy(pointer, handle));
  }
  contextResizeBuffer(context, buffer, width, height) {
    const handle = encodeContextHandle(context, buffer);
    const columns = toSafeFFIU32Length(width, "Context buffer width");
    const rows = toSafeFFIU32Length(height, "Context buffer height");
    const pointer = this.nativeContextPointer(context, "ot_buffer_resize");
    nativeResult("ot_buffer_resize", this.opentui.symbols.ot_buffer_resize(pointer, handle, columns, rows));
  }
  contextDrawBuffer(drawing, options) {
    this.getYogaHost().assertMutable();
    const text = drawRecordText(options);
    const bottom = drawRecordBottomTitle(options);
    const scratch = this.bufferDrawRecord ?? createBufferDrawRecord();
    this.bufferDrawRecord = undefined;
    try {
      const { context, target, frame } = drawing;
      const handle = encodeContextHandle(context, target);
      const ticket = frame === null ? null : encodeSceneFrameRequest(context, frame);
      const { signed, colors } = scratch;
      const encoded = encodeBufferDrawRecord(context, options, scratch.words, signed, colors, 0, scratch.source);
      const record = scratch.records[encoded.operation];
      const source = encoded.source;
      const textBytes = this.drawTextBytes;
      const bottomBytes = this.drawBottomBytes;
      const textLength = encodeDrawText(text, textBytes);
      const bottomLength = encodeDrawText(bottom, bottomBytes);
      const pointer = this.nativeContextPointer(context, "ot_buffer_draw");
      nativeResult("ot_buffer_draw", this.opentui.symbols.ot_buffer_draw(pointer, handle, ticket, record, source, textLength === 0 ? this.emptyBytes : textBytes, textLength, bottomLength === 0 ? this.emptyBytes : bottomBytes, bottomLength));
    } finally {
      this.bufferDrawRecord ??= scratch;
    }
  }
  contextBufferStack({ context, target, frame }, options) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, target);
    const ticket = frame === null ? null : encodeSceneFrameRequest(context, frame);
    const operation = BUFFER_STACK_OPERATIONS.indexOf(options.operation);
    if (operation < 0)
      throw new TypeError("Invalid checked buffer stack operation");
    const x = toFFII32(options.x ?? 0, "Buffer scissor x");
    const y = toFFII32(options.y ?? 0, "Buffer scissor y");
    const width = toSafeFFIU32Length(options.width ?? 0, "Buffer scissor width");
    const height = toSafeFFIU32Length(options.height ?? 0, "Buffer scissor height");
    const opacity = options.opacity ?? 1;
    if (!Number.isFinite(opacity))
      throw new RangeError("Buffer opacity must be finite");
    const input = this.bufferStackInput;
    const output = this.bufferStackOutput;
    input[0] = Math.max(0, Math.min(1, opacity));
    output[0] = 0;
    const pointer = this.nativeContextPointer(context, "ot_buffer_stack");
    nativeResult("ot_buffer_stack", this.opentui.symbols.ot_buffer_stack(pointer, handle, ticket, operation, x, y, width, height, input, output));
    return output[0];
  }
  contextDrawGrid({ context, target, frame }, options) {
    const layout = nativeLayouts.ot_buffer_grid_options;
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, target);
    const ticket = frame === null ? null : encodeSceneFrameRequest(context, frame);
    const { borderChars, borderFg, borderBg, columnOffsets, rowOffsets, drawInner, drawOuter } = options;
    if (borderChars.length !== 11)
      throw new RangeError("Border characters must contain 11 Unicode scalars");
    const [columns, rows] = [columnOffsets, rowOffsets].map((offsets) => new Int32Array(typedArrayAccessors.buffer.get.call(offsets), typedArrayAccessors.byteOffset.get.call(offsets), typedArrayAccessors.length.get.call(offsets)));
    const record = createContextRecord(layout);
    record[layout.fields.flags.offset / 4] = toFFIBool(drawInner, "Grid inner borders") | toFFIBool(drawOuter, "Grid outer borders") << 1;
    const colors = new Uint16Array(record.buffer);
    contextBufferColor(borderFg, colors, layout.fields.foreground.offset / 2);
    contextBufferColor(borderBg, colors, layout.fields.background.offset / 2);
    record.set(borderChars, layout.fields.border_chars.offset / 4);
    const columnCount = toSafeFFIU32Length(columns.length, "Grid column offsets");
    const rowCount = toSafeFFIU32Length(rows.length, "Grid row offsets");
    const pointer = this.nativeContextPointer(context, "ot_buffer_draw_grid");
    nativeResult("ot_buffer_draw_grid", this.opentui.symbols.ot_buffer_draw_grid(pointer, handle, ticket, record, columns, columnCount, rows, rowCount));
  }
  contextDrawPackedBuffer({ context, target, frame }, data, byteLength, x, y, width, height) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, target);
    const ticket = frame === null ? null : encodeSceneFrameRequest(context, frame);
    const length = toSafeFFIU32Length(byteLength, "Packed buffer byte count");
    const input = pixelInput(data, length);
    const cellX = toFFII32(x, "Packed buffer x");
    const cellY = toFFII32(y, "Packed buffer y");
    const cellWidth = toSafeFFIU32Length(width, "Packed buffer dimension");
    const cellHeight = toSafeFFIU32Length(height, "Packed buffer dimension");
    const pointer = this.nativeContextPointer(context, "ot_buffer_draw_packed");
    nativeResult("ot_buffer_draw_packed", this.opentui.symbols.ot_buffer_draw_packed(pointer, handle, ticket, input, length, cellX, cellY, cellWidth, cellHeight));
  }
  contextDrawSuperSampleBuffer({ context, target, frame }, data, byteLength, x, y, format, stride) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, target);
    const ticket = frame === null ? null : encodeSceneFrameRequest(context, frame);
    if (format !== "rgba8unorm" && format !== "bgra8unorm")
      throw new TypeError("Unknown pixel format");
    const length = toSafeFFIU32Length(byteLength, "Supersample buffer byte count");
    const input = pixelInput(data, length);
    const cellX = toFFII32(x, "Supersample buffer x");
    const cellY = toFFII32(y, "Supersample buffer y");
    const pixelFormat = format === "bgra8unorm" ? 0 : 1;
    const rowBytes = toSafeFFIU32Length(stride, "Supersample buffer dimension");
    const pointer = this.nativeContextPointer(context, "ot_buffer_draw_supersample");
    nativeResult("ot_buffer_draw_supersample", this.opentui.symbols.ot_buffer_draw_supersample(pointer, handle, ticket, input, length, cellX, cellY, pixelFormat, rowBytes));
  }
  contextDrawGrayscaleBuffer({ context, target, frame }, data, x, y, width, height, foreground, background, supersampled) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, target);
    const ticket = frame === null ? null : encodeSceneFrameRequest(context, frame);
    if (!(data instanceof Float32Array))
      throw new TypeError("Grayscale input must be a Float32Array");
    const input = new Float32Array(typedArrayAccessors.buffer.get.call(data), typedArrayAccessors.byteOffset.get.call(data), typedArrayAccessors.length.get.call(data));
    const count = toSafeFFIU32Length(input.length, "Grayscale sample count");
    toFFII32(x, "Grayscale x");
    toFFII32(y, "Grayscale y");
    const sourceWidth = toSafeFFIU32Length(width, "Grayscale source width");
    const sourceHeight = toSafeFFIU32Length(height, "Grayscale source height");
    const fg = foreground === null ? null : contextBufferColor(foreground);
    const bg = background === null ? null : contextBufferColor(background);
    const doubled = toFFIBool(supersampled, "Grayscale supersampling");
    const pointer = this.nativeContextPointer(context, "ot_buffer_draw_grayscale");
    nativeResult("ot_buffer_draw_grayscale", this.opentui.symbols.ot_buffer_draw_grayscale(pointer, handle, ticket, input, count, x, y, sourceWidth, sourceHeight, fg, bg, doubled));
  }
  contextColorMatrixBuffer({ context, target, frame }, matrix, mask, strength, channel) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, target);
    const ticket = frame === null ? null : encodeSceneFrameRequest(context, frame);
    const [transform, cells] = [matrix, mask].map((value) => {
      if (value === null)
        return null;
      if (!(value instanceof Float32Array))
        throw new TypeError("Color matrix input must be a Float32Array");
      return new Float32Array(typedArrayAccessors.buffer.get.call(value), typedArrayAccessors.byteOffset.get.call(value), typedArrayAccessors.length.get.call(value));
    });
    if (transform === null || transform.length !== 16)
      throw new RangeError("Color matrix must contain 16 floats");
    const count = toSafeFFIU32Length(cells?.length ?? 0, "Color matrix mask length");
    if (!Number.isFinite(strength))
      throw new RangeError("Color matrix strength must be finite");
    const targetChannel = toSafeFFIU32Length(channel, "Color matrix channel");
    const pointer = this.nativeContextPointer(context, "ot_buffer_color_matrix");
    nativeResult("ot_buffer_color_matrix", this.opentui.symbols.ot_buffer_color_matrix(pointer, handle, ticket, transform, transform.length, cells?.length === 0 ? transform : cells, count, new Float32Array([strength]), targetChannel));
  }
  contextAcquireBufferLease(context, buffer) {
    return this.acquireBufferLease(context, buffer);
  }
  createSession(context, options) {
    const layout = nativeLayouts.ot_session_options;
    const record = new BigUint64Array(layout.size / 8);
    const words = new Uint32Array(record.buffer);
    words[layout.fields.struct_size.offset / 4] = layout.size;
    words[layout.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
    words[layout.fields.chunk_size.offset / 4] = toSafeFFIU32Length(options.chunkSize, "Session chunkSize");
    words[layout.fields.span_capacity.offset / 4] = toSafeFFIU32Length(options.spanCapacity, "Session spanCapacity");
    record[layout.fields.max_bytes.offset / 8] = toFFIU64(options.maxBytes, "Session maxBytes");
    words[layout.fields.control_capacity.offset / 4] = toSafeFFIU32Length(options.controlCapacity ?? 0, "Session controlCapacity");
    const output = new Uint32Array(handleWords);
    const pointer = this.nativeContextPointer(context, "ot_session_create");
    nativeResult("ot_session_create", this.opentui.symbols.ot_session_create(pointer, record, output));
    return decodeContextHandle(context, output);
  }
  sessionGetWriteLimit(context, session) {
    const handle = encodeContextHandle(context, session);
    const output = new BigUint64Array(1);
    const pointer = this.nativeContextPointer(context, "ot_session_get_write_limit");
    nativeResult("ot_session_get_write_limit", this.opentui.symbols.ot_session_get_write_limit(pointer, handle, output));
    return output[0];
  }
  sessionWrite(context, session, bytes) {
    const handle = encodeContextHandle(context, session);
    const input = sessionBytes(bytes, "Session write length");
    const length = input.byteLength;
    const pointer = this.nativeContextPointer(context, "ot_session_write");
    const status = this.opentui.symbols.ot_session_write(pointer, handle, length === 0 ? null : input, length);
    if (status === -11 /* OutputBackpressure */ && length > this.sessionGetWriteLimit(context, session)) {
      throw new RangeError("Session write exceeds the atomic output limit");
    }
    nativeResult("ot_session_write", status);
  }
  sessionAttachRenderer(context, session, options) {
    const layout = nativeLayouts.ot_session_renderer_env_options;
    const handle = encodeContextHandle(context, session);
    const remote = options.remote;
    const record = createContextRecord(layout);
    record[layout.fields.width.offset / 4] = toSafeFFIU32Length(options.width, "Session renderer width");
    record[layout.fields.height.offset / 4] = toSafeFFIU32Length(options.height, "Session renderer height");
    record[layout.fields.remote_mode.offset / 4] = remote === undefined ? nativeConstants.OT_SESSION_REMOTE_AUTO : toFFIBool(remote, "Session renderer remote") ? nativeConstants.OT_SESSION_REMOTE_REMOTE : nativeConstants.OT_SESSION_REMOTE_LOCAL;
    const environment = options.environment ?? {};
    const bytes = new Uint8Array(nativeConstants.OT_SESSION_ENV_BYTES_MAX);
    const lengths = new DataView(bytes.buffer);
    let offset = 0;
    for (const key of Object.keys(environment)) {
      const value = environment[key];
      if (typeof value !== "string")
        throw new TypeError("Session environment values must be strings");
      if (key.length + value.length + 8 > bytes.length - offset) {
        throw new RangeError(`Session environment exceeds ${bytes.length} bytes`);
      }
      const keyBytes = this.encoder.encode(key);
      const valueBytes = this.encoder.encode(value);
      if (keyBytes.length + valueBytes.length + 8 > bytes.length - offset) {
        throw new RangeError(`Session environment exceeds ${bytes.length} bytes`);
      }
      lengths.setUint32(offset, keyBytes.length, true);
      lengths.setUint32(offset + 4, valueBytes.length, true);
      bytes.set(keyBytes, offset + 8);
      bytes.set(valueBytes, offset + 8 + keyBytes.length);
      offset += 8 + keyBytes.length + valueBytes.length;
      record[layout.fields.entry_count.offset / 4]++;
    }
    record[layout.fields.byte_count.offset / 4] = offset;
    const input = bytes.subarray(0, offset);
    const pointer = this.nativeContextPointer(context, "ot_session_attach_renderer_with_env");
    nativeResult("ot_session_attach_renderer_with_env", this.opentui.symbols.ot_session_attach_renderer_with_env(pointer, handle, record, input));
  }
  sessionResizeRenderer(context, session, width, height) {
    const handle = encodeContextHandle(context, session);
    const columns = toSafeFFIU32Length(width, "Session renderer width");
    const rows = toSafeFFIU32Length(height, "Session renderer height");
    const pointer = this.nativeContextPointer(context, "ot_session_resize_renderer");
    nativeResult("ot_session_resize_renderer", this.opentui.symbols.ot_session_resize_renderer(pointer, handle, columns, rows));
  }
  sessionSetDebugOverlay(context, session, enabled, corner) {
    const handle = encodeContextHandle(context, session);
    const active = toFFIBool(enabled, "Session debug overlay enabled");
    const position = toSafeFFIU32Length(corner, "Session debug overlay corner");
    const pointer = this.nativeContextPointer(context, "ot_session_set_debug_overlay");
    nativeResult("ot_session_set_debug_overlay", this.opentui.symbols.ot_session_set_debug_overlay(pointer, handle, active, position));
  }
  sessionUpdateStats(context, session, overallMs, fps, callbackMs) {
    const handle = encodeContextHandle(context, session);
    const framesPerSecond = toSafeFFIU32Length(fps, "Session frames per second");
    for (const value of [overallMs, callbackMs]) {
      if (!Number.isFinite(value) || value < 0)
        throw new RangeError("Session frame times must be finite nonnegative numbers");
    }
    const pointer = this.nativeContextPointer(context, "ot_session_update_stats");
    nativeResult("ot_session_update_stats", this.opentui.symbols.ot_session_update_stats(pointer, handle, overallMs, framesPerSecond, callbackMs));
  }
  sessionUpdateMemoryStats(context, session, heapUsed, heapTotal, arrayBuffers) {
    const handle = encodeContextHandle(context, session);
    const used = toSafeFFIU32Length(heapUsed, "Session heap used");
    const total = toSafeFFIU32Length(heapTotal, "Session heap total");
    const buffers = toSafeFFIU32Length(arrayBuffers, "Session array buffers");
    const pointer = this.nativeContextPointer(context, "ot_session_update_memory_stats");
    nativeResult("ot_session_update_memory_stats", this.opentui.symbols.ot_session_update_memory_stats(pointer, handle, used, total, buffers));
  }
  sessionDumpHitGrid(context, session) {
    const handle = encodeContextHandle(context, session);
    const pointer = this.nativeContextPointer(context, "ot_session_dump_hit_grid");
    nativeResult("ot_session_dump_hit_grid", this.opentui.symbols.ot_session_dump_hit_grid(pointer, handle));
  }
  sessionGetRendererState(context, session) {
    const layout = nativeLayouts.ot_session_renderer_state;
    const handle = encodeContextHandle(context, session);
    const output = new BigUint64Array(layout.size / 8);
    const words = new Uint32Array(output.buffer);
    words[layout.fields.struct_size.offset / 4] = layout.size;
    words[layout.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
    const pointer = this.nativeContextPointer(context, "ot_session_get_renderer_state");
    nativeResult("ot_session_get_renderer_state", this.opentui.symbols.ot_session_get_renderer_state(pointer, handle, output));
    return {
      width: words[layout.fields.width.offset / 4],
      height: words[layout.fields.height.offset / 4],
      frameCount: output[layout.fields.frame_count.offset / 8],
      framePending: words[layout.fields.frame_pending.offset / 4] !== 0
    };
  }
  sessionAcquireBufferLease(context, session, which) {
    if (which !== "current" && which !== "next")
      throw new TypeError("Session buffer must be current or next");
    return this.acquireBufferLease(context, session, which);
  }
  sessionGetLinkId(context, session, x, y) {
    const handle = encodeContextHandle(context, session);
    toFFII32(x, "Link x");
    toFFII32(y, "Link y");
    const output = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_session_get_link_id");
    nativeResult("ot_session_get_link_id", this.opentui.symbols.ot_session_get_link_id(pointer, handle, x, y, output));
    return output[0] ?? 0;
  }
  acquireBufferLease(context, target, which, frame) {
    const layout = nativeLayouts.ot_buffer_lease_snapshot;
    const handle = encodeContextHandle(context, target);
    const ticket = frame === undefined ? null : encodeSceneFrameRequest(context, frame);
    const output = new BigUint64Array(layout.size / 8);
    const words = new Uint32Array(output.buffer);
    const lease = new BigUint64Array(output.buffer, layout.fields.lease.offset, layout.fields.lease.size / 8);
    words[layout.fields.struct_size.offset / 4] = layout.size;
    words[layout.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
    const operation = ticket ? "ot_scene_frame_acquire_buffer_lease" : which === undefined ? "ot_buffer_acquire_lease" : "ot_session_acquire_buffer_lease";
    const pointer = this.nativeContextPointer(context, operation);
    nativeResult(operation, ticket ? this.opentui.symbols.ot_scene_frame_acquire_buffer_lease(pointer, handle, ticket, which === "current" ? 0 : 1, output) : which === undefined ? this.opentui.symbols.ot_buffer_acquire_lease(pointer, handle, output) : this.opentui.symbols.ot_session_acquire_buffer_lease(pointer, handle, which === "current" ? 0 : 1, output));
    try {
      return {
        handle: decodeContextHandle(context, lease),
        width: words[layout.fields.width.offset / 4],
        height: words[layout.fields.height.offset / 4],
        generation: output[layout.fields.generation.offset / 8],
        char: toPointer(output[layout.fields.char_ptr.offset / 8]),
        fg: toPointer(output[layout.fields.fg_ptr.offset / 8]),
        bg: toPointer(output[layout.fields.bg_ptr.offset / 8]),
        attributes: toPointer(output[layout.fields.attributes_ptr.offset / 8])
      };
    } catch (error) {
      this.opentui.symbols.ot_buffer_lease_release(pointer, lease);
      throw error;
    }
  }
  contextValidateBufferLease(context, lease) {
    const handle = encodeContextHandle(context, lease);
    const pointer = this.nativeContextPointer(context, "ot_buffer_lease_validate");
    nativeResult("ot_buffer_lease_validate", this.opentui.symbols.ot_buffer_lease_validate(pointer, handle));
  }
  contextReleaseBufferLease(context, lease) {
    const handle = encodeContextHandle(context, lease);
    const pointer = this.nativeContextPointer(context, "ot_buffer_lease_release");
    nativeResult("ot_buffer_lease_release", this.opentui.symbols.ot_buffer_lease_release(pointer, handle));
  }
  contextBufferLeaseGetRealCharSize(context, lease, addLineBreaks) {
    const handle = encodeContextHandle(context, lease);
    const lineBreaks = toFFIBool(addLineBreaks, "Buffer lease addLineBreaks");
    const output = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_buffer_lease_get_real_char_size");
    nativeResult("ot_buffer_lease_get_real_char_size", this.opentui.symbols.ot_buffer_lease_get_real_char_size(pointer, handle, lineBreaks, output));
    return output[0];
  }
  contextBufferLeaseWriteResolvedChars(context, lease, bytes, addLineBreaks, cellLengths) {
    const handle = encodeContextHandle(context, lease);
    const target = sessionBytes(bytes, "Buffer lease resolved character capacity");
    const capacity = target.byteLength;
    const lineBreaks = toFFIBool(addLineBreaks, "Buffer lease addLineBreaks");
    const lengths = cellLengths === undefined ? null : sessionBytes(cellLengths, "Buffer lease cell length capacity");
    const output = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_buffer_lease_write_resolved_chars");
    nativeResult("ot_buffer_lease_write_resolved_chars", this.opentui.symbols.ot_buffer_lease_write_resolved_chars(pointer, handle, capacity === 0 ? null : target, capacity, lineBreaks, lengths, lengths?.byteLength ?? 0, output));
    return output[0];
  }
  sessionSetupTerminal(context, session, options = {}) {
    const layout = nativeLayouts.ot_session_terminal_options;
    const handle = encodeContextHandle(context, session);
    const flag = (value, label, bit) => toFFIBool(value ?? true, `Session ${label}`) ? bit : 0;
    const flags = flag(options.useAlternateScreen, "useAlternateScreen", nativeConstants.OT_TERMINAL_ALTERNATE_SCREEN) | flag(options.mouse, "mouse", nativeConstants.OT_TERMINAL_MOUSE) | flag(options.mouseMovement, "mouseMovement", nativeConstants.OT_TERMINAL_MOUSE_MOVEMENT) | flag(options.clearOnClose, "clearOnClose", nativeConstants.OT_TERMINAL_CLEAR_ON_CLOSE);
    const record = createContextRecord(layout);
    record[layout.fields.flags.offset / 4] = flags;
    record[layout.fields.kitty_keyboard_flags.offset / 4] = toSafeFFIU32Length(options.kittyKeyboardFlags ?? 5, "Session kittyKeyboardFlags");
    const pointer = this.nativeContextPointer(context, "ot_session_setup_terminal");
    nativeResult("ot_session_setup_terminal", this.opentui.symbols.ot_session_setup_terminal(pointer, handle, record));
  }
  sessionSuspend(context, session) {
    const handle = encodeContextHandle(context, session);
    const pointer = this.nativeContextPointer(context, "ot_session_suspend");
    nativeResult("ot_session_suspend", this.opentui.symbols.ot_session_suspend(pointer, handle));
  }
  sessionResume(context, session) {
    const handle = encodeContextHandle(context, session);
    const pointer = this.nativeContextPointer(context, "ot_session_resume");
    nativeResult("ot_session_resume", this.opentui.symbols.ot_session_resume(pointer, handle));
  }
  sessionGetTerminalState(context, session) {
    const handle = encodeContextHandle(context, session);
    const output = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_session_get_terminal_state");
    nativeResult("ot_session_get_terminal_state", this.opentui.symbols.ot_session_get_terminal_state(pointer, handle, output));
    return output[0];
  }
  sessionPump(context, session, nowNs, workBudget) {
    const layout = nativeLayouts.ot_session_pump_result;
    const handle = encodeContextHandle(context, session);
    const now = toFFIU64(nowNs, "Session nowNs");
    const budget = toSafeFFIU32Length(workBudget, "Session workBudget");
    const output = new BigUint64Array(layout.size / 8);
    const words = new Uint32Array(output.buffer);
    words[layout.fields.struct_size.offset / 4] = layout.size;
    words[layout.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
    const pointer = this.nativeContextPointer(context, "ot_session_pump");
    nativeResult("ot_session_pump", this.opentui.symbols.ot_session_pump(pointer, handle, now, budget, output));
    const status = words[layout.fields.status.offset / 4];
    return {
      status,
      deadlineNs: status === 3 /* WaitUntil */ ? output[layout.fields.deadline_ns.offset / 8] : null
    };
  }
  sessionPumpExit(context, session) {
    const handle = encodeContextHandle(context, session);
    const output = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_session_pump_exit");
    nativeResult("ot_session_pump_exit", this.opentui.symbols.ot_session_pump_exit(pointer, handle, output));
    return output[0];
  }
  terminalFlushInput() {
    nativeResult("ot_terminal_flush_input", this.opentui.symbols.ot_terminal_flush_input());
  }
  sessionControl(context, session, command) {
    const layout = nativeLayouts.ot_session_control_options;
    const handle = encodeContextHandle(context, session);
    const record = createContextRecord(layout);
    const kind = layout.fields.kind.offset / 4;
    let bytes = null;
    switch (command.kind) {
      case "capability-response":
        record[kind] = nativeConstants.OT_CONTROL_CAPABILITY_RESPONSE;
        bytes = sessionBytes(command.bytes, "Session capability response length");
        break;
      case "palette-query":
        record[kind] = nativeConstants.OT_CONTROL_PALETTE_QUERY;
        bytes = sessionBytes(command.bytes, "Session palette query length");
        break;
      case "title": {
        record[kind] = nativeConstants.OT_CONTROL_TITLE;
        const title = command.title;
        if (typeof title !== "string")
          throw new TypeError("Session title must be a string");
        if (title.length > NATIVE_SESSION_CONTROL_PACKET_BYTES2 - "\x1B]0;\x07".length) {
          throw new NativeError2("ot_session_control", -1 /* InvalidArgument */);
        }
        bytes = this.encoder.encode(title);
        break;
      }
      case "mouse": {
        record[kind] = nativeConstants.OT_CONTROL_MOUSE;
        const mode = command.mode;
        if (mode !== "disabled" && mode !== "drag" && mode !== "motion") {
          throw new TypeError("Session mouse mode must be disabled, drag, or motion");
        }
        record[layout.fields.argument.offset / 4] = mode === "disabled" ? 0 : mode === "drag" ? 1 : 2;
        break;
      }
      case "kitty-keyboard-flags":
        record[kind] = nativeConstants.OT_CONTROL_KITTY_KEYBOARD_FLAGS;
        record[layout.fields.argument.offset / 4] = toSafeFFIU32Length(command.flags, "Session Kitty keyboard flags");
        break;
      case "program-status":
        record[kind] = nativeConstants.OT_CONTROL_PROGRAM_STATUS;
        bytes = programStatusPayload(command.status, this.encoder);
        break;
      case "restore-modes":
        record[kind] = nativeConstants.OT_CONTROL_RESTORE_MODES;
        break;
      case "query-pixel-resolution":
        record[kind] = nativeConstants.OT_CONTROL_QUERY_PIXEL_RESOLUTION;
        break;
      case "query-theme-colors":
        record[kind] = nativeConstants.OT_CONTROL_QUERY_THEME_COLORS;
        break;
      case "reset-background":
        record[kind] = nativeConstants.OT_CONTROL_RESET_BACKGROUND;
        break;
      default:
        throw new TypeError("Unknown Session control kind");
    }
    const length = bytes?.byteLength ?? 0;
    const pointer = this.nativeContextPointer(context, "ot_session_control");
    nativeResult("ot_session_control", this.opentui.symbols.ot_session_control(pointer, handle, record, length === 0 ? null : bytes, length));
  }
  sessionClipboard(context, session, target, bytes) {
    const handle = encodeContextHandle(context, session);
    const selection = toSafeFFIU32Length(target, "Session clipboard target");
    const input = sessionBytes(bytes, "Session clipboard byte count");
    const out = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_session_clipboard");
    nativeResult("ot_session_clipboard", this.opentui.symbols.ot_session_clipboard(pointer, handle, selection, input, input.byteLength, out));
    return out[0] !== 0;
  }
  sessionNotification(context, session, message, title) {
    const handle = encodeContextHandle(context, session);
    if (typeof message !== "string" || title !== undefined && typeof title !== "string") {
      throw new TypeError("Notification message and title must be strings");
    }
    const limit = NATIVE_SESSION_CONTROL_PACKET_BYTES2 + 1;
    const body = this.encoder.encode(message.slice(0, limit));
    const heading = title === undefined ? null : this.encoder.encode(title.slice(0, limit));
    const output = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_session_notification");
    nativeResult("ot_session_notification", this.opentui.symbols.ot_session_notification(pointer, handle, body, body.byteLength, heading, heading?.byteLength ?? 0, output));
    return output[0] !== 0;
  }
  sessionSetPaletteState(context, session, palette, foreground, background, epoch) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, session);
    const count = toSafeFFIU32Length(palette.length, "Session palette length");
    if (count > 256)
      throw new RangeError("Session palette cannot exceed 256 colors");
    const input = new Uint16Array(count * 4);
    for (let index = 0;index < count; index++)
      contextBufferColor(palette[index], input, index * 4);
    const fg = contextBufferColor(foreground);
    const bg = contextBufferColor(background);
    const revision = toSafeFFIU32Length(epoch, "Session palette epoch");
    const pointer = this.nativeContextPointer(context, "ot_session_set_palette_state");
    nativeResult("ot_session_set_palette_state", this.opentui.symbols.ot_session_set_palette_state(pointer, handle, input, count, fg, bg, revision));
  }
  sessionSetCursor(context, session, options) {
    const layout = nativeLayouts.ot_session_cursor_update;
    const handle = encodeContextHandle(context, session);
    const { position, style, blinking, color, cursor } = options;
    const bytes = new Uint8Array(layout.size);
    const words = new Int32Array(bytes.buffer);
    if (position !== undefined) {
      const { x, y, visible } = position;
      for (const coordinate of [x, y]) {
        if (!Number.isFinite(coordinate) || coordinate < -2147483648 || coordinate > 2147483647) {
          throw new RangeError("Session cursor coordinates must fit signed 32-bit cells");
        }
      }
      words[layout.fields.fields.offset / 4] |= nativeConstants.OT_CURSOR_POSITION;
      words[layout.fields.x.offset / 4] = x;
      words[layout.fields.y.offset / 4] = y;
      bytes[layout.fields.visible.offset] = toFFIBool(visible, "Session cursor visibility");
    }
    if (style != null) {
      const id = CURSOR_STYLE_TO_ID[style];
      if (typeof id !== "number")
        throw new TypeError("Unknown cursor style");
      words[layout.fields.fields.offset / 4] |= nativeConstants.OT_CURSOR_STYLE;
      bytes[layout.fields.style.offset] = id;
    }
    if (blinking != null) {
      words[layout.fields.fields.offset / 4] |= nativeConstants.OT_CURSOR_BLINKING;
      bytes[layout.fields.blinking.offset] = toFFIBool(blinking, "Session cursor blinking");
    }
    if (color != null) {
      const source = rgbaBuffer(color);
      if (source.length !== 4)
        throw new RangeError("Session cursor color must have four packed RGBA lanes");
      words[layout.fields.fields.offset / 4] |= nativeConstants.OT_CURSOR_COLOR;
      new Uint16Array(bytes.buffer, layout.fields.color.offset, layout.fields.color.size / 2).set(source);
    }
    if (cursor != null) {
      const id = MOUSE_STYLE_TO_ID[cursor];
      if (typeof id !== "number")
        throw new TypeError("Unknown mouse pointer style");
      words[layout.fields.fields.offset / 4] |= nativeConstants.OT_CURSOR_MOUSE_POINTER;
      bytes[layout.fields.mouse_pointer.offset] = id;
    }
    const record = new Uint32Array(nativeLayouts.ot_session_control_options.size / 4);
    record[nativeLayouts.ot_session_control_options.fields.struct_size.offset / 4] = nativeLayouts.ot_session_control_options.size;
    record[nativeLayouts.ot_session_control_options.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
    record[nativeLayouts.ot_session_control_options.fields.kind.offset / 4] = nativeConstants.OT_CONTROL_CURSOR;
    const pointer = this.nativeContextPointer(context, "ot_session_control");
    nativeResult("ot_session_control", this.opentui.symbols.ot_session_control(pointer, handle, record, bytes, bytes.byteLength));
  }
  sessionGetCapabilities(context, session) {
    const layout = nativeLayouts.ot_session_capabilities;
    const handle = encodeContextHandle(context, session);
    const output = createContextRecord(layout);
    const pointer = this.nativeContextPointer(context, "ot_session_get_capabilities");
    nativeResult("ot_session_get_capabilities", this.opentui.symbols.ot_session_get_capabilities(pointer, handle, output));
    const flags = output[layout.fields.flags.offset / 4];
    const flag = (bit) => (flags & bit) !== 0;
    const bytes = new Uint8Array(output.buffer);
    return {
      kitty_keyboard: flag(nativeConstants.OT_CAP_KITTY_KEYBOARD),
      kitty_graphics: flag(nativeConstants.OT_CAP_KITTY_GRAPHICS),
      rgb: flag(nativeConstants.OT_CAP_RGB),
      ansi256: flag(nativeConstants.OT_CAP_ANSI256),
      sgr_pixels: flag(nativeConstants.OT_CAP_SGR_PIXELS),
      color_scheme_updates: flag(nativeConstants.OT_CAP_COLOR_SCHEME_UPDATES),
      explicit_width: flag(nativeConstants.OT_CAP_EXPLICIT_WIDTH),
      scaled_text: flag(nativeConstants.OT_CAP_SCALED_TEXT),
      sixel: flag(nativeConstants.OT_CAP_SIXEL),
      focus_tracking: flag(nativeConstants.OT_CAP_FOCUS_TRACKING),
      sync: flag(nativeConstants.OT_CAP_SYNC),
      bracketed_paste: flag(nativeConstants.OT_CAP_BRACKETED_PASTE),
      hyperlinks: flag(nativeConstants.OT_CAP_HYPERLINKS),
      osc52: flag(nativeConstants.OT_CAP_OSC52),
      notifications: flag(nativeConstants.OT_CAP_NOTIFICATIONS),
      explicit_cursor_positioning: flag(nativeConstants.OT_CAP_EXPLICIT_CURSOR_POSITIONING),
      remote: flag(nativeConstants.OT_CAP_REMOTE),
      program_status: flag(nativeConstants.OT_CAP_PROGRAM_STATUS),
      unicode: widthMethodFromCode(output[layout.fields.width_method.offset / 4]),
      multiplexer: ["none", "tmux", "zellij", "screen", "unknown"][output[layout.fields.multiplexer.offset / 4]],
      image_protocol: ["auto", "kitty", "sixel", "blocks"][output[layout.fields.image_protocol.offset / 4]],
      osc52_support: ["unknown", "supported", "unsupported"][output[layout.fields.osc52_support.offset / 4]],
      kittyKeyboardFlags: output[layout.fields.kitty_keyboard_flags.offset / 4],
      terminal: {
        name: this.decoder.decode(bytes.subarray(layout.fields.term_name.offset, layout.fields.term_name.offset + output[layout.fields.term_name_len.offset / 4])),
        version: this.decoder.decode(bytes.subarray(layout.fields.term_version.offset, layout.fields.term_version.offset + output[layout.fields.term_version_len.offset / 4])),
        from_xtversion: output[layout.fields.term_from_xtversion.offset / 4] !== 0
      }
    };
  }
  sessionReadOutput(context, session, bytes) {
    const layout = nativeLayouts.ot_output_ticket;
    const handle = encodeContextHandle(context, session);
    const target = sessionBytes(bytes, "Session output capacity");
    const capacity = target.byteLength;
    const output = new BigUint64Array(layout.size / 8);
    const pointer = this.nativeContextPointer(context, "ot_session_read_output");
    nativeResult("ot_session_read_output", this.opentui.symbols.ot_session_read_output(pointer, handle, capacity === 0 ? null : target, capacity, output));
    const byteCount = new Uint32Array(output.buffer)[layout.fields.byte_count.offset / 4];
    return byteCount === 0 ? null : {
      session: decodeContextHandle(context, new BigUint64Array(output.buffer, layout.fields.session.offset, nativeLayouts.ot_handle.size / 8)),
      requestId: output[layout.fields.request_id.offset / 8],
      byteCount
    };
  }
  sessionDrainStdout(context, session, maxBytes = 65536) {
    const handle = encodeContextHandle(context, session);
    const limit = toSafeFFIU32Length(maxBytes, "Stdout byte limit");
    const output = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_session_drain_stdout");
    nativeResult("ot_session_drain_stdout", this.opentui.symbols.ot_session_drain_stdout(pointer, handle, limit, output));
    return output[0];
  }
  sessionCompleteOutput(context, session, ticket, success) {
    const layout = nativeLayouts.ot_output_ticket;
    const written = toFFIBool(success, "Session output success");
    const record = new BigUint64Array(layout.size / 8);
    encodeContextHandle(context, ticket.session, new BigUint64Array(record.buffer, layout.fields.session.offset, nativeLayouts.ot_handle.size / 8));
    record[layout.fields.request_id.offset / 8] = toFFIU64(ticket.requestId, "Output requestId");
    new Uint32Array(record.buffer)[layout.fields.byte_count.offset / 4] = toSafeFFIU32Length(ticket.byteCount, "Output byteCount");
    const handle = encodeContextHandle(context, session);
    const pointer = this.nativeContextPointer(context, "ot_session_complete_output");
    nativeResult("ot_session_complete_output", this.opentui.symbols.ot_session_complete_output(pointer, handle, record, written));
  }
  sessionClose(context, session) {
    const handle = encodeContextHandle(context, session);
    nativeResult("ot_session_close", this.opentui.symbols.ot_session_close(this.nativeContextPointer(context, "ot_session_close"), handle));
  }
  sessionCancel(context, session) {
    const handle = encodeContextHandle(context, session);
    nativeResult("ot_session_cancel", this.opentui.symbols.ot_session_cancel(this.nativeContextPointer(context, "ot_session_cancel"), handle));
  }
  sessionGetState(context, session) {
    const handle = encodeContextHandle(context, session);
    const output = new Uint32Array(1);
    nativeResult("ot_session_get_state", this.opentui.symbols.ot_session_get_state(this.nativeContextPointer(context, "ot_session_get_state"), handle, output));
    return output[0];
  }
  destroySession(context, session) {
    this.destroyContextObject(context, session, "ot_session_destroy");
    const registrations = this.sceneMeasures.get(context)?.nodes;
    if (!registrations)
      return;
    for (const [slot, entry] of registrations) {
      try {
        this.sceneHasMeasure(context, entry.handle);
      } catch (error) {
        if (!(error instanceof NativeError2) || error.status !== -9 /* StaleHandle */)
          throw error;
        registrations.delete(slot);
      }
    }
  }
  sceneCreateNode(context, session, kind, num) {
    this.getYogaHost().assertMutable();
    const scratch = this.sceneCreateRecord ?? createSceneNodeRecord();
    this.sceneCreateRecord = undefined;
    try {
      const handle = encodeContextHandle(context, session, scratch.handle.record, scratch.handle.words);
      const tag = SCENE_NODE_KINDS.indexOf(kind);
      if (tag < 0)
        throw new TypeError("Unknown scene node kind");
      const number = toSafeFFIU32Length(num, "Scene node number");
      const output = scratch.target.record;
      const pointer = this.nativeContextPointer(context, "ot_scene_create_node");
      nativeResult("ot_scene_create_node", this.opentui.symbols.ot_scene_create_node(pointer, handle, tag, number, output));
      try {
        return decodeContextHandle(context, output, scratch.target.words);
      } catch (error) {
        const live = this.nativeContexts.get(context);
        if (live !== undefined)
          this.opentui.symbols.ot_scene_destroy_node(live, output);
        throw error;
      }
    } finally {
      this.sceneCreateRecord ??= scratch;
    }
  }
  sceneDestroyNode(context, node) {
    this.getYogaHost().assertMutable();
    const scratch = this.sceneDestroyHandle ?? createContextHandleRecord();
    this.sceneDestroyHandle = undefined;
    try {
      const handle = encodeContextHandle(context, node, scratch.record, scratch.words);
      const slot = scratch.words[nativeLayouts.ot_handle.fields.slot.offset / 4];
      const pointer = this.nativeContextPointer(context, "ot_scene_destroy_node");
      nativeResult("ot_scene_destroy_node", this.opentui.symbols.ot_scene_destroy_node(pointer, handle));
      this.sceneMeasures.get(context)?.nodes.delete(slot);
    } finally {
      this.sceneDestroyHandle ??= scratch;
    }
  }
  sceneSetMeasure(context, node, measure) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, node);
    const identity = decodeContextHandle(context, handle);
    const pointer = this.nativeContextPointer(context, "ot_scene_set_measure");
    let registration = this.sceneMeasures.get(context);
    const existing = registration !== undefined;
    if (measure && !registration) {
      const nodes = new Map;
      const callback = this.opentui.createCallback((contextId, slot, generation, width, widthMode, height, heightMode, output) => {
        this.getYogaHost().invokeCallback(() => {
          const entry = nodes.get(slot);
          if (!entry || entry.handle.contextId !== contextId || entry.handle.generation !== generation) {
            throw new Error("Native scene returned a stale measurement handle");
          }
          const result = entry.measure(width, widthMode, height, heightMode);
          rejectAsyncCallback(result);
          const dimensions = new Float32Array([result?.width ?? NaN, result?.height ?? NaN]);
          new Float32Array(toArrayBuffer(output, 0, 8)).set(dimensions);
        });
      }, nativeCallbacks.ot_scene_measure_callback);
      if (!callback.ptr) {
        callback.close();
        throw new Error("Failed to create native scene measurement callback");
      }
      registration = { callback, nodes };
      this.sceneMeasures.set(context, registration);
    }
    try {
      nativeResult("ot_scene_set_measure", this.opentui.symbols.ot_scene_set_measure(pointer, handle, measure ? registration.callback.ptr : null));
    } catch (error) {
      if (!existing && registration) {
        registration.callback.close();
        this.sceneMeasures.delete(context);
      }
      throw error;
    }
    if (measure) {
      registration.nodes.set(identity.slot, { handle: identity, measure });
    } else
      registration?.nodes.delete(identity.slot);
  }
  sceneHasMeasure(context, node) {
    const handle = encodeContextHandle(context, node);
    const output = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_scene_has_measure");
    nativeResult("ot_scene_has_measure", this.opentui.symbols.ot_scene_has_measure(pointer, handle, output));
    return output[0] !== 0;
  }
  sceneMarkDirty(context, node) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, node);
    const pointer = this.nativeContextPointer(context, "ot_scene_mark_dirty");
    nativeResult("ot_scene_mark_dirty", this.opentui.symbols.ot_scene_mark_dirty(pointer, handle));
  }
  sceneMoveNode(context, node, parent, index) {
    this.getYogaHost().assertMutable();
    const scratch = this.sceneMoveRecord ?? createSceneNodeRecord();
    this.sceneMoveRecord = undefined;
    try {
      const handle = encodeContextHandle(context, node, scratch.handle.record, scratch.handle.words);
      const destination = parent === null ? null : encodeContextHandle(context, parent, scratch.target.record, scratch.target.words);
      const childIndex = toSafeFFIU32Length(index, "Scene child index");
      const pointer = this.nativeContextPointer(context, "ot_scene_move_node");
      const status = this.opentui.symbols.ot_scene_move_node(pointer, handle, destination, childIndex);
      if (status === -16 /* ObjectLimit */)
        throw new NativeError2("ot_scene_move_node", status, "Scene nesting depth exceeds the native limit");
      nativeResult("ot_scene_move_node", status);
    } finally {
      this.sceneMoveRecord ??= scratch;
    }
  }
  sceneSetViewport(context, node, viewport) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, node);
    const target = viewport === null ? null : encodeContextHandle(context, viewport);
    const pointer = this.nativeContextPointer(context, "ot_scene_set_viewport");
    nativeResult("ot_scene_set_viewport", this.opentui.symbols.ot_scene_set_viewport(pointer, handle, target));
  }
  sceneSetFocus(context, node, focused) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, node);
    const value = toFFIBool(focused, "Scene focused");
    const pointer = this.nativeContextPointer(context, "ot_scene_set_focus");
    nativeResult("ot_scene_set_focus", this.opentui.symbols.ot_scene_set_focus(pointer, handle, value));
  }
  sceneGetStyle(context, node, group, kind, edge) {
    const layout = nativeLayouts.ot_scene_style_value;
    const handle = encodeContextHandle(context, node);
    const styleGroup = toSafeFFIU32Length(group, "Scene style group");
    const styleKind = toSafeFFIU32Length(kind, "Scene style kind");
    const styleEdge = toSafeFFIU32Length(edge, "Scene style edge");
    const output = createContextRecord(layout);
    const values = new Float32Array(output.buffer);
    const pointer = this.nativeContextPointer(context, "ot_scene_get_style");
    nativeResult("ot_scene_get_style", this.opentui.symbols.ot_scene_get_style(pointer, handle, styleGroup, styleKind, styleEdge, output));
    return { unit: output[layout.fields.unit.offset / 4], value: values[layout.fields.value.offset / 4] };
  }
  sceneSetBoxDetails(context, node, details) {
    const layout = nativeLayouts.ot_scene_box_details;
    const handle = encodeContextHandle(context, node);
    const record = createContextRecord(layout);
    const alignments = ["left", "center", "right"];
    const topAlignment = alignments.indexOf(details.titleAlignment);
    const bottomAlignment = alignments.indexOf(details.bottomTitleAlignment);
    if (topAlignment < 0 || bottomAlignment < 0)
      throw new TypeError("Unknown Box title alignment");
    record[layout.fields.title_alignment.offset / 4] = topAlignment;
    record[layout.fields.bottom_title_alignment.offset / 4] = bottomAlignment;
    const color = details.titleColor;
    if (color !== undefined) {
      record[layout.fields.flags.offset / 4] |= 1;
      new Uint16Array(record.buffer, layout.fields.title_color.offset, layout.fields.title_color.size / 2).set(contextBufferColor(color));
    }
    const chars = details.customBorderChars;
    if (chars !== undefined) {
      if (!(chars instanceof Uint32Array) || chars.length !== 11)
        throw new TypeError("Box borders require 11 scalars");
      record[layout.fields.flags.offset / 4] |= 2;
      record.set(chars, layout.fields.border_characters.offset / 4);
    }
    const title = details.title ?? "";
    const bottomTitle = details.bottomTitle ?? "";
    if (typeof title !== "string" || typeof bottomTitle !== "string")
      throw new TypeError("Box titles must be strings");
    const topLength = encodeDrawText(title, this.drawTextBytes);
    const bottomLength = encodeDrawText(bottomTitle, this.drawBottomBytes);
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_scene_set_box_details");
      nativeResult("ot_scene_set_box_details", this.opentui.symbols.ot_scene_set_box_details(pointer, handle, record, topLength === 0 ? null : this.drawTextBytes, topLength, bottomLength === 0 ? null : this.drawBottomBytes, bottomLength));
    });
  }
  sceneSetSurface(context, node, buffer) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, node);
    const source = buffer === null ? null : encodeContextHandle(context, buffer);
    const pointer = this.nativeContextPointer(context, "ot_scene_set_surface");
    nativeResult("ot_scene_set_surface", this.opentui.symbols.ot_scene_set_surface(pointer, handle, source));
  }
  sceneFlush(context, staging) {
    const operation = "ot_scene_flush";
    const count = staging.count;
    if (count === 0)
      return;
    const applied = this.sceneFlushApplied ?? new Uint32Array(1);
    this.getYogaHost().runMutation(() => {
      const views = staging._views(context);
      this.sceneFlushApplied = undefined;
      applied[0] = 0;
      let status;
      let rejected = 0;
      try {
        const pointer = this.nativeContextPointer(context, operation);
        status = this.opentui.symbols.ot_scene_flush(pointer, views, staging.byteLength, applied);
        if (sceneRecordRejections.has(status) && applied[0] < count)
          rejected = 1;
      } finally {
        this.sceneFlushApplied ??= applied;
        staging.consume(applied[0] + rejected);
      }
      if (status !== 0 /* Ok */) {
        const error = new NativeError2(operation, status);
        error.message += ` after ${applied[0]} of ${count} staged entries`;
        throw error;
      }
    });
  }
  sceneSetText(context, node, bytes) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, node);
    const input = sessionBytes(bytes, "Scene text length");
    const length = input.byteLength;
    const pointer = this.nativeContextPointer(context, "ot_scene_set_text");
    nativeResult("ot_scene_set_text", this.opentui.symbols.ot_scene_set_text(pointer, handle, length === 0 ? null : input, length));
  }
  sceneSetStyledText(context, node, content) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, node);
    const { bytes, records, count, urlBytes } = this.encodeStyledText(content);
    const pointer = this.nativeContextPointer(context, "ot_scene_set_styled_text");
    nativeResult("ot_scene_set_styled_text", this.opentui.symbols.ot_scene_set_styled_text(pointer, handle, viewOrNull(bytes), bytes.length, count === 0 ? null : records, count, viewOrNull(urlBytes), urlBytes.length));
  }
  encodeStyledText(content, allowLinks = true, preserveChunkOrdinals = false) {
    if (typeof content !== "object" || content === null || isStyledText2(content) !== true) {
      throw new TypeError("Native scene text requires a string or branded StyledText");
    }
    const chunks = content.chunks;
    if (!Array.isArray(chunks))
      throw new TypeError("Native scene StyledText requires a chunk array");
    const count = toSafeFFIU32Length(chunks.length, "Scene styled chunk count");
    const layout = nativeLayouts.ot_styled_text_chunk;
    const stride = layout.size / 4;
    const records = new Uint32Array(count * stride);
    const colors = new Uint16Array(records.buffer);
    const parts = [];
    const urls = [];
    let byteCount = 0;
    let urlByteCount = 0;
    for (let index = 0;index < count; index++) {
      const chunk = chunks[index];
      if (typeof chunk !== "object" || chunk === null)
        throw new TypeError("Invalid native scene StyledText chunk");
      const { __isChunk, text, fg, bg, attributes, link } = chunk;
      if (__isChunk !== true || typeof text !== "string")
        throw new TypeError("Invalid native scene StyledText chunk");
      const foreground = fg === undefined ? undefined : contextBufferColor(fg);
      const background = bg === undefined ? undefined : contextBufferColor(bg);
      const attrs = attributes === undefined ? 0 : toSafeFFIU32Length(attributes, "Scene styled chunk attributes");
      if (attrs > ATTRIBUTE_BASE_MASK2)
        throw new RangeError("Native scene StyledText supports only base attributes");
      let urlBytes;
      if (link !== undefined) {
        if (!allowLinks)
          throw new TypeError("Native editor placeholder does not support links");
        if (typeof link !== "object" || link === null)
          throw new TypeError("Invalid native scene StyledText link");
        const url = link.url;
        if (typeof url !== "string")
          throw new TypeError("Native scene StyledText link requires a URL string");
        urlBytes = this.encoder.encode(url);
      }
      const bytes = this.encoder.encode(text);
      if (bytes.length === 0 && !preserveChunkOrdinals)
        continue;
      byteCount = toSafeFFIU32Length(byteCount + bytes.length, "Scene styled text length");
      const offset = parts.length * stride;
      records[offset + layout.fields.struct_size.offset / 4] = layout.size;
      records[offset + layout.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
      records[offset + layout.fields.byte_count.offset / 4] = bytes.length;
      records[offset + layout.fields.flags.offset / 4] = (foreground ? 1 : 0) | (background ? 2 : 0) | (urlBytes ? 4 : 0);
      if (foreground)
        colors.set(foreground, offset * 2 + layout.fields.foreground.offset / 2);
      if (background)
        colors.set(background, offset * 2 + layout.fields.background.offset / 2);
      records[offset + layout.fields.attributes.offset / 4] = attrs;
      if (urlBytes) {
        records[offset + layout.fields.link_offset.offset / 4] = urlByteCount;
        records[offset + layout.fields.link_byte_count.offset / 4] = urlBytes.length;
        urlByteCount = toSafeFFIU32Length(urlByteCount + urlBytes.length, "Scene styled URL length");
        urls.push(urlBytes);
      }
      parts.push(bytes);
    }
    const bytes = new Uint8Array(byteCount);
    let offset = 0;
    for (const part of parts) {
      bytes.set(part, offset);
      offset += part.length;
    }
    const urlBytes = new Uint8Array(urlByteCount);
    offset = 0;
    for (const url of urls) {
      urlBytes.set(url, offset);
      offset += url.length;
    }
    return { bytes, records, count: parts.length, urlBytes };
  }
  sceneSetSlider(context, node, options) {
    const layout = nativeLayouts.ot_scene_slider_options;
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, node);
    const record = new Uint32Array(layout.size / 4);
    const values = new Float64Array(record.buffer);
    const colors = new Uint16Array(record.buffer);
    if (options.orientation !== "horizontal" && options.orientation !== "vertical") {
      throw new TypeError("Unknown scene slider orientation");
    }
    record[layout.fields.struct_size.offset / 4] = layout.size;
    record[layout.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
    record[layout.fields.orientation.offset / 4] = options.orientation === "vertical" ? 1 : 0;
    for (const [field, value] of [
      ["min", options.min],
      ["max", options.max],
      ["value", options.value],
      ["viewport_size", options.viewPortSize]
    ]) {
      if (!Number.isFinite(value))
        throw new RangeError("Scene slider values must be finite numbers");
      values[layout.fields[field].offset / 8] = value;
    }
    contextBufferColor(options.foregroundColor, colors, layout.fields.foreground.offset / 2);
    contextBufferColor(options.backgroundColor, colors, layout.fields.background.offset / 2);
    const pointer = this.nativeContextPointer(context, "ot_scene_set_slider");
    nativeResult("ot_scene_set_slider", this.opentui.symbols.ot_scene_set_slider(pointer, handle, record));
  }
  sceneGetSliderThumb(context, node) {
    const layout = nativeLayouts.ot_scene_slider_thumb;
    const handle = encodeContextHandle(context, node);
    const output = createContextRecord(layout);
    const values = new Float64Array(output.buffer);
    const pointer = this.nativeContextPointer(context, "ot_scene_get_slider_thumb");
    nativeResult("ot_scene_get_slider_thumb", this.opentui.symbols.ot_scene_get_slider_thumb(pointer, handle, output));
    return { size: values[layout.fields.size.offset / 8], start: values[layout.fields.start.offset / 8] };
  }
  sceneSetArrow(context, node, options) {
    const layout = nativeLayouts.ot_scene_arrow_options;
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, node);
    const direction = SCENE_ARROW_DIRECTIONS.indexOf(options.direction);
    if (direction < 0)
      throw new TypeError("Unknown scene arrow direction");
    const record = createContextRecord(layout);
    record[layout.fields.direction.offset / 4] = direction;
    record[layout.fields.attributes.offset / 4] = toSafeFFIU32Length(options.attributes, "Scene arrow attributes");
    const colors = new Uint16Array(record.buffer);
    contextBufferColor(options.foregroundColor, colors, layout.fields.foreground.offset / 2);
    contextBufferColor(options.backgroundColor, colors, layout.fields.background.offset / 2);
    const text = options.text;
    if (text !== undefined && typeof text !== "string")
      throw new TypeError("Scene arrow text must be a string");
    const bytes = text === undefined ? null : sessionBytes(this.encoder.encode(text), "Scene arrow text length");
    if (bytes && bytes.length > NATIVE_BUFFER_TEXT_BYTES_MAX2)
      throw new RangeError("Scene arrow text is too long");
    const pointer = this.nativeContextPointer(context, "ot_scene_set_arrow");
    nativeResult("ot_scene_set_arrow", this.opentui.symbols.ot_scene_set_arrow(pointer, handle, record, bytes?.length === 0 ? new Uint8Array(1) : bytes, bytes?.length ?? 0));
  }
  sceneSetTextOptions(context, node, options) {
    const layout = nativeLayouts.ot_scene_text_options;
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, node);
    const record = new Uint32Array(layout.size / 4);
    const offsets = new Float64Array(record.buffer);
    record[layout.fields.struct_size.offset / 4] = layout.size;
    record[layout.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
    const colors = new Uint16Array(record.buffer);
    contextBufferColor(options.fg, colors, layout.fields.foreground.offset / 2);
    contextBufferColor(options.bg, colors, layout.fields.background.offset / 2);
    record[layout.fields.attributes.offset / 4] = toSafeFFIU32Length(options.attributes, "Scene text attributes");
    const wrapMode = SCENE_TEXT_WRAP_MODES.indexOf(options.wrapMode);
    if (wrapMode < 0)
      throw new TypeError("Unknown scene text wrap mode");
    record[layout.fields.wrap_mode.offset / 4] = wrapMode;
    const textAlign = SCENE_TEXT_ALIGNS.indexOf(options.textAlign);
    if (textAlign < 0)
      throw new TypeError("Unknown scene text alignment");
    record[layout.fields.text_align.offset / 4] = textAlign;
    record[layout.fields.truncate.offset / 4] = toFFIBool(options.truncate, "Scene text truncate");
    record[layout.fields.first_line_offset.offset / 4] = toSafeFFIU32Length(options.firstLineOffset, "Scene text firstLineOffset");
    for (const [field, value] of [
      ["scroll_x", options.scrollX],
      ["scroll_y", options.scrollY]
    ]) {
      if (!Number.isFinite(value) || value < 0 || value > 2147483647) {
        throw new RangeError("Scene text scroll offsets must be finite numbers in 0..2147483647");
      }
      offsets[layout.fields[field].offset / 8] = value;
    }
    const indicator = options.tabIndicator;
    record[layout.fields.tab_indicator.offset / 4] = toSafeFFIU32Length(typeof indicator === "string" ? indicator.codePointAt(0) ?? 0 : indicator ?? 0, "Scene text tab indicator");
    if (options.tabIndicatorColor !== undefined) {
      record[layout.fields.tab_color_set.offset / 4] = 1;
      contextBufferColor(options.tabIndicatorColor, colors, layout.fields.tab_color.offset / 2);
    }
    const pointer = this.nativeContextPointer(context, "ot_scene_set_text_options");
    nativeResult("ot_scene_set_text_options", this.opentui.symbols.ot_scene_set_text_options(pointer, handle, record));
  }
  sceneSetTextSelection(context, node, options) {
    const layout = nativeLayouts.ot_scene_text_selection_options;
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, node);
    const record = createContextRecord(layout);
    const operation = ["reset", "set", "update"].indexOf(options.operation);
    const behavior = ["cell", "word", "line"].indexOf(options.behavior);
    if (operation < 0 || behavior < 0)
      throw new TypeError("Unknown scene text selection operation or behavior");
    record[layout.fields.operation.offset / 4] = operation;
    record[layout.fields.behavior.offset / 4] = behavior;
    const coordinates = new Int32Array(record.buffer);
    for (const [field, value] of [
      ["anchor_x", options.anchorX],
      ["anchor_y", options.anchorY],
      ["focus_x", options.focusX],
      ["focus_y", options.focusY]
    ]) {
      if (!Number.isFinite(value) || value < -2147483648 || value > 2147483647) {
        throw new RangeError("Scene selection coordinates must fit signed 32-bit cells");
      }
      coordinates[layout.fields[field].offset / 4] = Math.trunc(value);
    }
    const colors = new Uint16Array(record.buffer);
    const bg = options.bg;
    const fg = options.fg;
    if (bg !== undefined) {
      record[layout.fields.flags.offset / 4] |= 1;
      contextBufferColor(bg, colors, layout.fields.background.offset / 2);
    }
    if (fg !== undefined) {
      record[layout.fields.flags.offset / 4] |= 2;
      contextBufferColor(fg, colors, layout.fields.foreground.offset / 2);
    }
    const changed = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_scene_set_text_selection");
    nativeResult("ot_scene_set_text_selection", this.opentui.symbols.ot_scene_set_text_selection(pointer, handle, record, changed));
    return changed[0] !== 0;
  }
  sceneGetTextSelection(context, node) {
    const handle = encodeContextHandle(context, node);
    const output = new BigUint64Array(1);
    const pointer = this.nativeContextPointer(context, "ot_scene_get_text_selection");
    nativeResult("ot_scene_get_text_selection", this.opentui.symbols.ot_scene_get_text_selection(pointer, handle, output));
    const packed = output[0];
    return packed === 0xffffffffffffffffn ? null : { start: Number(packed >> 32n), end: Number(packed & 0xffffffffn) };
  }
  sceneGetSelectedText(context, node) {
    const handle = encodeContextHandle(context, node);
    const pointer = this.nativeContextPointer(context, "ot_scene_get_selected_text");
    return this.readText("ot_scene_get_selected_text", (bytes, capacity, count) => this.opentui.symbols.ot_scene_get_selected_text(pointer, handle, bytes, capacity, count));
  }
  sceneGetTextMetrics(context, node) {
    return this.sceneTextMetrics(context, encodeContextHandle(context, node));
  }
  sceneTextMetrics(context, handle) {
    const layout = nativeLayouts.ot_scene_text_info;
    const output = createContextRecord(layout);
    const pointer = this.nativeContextPointer(context, "ot_scene_get_text_info");
    nativeResult("ot_scene_get_text_info", this.opentui.symbols.ot_scene_get_text_info(pointer, handle, output));
    return {
      byteLength: output[layout.fields.byte_count.offset / 4],
      textLength: output[layout.fields.text_length.offset / 4],
      lineCount: output[layout.fields.line_count.offset / 4],
      virtualLineCount: output[layout.fields.virtual_line_count.offset / 4],
      widthColsMax: output[layout.fields.width_cols_max.offset / 4]
    };
  }
  sceneGetText(context, node) {
    const handle = encodeContextHandle(context, node);
    return this.readText("ot_scene_get_text", (bytes, capacity, count) => this.opentui.symbols.ot_scene_get_text(this.nativeContextPointer(context, "ot_scene_get_text"), handle, bytes, capacity, count));
  }
  sceneGetTextLineInfo(context, node, firstLine = 0, lineCount = MAX_FFI_U32) {
    const handle = encodeContextHandle(context, node);
    const metrics = this.sceneTextMetrics(context, handle);
    const first = toSafeFFIU32Length(firstLine, "Text first line");
    const capacity = Math.min(toSafeFFIU32Length(lineCount, "Text line count"), Math.max(0, metrics.virtualLineCount - first));
    const lines = new Uint32Array(capacity * (nativeLayouts.ot_scene_text_line.size / 4));
    const count = new Uint32Array(1);
    nativeResult("ot_scene_get_text_lines", this.opentui.symbols.ot_scene_get_text_lines(this.nativeContextPointer(context, "ot_scene_get_text_lines"), handle, first, capacity === 0 ? null : lines, capacity, count));
    if (count[0] !== metrics.virtualLineCount)
      throw new NativeError2("ot_scene_get_text_lines", -5 /* InternalError */);
    return decodeContextTextLines(lines, metrics.widthColsMax);
  }
  sceneGetLayout(context, node, observation = false) {
    const layout = nativeLayouts.ot_scene_layout;
    const scratch = this.sceneLayoutRecord ?? createSceneLayoutRecord();
    this.sceneLayoutRecord = undefined;
    try {
      const handle = encodeContextHandle(context, node, scratch.handle.record, scratch.handle.words);
      const mode = observation === "paint" ? nativeConstants.OT_LAYOUT_PAINT : toFFIBool(observation, "Scene Yoga layout observation") ? nativeConstants.OT_LAYOUT_YOGA : nativeConstants.OT_LAYOUT_PUBLIC;
      const { output, values, coordinates } = scratch;
      output[layout.fields.struct_size.offset / 4] = layout.size;
      output[layout.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
      const pointer = this.nativeContextPointer(context, "ot_scene_get_layout");
      nativeResult("ot_scene_get_layout", this.opentui.symbols.ot_scene_get_layout(pointer, handle, mode, output));
      return decodeSceneLayout(values, coordinates);
    } finally {
      this.sceneLayoutRecord ??= scratch;
    }
  }
  sceneSetHooks(context, node, flags, generation, initialWidth, initialHeight) {
    const layout = nativeLayouts.ot_scene_hooks;
    this.getYogaHost().assertMutable();
    const scratch = this.sceneHooksRecord ?? createSceneHooksRecord();
    this.sceneHooksRecord = undefined;
    try {
      const handle = encodeContextHandle(context, node, scratch.handle.record, scratch.handle.words);
      const { record, words, dimensions } = scratch;
      words[layout.fields.struct_size.offset / 4] = layout.size;
      words[layout.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
      words[layout.fields.flags.offset / 4] = toSafeFFIU32Length(flags, "Scene hook flags");
      record[layout.fields.generation.offset / 8] = toFFIU64(generation, "Scene hook generation");
      for (const [field, value] of [
        ["initial_width", initialWidth],
        ["initial_height", initialHeight]
      ]) {
        if (!Number.isFinite(value) || value < 0 || value > 2147483647) {
          throw new RangeError("Scene initial dimensions must be finite numbers in 0..2147483647");
        }
        dimensions[layout.fields[field].offset / 8] = value;
      }
      const pointer = this.nativeContextPointer(context, "ot_scene_set_hooks");
      nativeResult("ot_scene_set_hooks", this.opentui.symbols.ot_scene_set_hooks(pointer, handle, record));
    } finally {
      this.sceneHooksRecord ??= scratch;
    }
  }
  sceneFrameStep(context, session, previous, options, maxWorkItems, recording = null) {
    const layout = nativeLayouts.ot_scene_frame_options;
    this.getYogaHost().assertMutable();
    const scratch = this.sceneFrameRecord ?? createSceneFrameRecord();
    this.sceneFrameRecord = undefined;
    try {
      const handle = encodeContextHandle(context, session, scratch.handle.record, scratch.handle.words);
      const { config, colors, words, geometry } = scratch;
      contextBufferColor(options.background, colors, layout.fields.background.offset / 2);
      config[layout.fields.use_mouse.offset / 4] = toFFIBool(options.useMouse, "Scene useMouse");
      config[layout.fields.excluded_hit_num.offset / 4] = toSafeFFIU32Length(options.excludedHitNum, "Scene excluded hit number");
      config[layout.fields.max_layout_rounds.offset / 4] = toSafeFFIU32Length(options.maxLayoutRounds, "Scene layout round limit");
      config[layout.fields.max_host_requests.offset / 4] = toSafeFFIU32Length(options.maxHostRequests, "Scene host request limit");
      config[layout.fields.preserve_unwritten.offset / 4] = toFFIBool(options.preserveUnwritten ?? false, "Scene preserve unwritten cells");
      const workBudget = maxWorkItems === undefined ? 4294967295 : toSafeFFIU32Length(maxWorkItems, "Scene work budget");
      if (workBudget === 0)
        throw new RangeError("Scene work budget must be positive");
      const recordingLength = recording === null ? 0 : toSafeFFIU32Length(recording.byteLength, "Scene recording");
      const recordingView = recordingLength === 0 ? null : recording;
      const output = encodeSceneFrameRequest(context, previous, scratch);
      const operation = "ot_scene_frame_step_with_geometry";
      const measures = this.sceneMeasures.get(context)?.nodes.size;
      if (measures)
        this.getYogaHost().flushSceneMutations();
      const pointer = this.nativeContextPointer(context, operation);
      if (measures) {
        this.sceneFrameStepWithMeasures(context, pointer, handle, previous === null ? null : output, config, output, workBudget, recordingView, recordingLength, geometry);
      } else {
        nativeResult(operation, this.opentui.symbols.ot_scene_frame_step_with_geometry(pointer, handle, previous === null ? null : output, config, workBudget, recordingView, recordingLength, output, geometry));
      }
      try {
        const fields = nativeLayouts.ot_scene_frame_geometry.fields;
        const flags = geometry[fields.flags.offset / 4];
        return {
          session: decodeContextHandle(context, scratch.session.record, scratch.session.words),
          root: decodeContextHandle(context, scratch.root.record, scratch.root.words),
          node: decodeContextHandle(context, scratch.node.record, scratch.node.words),
          frameId: output[nativeLayouts.ot_scene_frame_request.fields.frame_id.offset / 8],
          requestId: output[nativeLayouts.ot_scene_frame_request.fields.request_id.offset / 8],
          layoutEpoch: output[nativeLayouts.ot_scene_frame_request.fields.layout_epoch.offset / 8],
          hookGeneration: output[nativeLayouts.ot_scene_frame_request.fields.hook_generation.offset / 8],
          kind: words[nativeLayouts.ot_scene_frame_request.fields.kind.offset / 4],
          num: words[nativeLayouts.ot_scene_frame_request.fields.num.offset / 4],
          width: words[nativeLayouts.ot_scene_frame_request.fields.width.offset / 4],
          height: words[nativeLayouts.ot_scene_frame_request.fields.height.offset / 4],
          paintLayout: flags & nativeConstants.OT_SCENE_GEOMETRY_PAINT ? decodeSceneLayout(scratch.geometryValues, scratch.geometryCoordinates, fields.paint.offset) : undefined,
          publicLayout: flags & nativeConstants.OT_SCENE_GEOMETRY_PUBLIC ? decodeSceneLayout(scratch.geometryValues, scratch.geometryCoordinates, fields.public_layout.offset) : undefined,
          geometryRevision: undefined
        };
      } catch (error) {
        const livePointer = this.nativeContexts.get(context);
        if (livePointer !== undefined)
          this.opentui.symbols.ot_scene_frame_cancel(livePointer, handle, output[nativeLayouts.ot_scene_frame_request.fields.frame_id.offset / 8]);
        throw error;
      }
    } finally {
      this.sceneFrameRecord ??= scratch;
    }
  }
  sceneFrameStepWithMeasures(context, pointer, handle, previous, config, output, workBudget, recording, recordingLength, geometry) {
    let accepted = false;
    try {
      this.getYogaHost().runMutation(() => {
        nativeResult("ot_scene_frame_step_with_geometry", this.opentui.symbols.ot_scene_frame_step_with_geometry(pointer, handle, previous, config, workBudget, recording, recordingLength, output, geometry));
        accepted = true;
      });
    } catch (error) {
      const livePointer = this.nativeContexts.get(context);
      if (accepted && livePointer !== undefined)
        this.opentui.symbols.ot_scene_frame_cancel(livePointer, handle, output[nativeLayouts.ot_scene_frame_request.fields.frame_id.offset / 8]);
      throw error;
    }
  }
  releaseAfterPaint(context, release) {
    const releases = releaseWindows.get(context);
    if (releases)
      releases.push(release);
    else
      release();
  }
  sceneFrameGetPaintSlots(context, session, frame) {
    const layout = nativeLayouts.ot_scene_paint_slot;
    const fields = layout.fields;
    const node = nativeLayouts.ot_handle.fields;
    const handle = encodeContextHandle(context, session);
    const ticket = encodeSceneFrameRequest(context, frame);
    const count = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_scene_frame_get_paint_slots");
    let scratch = this.scenePaintSlots;
    for (;; ) {
      const capacity = scratch.byteLength / layout.size;
      nativeResult("ot_scene_frame_get_paint_slots", this.opentui.symbols.ot_scene_frame_get_paint_slots(pointer, handle, ticket, scratch, capacity, count));
      if (count[0] <= capacity)
        break;
      scratch = this.scenePaintSlots = new BigUint64Array(count[0] * layout.size / 8);
    }
    const words = new Uint32Array(scratch.buffer);
    const values = new Float32Array(scratch.buffer);
    const coordinates = new Float64Array(scratch.buffer);
    const slots = new Array(count[0]);
    for (let index = 0;index < count[0]; index++) {
      const base = index * layout.size;
      const flags = words[(base + fields.flags.offset) / 4];
      slots[index] = {
        node: {
          context,
          contextId: scratch[(base + fields.node.offset + node.context_id.offset) / 8],
          slot: words[(base + fields.node.offset + node.slot.offset) / 4],
          generation: words[(base + fields.node.offset + node.generation.offset) / 4]
        },
        num: words[(base + fields.num.offset) / 4],
        hooks: words[(base + fields.hooks.offset) / 4],
        opacity: values[(base + fields.opacity.offset) / 4],
        paintLayout: decodeSceneLayout(values, coordinates, base + fields.paint.offset),
        publicLayout: flags & nativeConstants.OT_SCENE_GEOMETRY_PUBLIC ? decodeSceneLayout(values, coordinates, base + fields.public_layout.offset) : undefined
      };
    }
    return slots;
  }
  sceneFrameAcquireBufferLease(context, session, frame, which) {
    this.getYogaHost().assertMutable();
    if (which !== "current" && which !== "next")
      throw new TypeError("Session buffer must be current or next");
    if (!frame)
      throw new TypeError("Scene frame ticket is required");
    return this.acquireBufferLease(context, session, which, frame);
  }
  sceneFrameCommit(context, session, frame, force) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, session);
    const ticket = encodeSceneFrameRequest(context, frame);
    const forceRender = toFFIBool(force, "Scene frame commit force");
    const output = new Uint32Array(1);
    const pointer = this.nativeContextPointer(context, "ot_scene_frame_commit");
    nativeResult("ot_scene_frame_commit", this.opentui.symbols.ot_scene_frame_commit(pointer, handle, ticket, forceRender, output));
    return output[0];
  }
  sceneFrameCancel(context, session, frameId) {
    this.getYogaHost().assertMutable();
    const handle = encodeContextHandle(context, session);
    const id = toFFIU64(frameId, "Scene frame ID");
    const pointer = this.nativeContextPointer(context, "ot_scene_frame_cancel");
    nativeResult("ot_scene_frame_cancel", this.opentui.symbols.ot_scene_frame_cancel(pointer, handle, id));
  }
  sceneHitTest(context, session, x, y) {
    const handle = encodeContextHandle(context, session);
    toFFII32(x, "Scene hit x");
    toFFII32(y, "Scene hit y");
    const output = this.hitTestOutput;
    const pointer = this.nativeContextPointer(context, "ot_scene_hit_test");
    nativeResult("ot_scene_hit_test", this.opentui.symbols.ot_scene_hit_test(pointer, handle, x, y, output));
    return output[0];
  }
  sceneGetStats(context, session) {
    const layout = nativeLayouts.ot_scene_stats;
    const handle = encodeContextHandle(context, session);
    const output = new BigUint64Array(layout.size / 8);
    const words = new Uint32Array(output.buffer);
    const times = new Float64Array(output.buffer);
    words[layout.fields.struct_size.offset / 4] = layout.size;
    words[layout.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
    const pointer = this.nativeContextPointer(context, "ot_scene_get_stats");
    nativeResult("ot_scene_get_stats", this.opentui.symbols.ot_scene_get_stats(pointer, handle, output));
    return {
      nativeLastFrameTime: times[layout.fields.last_frame_time.offset / 8],
      nativeAverageFrameTime: times[layout.fields.average_frame_time.offset / 8],
      nativeFrameCount: toNumber(output[layout.fields.frame_count.offset / 8]),
      cellsUpdated: words[layout.fields.cells_updated.offset / 4],
      averageCellsUpdated: words[layout.fields.average_cells_updated.offset / 4],
      nativeRenderTime: words[layout.fields.render_time_valid.offset / 4] !== 0 ? times[layout.fields.render_time.offset / 8] : undefined,
      nativeStdoutWriteTime: words[layout.fields.stdout_write_time_valid.offset / 4] !== 0 ? times[layout.fields.stdout_write_time.offset / 8] : undefined
    };
  }
  sceneGetCursorState(context, session) {
    const layout = nativeLayouts.ot_scene_cursor_state;
    const handle = encodeContextHandle(context, session);
    const output = new Uint32Array(layout.size / 4);
    const colors = new Float32Array(output.buffer);
    output[layout.fields.struct_size.offset / 4] = layout.size;
    output[layout.fields.abi_version.offset / 4] = nativeConstants.OT_CONTEXT_ABI_VERSION;
    const pointer = this.nativeContextPointer(context, "ot_scene_get_cursor_state");
    nativeResult("ot_scene_get_cursor_state", this.opentui.symbols.ot_scene_get_cursor_state(pointer, handle, output));
    return {
      x: output[layout.fields.x.offset / 4],
      y: output[layout.fields.y.offset / 4],
      visible: output[layout.fields.visible.offset / 4] !== 0,
      style: CURSOR_ID_TO_STYLE[output[layout.fields.style.offset / 4]] ?? "block",
      blinking: output[layout.fields.blinking.offset / 4] !== 0,
      color: RGBA2.fromValues(colors[layout.fields.r.offset / 4], colors[layout.fields.g.offset / 4], colors[layout.fields.b.offset / 4], colors[layout.fields.a.offset / 4])
    };
  }
  constructor(libPath) {
    this.opentui = getOpenTUILib(libPath);
    this.imageRetainIccCache();
    this.iccCacheClient = true;
    try {
      this.setupLogging();
    } catch (error) {
      this.dispose();
      throw error;
    }
  }
  logContextDiagnostics(context, maxLevel = 3 /* Debug */) {
    const layout = nativeLayouts.ot_diagnostic;
    const fields = nativeLayouts.ot_diagnostic_drain.fields;
    const { records, output, words } = this.diagnosticDrain ??= createDiagnosticDrainRecord();
    let pointer = this.nativeContextPointer(context, "ot_context_drain_diagnostics");
    for (let batch = 0;pointer !== undefined && batch < DIAGNOSTIC_QUEUE_MAX / DIAGNOSTIC_BATCH; batch++) {
      nativeResult("ot_context_drain_diagnostics", this.opentui.symbols.ot_context_drain_diagnostics(pointer, records, DIAGNOSTIC_BATCH, output));
      const count = words[fields.count.offset / 4];
      if (count > DIAGNOSTIC_BATCH)
        throw new RangeError("Invalid diagnostic count");
      if (count === 0)
        return;
      const messages = [];
      for (let index = 0;index < count; index++) {
        const offset = index * layout.size;
        const level = records[(offset + layout.fields.level.offset) / 4];
        const length = records[(offset + layout.fields.message_len.offset) / 4];
        if (length > layout.fields.message.size)
          throw new RangeError("Invalid diagnostic message length");
        if (level > maxLevel)
          continue;
        const bytes = new Uint8Array(records.buffer, offset + layout.fields.message.offset, length);
        messages.push([level, this.decoder.decode(bytes)]);
      }
      const remaining = words[fields.remaining.offset / 4];
      for (const [level, message] of messages)
        this.logMessage(level, message);
      pointer = remaining === 0 ? undefined : this.nativeContexts.get(context);
    }
  }
  logMessage(level, message) {
    console[LOG_METHODS[level] ?? "log"](message);
  }
  setupLogging() {
    if (isWorkerRuntime)
      return;
    const logCallback = this.opentui.createCallback((level, msgPtr, msgLen) => {
      try {
        if (msgLen === 0 || !msgPtr) {
          return;
        }
        const msgBuffer = toArrayBuffer(msgPtr, 0, msgLen);
        const msgBytes = new Uint8Array(msgBuffer);
        const message = this.decoder.decode(msgBytes);
        this.logMessage(level, message);
      } catch (error) {
        console.error("Error in Zig log callback:", error);
      }
    }, {
      args: ["u8", "ptr", "u32"],
      returns: "void"
    });
    this.logCallbackWrapper = logCallback;
    if (!logCallback.ptr) {
      throw new Error("Failed to create log callback");
    }
    this.setLogCallback(logCallback.ptr);
    processLogLibraries.push(this);
  }
  setLogCallback(callbackPtr) {
    this.opentui.symbols.setLogCallback(callbackPtr);
  }
  releaseProcessLog() {
    const index = processLogLibraries.indexOf(this);
    if (index < 0)
      return;
    processLogLibraries.splice(index, 1);
    if (index < processLogLibraries.length)
      return;
    this.setLogCallback(processLogLibraries.at(-1)?.logCallbackWrapper?.ptr ?? null);
  }
  dispose() {
    if (this.disposed)
      return;
    if (this.clipboardServices.size > 0) {
      throw new Error("Cannot dispose OpenTUI native library while clipboard services are active");
    }
    if (this.nativeContexts.size !== this.audioEngines.size + Number(this.editMeasureContext !== undefined)) {
      throw new NativeError2("dispose", -6 /* ContextBusy */);
    }
    this.yogaHost?.dispose();
    if (this.editMeasureContext)
      this.releaseContext(this.editMeasureContext);
    this.editMeasureContext = undefined;
    for (const [engine, context] of this.audioEngines) {
      this.releaseContext(context);
      this.audioEngines.delete(engine);
    }
    this.disposed = true;
    try {
      this.releaseProcessLog();
    } finally {
      try {
        if (this.iccCacheClient) {
          this.iccCacheClient = false;
          this.imageReleaseIccCache();
        }
      } finally {
        try {
          this.opentui.close();
        } finally {
          this.logCallbackWrapper = null;
          this.nativeSpanFeedCallbackWrapper = null;
          this.nativeSpanFeedHandlers.clear();
        }
      }
    }
  }
  ensureNativeSpanFeedCallback() {
    if (this.nativeSpanFeedCallbackWrapper) {
      return this.nativeSpanFeedCallbackWrapper;
    }
    const callback = this.opentui.createCallback((streamPtr, eventId, arg0, arg1) => {
      const handler = this.nativeSpanFeedHandlers.get(streamPtr);
      if (handler) {
        handler(eventId, arg0, arg1);
      }
    }, {
      args: ["ptr", "u32", "ptr", "u64"],
      returns: "void"
    });
    this.nativeSpanFeedCallbackWrapper = callback;
    if (!callback.ptr) {
      throw new Error("Failed to create native span feed callback");
    }
    return callback;
  }
  clipboardServiceCreate(maxConcurrentOperations, maxProviderTransfers, waylandSeat) {
    const seat = waylandSeat === undefined ? null : this.encoder.encode(waylandSeat);
    const operations = toSafeFFIU32Length(maxConcurrentOperations, "clipboard operation limit");
    const transfers = toSafeFFIU32Length(maxProviderTransfers, "clipboard provider transfer limit");
    if (operations === 0 || transfers === 0)
      return null;
    const service = nextStandaloneHandle();
    const context = this.tryCreateStandaloneContext(Math.min(operations + 1, 65535));
    if (!context)
      return null;
    try {
      const pointer = this.nativeContextPointer(context, "ot_clipboard_service_create");
      if (this.opentui.symbols.ot_clipboard_service_create(pointer, operations, transfers, seat, seat?.byteLength ?? 0) !== 0) {
        this.releaseContext(context);
        return null;
      }
      this.clipboardServices.set(service, context);
      return service;
    } catch (error) {
      this.releaseContext(context);
      throw error;
    }
  }
  clipboardContext(service) {
    const context = this.clipboardServices.get(service);
    return context ? this.nativeContextPointer(context, "clipboard") : null;
  }
  clipboardOperationArgs(operation) {
    const value = this.clipboardOperations.get(operation);
    return value ? [this.clipboardContext(value.service), value.handle] : [null, this.invalidStandaloneHandle];
  }
  clipboardServiceBeginShutdown(service) {
    return this.opentui.symbols.ot_clipboard_service_begin_shutdown(this.clipboardContext(service));
  }
  clipboardServicePollShutdown(service) {
    return this.opentui.symbols.ot_clipboard_service_poll_shutdown(this.clipboardContext(service));
  }
  clipboardServiceDestroy(service) {
    const context = this.clipboardServices.get(service);
    if (!context)
      return NativeClipboardDestroyStatus2.InvalidHandle;
    const status = this.opentui.symbols.ot_clipboard_service_destroy(this.clipboardContext(service));
    if (status === NativeClipboardDestroyStatus2.Destroyed) {
      this.releaseContext(context);
      this.clipboardServices.delete(service);
      for (const [id, operation] of this.clipboardOperations) {
        if (operation.service === service)
          this.clipboardOperations.delete(id);
      }
    }
    return status;
  }
  clipboardServiceDrain(service) {
    return this.opentui.symbols.ot_clipboard_service_drain(this.clipboardContext(service));
  }
  clipboardStart(service, start, args) {
    if (!this.clipboardServices.has(service))
      return { status: NativeClipboardStartStatus2.InvalidService, operation: null };
    const operation = nextStandaloneHandle();
    const handle = new BigUint64Array(nativeLayouts.ot_handle.size / 8);
    this.clipboardOperations.set(operation, { service, handle });
    let retained = false;
    try {
      const status = start(this.clipboardContext(service), ...args, handle);
      retained = status === NativeClipboardStartStatus2.Ok;
      return { status, operation: retained ? operation : null };
    } finally {
      if (!retained)
        this.clipboardOperations.delete(operation);
    }
  }
  clipboardReadOperationStart(service, request, selection, maxBytes, maxImagePixels, maxConversionBytes, timeoutMs) {
    return this.clipboardStart(service, this.opentui.symbols.ot_clipboard_read_operation_start, [
      request,
      toSafeFFIU32Length(request.byteLength, "clipboard read request"),
      selection,
      toSafeFFIU32Length(maxBytes, "clipboard read byte limit"),
      toSafeFFIU32Length(maxImagePixels, "clipboard image pixel limit"),
      toSafeFFIU32Length(maxConversionBytes, "clipboard conversion byte limit"),
      toSafeFFIU32Length(timeoutMs, "clipboard read timeout")
    ]);
  }
  clipboardWriteOperationStart(service, textUtf8, selection, timeoutMs) {
    return this.clipboardStart(service, this.opentui.symbols.ot_clipboard_write_operation_start, [
      textUtf8,
      toSafeFFIU32Length(textUtf8.byteLength, "clipboard write text"),
      selection,
      toSafeFFIU32Length(timeoutMs, "clipboard write timeout")
    ]);
  }
  clipboardClearOperationStart(service, selection, timeoutMs) {
    return this.clipboardStart(service, this.opentui.symbols.ot_clipboard_clear_operation_start, [
      selection,
      toSafeFFIU32Length(timeoutMs, "clipboard clear timeout")
    ]);
  }
  clipboardOperationPoll(operation) {
    return this.opentui.symbols.ot_clipboard_operation_poll(...this.clipboardOperationArgs(operation));
  }
  clipboardOperationCancel(operation) {
    return this.opentui.symbols.ot_clipboard_operation_cancel(...this.clipboardOperationArgs(operation));
  }
  clipboardResultLength(symbol, operation) {
    const output = new Uint32Array(1);
    const status = symbol(...this.clipboardOperationArgs(operation), output);
    return { status, length: output[0] };
  }
  clipboardOperationResultMimeLength(operation) {
    return this.clipboardResultLength(this.opentui.symbols.ot_clipboard_operation_result_mime_length, operation);
  }
  clipboardOperationResultMimeCopy(operation, output) {
    const capacity = toSafeFFIU32Length(output.byteLength, "clipboard MIME output");
    return this.opentui.symbols.ot_clipboard_operation_result_mime_copy(...this.clipboardOperationArgs(operation), output, capacity);
  }
  clipboardOperationResultDataLength(operation) {
    return this.clipboardResultLength(this.opentui.symbols.ot_clipboard_operation_result_data_length, operation);
  }
  clipboardOperationResultDataCopy(operation, output) {
    const capacity = toSafeFFIU32Length(output.byteLength, "clipboard data output");
    return this.opentui.symbols.ot_clipboard_operation_result_data_copy(...this.clipboardOperationArgs(operation), output, capacity);
  }
  clipboardOperationResultErrorCode(operation) {
    const output = new Uint32Array(1);
    const status = this.opentui.symbols.ot_clipboard_operation_result_error_code(...this.clipboardOperationArgs(operation), output);
    return { status, errorCode: output[0] };
  }
  clipboardOperationResultDiagnosticLength(operation) {
    return this.clipboardResultLength(this.opentui.symbols.ot_clipboard_operation_result_diagnostic_length, operation);
  }
  clipboardOperationResultDiagnosticCopy(operation, output) {
    const capacity = toSafeFFIU32Length(output.byteLength, "clipboard diagnostic output");
    return this.opentui.symbols.ot_clipboard_operation_result_diagnostic_copy(...this.clipboardOperationArgs(operation), output, capacity);
  }
  clipboardOperationDestroy(operation) {
    const status = this.opentui.symbols.ot_clipboard_operation_destroy(...this.clipboardOperationArgs(operation));
    if (status === NativeClipboardDestroyStatus2.Destroyed)
      this.clipboardOperations.delete(operation);
    return status;
  }
  getYogaHost() {
    if (this.disposed)
      throw new Error("OpenTUI native library is disposed");
    return this.yogaHost ??= new YogaHost(this);
  }
  yogaMutation(call, ...args) {
    return this.getYogaHost().runMutation(() => call(...args));
  }
  yogaChecked(operation, mutation, ...args) {
    const call = () => {
      const signature = yogaSymbols[operation].args;
      for (let index = 0;index < signature.length; index++) {
        if (signature[index] !== "u32")
          continue;
        const value = args[index];
        if (typeof value !== "number" || !Number.isInteger(value) || value < 0 || value > 4294967295) {
          throw new YogaError2(operation, 1 /* InvalidArgument */);
        }
      }
      const status = this.opentui.symbols[operation](...args);
      if (status !== 0 /* Ok */)
        throw new YogaError2(operation, status);
    };
    if (mutation)
      this.getYogaHost().runMutation(call);
    else
      call();
  }
  yogaConfigCreate() {
    this.yogaChecked("yogaConfigCreateChecked", true, this.yogaU64);
    return toPointer(this.yogaU64[0]);
  }
  yogaConfigFree(config) {
    this.yogaChecked("yogaConfigFreeChecked", true, config);
  }
  yogaConfigSetCallbacks(config, measure, dirtied) {
    return Boolean(this.yogaMutation(this.opentui.symbols.yogaConfigSetCallbacks, config, measure, dirtied));
  }
  yogaConfigClearCallbacks(config, measure) {
    return Boolean(this.yogaMutation(this.opentui.symbols.yogaConfigClearCallbacks, config, measure));
  }
  yogaConfigSetUseWebDefaults(config, enabled) {
    this.yogaChecked("yogaConfigSetUseWebDefaultsChecked", true, config, ffiBool(enabled));
  }
  yogaConfigGetUseWebDefaults(config) {
    return Boolean(this.opentui.symbols.yogaConfigGetUseWebDefaults(config));
  }
  yogaConfigSetPointScaleFactor(config, pointScaleFactor) {
    this.yogaChecked("yogaConfigSetPointScaleFactorChecked", true, config, pointScaleFactor);
  }
  yogaConfigGetPointScaleFactor(config) {
    return this.opentui.symbols.yogaConfigGetPointScaleFactor(config);
  }
  yogaConfigSetErrata(config, errata) {
    this.yogaChecked("yogaConfigSetErrataChecked", true, config, errata);
  }
  yogaConfigGetErrata(config) {
    return this.opentui.symbols.yogaConfigGetErrata(config);
  }
  yogaConfigSetExperimentalFeatureEnabled(config, feature, enabled) {
    this.yogaChecked("yogaConfigSetExperimentalFeatureEnabledChecked", true, config, feature, ffiBool(enabled));
  }
  yogaConfigIsExperimentalFeatureEnabled(config, feature) {
    this.yogaChecked("yogaConfigIsExperimentalFeatureEnabledChecked", false, config, feature, this.yogaU32);
    return this.yogaU32[0] !== 0;
  }
  yogaNodeCreateForOpenTUI() {
    this.yogaChecked("yogaNodeCreateForOpenTUIChecked", true, this.yogaU64);
    return toPointer(this.yogaU64[0]);
  }
  yogaNodeCreateWithConfig(config) {
    this.yogaChecked("yogaNodeCreateWithConfigChecked", true, config, this.yogaU64);
    return toPointer(this.yogaU64[0]);
  }
  yogaNodeGetConfig(node) {
    const config = this.opentui.symbols.yogaNodeGetConfig(node);
    if (!config)
      throw new Error("Failed to get Yoga node config");
    return config;
  }
  yogaNodeFree(node) {
    this.yogaChecked("yogaNodeFreeChecked", true, node);
  }
  yogaNodeFreeRecursive(node) {
    this.yogaChecked("yogaNodeFreeRecursiveChecked", true, node);
  }
  yogaNodeReset(node) {
    this.yogaChecked("yogaNodeResetChecked", true, node);
  }
  yogaNodeCopyStyle(dstNode, srcNode) {
    this.yogaChecked("yogaNodeCopyStyleChecked", true, dstNode, srcNode);
  }
  yogaNodeInsertChild(node, child, index) {
    this.yogaChecked("yogaNodeInsertChildChecked", true, node, child, index);
  }
  yogaNodeRemoveChild(node, child) {
    this.yogaChecked("yogaNodeRemoveChildChecked", true, node, child);
  }
  yogaNodeRemoveAllChildren(node) {
    this.yogaChecked("yogaNodeRemoveAllChildrenChecked", true, node);
  }
  yogaNodeGetChild(node, index) {
    this.yogaChecked("yogaNodeGetChildChecked", false, node, index, this.yogaU64);
    return this.yogaU64[0] ? toPointer(this.yogaU64[0]) : null;
  }
  yogaNodeGetChildCount(node) {
    return this.opentui.symbols.yogaNodeGetChildCount(node);
  }
  yogaNodeGetParent(node) {
    return this.opentui.symbols.yogaNodeGetParent(node) || null;
  }
  yogaNodeCalculateLayout(node, width, height, direction) {
    this.getYogaHost().flushSceneMutations();
    this.yogaChecked("yogaNodeCalculateLayoutChecked", true, node, width, height, direction);
  }
  yogaNodeIsDirty(node) {
    this.yogaChecked("yogaNodeIsDirtyChecked", false, node, this.yogaU32);
    return this.yogaU32[0] !== 0;
  }
  yogaNodeMarkDirty(node) {
    this.yogaChecked("yogaNodeMarkDirtyChecked", true, node);
  }
  yogaNodeGetHasNewLayout(node) {
    this.yogaChecked("yogaNodeGetHasNewLayoutChecked", false, node, this.yogaU32);
    return this.yogaU32[0] !== 0;
  }
  yogaNodeSetHasNewLayout(node, hasNewLayout) {
    this.yogaChecked("yogaNodeSetHasNewLayoutChecked", true, node, ffiBool(hasNewLayout));
  }
  yogaNodeSetIsReferenceBaseline(node, isReferenceBaseline) {
    this.yogaChecked("yogaNodeSetIsReferenceBaselineChecked", true, node, ffiBool(isReferenceBaseline));
  }
  yogaNodeIsReferenceBaseline(node) {
    this.yogaChecked("yogaNodeIsReferenceBaselineChecked", false, node, this.yogaU32);
    return this.yogaU32[0] !== 0;
  }
  yogaNodeSetAlwaysFormsContainingBlock(node, alwaysFormsContainingBlock) {
    this.yogaChecked("yogaNodeSetAlwaysFormsContainingBlockChecked", true, node, ffiBool(alwaysFormsContainingBlock));
  }
  yogaNodeGetAlwaysFormsContainingBlock(node) {
    this.yogaChecked("yogaNodeGetAlwaysFormsContainingBlockChecked", false, node, this.yogaU32);
    return this.yogaU32[0] !== 0;
  }
  yogaNodeGetComputedLayout(node) {
    const layout = this.yogaLayout;
    this.yogaChecked("yogaNodeGetComputedLayoutChecked", false, node, layout);
    return {
      left: layout[0],
      top: layout[1],
      right: layout[2],
      bottom: layout[3],
      width: layout[4],
      height: layout[5]
    };
  }
  yogaNodeLayoutGetEdge(node, kind, edge) {
    this.yogaChecked("yogaNodeLayoutGetEdgeChecked", false, node, kind, edge, this.yogaF32);
    return this.yogaF32[0];
  }
  yogaNodeStyleSetEnum(node, kind, value) {
    this.yogaChecked("yogaNodeStyleSetEnumChecked", true, node, kind, value);
  }
  yogaNodeStyleGetEnum(node, kind) {
    this.yogaChecked("yogaNodeStyleGetEnumChecked", false, node, kind, this.yogaU32);
    return this.yogaU32[0];
  }
  yogaNodeStyleSetFloat(node, kind, value) {
    this.yogaChecked("yogaNodeStyleSetFloatChecked", true, node, kind, value);
  }
  yogaNodeStyleGetFloat(node, kind) {
    this.yogaChecked("yogaNodeStyleGetFloatChecked", false, node, kind, this.yogaF32);
    return this.yogaF32[0];
  }
  yogaNodeStyleSetBorder(node, edge, border) {
    this.yogaChecked("yogaNodeStyleSetBorderChecked", true, node, edge, border);
  }
  yogaNodeStyleGetBorder(node, edge) {
    this.yogaChecked("yogaNodeStyleGetBorderChecked", false, node, edge, this.yogaF32);
    return this.yogaF32[0];
  }
  yogaNodeStyleSetValue(node, kind, edgeOrGutter, unit, value) {
    this.yogaChecked("yogaNodeStyleSetValueChecked", true, node, kind, edgeOrGutter, unit, value);
  }
  yogaNodeStyleGetValue(node, kind, edgeOrGutter) {
    this.yogaChecked("yogaNodeStyleGetValueChecked", false, node, kind, edgeOrGutter, this.yogaU64);
    return this.yogaU64[0];
  }
  yogaNodeSetMeasureFunc(node, enabled) {
    this.yogaChecked("yogaNodeSetMeasureFuncChecked", true, node, ffiBool(enabled));
  }
  yogaNodeUnsetMeasureFunc(node) {
    this.yogaChecked("yogaNodeUnsetMeasureFuncChecked", true, node);
  }
  yogaNodeHasMeasureFunc(node) {
    return Boolean(this.opentui.symbols.yogaNodeHasMeasureFunc(node));
  }
  yogaNodeSetDirtiedFunc(node, enabled) {
    this.yogaChecked("yogaNodeSetDirtiedFuncChecked", true, node, ffiBool(enabled));
  }
  yogaNodeUnsetDirtiedFunc(node) {
    this.yogaChecked("yogaNodeUnsetDirtiedFuncChecked", true, node);
  }
  yogaStoreMeasureResult(config, width, height) {
    this.opentui.symbols.yogaStoreMeasureResult(config, width, height);
  }
  createYogaMeasureCallback(callback) {
    const host = this.getYogaHost();
    return this.opentui.createCallback((...args) => {
      host.invokeCallback(() => callback(...args));
    }, {
      args: ["ptr", "f32", "u32", "f32", "u32"],
      returns: "void"
    });
  }
  createYogaDirtiedCallback(callback) {
    const host = this.getYogaHost();
    return this.opentui.createCallback((node) => {
      host.invokeCallback(() => callback(node));
    }, {
      args: ["ptr"],
      returns: "void"
    });
  }
  getArenaAllocatedBytes() {
    const result = this.opentui.symbols.getArenaAllocatedBytes();
    return toSafeByteCount(result, "Arena allocated bytes");
  }
  getBuildOptions() {
    const optionsBuffer = new ArrayBuffer(BuildOptionsStruct.size);
    this.opentui.symbols.getBuildOptions(optionsBuffer);
    const options = BuildOptionsStruct.unpack(optionsBuffer);
    return {
      gpaSafeStats: !!options.gpaSafeStats,
      gpaMemoryLimitTracking: !!options.gpaMemoryLimitTracking
    };
  }
  getAllocatorStats() {
    const statsBuffer = new ArrayBuffer(AllocatorStatsStruct.size);
    this.opentui.symbols.getAllocatorStats(statsBuffer);
    const stats = AllocatorStatsStruct.unpack(statsBuffer);
    return {
      totalRequestedBytes: toNumber(stats.totalRequestedBytes),
      activeAllocations: toNumber(stats.activeAllocations),
      smallAllocations: toNumber(stats.smallAllocations),
      largeAllocations: toNumber(stats.largeAllocations),
      requestedBytesValid: !!stats.requestedBytesValid
    };
  }
  tryCreateStandaloneContext(objectCapacity) {
    try {
      return this.createContext({ objectCapacity, renderCellsMax: 1 });
    } catch (error) {
      if (error instanceof NativeError2)
        return null;
      throw error;
    }
  }
  createAudioEngine(options) {
    const optionsBuffer = options == null ? null : AudioCreateOptionsStruct.pack(options);
    const id = nextStandaloneHandle();
    const context = this.tryCreateStandaloneContext(1);
    if (!context)
      return null;
    try {
      const pointer = this.nativeContextPointer(context, "createAudioEngine");
      if (this.opentui.symbols.createAudioEngine(pointer, optionsBuffer) !== 0) {
        this.releaseContext(context);
        return null;
      }
      this.audioEngines.set(id, context);
      return id;
    } catch (error) {
      this.releaseContext(context);
      throw error;
    }
  }
  destroyAudioEngine(engine) {
    const context = this.audioEngines.get(engine);
    if (!context)
      return;
    this.releaseContext(context);
    this.audioEngines.delete(engine);
  }
  audioContext(engine) {
    const context = this.audioEngines.get(engine);
    return context ? this.nativeContextPointer(context, "audio") : null;
  }
  audioRefreshPlaybackDevices(engine) {
    return this.opentui.symbols.audioRefreshPlaybackDevices(this.audioContext(engine));
  }
  audioGetPlaybackDeviceCount(engine) {
    return this.opentui.symbols.audioGetPlaybackDeviceCount(this.audioContext(engine));
  }
  audioGetPlaybackDeviceName(engine, index) {
    const outBuffer = new Uint8Array(512);
    const bytesWritten = toNumber(this.opentui.symbols.audioGetPlaybackDeviceName(this.audioContext(engine), index, outBuffer, outBuffer.length));
    const safeBytesWritten = Math.max(0, Math.min(outBuffer.length, bytesWritten));
    return this.decoder.decode(outBuffer.subarray(0, safeBytesWritten));
  }
  audioIsPlaybackDeviceDefault(engine, index) {
    return this.opentui.symbols.audioIsPlaybackDeviceDefault(this.audioContext(engine), index);
  }
  audioSelectPlaybackDevice(engine, index) {
    return this.opentui.symbols.audioSelectPlaybackDevice(this.audioContext(engine), index);
  }
  audioClearPlaybackDeviceSelection(engine) {
    this.opentui.symbols.audioClearPlaybackDeviceSelection(this.audioContext(engine));
  }
  audioRefreshCaptureDevices(engine) {
    return this.opentui.symbols.audioRefreshCaptureDevices(this.audioContext(engine));
  }
  audioGetCaptureDeviceCount(engine) {
    return this.opentui.symbols.audioGetCaptureDeviceCount(this.audioContext(engine));
  }
  audioGetCaptureDeviceName(engine, index) {
    const outBuffer = new Uint8Array(512);
    const bytesWritten = toNumber(this.opentui.symbols.audioGetCaptureDeviceName(this.audioContext(engine), index, outBuffer, outBuffer.length));
    const safeBytesWritten = Math.max(0, Math.min(outBuffer.length, bytesWritten));
    return this.decoder.decode(outBuffer.subarray(0, safeBytesWritten));
  }
  audioIsCaptureDeviceDefault(engine, index) {
    return Boolean(this.opentui.symbols.audioIsCaptureDeviceDefault(this.audioContext(engine), index));
  }
  audioSelectCaptureDevice(engine, index) {
    return this.opentui.symbols.audioSelectCaptureDevice(this.audioContext(engine), index);
  }
  audioClearCaptureDeviceSelection(engine) {
    this.opentui.symbols.audioClearCaptureDeviceSelection(this.audioContext(engine));
  }
  audioStartCapture(engine, options, channels, capacityFrames) {
    let optionsBuffer;
    try {
      const noFixedSizedCallback = options?.noFixedSizedCallback;
      optionsBuffer = AudioStartOptionsStruct.pack(options ?? {});
      if (noFixedSizedCallback === undefined) {
        const field = AudioStartOptionsStruct.layoutByName.get("noFixedSizedCallback");
        if (!field)
          return -1;
        new DataView(optionsBuffer).setUint8(field.offset, 1);
      }
    } catch {
      return -1;
    }
    return this.opentui.symbols.audioStartCapture(this.audioContext(engine), optionsBuffer, channels, capacityFrames);
  }
  audioStopCapture(engine) {
    return this.opentui.symbols.audioStopCapture(this.audioContext(engine));
  }
  audioIsCaptureRunning(engine) {
    return Boolean(this.opentui.symbols.audioIsCaptureRunning(this.audioContext(engine)));
  }
  audioReadCapture(engine, outBuffer, frameCount) {
    const outFramesReadBuffer = new ArrayBuffer(4);
    const sampleCapacity = toSafeFFIU32Length(outBuffer.length, "Audio capture output sample capacity");
    const status = this.opentui.symbols.audioReadCapture(this.audioContext(engine), outBuffer, sampleCapacity, frameCount, outFramesReadBuffer);
    if (status !== 0)
      return { status, framesRead: 0 };
    return { status, framesRead: new Uint32Array(outFramesReadBuffer)[0] ?? 0 };
  }
  audioGetCaptureStats(engine) {
    const statsBuffer = new ArrayBuffer(AudioCaptureStatsStruct.size);
    const status = this.opentui.symbols.audioGetCaptureStats(this.audioContext(engine), statsBuffer);
    if (status !== 0)
      return { status, stats: null };
    const stats = AudioCaptureStatsStruct.unpack(statsBuffer);
    return {
      status,
      stats: {
        framesReceived: typeof stats.framesReceived === "bigint" ? stats.framesReceived : BigInt(stats.framesReceived),
        framesRead: typeof stats.framesRead === "bigint" ? stats.framesRead : BigInt(stats.framesRead),
        framesDropped: typeof stats.framesDropped === "bigint" ? stats.framesDropped : BigInt(stats.framesDropped),
        sampleRate: stats.sampleRate,
        channels: stats.channels,
        bufferedFrames: stats.bufferedFrames,
        capacityFrames: stats.capacityFrames
      }
    };
  }
  audioStart(engine, options) {
    let optionsBuffer;
    try {
      optionsBuffer = options == null ? null : AudioStartOptionsStruct.pack(options);
    } catch {
      return -1;
    }
    return this.opentui.symbols.audioStart(this.audioContext(engine), optionsBuffer);
  }
  audioStartMixer(engine) {
    return this.opentui.symbols.audioStartMixer(this.audioContext(engine));
  }
  audioStop(engine) {
    return this.opentui.symbols.audioStop(this.audioContext(engine));
  }
  audioCreateStream(engine, options) {
    if (!isFFIU32(options.groupId) || !isFFIU32(options.sampleRate ?? 0) || !isFFIU32(options.channels ?? 0) || !Object.values(NativeAudioStreamFormat3).includes(options.format)) {
      return { status: -1, streamId: null };
    }
    const optionsBuffer = new Uint8Array(AudioStreamCreateOptionsStruct.pack(options));
    const outBuffer = new Uint32Array(1);
    const status = this.opentui.symbols.audioCreateStream(this.audioContext(engine), optionsBuffer, outBuffer);
    if (status !== 0)
      return { status, streamId: null };
    return { status, streamId: outBuffer[0] ?? null };
  }
  audioWriteStream(engine, streamId, data) {
    const dataLength = toSafeFFIU32Length(data.byteLength, "Audio stream data length");
    return this.opentui.symbols.audioWriteStream(this.audioContext(engine), streamId, data, dataLength);
  }
  audioEndStream(engine, streamId) {
    return this.opentui.symbols.audioEndStream(this.audioContext(engine), streamId);
  }
  audioRestartStream(engine, streamId) {
    return this.opentui.symbols.audioRestartStream(this.audioContext(engine), streamId);
  }
  audioSetStreamVolume(engine, streamId, volume) {
    return this.opentui.symbols.audioSetStreamVolume(this.audioContext(engine), streamId, volume);
  }
  audioSetStreamPan(engine, streamId, pan) {
    return this.opentui.symbols.audioSetStreamPan(this.audioContext(engine), streamId, pan);
  }
  audioSetStreamGroup(engine, streamId, groupId) {
    if (!isFFIU32(groupId))
      return -1;
    return this.opentui.symbols.audioSetStreamGroup(this.audioContext(engine), streamId, groupId);
  }
  audioGetStreamStats(engine, streamId) {
    const storage = this.ffiStructStorage.audioStreamStats;
    const status = this.opentui.symbols.audioGetStreamStats(this.audioContext(engine), streamId, storage.ffiView);
    if (status !== 0)
      return null;
    const stats = AudioStreamStatsStruct.unpackInto(storage.view, storage.result);
    return { ...stats };
  }
  audioCloseStream(engine, streamId, reason) {
    const storage = this.ffiStructStorage.audioStreamStats;
    const status = this.opentui.symbols.audioCloseStream(this.audioContext(engine), streamId, reason, storage.ffiView);
    if (status !== 0)
      return { status, stats: null };
    const stats = AudioStreamStatsStruct.unpackInto(storage.view, storage.result);
    return { status, stats: { ...stats } };
  }
  audioLoad(engine, data) {
    const outBuffer = new ArrayBuffer(4);
    const dataLength = toSafeFFIU32Length(data.byteLength, "Audio data length");
    const status = this.opentui.symbols.audioLoad(this.audioContext(engine), data, dataLength, outBuffer);
    if (status !== 0) {
      return { status, soundId: null };
    }
    const view = new Uint32Array(outBuffer);
    return { status, soundId: view[0] };
  }
  audioUnload(engine, soundId) {
    return this.opentui.symbols.audioUnload(this.audioContext(engine), soundId);
  }
  audioPlay(engine, soundId, options) {
    if (options?.groupId !== undefined && !isFFIU32(options.groupId))
      return { status: -1, voiceId: null };
    const outBuffer = new ArrayBuffer(4);
    const optionsBuffer = options ? AudioVoiceOptionsStruct.pack(options) : null;
    const status = this.opentui.symbols.audioPlay(this.audioContext(engine), soundId, optionsBuffer, outBuffer);
    if (status !== 0) {
      return { status, voiceId: null };
    }
    const view = new Uint32Array(outBuffer);
    return { status, voiceId: view[0] };
  }
  audioStopVoice(engine, voiceId) {
    return this.opentui.symbols.audioStopVoice(this.audioContext(engine), voiceId);
  }
  audioSetVoiceGroup(engine, voiceId, groupId) {
    if (!isFFIU32(groupId))
      return -1;
    return this.opentui.symbols.audioSetVoiceGroup(this.audioContext(engine), voiceId, groupId);
  }
  audioCreateGroup(engine, name) {
    const outBuffer = new ArrayBuffer(4);
    const nameBytes = this.encoder.encode(name);
    const nameLength = toSafeFFIU32Length(nameBytes.byteLength, "Audio group name length");
    const status = this.opentui.symbols.audioCreateGroup(this.audioContext(engine), nameBytes, nameLength, outBuffer);
    if (status !== 0) {
      return { status, groupId: null };
    }
    const view = new Uint32Array(outBuffer);
    return { status, groupId: view[0] };
  }
  audioSetGroupVolume(engine, groupId, volume) {
    return this.opentui.symbols.audioSetGroupVolume(this.audioContext(engine), groupId, volume);
  }
  audioSetMasterVolume(engine, volume) {
    return this.opentui.symbols.audioSetMasterVolume(this.audioContext(engine), volume);
  }
  audioMixToBuffer(engine, outBuffer, frameCount, channels) {
    return this.opentui.symbols.audioMixToBuffer(this.audioContext(engine), outBuffer, frameCount, channels);
  }
  audioEnableTap(engine, enabled, capacityFrames) {
    return this.opentui.symbols.audioEnableTap(this.audioContext(engine), ffiBool(enabled), capacityFrames);
  }
  audioReadTap(engine, outBuffer, frameCount, channels) {
    const outFramesReadBuffer = new ArrayBuffer(4);
    const status = this.opentui.symbols.audioReadTap(this.audioContext(engine), outBuffer, frameCount, channels, outFramesReadBuffer);
    if (status !== 0) {
      return { status, framesRead: 0 };
    }
    const view = new Uint32Array(outFramesReadBuffer);
    return { status, framesRead: view[0] ?? 0 };
  }
  audioGetStats(engine) {
    const statsBuffer = new ArrayBuffer(AudioStatsStruct.size);
    const status = this.opentui.symbols.audioGetStats(this.audioContext(engine), statsBuffer);
    if (status !== 0) {
      return null;
    }
    const stats = AudioStatsStruct.unpack(statsBuffer);
    return {
      soundsLoaded: stats.soundsLoaded,
      voicesActive: stats.voicesActive,
      framesMixed: typeof stats.framesMixed === "bigint" ? stats.framesMixed : BigInt(stats.framesMixed),
      lockMisses: stats.lockMisses,
      lastPeak: stats.lastPeak,
      lastRms: stats.lastRms
    };
  }
  registerNativeSpanFeedStream(stream, handler) {
    const callback = this.ensureNativeSpanFeedCallback();
    this.nativeSpanFeedHandlers.set(stream, handler);
    this.opentui.symbols.streamSetCallback(stream, callback.ptr);
  }
  unregisterNativeSpanFeedStream(stream) {
    this.opentui.symbols.streamSetCallback(stream, null);
    this.nativeSpanFeedHandlers.delete(stream);
  }
  createNativeSpanFeed(options) {
    const optionsBuffer = options == null ? null : NativeSpanFeedOptionsStruct.pack(options);
    const streamPtr = this.opentui.symbols.createNativeSpanFeed(optionsBuffer);
    if (!streamPtr) {
      throw new Error("Failed to create stream");
    }
    return streamPtr;
  }
  attachNativeSpanFeed(stream) {
    return this.opentui.symbols.attachNativeSpanFeed(stream);
  }
  destroyNativeSpanFeed(stream) {
    const status = this.opentui.symbols.destroyNativeSpanFeed(stream);
    if (status === 0)
      this.nativeSpanFeedHandlers.delete(stream);
    return status;
  }
  streamWrite(stream, data) {
    const bytes = typeof data === "string" ? this.encoder.encode(data) : data;
    return this.opentui.symbols.streamWrite(stream, viewOrNull(bytes), bytes.byteLength);
  }
  streamCommit(stream) {
    return this.opentui.symbols.streamCommit(stream);
  }
  streamDrainSpans(stream, outBuffer, maxSpans) {
    if (!Number.isInteger(maxSpans) || maxSpans < 0 || maxSpans > outBuffer.byteLength / SpanInfoStruct.size) {
      throw new RangeError("Span drain buffer is too small");
    }
    const count = this.opentui.symbols.streamDrainSpans(stream, outBuffer, maxSpans);
    return toNumber(count);
  }
  streamReleaseSpan(stream, slotIndex, releaseId) {
    return this.opentui.symbols.streamReleaseSpan(stream, slotIndex, releaseId);
  }
  streamClose(stream) {
    return this.opentui.symbols.streamClose(stream);
  }
  streamGetStats(stream) {
    const statsBuffer = new ArrayBuffer(NativeSpanFeedStatsStruct.size);
    const status = this.opentui.symbols.streamGetStats(stream, statsBuffer);
    if (status !== 0) {
      return null;
    }
    const stats = NativeSpanFeedStatsStruct.unpack(statsBuffer);
    return {
      bytesWritten: typeof stats.bytesWritten === "bigint" ? stats.bytesWritten : BigInt(stats.bytesWritten),
      spansCommitted: typeof stats.spansCommitted === "bigint" ? stats.spansCommitted : BigInt(stats.spansCommitted),
      chunks: stats.chunks,
      pendingSpans: stats.pendingSpans,
      outstandingSpans: stats.outstandingSpans,
      outstandingBytes: BigInt(stats.outstandingBytes)
    };
  }
  streamReserve(stream, minLen) {
    const reserveBuffer = new ArrayBuffer(ReserveInfoStruct.size);
    const status = this.opentui.symbols.streamReserve(stream, minLen, reserveBuffer);
    if (status !== 0) {
      return { status, info: null };
    }
    return { status, info: ReserveInfoStruct.unpack(reserveBuffer) };
  }
  streamCommitReserved(stream, length) {
    return this.opentui.symbols.streamCommitReserved(stream, length);
  }
  imageStatus(operation, status) {
    const result = imageStatusCodes.get(status);
    if (result !== undefined)
      return result;
    nativeResult(operation, status);
    return 0;
  }
  imageCall(context, operation, call) {
    return this.getYogaHost().runMutation(() => this.imageStatus(operation, call(this.nativeContextPointer(context, operation))));
  }
  imageOutput(context, operation, call) {
    const output = new Uint32Array(handleWords);
    const status = this.imageCall(context, operation, (pointer) => call(pointer, output));
    if (status !== 0)
      return { status, handle: null };
    return { status, handle: decodeContextHandle(context, output) };
  }
  imageInfoOutput(context, operation, call) {
    const layout = nativeLayouts.ot_image_info;
    const output = new Uint32Array(layout.size / 4);
    const status = this.imageCall(context, operation, (pointer) => call(pointer, output));
    const fields = layout.fields;
    return {
      status,
      info: {
        width: output[fields.width.offset / 4],
        height: output[fields.height.offset / 4],
        sourceWidth: output[fields.source_width.offset / 4],
        sourceHeight: output[fields.source_height.offset / 4],
        format: output[fields.format.offset / 4],
        colorStatus: output[fields.color_status.offset / 4],
        orientation: output[fields.orientation.offset / 4],
        hasAlpha: output[fields.has_alpha.offset / 4]
      }
    };
  }
  imageInfo(context, data) {
    const bytes = sessionBytes(data, "Image data byte length");
    const length = BigInt(bytes.byteLength);
    return this.imageInfoOutput(context, "ot_image_inspect", (pointer, output) => this.opentui.symbols.ot_image_inspect(pointer, bytes, length, output));
  }
  imageDecode(context, data) {
    const bytes = sessionBytes(data, "Image data byte length");
    const length = BigInt(bytes.byteLength);
    return this.imageOutput(context, "ot_image_decode", (pointer, output) => this.opentui.symbols.ot_image_decode(pointer, bytes, length, output));
  }
  imageCreateFromRgba(context, pixels, width, height, stride) {
    return this.imageCreateFromPixels(context, pixels, width, height, stride, 0, 0);
  }
  imageCreateFromPixels(context, pixels, width, height, stride, format, alpha) {
    const bytes = sessionBytes(pixels, "Image pixel byte length");
    const length = BigInt(bytes.byteLength);
    toSafeFFIU32Length(width, "Image width");
    toSafeFFIU32Length(height, "Image height");
    toSafeFFIU32Length(stride, "Image stride");
    toSafeFFIU32Length(format, "Image pixel format");
    toSafeFFIU32Length(alpha, "Image alpha");
    return this.imageOutput(context, "ot_image_create_pixels", (pointer, output) => this.opentui.symbols.ot_image_create_pixels(pointer, bytes, length, width, height, stride, format, alpha, output));
  }
  imageUpdatePixels(image, pixels, stride, format, alpha) {
    const context = image.context;
    const handle = encodeContextHandle(context, image);
    const bytes = sessionBytes(pixels, "Image pixel byte length");
    const length = BigInt(bytes.byteLength);
    toSafeFFIU32Length(stride, "Image stride");
    toSafeFFIU32Length(format, "Image pixel format");
    toSafeFFIU32Length(alpha, "Image alpha");
    return this.imageCall(context, "ot_image_update_pixels", (pointer) => this.opentui.symbols.ot_image_update_pixels(pointer, handle, bytes, length, stride, format, alpha));
  }
  imageDestroy(image) {
    this.destroyContextImage(image.context, image);
  }
  imageRetain(image) {
    const context = image.context;
    const handle = encodeContextHandle(context, image);
    return this.imageOutput(context, "ot_image_retain", (pointer, output) => this.opentui.symbols.ot_image_retain(pointer, handle, output));
  }
  imageRetainIccCache() {
    this.opentui.symbols.imageRetainIccCache();
  }
  imageReleaseIccCache() {
    this.opentui.symbols.imageReleaseIccCache();
  }
  imageGetInfo(image) {
    const context = image.context;
    const handle = encodeContextHandle(context, image);
    return this.imageInfoOutput(context, "ot_image_get_info", (pointer, output) => this.opentui.symbols.ot_image_get_info(pointer, handle, output));
  }
  imageEnsureEncodedPng(image) {
    return this.imageCopyPng(image, new Uint8Array).status;
  }
  imageCopyPng(image, destination) {
    const context = image.context;
    const handle = encodeContextHandle(context, image);
    const bytes = sessionBytes(destination, "Image PNG output byte length");
    const capacity = BigInt(bytes.byteLength);
    const count = new BigUint64Array(1);
    const status = this.imageCall(context, "ot_image_copy_png", (pointer) => this.opentui.symbols.ot_image_copy_png(pointer, handle, bytes, capacity, count));
    return { status, byteCount: Number(count[0]) };
  }
  imageTakePixels(image) {
    const context = image.context;
    const handle = encodeContextHandle(context, image);
    const layout = nativeLayouts.ot_image_pixels;
    const output = new BigUint64Array(layout.size / 8);
    const status = this.imageCall(context, "ot_image_take_pixels", (pointer) => this.opentui.symbols.ot_image_take_pixels(pointer, handle, output));
    if (status !== 0)
      return { status, lease: null, pointer: null, byteCount: 0 };
    try {
      return {
        status,
        lease: decodeContextHandle(context, output),
        pointer: toPointer(output[layout.fields.pixels.offset / 8]),
        byteCount: Number(output[layout.fields.byte_count.offset / 8])
      };
    } catch (error) {
      this.opentui.symbols.ot_image_pixels_release(this.nativeContextPointer(context, "ot_image_pixels_release"), output);
      throw error;
    }
  }
  imageReleasePixels(lease) {
    const context = lease.context;
    const handle = encodeContextHandle(context, lease);
    this.getYogaHost().runMutation(() => {
      const pointer = this.nativeContextPointer(context, "ot_image_pixels_release");
      nativeResult("ot_image_pixels_release", this.opentui.symbols.ot_image_pixels_release(pointer, handle));
    });
  }
  imageClone(image, context) {
    const sourceContext = image.context;
    const handle = encodeContextHandle(sourceContext, image);
    return this.imageOutput(context ?? sourceContext, "ot_image_clone", (pointer, output) => this.opentui.symbols.ot_image_clone(pointer, this.nativeContextPointer(sourceContext, "ot_image_clone"), handle, output));
  }
  imageCopyPixels(image, destination, stride, bgra) {
    const context = image.context;
    const handle = encodeContextHandle(context, image);
    const bytes = sessionBytes(destination, "Image pixel output byte length");
    const length = BigInt(bytes.byteLength);
    toSafeFFIU32Length(stride, "Image stride");
    const format = toFFIBool(bgra, "Image BGRA");
    return this.imageCall(context, "ot_image_copy_pixels", (pointer) => this.opentui.symbols.ot_image_copy_pixels(pointer, handle, bytes, length, stride, format));
  }
  imageResize(image, width, height, filter) {
    const context = image.context;
    const handle = encodeContextHandle(context, image);
    toSafeFFIU32Length(width, "Image width");
    toSafeFFIU32Length(height, "Image height");
    toSafeFFIU32Length(filter, "Image resize filter");
    return this.imageOutput(context, "ot_image_resize", (pointer, output) => this.opentui.symbols.ot_image_resize(pointer, handle, width, height, filter, output));
  }
  imageExtract(image, left, top, width, height) {
    const context = image.context;
    const handle = encodeContextHandle(context, image);
    toSafeFFIU32Length(left, "Image left");
    toSafeFFIU32Length(top, "Image top");
    toSafeFFIU32Length(width, "Image width");
    toSafeFFIU32Length(height, "Image height");
    return this.imageOutput(context, "ot_image_extract", (pointer, output) => this.opentui.symbols.ot_image_extract(pointer, handle, left, top, width, height, output));
  }
  imageExtend(image, top, right, bottom, left, background) {
    if (!(background instanceof Uint8Array))
      return { status: 7, handle: null };
    const bytes = sessionBytes(background, "Image background byte length");
    if (bytes.byteLength !== 4)
      return { status: 7, handle: null };
    const context = image.context;
    const handle = encodeContextHandle(context, image);
    toSafeFFIU32Length(top, "Image top");
    toSafeFFIU32Length(right, "Image right");
    toSafeFFIU32Length(bottom, "Image bottom");
    toSafeFFIU32Length(left, "Image left");
    return this.imageOutput(context, "ot_image_extend", (pointer, output) => this.opentui.symbols.ot_image_extend(pointer, handle, top, right, bottom, left, bytes, output));
  }
  imageTransform(image, operation) {
    const context = image.context;
    const handle = encodeContextHandle(context, image);
    toSafeFFIU32Length(operation, "Image transform");
    return this.imageOutput(context, "ot_image_transform", (pointer, output) => this.opentui.symbols.ot_image_transform(pointer, handle, operation, output));
  }
  imageComposite(base, overlay, left, top, blend, opacity) {
    const context = base.context;
    const baseHandle = encodeContextHandle(context, base);
    const overlayHandle = encodeContextHandle(context, overlay);
    toFFII32(left, "Image composite left");
    toFFII32(top, "Image composite top");
    toSafeFFIU32Length(blend, "Image blend mode");
    if (!isFFIU32(opacity) || opacity > 255)
      throw new RangeError("Image opacity must be an integer from 0 to 255");
    return this.imageOutput(context, "ot_image_composite", (pointer, output) => this.opentui.symbols.ot_image_composite(pointer, baseHandle, overlayHandle, left, top, blend, opacity, output));
  }
}
var opentuiLibPath;
var opentuiLib;
var renderLibResolved = false;
function setRenderLibPath2(libPath) {
  if (opentuiLibPath !== libPath) {
    if (renderLibResolved) {
      throw new Error("setRenderLibPath() must be called before resolveRenderLib()");
    }
    if (opentuiLib instanceof FFIRenderLib2) {
      opentuiLib.dispose();
    }
    opentuiLibPath = libPath;
    opentuiLib = undefined;
  }
}
function resolveRenderLib2() {
  if (!opentuiLib) {
    try {
      opentuiLib = new FFIRenderLib2(opentuiLibPath);
    } catch (error) {
      throw new Error(`Failed to initialize OpenTUI render library: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  }
  renderLibResolved = true;
  return opentuiLib;
}
try {
  opentuiLib = new FFIRenderLib2(opentuiLibPath);
} catch (error) {}

// src/yoga.ts
var Align2;
((Align) => {
  Align[Align["Auto"] = nativeConstants.OT_ALIGN_AUTO] = "Auto";
  Align[Align["FlexStart"] = nativeConstants.OT_ALIGN_FLEX_START] = "FlexStart";
  Align[Align["Center"] = nativeConstants.OT_ALIGN_CENTER] = "Center";
  Align[Align["FlexEnd"] = nativeConstants.OT_ALIGN_FLEX_END] = "FlexEnd";
  Align[Align["Stretch"] = nativeConstants.OT_ALIGN_STRETCH] = "Stretch";
  Align[Align["Baseline"] = nativeConstants.OT_ALIGN_BASELINE] = "Baseline";
  Align[Align["SpaceBetween"] = nativeConstants.OT_ALIGN_SPACE_BETWEEN] = "SpaceBetween";
  Align[Align["SpaceAround"] = nativeConstants.OT_ALIGN_SPACE_AROUND] = "SpaceAround";
  Align[Align["SpaceEvenly"] = nativeConstants.OT_ALIGN_SPACE_EVENLY] = "SpaceEvenly";
})(Align2 ||= {});
var BoxSizing2;
((BoxSizing) => {
  BoxSizing[BoxSizing["BorderBox"] = nativeConstants.OT_BOX_SIZING_BORDER_BOX] = "BorderBox";
  BoxSizing[BoxSizing["ContentBox"] = nativeConstants.OT_BOX_SIZING_CONTENT_BOX] = "ContentBox";
})(BoxSizing2 ||= {});
var Dimension2;
((Dimension) => {
  Dimension[Dimension["Width"] = nativeConstants.OT_DIMENSION_WIDTH] = "Width";
  Dimension[Dimension["Height"] = nativeConstants.OT_DIMENSION_HEIGHT] = "Height";
})(Dimension2 ||= {});
var Direction2;
((Direction) => {
  Direction[Direction["Inherit"] = nativeConstants.OT_DIRECTION_INHERIT] = "Inherit";
  Direction[Direction["LTR"] = nativeConstants.OT_DIRECTION_LTR] = "LTR";
  Direction[Direction["RTL"] = nativeConstants.OT_DIRECTION_RTL] = "RTL";
})(Direction2 ||= {});
var Display2;
((Display) => {
  Display[Display["Flex"] = 0] = "Flex";
  Display[Display["None"] = 1] = "None";
  Display[Display["Contents"] = 2] = "Contents";
})(Display2 ||= {});
var Edge2;
((Edge) => {
  Edge[Edge["Left"] = nativeConstants.OT_EDGE_LEFT] = "Left";
  Edge[Edge["Top"] = nativeConstants.OT_EDGE_TOP] = "Top";
  Edge[Edge["Right"] = nativeConstants.OT_EDGE_RIGHT] = "Right";
  Edge[Edge["Bottom"] = nativeConstants.OT_EDGE_BOTTOM] = "Bottom";
  Edge[Edge["Start"] = nativeConstants.OT_EDGE_START] = "Start";
  Edge[Edge["End"] = nativeConstants.OT_EDGE_END] = "End";
  Edge[Edge["Horizontal"] = nativeConstants.OT_EDGE_HORIZONTAL] = "Horizontal";
  Edge[Edge["Vertical"] = nativeConstants.OT_EDGE_VERTICAL] = "Vertical";
  Edge[Edge["All"] = nativeConstants.OT_EDGE_ALL] = "All";
})(Edge2 ||= {});
var Errata2;
((Errata) => {
  Errata[Errata["None"] = 0] = "None";
  Errata[Errata["StretchFlexBasis"] = 1] = "StretchFlexBasis";
  Errata[Errata["AbsolutePositionWithoutInsetsExcludesPadding"] = 2] = "AbsolutePositionWithoutInsetsExcludesPadding";
  Errata[Errata["AbsolutePercentAgainstInnerSize"] = 4] = "AbsolutePercentAgainstInnerSize";
  Errata[Errata["All"] = 2147483647] = "All";
  Errata[Errata["Classic"] = 2147483646] = "Classic";
})(Errata2 ||= {});
var ExperimentalFeature2;
((ExperimentalFeature) => {
  ExperimentalFeature[ExperimentalFeature["WebFlexBasis"] = 0] = "WebFlexBasis";
})(ExperimentalFeature2 ||= {});
var FlexDirection2;
((FlexDirection) => {
  FlexDirection[FlexDirection["Column"] = nativeConstants.OT_FLEX_DIRECTION_COLUMN] = "Column";
  FlexDirection[FlexDirection["ColumnReverse"] = nativeConstants.OT_FLEX_DIRECTION_COLUMN_REVERSE] = "ColumnReverse";
  FlexDirection[FlexDirection["Row"] = nativeConstants.OT_FLEX_DIRECTION_ROW] = "Row";
  FlexDirection[FlexDirection["RowReverse"] = nativeConstants.OT_FLEX_DIRECTION_ROW_REVERSE] = "RowReverse";
})(FlexDirection2 ||= {});
var Gutter2;
((Gutter) => {
  Gutter[Gutter["Column"] = nativeConstants.OT_GUTTER_COLUMN] = "Column";
  Gutter[Gutter["Row"] = nativeConstants.OT_GUTTER_ROW] = "Row";
  Gutter[Gutter["All"] = nativeConstants.OT_GUTTER_ALL] = "All";
})(Gutter2 ||= {});
var Justify2;
((Justify) => {
  Justify[Justify["FlexStart"] = nativeConstants.OT_JUSTIFY_FLEX_START] = "FlexStart";
  Justify[Justify["Center"] = nativeConstants.OT_JUSTIFY_CENTER] = "Center";
  Justify[Justify["FlexEnd"] = nativeConstants.OT_JUSTIFY_FLEX_END] = "FlexEnd";
  Justify[Justify["SpaceBetween"] = nativeConstants.OT_JUSTIFY_SPACE_BETWEEN] = "SpaceBetween";
  Justify[Justify["SpaceAround"] = nativeConstants.OT_JUSTIFY_SPACE_AROUND] = "SpaceAround";
  Justify[Justify["SpaceEvenly"] = nativeConstants.OT_JUSTIFY_SPACE_EVENLY] = "SpaceEvenly";
})(Justify2 ||= {});
var LogLevel3;
((LogLevel) => {
  LogLevel[LogLevel["Error"] = 0] = "Error";
  LogLevel[LogLevel["Warn"] = 1] = "Warn";
  LogLevel[LogLevel["Info"] = 2] = "Info";
  LogLevel[LogLevel["Debug"] = 3] = "Debug";
  LogLevel[LogLevel["Verbose"] = 4] = "Verbose";
  LogLevel[LogLevel["Fatal"] = 5] = "Fatal";
})(LogLevel3 ||= {});
var MeasureMode2;
((MeasureMode) => {
  MeasureMode[MeasureMode["Undefined"] = nativeConstants.OT_MEASURE_UNDEFINED] = "Undefined";
  MeasureMode[MeasureMode["Exactly"] = nativeConstants.OT_MEASURE_EXACTLY] = "Exactly";
  MeasureMode[MeasureMode["AtMost"] = nativeConstants.OT_MEASURE_AT_MOST] = "AtMost";
})(MeasureMode2 ||= {});
var NodeType2;
((NodeType) => {
  NodeType[NodeType["Default"] = 0] = "Default";
  NodeType[NodeType["Text"] = 1] = "Text";
})(NodeType2 ||= {});
var Overflow2;
((Overflow) => {
  Overflow[Overflow["Visible"] = nativeConstants.OT_OVERFLOW_VISIBLE] = "Visible";
  Overflow[Overflow["Hidden"] = nativeConstants.OT_OVERFLOW_HIDDEN] = "Hidden";
  Overflow[Overflow["Scroll"] = nativeConstants.OT_OVERFLOW_SCROLL] = "Scroll";
})(Overflow2 ||= {});
var PositionType2;
((PositionType) => {
  PositionType[PositionType["Static"] = nativeConstants.OT_POSITION_STATIC] = "Static";
  PositionType[PositionType["Relative"] = nativeConstants.OT_POSITION_RELATIVE] = "Relative";
  PositionType[PositionType["Absolute"] = nativeConstants.OT_POSITION_ABSOLUTE] = "Absolute";
})(PositionType2 ||= {});
var Unit2;
((Unit) => {
  Unit[Unit["Undefined"] = nativeConstants.OT_UNIT_UNDEFINED] = "Undefined";
  Unit[Unit["Point"] = nativeConstants.OT_UNIT_POINT] = "Point";
  Unit[Unit["Percent"] = nativeConstants.OT_UNIT_PERCENT] = "Percent";
  Unit[Unit["Auto"] = nativeConstants.OT_UNIT_AUTO] = "Auto";
})(Unit2 ||= {});
var Wrap2;
((_Wrap) => {
  _Wrap[_Wrap["NoWrap"] = nativeConstants.OT_FLEX_WRAP_NONE] = "NoWrap";
  _Wrap[_Wrap["Wrap"] = nativeConstants.OT_FLEX_WRAP_WRAP] = "Wrap";
  _Wrap[_Wrap["WrapReverse"] = nativeConstants.OT_FLEX_WRAP_REVERSE] = "WrapReverse";
})(Wrap2 ||= {});
var ALIGN_AUTO2 = Align2.Auto;
var ALIGN_FLEX_START2 = Align2.FlexStart;
var ALIGN_CENTER2 = Align2.Center;
var ALIGN_FLEX_END2 = Align2.FlexEnd;
var ALIGN_STRETCH2 = Align2.Stretch;
var ALIGN_BASELINE2 = Align2.Baseline;
var ALIGN_SPACE_BETWEEN2 = Align2.SpaceBetween;
var ALIGN_SPACE_AROUND2 = Align2.SpaceAround;
var ALIGN_SPACE_EVENLY2 = Align2.SpaceEvenly;
var BOX_SIZING_BORDER_BOX2 = BoxSizing2.BorderBox;
var BOX_SIZING_CONTENT_BOX2 = BoxSizing2.ContentBox;
var DIMENSION_WIDTH2 = Dimension2.Width;
var DIMENSION_HEIGHT2 = Dimension2.Height;
var DIRECTION_INHERIT2 = Direction2.Inherit;
var DIRECTION_LTR2 = Direction2.LTR;
var DIRECTION_RTL2 = Direction2.RTL;
var DISPLAY_FLEX2 = 0 /* Flex */;
var DISPLAY_NONE2 = 1 /* None */;
var DISPLAY_CONTENTS2 = 2 /* Contents */;
var EDGE_LEFT2 = Edge2.Left;
var EDGE_TOP2 = Edge2.Top;
var EDGE_RIGHT2 = Edge2.Right;
var EDGE_BOTTOM2 = Edge2.Bottom;
var EDGE_START2 = Edge2.Start;
var EDGE_END2 = Edge2.End;
var EDGE_HORIZONTAL2 = Edge2.Horizontal;
var EDGE_VERTICAL2 = Edge2.Vertical;
var EDGE_ALL2 = Edge2.All;
var ERRATA_NONE2 = 0 /* None */;
var ERRATA_STRETCH_FLEX_BASIS2 = 1 /* StretchFlexBasis */;
var ERRATA_ABSOLUTE_POSITION_WITHOUT_INSETS_EXCLUDES_PADDING2 = 2 /* AbsolutePositionWithoutInsetsExcludesPadding */;
var ERRATA_ABSOLUTE_PERCENT_AGAINST_INNER_SIZE2 = 4 /* AbsolutePercentAgainstInnerSize */;
var ERRATA_ALL2 = 2147483647 /* All */;
var ERRATA_CLASSIC2 = 2147483646 /* Classic */;
var EXPERIMENTAL_FEATURE_WEB_FLEX_BASIS2 = 0 /* WebFlexBasis */;
var FLEX_DIRECTION_COLUMN2 = FlexDirection2.Column;
var FLEX_DIRECTION_COLUMN_REVERSE2 = FlexDirection2.ColumnReverse;
var FLEX_DIRECTION_ROW2 = FlexDirection2.Row;
var FLEX_DIRECTION_ROW_REVERSE2 = FlexDirection2.RowReverse;
var GUTTER_COLUMN2 = Gutter2.Column;
var GUTTER_ROW2 = Gutter2.Row;
var GUTTER_ALL2 = Gutter2.All;
var JUSTIFY_FLEX_START2 = Justify2.FlexStart;
var JUSTIFY_CENTER2 = Justify2.Center;
var JUSTIFY_FLEX_END2 = Justify2.FlexEnd;
var JUSTIFY_SPACE_BETWEEN2 = Justify2.SpaceBetween;
var JUSTIFY_SPACE_AROUND2 = Justify2.SpaceAround;
var JUSTIFY_SPACE_EVENLY2 = Justify2.SpaceEvenly;
var LOG_LEVEL_ERROR2 = 0 /* Error */;
var LOG_LEVEL_WARN2 = 1 /* Warn */;
var LOG_LEVEL_INFO2 = 2 /* Info */;
var LOG_LEVEL_DEBUG2 = 3 /* Debug */;
var LOG_LEVEL_VERBOSE2 = 4 /* Verbose */;
var LOG_LEVEL_FATAL2 = 5 /* Fatal */;
var MEASURE_MODE_UNDEFINED2 = MeasureMode2.Undefined;
var MEASURE_MODE_EXACTLY2 = MeasureMode2.Exactly;
var MEASURE_MODE_AT_MOST2 = MeasureMode2.AtMost;
var NODE_TYPE_DEFAULT2 = 0 /* Default */;
var NODE_TYPE_TEXT2 = 1 /* Text */;
var OVERFLOW_VISIBLE2 = Overflow2.Visible;
var OVERFLOW_HIDDEN2 = Overflow2.Hidden;
var OVERFLOW_SCROLL2 = Overflow2.Scroll;
var POSITION_TYPE_STATIC2 = PositionType2.Static;
var POSITION_TYPE_RELATIVE2 = PositionType2.Relative;
var POSITION_TYPE_ABSOLUTE2 = PositionType2.Absolute;
var UNIT_UNDEFINED2 = Unit2.Undefined;
var UNIT_POINT2 = Unit2.Point;
var UNIT_PERCENT2 = Unit2.Percent;
var UNIT_AUTO2 = Unit2.Auto;
var WRAP_NO_WRAP2 = Wrap2.NoWrap;
var WRAP_WRAP2 = Wrap2.Wrap;
var WRAP_WRAP_REVERSE2 = Wrap2.WrapReverse;
var YogaEdgeLayoutKind = {
  Margin: 0,
  Padding: 1,
  Border: 2
};
var YogaStatus2;
((YogaStatus) => {
  YogaStatus[YogaStatus["Ok"] = 0] = "Ok";
  YogaStatus[YogaStatus["InvalidArgument"] = 1] = "InvalidArgument";
  YogaStatus[YogaStatus["OutOfMemory"] = 2] = "OutOfMemory";
  YogaStatus[YogaStatus["Exception"] = 3] = "Exception";
  YogaStatus[YogaStatus["Poisoned"] = 4] = "Poisoned";
  YogaStatus[YogaStatus["Busy"] = 5] = "Busy";
  YogaStatus[YogaStatus["DepthLimit"] = 6] = "DepthLimit";
})(YogaStatus2 ||= {});

class YogaError2 extends Error {
  operation;
  status;
  name = "YogaError";
  constructor(operation, status) {
    super(`${operation} failed: ${YogaStatus2[status] ?? "Unknown"} (status ${status})`);
    this.operation = operation;
    this.status = status;
  }
}
function unpackValue(packedValue) {
  const packed = typeof packedValue === "bigint" ? packedValue : BigInt(packedValue);
  const unit = Number(packed & 0xffffffffn);
  const valueBits = Number(packed >> 32n & 0xffffffffn);
  const buffer = new ArrayBuffer(4);
  const view = new DataView(buffer);
  view.setUint32(0, valueBits, true);
  return { unit, value: view.getFloat32(0, true) };
}
function normalizeLayoutInput(value) {
  return value === undefined || value === "auto" ? NaN : value;
}

class Config2 {
  renderLib;
  ownsConfig;
  ptr;
  nodes = new Map;
  measures = new Map;
  dirtied = new Map;
  freed = false;
  measureCallback;
  dirtiedCallback;
  constructor(ptr, renderLib, ownsConfig) {
    this.renderLib = renderLib;
    this.ownsConfig = ownsConfig;
    this.ptr = ptr;
    renderLib.getYogaHost().configs.set(ptr, this);
  }
  static create(renderLib = resolveRenderLib2()) {
    return new Config2(renderLib.yogaConfigCreate(), renderLib, true);
  }
  static fromBorrowedPointer(ptr, renderLib = resolveRenderLib2()) {
    return renderLib.getYogaHost().configs.get(ptr) ?? new Config2(ptr, renderLib, false);
  }
  static destroy(config) {
    config.free();
  }
  free() {
    if (this.freed)
      return;
    this.renderLib.getYogaHost().assertMutable();
    this.assertUnused();
    if (this.ownsConfig) {
      this.renderLib.yogaConfigFree(this.ptr);
    } else if (this.measureCallback?.ptr) {
      this.renderLib.yogaConfigClearCallbacks(this.ptr, this.measureCallback.ptr);
    }
    this.measureCallback?.close();
    this.dirtiedCallback?.close();
    this.renderLib.getYogaHost().configs.delete(this.ptr);
    this.freed = true;
  }
  assertUnused() {
    if (this.nodes.size !== 0)
      throw new Error("Cannot free Yoga config while Yoga nodes are active");
  }
  assertAlive() {
    if (this.freed)
      throw new Error("Yoga config is freed");
  }
  ensureCallbacks() {
    this.assertAlive();
    this.renderLib.getYogaHost().assertMutable();
    if (this.measureCallback)
      return;
    const measure = this.renderLib.createYogaMeasureCallback((node, width, widthMode, height, heightMode) => {
      const result = node ? this.measures.get(node)?.(width, widthMode, height, heightMode) : undefined;
      rejectAsyncCallback(result);
      this.renderLib.yogaStoreMeasureResult(this.ptr, result?.width ?? NaN, result?.height ?? NaN);
    });
    let dirtied;
    try {
      dirtied = this.renderLib.createYogaDirtiedCallback((node) => {
        const registration = node ? this.dirtied.get(node) : undefined;
        return registration?.callback(registration.node);
      });
      if (!measure.ptr || !dirtied.ptr)
        throw new Error("Failed to create Yoga callbacks");
      if (!this.renderLib.yogaConfigSetCallbacks(this.ptr, measure.ptr, dirtied.ptr)) {
        throw new Error("Yoga config callbacks are owned by another native library facade");
      }
      this.measureCallback = measure;
      this.dirtiedCallback = dirtied;
    } catch (error) {
      measure.close();
      dirtied?.close();
      throw error;
    }
  }
  setUseWebDefaults(useWebDefaults) {
    if (this.freed)
      return;
    this.renderLib.yogaConfigSetUseWebDefaults(this.ptr, useWebDefaults);
  }
  useWebDefaults() {
    if (this.freed)
      return false;
    return this.renderLib.yogaConfigGetUseWebDefaults(this.ptr);
  }
  setPointScaleFactor(pointScaleFactor) {
    if (this.freed)
      return;
    this.renderLib.yogaConfigSetPointScaleFactor(this.ptr, pointScaleFactor);
  }
  getPointScaleFactor() {
    if (this.freed)
      return 0;
    return this.renderLib.yogaConfigGetPointScaleFactor(this.ptr);
  }
  setErrata(errata) {
    if (this.freed)
      return;
    this.renderLib.yogaConfigSetErrata(this.ptr, errata);
  }
  getErrata() {
    if (this.freed)
      return 0 /* None */;
    return this.renderLib.yogaConfigGetErrata(this.ptr);
  }
  setExperimentalFeatureEnabled(feature, enabled) {
    if (this.freed)
      return;
    this.renderLib.yogaConfigSetExperimentalFeatureEnabled(this.ptr, feature, enabled);
  }
  isExperimentalFeatureEnabled(feature) {
    if (this.freed)
      return false;
    return this.renderLib.yogaConfigIsExperimentalFeatureEnabled(this.ptr, feature);
  }
}

class Node2 {
  ptr;
  config;
  freed = false;
  constructor(ptr, config) {
    this.ptr = ptr;
    this.config = config;
    config.nodes.set(ptr, this);
  }
  get renderLib() {
    return this.config.renderLib;
  }
  static create(config) {
    config ??= resolveRenderLib2().getYogaHost().getDefaultConfig();
    config.assertAlive();
    return Node2.fromPointer(config.renderLib.yogaNodeCreateWithConfig(config.ptr), config.renderLib);
  }
  static createForOpenTUI() {
    const renderLib = resolveRenderLib2();
    return Node2.fromPointer(renderLib.yogaNodeCreateForOpenTUI(), renderLib);
  }
  static createDefault() {
    return Node2.create();
  }
  static createWithConfig(config) {
    return Node2.create(config);
  }
  static destroy(node) {
    node.free();
  }
  static fromPointer(ptr, renderLib) {
    const config = Config2.fromBorrowedPointer(renderLib.yogaNodeGetConfig(ptr), renderLib);
    const existing = config.nodes.get(ptr);
    if (existing)
      return existing;
    return new Node2(ptr, config);
  }
  isFreed() {
    return this.freed;
  }
  assertMutable() {
    this.renderLib.getYogaHost().assertMutable();
  }
  runMutation(operation) {
    return this.renderLib.getYogaHost().runMutation(operation);
  }
  free() {
    if (this.freed)
      return;
    this.assertMutable();
    this.runMutation(() => {
      this.renderLib.yogaNodeFree(this.ptr);
      this.markFreed();
    });
  }
  freeRecursive() {
    if (this.freed)
      return;
    this.assertMutable();
    const nodes = this.collectSubtree([]);
    this.runMutation(() => {
      this.renderLib.yogaNodeFreeRecursive(this.ptr);
      for (const node of nodes)
        node.markFreed();
    });
  }
  reset() {
    if (this.freed)
      return;
    this.runMutation(() => {
      this.renderLib.yogaNodeReset(this.ptr);
      this.unregisterCallbacks();
    });
  }
  copyStyle(node) {
    if (this.freed)
      return;
    this.assertSameLibrary(node);
    this.renderLib.yogaNodeCopyStyle(this.ptr, node.ptr);
  }
  insertChild(child, index) {
    if (this.freed)
      return;
    this.assertSameLibrary(child);
    this.renderLib.yogaNodeInsertChild(this.ptr, child.ptr, index);
  }
  removeChild(child) {
    if (this.freed)
      return;
    this.assertSameLibrary(child);
    this.renderLib.yogaNodeRemoveChild(this.ptr, child.ptr);
  }
  removeAllChildren() {
    if (this.freed)
      return;
    this.renderLib.yogaNodeRemoveAllChildren(this.ptr);
  }
  getChild(index) {
    if (this.freed)
      return null;
    const child = this.renderLib.yogaNodeGetChild(this.ptr, index);
    return child ? Node2.fromPointer(child, this.renderLib) : null;
  }
  getChildCount() {
    if (this.freed)
      return 0;
    return this.renderLib.yogaNodeGetChildCount(this.ptr);
  }
  getParent() {
    if (this.freed)
      return null;
    const parent = this.renderLib.yogaNodeGetParent(this.ptr);
    return parent ? Node2.fromPointer(parent, this.renderLib) : null;
  }
  calculateLayout(width, height, direction = Direction2.LTR) {
    if (this.freed)
      return;
    this.renderLib.yogaNodeCalculateLayout(this.ptr, normalizeLayoutInput(width), normalizeLayoutInput(height), direction);
  }
  hasNewLayout() {
    if (this.freed)
      return false;
    return this.renderLib.yogaNodeGetHasNewLayout(this.ptr);
  }
  markLayoutSeen() {
    if (this.freed)
      return;
    this.renderLib.yogaNodeSetHasNewLayout(this.ptr, false);
  }
  markDirty() {
    if (this.freed)
      return;
    this.renderLib.yogaNodeMarkDirty(this.ptr);
  }
  isDirty() {
    if (this.freed)
      return true;
    return this.renderLib.yogaNodeIsDirty(this.ptr);
  }
  getComputedLayout() {
    if (this.freed)
      return { left: 0, top: 0, right: 0, bottom: 0, width: 0, height: 0 };
    return this.renderLib.yogaNodeGetComputedLayout(this.ptr);
  }
  getComputedLeft() {
    return this.getComputedLayout().left;
  }
  getComputedTop() {
    return this.getComputedLayout().top;
  }
  getComputedRight() {
    return this.getComputedLayout().right;
  }
  getComputedBottom() {
    return this.getComputedLayout().bottom;
  }
  getComputedWidth() {
    return this.getComputedLayout().width;
  }
  getComputedHeight() {
    return this.getComputedLayout().height;
  }
  getComputedMargin(edge) {
    if (this.freed)
      return 0;
    return this.renderLib.yogaNodeLayoutGetEdge(this.ptr, YogaEdgeLayoutKind.Margin, edge);
  }
  getComputedPadding(edge) {
    if (this.freed)
      return 0;
    return this.renderLib.yogaNodeLayoutGetEdge(this.ptr, YogaEdgeLayoutKind.Padding, edge);
  }
  getComputedBorder(edge) {
    if (this.freed)
      return 0;
    return this.renderLib.yogaNodeLayoutGetEdge(this.ptr, YogaEdgeLayoutKind.Border, edge);
  }
  setDirection(direction) {
    this.setEnum(YogaEnumKind.Direction, direction);
  }
  getDirection() {
    return this.getEnum(YogaEnumKind.Direction, Direction2.Inherit);
  }
  setFlexDirection(flexDirection) {
    this.setEnum(YogaEnumKind.FlexDirection, flexDirection);
  }
  getFlexDirection() {
    return this.getEnum(YogaEnumKind.FlexDirection, FlexDirection2.Column);
  }
  setJustifyContent(justifyContent) {
    this.setEnum(YogaEnumKind.JustifyContent, justifyContent);
  }
  getJustifyContent() {
    return this.getEnum(YogaEnumKind.JustifyContent, Justify2.FlexStart);
  }
  setAlignContent(alignContent) {
    this.setEnum(YogaEnumKind.AlignContent, alignContent);
  }
  getAlignContent() {
    return this.getEnum(YogaEnumKind.AlignContent, Align2.FlexStart);
  }
  setAlignItems(alignItems) {
    this.setEnum(YogaEnumKind.AlignItems, alignItems);
  }
  getAlignItems() {
    return this.getEnum(YogaEnumKind.AlignItems, Align2.Stretch);
  }
  setAlignSelf(alignSelf) {
    this.setEnum(YogaEnumKind.AlignSelf, alignSelf);
  }
  getAlignSelf() {
    return this.getEnum(YogaEnumKind.AlignSelf, Align2.Auto);
  }
  setPositionType(positionType) {
    this.setEnum(YogaEnumKind.PositionType, positionType);
  }
  getPositionType() {
    return this.getEnum(YogaEnumKind.PositionType, PositionType2.Relative);
  }
  setFlexWrap(flexWrap) {
    this.setEnum(YogaEnumKind.FlexWrap, flexWrap);
  }
  getFlexWrap() {
    return this.getEnum(YogaEnumKind.FlexWrap, Wrap2.NoWrap);
  }
  setOverflow(overflow) {
    this.setEnum(YogaEnumKind.Overflow, overflow);
  }
  getOverflow() {
    return this.getEnum(YogaEnumKind.Overflow, Overflow2.Visible);
  }
  setDisplay(display) {
    this.setEnum(YogaEnumKind.Display, display);
  }
  getDisplay() {
    return this.getEnum(YogaEnumKind.Display, 0 /* Flex */);
  }
  setBoxSizing(boxSizing) {
    this.setEnum(YogaEnumKind.BoxSizing, boxSizing);
  }
  getBoxSizing() {
    return this.getEnum(YogaEnumKind.BoxSizing, BoxSizing2.BorderBox);
  }
  setFlex(flex) {
    this.setFloat(YogaFloatKind.Flex, flex);
  }
  getFlex() {
    return this.getFloat(YogaFloatKind.Flex);
  }
  setFlexGrow(flexGrow) {
    this.setFloat(YogaFloatKind.FlexGrow, flexGrow);
  }
  getFlexGrow() {
    return this.getFloat(YogaFloatKind.FlexGrow);
  }
  setFlexShrink(flexShrink) {
    this.setFloat(YogaFloatKind.FlexShrink, flexShrink);
  }
  getFlexShrink() {
    return this.getFloat(YogaFloatKind.FlexShrink);
  }
  setAspectRatio(aspectRatio) {
    this.setFloat(YogaFloatKind.AspectRatio, aspectRatio);
  }
  getAspectRatio() {
    return this.getFloat(YogaFloatKind.AspectRatio);
  }
  setFlexBasis(flexBasis) {
    this.setValue(YogaValueKind.FlexBasis, NATIVE_EDGE_NONE2, flexBasis);
  }
  setFlexBasisPercent(flexBasis) {
    this.setValue(YogaValueKind.FlexBasis, NATIVE_EDGE_NONE2, flexBasis === undefined ? undefined : { unit: Unit2.Percent, value: flexBasis });
  }
  setFlexBasisAuto() {
    this.setValue(YogaValueKind.FlexBasis, NATIVE_EDGE_NONE2, "auto");
  }
  getFlexBasis() {
    return this.getValue(YogaValueKind.FlexBasis, NATIVE_EDGE_NONE2);
  }
  setWidth(width) {
    this.setValue(YogaValueKind.Width, NATIVE_EDGE_NONE2, width);
  }
  setWidthPercent(width) {
    this.setValue(YogaValueKind.Width, NATIVE_EDGE_NONE2, width === undefined ? undefined : { unit: Unit2.Percent, value: width });
  }
  setWidthAuto() {
    this.setValue(YogaValueKind.Width, NATIVE_EDGE_NONE2, "auto");
  }
  getWidth() {
    return this.getValue(YogaValueKind.Width, NATIVE_EDGE_NONE2);
  }
  setHeight(height) {
    this.setValue(YogaValueKind.Height, NATIVE_EDGE_NONE2, height);
  }
  setHeightPercent(height) {
    this.setValue(YogaValueKind.Height, NATIVE_EDGE_NONE2, height === undefined ? undefined : { unit: Unit2.Percent, value: height });
  }
  setHeightAuto() {
    this.setValue(YogaValueKind.Height, NATIVE_EDGE_NONE2, "auto");
  }
  getHeight() {
    return this.getValue(YogaValueKind.Height, NATIVE_EDGE_NONE2);
  }
  setMinWidth(minWidth) {
    this.setValue(YogaValueKind.MinWidth, NATIVE_EDGE_NONE2, minWidth);
  }
  setMinWidthPercent(minWidth) {
    this.setValue(YogaValueKind.MinWidth, NATIVE_EDGE_NONE2, minWidth === undefined ? undefined : { unit: Unit2.Percent, value: minWidth });
  }
  getMinWidth() {
    return this.getValue(YogaValueKind.MinWidth, NATIVE_EDGE_NONE2);
  }
  setMinHeight(minHeight) {
    this.setValue(YogaValueKind.MinHeight, NATIVE_EDGE_NONE2, minHeight);
  }
  setMinHeightPercent(minHeight) {
    this.setValue(YogaValueKind.MinHeight, NATIVE_EDGE_NONE2, minHeight === undefined ? undefined : { unit: Unit2.Percent, value: minHeight });
  }
  getMinHeight() {
    return this.getValue(YogaValueKind.MinHeight, NATIVE_EDGE_NONE2);
  }
  setMaxWidth(maxWidth) {
    this.setValue(YogaValueKind.MaxWidth, NATIVE_EDGE_NONE2, maxWidth);
  }
  setMaxWidthPercent(maxWidth) {
    this.setValue(YogaValueKind.MaxWidth, NATIVE_EDGE_NONE2, maxWidth === undefined ? undefined : { unit: Unit2.Percent, value: maxWidth });
  }
  getMaxWidth() {
    return this.getValue(YogaValueKind.MaxWidth, NATIVE_EDGE_NONE2);
  }
  setMaxHeight(maxHeight) {
    this.setValue(YogaValueKind.MaxHeight, NATIVE_EDGE_NONE2, maxHeight);
  }
  setMaxHeightPercent(maxHeight) {
    this.setValue(YogaValueKind.MaxHeight, NATIVE_EDGE_NONE2, maxHeight === undefined ? undefined : { unit: Unit2.Percent, value: maxHeight });
  }
  getMaxHeight() {
    return this.getValue(YogaValueKind.MaxHeight, NATIVE_EDGE_NONE2);
  }
  setMargin(edge, margin) {
    this.setValue(YogaValueKind.Margin, edge, margin);
  }
  setMarginPercent(edge, margin) {
    this.setValue(YogaValueKind.Margin, edge, margin === undefined ? undefined : { unit: Unit2.Percent, value: margin });
  }
  setMarginAuto(edge) {
    this.setValue(YogaValueKind.Margin, edge, "auto");
  }
  getMargin(edge) {
    return this.getValue(YogaValueKind.Margin, edge);
  }
  setPadding(edge, padding) {
    this.setValue(YogaValueKind.Padding, edge, padding);
  }
  setPaddingPercent(edge, padding) {
    this.setValue(YogaValueKind.Padding, edge, padding === undefined ? undefined : { unit: Unit2.Percent, value: padding });
  }
  getPadding(edge) {
    return this.getValue(YogaValueKind.Padding, edge);
  }
  setPosition(edge, position) {
    this.setValue(YogaValueKind.Position, edge, position);
  }
  setPositionPercent(edge, position) {
    this.setValue(YogaValueKind.Position, edge, position === undefined ? undefined : { unit: Unit2.Percent, value: position });
  }
  setPositionAuto(edge) {
    this.setValue(YogaValueKind.Position, edge, "auto");
  }
  getPosition(edge) {
    return this.getValue(YogaValueKind.Position, edge);
  }
  setGap(gutter, gap) {
    this.setValue(YogaValueKind.Gap, gutter, gap);
  }
  setGapPercent(gutter, gap) {
    this.setValue(YogaValueKind.Gap, gutter, gap === undefined ? undefined : { unit: Unit2.Percent, value: gap });
  }
  getGap(gutter) {
    return this.getValue(YogaValueKind.Gap, gutter);
  }
  setBorder(edge, border) {
    if (this.freed)
      return;
    this.renderLib.yogaNodeStyleSetBorder(this.ptr, edge, border ?? NaN);
  }
  getBorder(edge) {
    if (this.freed)
      return NaN;
    return this.renderLib.yogaNodeStyleGetBorder(this.ptr, edge);
  }
  setIsReferenceBaseline(isReferenceBaseline) {
    if (this.freed)
      return;
    this.renderLib.yogaNodeSetIsReferenceBaseline(this.ptr, isReferenceBaseline);
  }
  isReferenceBaseline() {
    if (this.freed)
      return false;
    return this.renderLib.yogaNodeIsReferenceBaseline(this.ptr);
  }
  setAlwaysFormsContainingBlock(alwaysFormsContainingBlock) {
    if (this.freed)
      return;
    this.renderLib.yogaNodeSetAlwaysFormsContainingBlock(this.ptr, alwaysFormsContainingBlock);
  }
  getAlwaysFormsContainingBlock() {
    if (this.freed)
      return false;
    return this.renderLib.yogaNodeGetAlwaysFormsContainingBlock(this.ptr);
  }
  setMeasureFunc(measureFunc) {
    if (this.freed)
      return;
    if (!measureFunc)
      return this.unsetMeasureFunc();
    this.config.ensureCallbacks();
    this.runMutation(() => {
      this.renderLib.yogaNodeSetMeasureFunc(this.ptr, true);
      this.config.measures.set(this.ptr, measureFunc);
    });
  }
  unsetMeasureFunc() {
    if (this.freed)
      return;
    this.runMutation(() => {
      this.renderLib.yogaNodeUnsetMeasureFunc(this.ptr);
      this.config.measures.delete(this.ptr);
    });
  }
  hasMeasureFunc() {
    if (this.freed)
      return false;
    return this.renderLib.yogaNodeHasMeasureFunc(this.ptr);
  }
  setDirtiedFunc(dirtiedFunc) {
    if (this.freed)
      return;
    if (!dirtiedFunc)
      return this.unsetDirtiedFunc();
    this.config.ensureCallbacks();
    this.runMutation(() => {
      this.renderLib.yogaNodeSetDirtiedFunc(this.ptr, true);
      this.config.dirtied.set(this.ptr, { node: this, callback: dirtiedFunc });
    });
  }
  unsetDirtiedFunc() {
    if (this.freed)
      return;
    this.runMutation(() => {
      this.renderLib.yogaNodeUnsetDirtiedFunc(this.ptr);
      this.config.dirtied.delete(this.ptr);
    });
  }
  setEnum(kind, value) {
    if (this.freed)
      return;
    this.renderLib.yogaNodeStyleSetEnum(this.ptr, kind, value);
  }
  getEnum(kind, fallback) {
    if (this.freed)
      return fallback;
    return this.renderLib.yogaNodeStyleGetEnum(this.ptr, kind);
  }
  setFloat(kind, value) {
    if (this.freed)
      return;
    this.renderLib.yogaNodeStyleSetFloat(this.ptr, kind, value ?? NaN);
  }
  getFloat(kind) {
    if (this.freed)
      return NaN;
    return this.renderLib.yogaNodeStyleGetFloat(this.ptr, kind);
  }
  setValue(kind, edgeOrGutter, valueInput) {
    if (this.freed)
      return;
    const value = parseYogaValue(valueInput);
    this.renderLib.yogaNodeStyleSetValue(this.ptr, kind, edgeOrGutter, value.unit, value.value);
  }
  getValue(kind, edgeOrGutter) {
    if (this.freed)
      return UNDEFINED_VALUE;
    return unpackValue(this.renderLib.yogaNodeStyleGetValue(this.ptr, kind, edgeOrGutter));
  }
  collectSubtree(nodes) {
    for (let index = 0;index < this.getChildCount(); index++) {
      this.getChild(index)?.collectSubtree(nodes);
    }
    nodes.push(this);
    return nodes;
  }
  unregisterCallbacks() {
    this.config.measures.delete(this.ptr);
    this.config.dirtied.delete(this.ptr);
  }
  markFreed() {
    this.unregisterCallbacks();
    this.freed = true;
    this.config.nodes.delete(this.ptr);
  }
  assertSameLibrary(node) {
    if (this.renderLib !== node.renderLib)
      throw new Error("Yoga nodes belong to different native libraries");
    if (node.freed)
      throw new Error("Yoga node is freed");
  }
}
var Yoga = {
  Config: Config2,
  Node: Node2,
  Align: Align2,
  BoxSizing: BoxSizing2,
  Dimension: Dimension2,
  Direction: Direction2,
  Display: Display2,
  Edge: Edge2,
  Errata: Errata2,
  ExperimentalFeature: ExperimentalFeature2,
  FlexDirection: FlexDirection2,
  Gutter: Gutter2,
  Justify: Justify2,
  LogLevel: LogLevel3,
  MeasureMode: MeasureMode2,
  NodeType: NodeType2,
  Overflow: Overflow2,
  PositionType: PositionType2,
  Unit: Unit2,
  Wrap: Wrap2,
  ALIGN_AUTO: ALIGN_AUTO2,
  ALIGN_FLEX_START: ALIGN_FLEX_START2,
  ALIGN_CENTER: ALIGN_CENTER2,
  ALIGN_FLEX_END: ALIGN_FLEX_END2,
  ALIGN_STRETCH: ALIGN_STRETCH2,
  ALIGN_BASELINE: ALIGN_BASELINE2,
  ALIGN_SPACE_BETWEEN: ALIGN_SPACE_BETWEEN2,
  ALIGN_SPACE_AROUND: ALIGN_SPACE_AROUND2,
  ALIGN_SPACE_EVENLY: ALIGN_SPACE_EVENLY2,
  BOX_SIZING_BORDER_BOX: BOX_SIZING_BORDER_BOX2,
  BOX_SIZING_CONTENT_BOX: BOX_SIZING_CONTENT_BOX2,
  DIMENSION_WIDTH: DIMENSION_WIDTH2,
  DIMENSION_HEIGHT: DIMENSION_HEIGHT2,
  DIRECTION_INHERIT: DIRECTION_INHERIT2,
  DIRECTION_LTR: DIRECTION_LTR2,
  DIRECTION_RTL: DIRECTION_RTL2,
  DISPLAY_FLEX: DISPLAY_FLEX2,
  DISPLAY_NONE: DISPLAY_NONE2,
  DISPLAY_CONTENTS: DISPLAY_CONTENTS2,
  EDGE_LEFT: EDGE_LEFT2,
  EDGE_TOP: EDGE_TOP2,
  EDGE_RIGHT: EDGE_RIGHT2,
  EDGE_BOTTOM: EDGE_BOTTOM2,
  EDGE_START: EDGE_START2,
  EDGE_END: EDGE_END2,
  EDGE_HORIZONTAL: EDGE_HORIZONTAL2,
  EDGE_VERTICAL: EDGE_VERTICAL2,
  EDGE_ALL: EDGE_ALL2,
  ERRATA_NONE: ERRATA_NONE2,
  ERRATA_STRETCH_FLEX_BASIS: ERRATA_STRETCH_FLEX_BASIS2,
  ERRATA_ABSOLUTE_POSITION_WITHOUT_INSETS_EXCLUDES_PADDING: ERRATA_ABSOLUTE_POSITION_WITHOUT_INSETS_EXCLUDES_PADDING2,
  ERRATA_ABSOLUTE_PERCENT_AGAINST_INNER_SIZE: ERRATA_ABSOLUTE_PERCENT_AGAINST_INNER_SIZE2,
  ERRATA_ALL: ERRATA_ALL2,
  ERRATA_CLASSIC: ERRATA_CLASSIC2,
  EXPERIMENTAL_FEATURE_WEB_FLEX_BASIS: EXPERIMENTAL_FEATURE_WEB_FLEX_BASIS2,
  FLEX_DIRECTION_COLUMN: FLEX_DIRECTION_COLUMN2,
  FLEX_DIRECTION_COLUMN_REVERSE: FLEX_DIRECTION_COLUMN_REVERSE2,
  FLEX_DIRECTION_ROW: FLEX_DIRECTION_ROW2,
  FLEX_DIRECTION_ROW_REVERSE: FLEX_DIRECTION_ROW_REVERSE2,
  GUTTER_COLUMN: GUTTER_COLUMN2,
  GUTTER_ROW: GUTTER_ROW2,
  GUTTER_ALL: GUTTER_ALL2,
  JUSTIFY_FLEX_START: JUSTIFY_FLEX_START2,
  JUSTIFY_CENTER: JUSTIFY_CENTER2,
  JUSTIFY_FLEX_END: JUSTIFY_FLEX_END2,
  JUSTIFY_SPACE_BETWEEN: JUSTIFY_SPACE_BETWEEN2,
  JUSTIFY_SPACE_AROUND: JUSTIFY_SPACE_AROUND2,
  JUSTIFY_SPACE_EVENLY: JUSTIFY_SPACE_EVENLY2,
  LOG_LEVEL_ERROR: LOG_LEVEL_ERROR2,
  LOG_LEVEL_WARN: LOG_LEVEL_WARN2,
  LOG_LEVEL_INFO: LOG_LEVEL_INFO2,
  LOG_LEVEL_DEBUG: LOG_LEVEL_DEBUG2,
  LOG_LEVEL_VERBOSE: LOG_LEVEL_VERBOSE2,
  LOG_LEVEL_FATAL: LOG_LEVEL_FATAL2,
  MEASURE_MODE_UNDEFINED: MEASURE_MODE_UNDEFINED2,
  MEASURE_MODE_EXACTLY: MEASURE_MODE_EXACTLY2,
  MEASURE_MODE_AT_MOST: MEASURE_MODE_AT_MOST2,
  NODE_TYPE_DEFAULT: NODE_TYPE_DEFAULT2,
  NODE_TYPE_TEXT: NODE_TYPE_TEXT2,
  OVERFLOW_VISIBLE: OVERFLOW_VISIBLE2,
  OVERFLOW_HIDDEN: OVERFLOW_HIDDEN2,
  OVERFLOW_SCROLL: OVERFLOW_SCROLL2,
  POSITION_TYPE_STATIC: POSITION_TYPE_STATIC2,
  POSITION_TYPE_RELATIVE: POSITION_TYPE_RELATIVE2,
  POSITION_TYPE_ABSOLUTE: POSITION_TYPE_ABSOLUTE2,
  UNIT_UNDEFINED: UNIT_UNDEFINED2,
  UNIT_POINT: UNIT_POINT2,
  UNIT_PERCENT: UNIT_PERCENT2,
  UNIT_AUTO: UNIT_AUTO2,
  WRAP_NO_WRAP: WRAP_NO_WRAP2,
  WRAP_WRAP: WRAP_WRAP2,
  WRAP_WRAP_REVERSE: WRAP_WRAP_REVERSE2
};
var yoga_default = Yoga;

export { nativeConstants, toArrayBuffer, singleton, getSingleton, destroySingleton, envRegistry2, registerEnvVar2, clearEnvCache2, generateEnvMarkdown2, generateEnvColored2, env2, stringWidth, resolveBundledFilePath2, Worker, TextAttributes2, ATTRIBUTE_BASE_BITS2, ATTRIBUTE_BASE_MASK2, getBaseAttributes2, DebugOverlayCorner2, TargetChannel2, DEFAULT_FOREGROUND_RGB2, DEFAULT_BACKGROUND_RGB2, normalizeIndexedColorIndex2, ansi256IndexToRgb2, RGBA2, normalizeColorValue2, hexToRgb2, rgbToHex2, hsvToRgb2, parseColor2, createTextAttributes2, attributesWithLink2, getLinkId2, visualizeRenderableTree2, isStyledText2, StyledText2, stringToStyledText2, black2, red2, green2, yellow2, blue2, magenta2, cyan2, white2, brightBlack2, brightRed2, brightGreen2, brightYellow2, brightBlue2, brightMagenta2, brightCyan2, brightWhite2, bgBlack2, bgRed2, bgGreen2, bgYellow2, bgBlue2, bgMagenta2, bgCyan2, bgWhite2, bold2, italic2, underline2, strikethrough2, dim2, reverse2, blink2, fg2, bg2, link2, t2, YogaEnumKind, YogaFloatKind, YogaValueKind, sceneSetEnum, sceneGetEnum, sceneSetFloat, sceneGetFloat, sceneSetValue, sceneGetValue, sceneSetDimension, UNDEFINED_VALUE, parseYogaValue, SpanInfoStruct, NativeAudioStreamFormat2, NativeAudioStreamState2, NativeAudioStreamStateNames, NativeAudioStreamCloseReason2, isBunfsPath, normalizeBunfsPath, resolveDefaultParserAsset, resolveDefaultTreeSitterWorkerPath, resolveTreeSitterWasm, NativeAudioStreamState3, NativeAudioStreamCloseReason3, NativeAudioStreamFormat3, MAX_LINK_URL_BYTES2, NativeTextViewCommand2, NativeEditCommand2, NativeEditPositionQuery2, NativeEditorStyleMask2, NativeEditHighlightOperation2, NativeEditorCommand2, NativeEditorSelectionOperation2, NativeEditorPositionQuery2, NativeEditEvent2, NativeStyleGroup, NativeStyleFlags, NATIVE_EDGE_NONE2, NativeBorder2, NativeSceneHook2, NativeSceneFrame2, NativeScenePaintPhase2, NATIVE_BUFFER_TEXT_BYTES_MAX2, NativeSessionState2, NativeSessionRenderStatus2, NATIVE_SESSION_CONTROL_PACKET_BYTES2, NativeSessionTerminalPhase2, NativeSessionPumpStatus2, NativeStatus2, NativeError2, NativeClipboardOperationStatus2, NativeClipboardStartStatus2, NativeClipboardCancelStatus2, NativeClipboardCopyStatus2, NativeClipboardDestroyStatus2, NativeClipboardShutdownStatus2, SceneStaging, NativePaintRecorder, LogLevel2, FFIRenderLib2, setRenderLibPath2, resolveRenderLib2, Align2, BoxSizing2, Dimension2, Direction2, Display2, Edge2, Errata2, ExperimentalFeature2, FlexDirection2, Gutter2, Justify2, LogLevel3, MeasureMode2, NodeType2, Overflow2, PositionType2, Unit2, Wrap2, ALIGN_AUTO2, ALIGN_FLEX_START2, ALIGN_CENTER2, ALIGN_FLEX_END2, ALIGN_STRETCH2, ALIGN_BASELINE2, ALIGN_SPACE_BETWEEN2, ALIGN_SPACE_AROUND2, ALIGN_SPACE_EVENLY2, BOX_SIZING_BORDER_BOX2, BOX_SIZING_CONTENT_BOX2, DIMENSION_WIDTH2, DIMENSION_HEIGHT2, DIRECTION_INHERIT2, DIRECTION_LTR2, DIRECTION_RTL2, DISPLAY_FLEX2, DISPLAY_NONE2, DISPLAY_CONTENTS2, EDGE_LEFT2, EDGE_TOP2, EDGE_RIGHT2, EDGE_BOTTOM2, EDGE_START2, EDGE_END2, EDGE_HORIZONTAL2, EDGE_VERTICAL2, EDGE_ALL2, ERRATA_NONE2, ERRATA_STRETCH_FLEX_BASIS2, ERRATA_ABSOLUTE_POSITION_WITHOUT_INSETS_EXCLUDES_PADDING2, ERRATA_ABSOLUTE_PERCENT_AGAINST_INNER_SIZE2, ERRATA_ALL2, ERRATA_CLASSIC2, EXPERIMENTAL_FEATURE_WEB_FLEX_BASIS2, FLEX_DIRECTION_COLUMN2, FLEX_DIRECTION_COLUMN_REVERSE2, FLEX_DIRECTION_ROW2, FLEX_DIRECTION_ROW_REVERSE2, GUTTER_COLUMN2, GUTTER_ROW2, GUTTER_ALL2, JUSTIFY_FLEX_START2, JUSTIFY_CENTER2, JUSTIFY_FLEX_END2, JUSTIFY_SPACE_BETWEEN2, JUSTIFY_SPACE_AROUND2, JUSTIFY_SPACE_EVENLY2, LOG_LEVEL_ERROR2, LOG_LEVEL_WARN2, LOG_LEVEL_INFO2, LOG_LEVEL_DEBUG2, LOG_LEVEL_VERBOSE2, LOG_LEVEL_FATAL2, MEASURE_MODE_UNDEFINED2, MEASURE_MODE_EXACTLY2, MEASURE_MODE_AT_MOST2, NODE_TYPE_DEFAULT2, NODE_TYPE_TEXT2, OVERFLOW_VISIBLE2, OVERFLOW_HIDDEN2, OVERFLOW_SCROLL2, POSITION_TYPE_STATIC2, POSITION_TYPE_RELATIVE2, POSITION_TYPE_ABSOLUTE2, UNIT_UNDEFINED2, UNIT_POINT2, UNIT_PERCENT2, UNIT_AUTO2, WRAP_NO_WRAP2, WRAP_WRAP2, WRAP_WRAP_REVERSE2, YogaStatus2, YogaError2, Config2, Node2, exports_yoga, yoga_default };

//# debugId=471834061107F53364756E2164756E21
//# sourceMappingURL=chunk-node-p43t2gam.js.map
