import { EventEmitter } from "events";
import { Align, Edge, FlexDirection, Gutter, Justify, PositionType, Wrap, type Layout, type MeasureFunction, type Value } from "./yoga.js";
import type { NativeScene } from "./NativeScene.js";
import { OptimizedBuffer } from "./buffer.js";
import type { KeyEvent, PasteEvent } from "./lib/KeyHandler.js";
import type { Selection } from "./lib/selection.js";
import { type AlignString, type FlexDirectionString, type JustifyString, type OverflowString, type PositionTypeString, type WrapString } from "./lib/yoga.options.js";
import { type VNode } from "./renderables/composition/vnode.js";
import type { MouseEvent } from "./renderer.js";
import type { RenderContext } from "./types.js";
import { type NativePaintRecorder, type NativeSceneFrameRequest, type NativeScenePaint, type NativeScenePaintSlot, type SceneNodeHandle } from "./zig.js";
declare const BrandedRenderable: unique symbol;
export declare enum LayoutEvents {
    LAYOUT_CHANGED = "layout-changed",
    RESIZED = "resized"
}
export declare enum RenderableEvents {
    FOCUSED = "focused",
    BLURRED = "blurred",
    DESTROYED = "destroyed"
}
export interface Position {
    top?: number | "auto" | `${number}%`;
    right?: number | "auto" | `${number}%`;
    bottom?: number | "auto" | `${number}%`;
    left?: number | "auto" | `${number}%`;
}
export interface BaseRenderableOptions {
    id?: string;
}
export interface LayoutOptions extends BaseRenderableOptions {
    flexGrow?: number;
    flexShrink?: number;
    flexDirection?: FlexDirectionString;
    flexWrap?: WrapString;
    alignItems?: AlignString;
    justifyContent?: JustifyString;
    alignSelf?: AlignString;
    flexBasis?: number | "auto" | undefined;
    position?: PositionTypeString;
    overflow?: OverflowString;
    top?: number | "auto" | `${number}%`;
    right?: number | "auto" | `${number}%`;
    bottom?: number | "auto" | `${number}%`;
    left?: number | "auto" | `${number}%`;
    minWidth?: number | "auto" | `${number}%`;
    minHeight?: number | "auto" | `${number}%`;
    maxWidth?: number | "auto" | `${number}%`;
    maxHeight?: number | "auto" | `${number}%`;
    margin?: number | "auto" | `${number}%`;
    marginX?: number | "auto" | `${number}%`;
    marginY?: number | "auto" | `${number}%`;
    marginTop?: number | "auto" | `${number}%`;
    marginRight?: number | "auto" | `${number}%`;
    marginBottom?: number | "auto" | `${number}%`;
    marginLeft?: number | "auto" | `${number}%`;
    padding?: number | `${number}%`;
    paddingX?: number | `${number}%`;
    paddingY?: number | `${number}%`;
    paddingTop?: number | `${number}%`;
    paddingRight?: number | `${number}%`;
    paddingBottom?: number | `${number}%`;
    paddingLeft?: number | `${number}%`;
    enableLayout?: boolean;
}
export interface RenderableOptions<T extends BaseRenderable = BaseRenderable> extends Partial<LayoutOptions> {
    width?: number | "auto" | `${number}%`;
    height?: number | "auto" | `${number}%`;
    zIndex?: number;
    visible?: boolean;
    buffered?: boolean;
    live?: boolean;
    opacity?: number;
    renderBefore?: (this: T, buffer: OptimizedBuffer, deltaTime: number) => void;
    renderAfter?: (this: T, buffer: OptimizedBuffer, deltaTime: number) => void;
    onMouse?: (this: T, event: MouseEvent) => void;
    onMouseDown?: (this: T, event: MouseEvent) => void;
    onMouseUp?: (this: T, event: MouseEvent) => void;
    onMouseMove?: (this: T, event: MouseEvent) => void;
    onMouseDrag?: (this: T, event: MouseEvent) => void;
    onMouseDragEnd?: (this: T, event: MouseEvent) => void;
    onMouseDrop?: (this: T, event: MouseEvent) => void;
    onMouseOver?: (this: T, event: MouseEvent) => void;
    onMouseOut?: (this: T, event: MouseEvent) => void;
    onMouseScroll?: (this: T, event: MouseEvent) => void;
    onPaste?: (this: T, event: PasteEvent) => void;
    onKeyDown?: (key: KeyEvent) => void;
    onSizeChange?: (this: T) => void;
}
/** Class-owned native integration, declared with defineNativeIntegration(). Method identities
 * identify work performed by native; overrides use the ordinary host hook dispatcher. */
export interface NativeRenderableIntegration {
    readonly kind: Parameters<NativeScene["driver"]["renderLib"]["sceneCreateNode"]>[2];
    readonly body: "host" | {
        readonly native: (buffer: OptimizedBuffer, deltaTime: number) => void;
        readonly buffered?: boolean;
    };
    readonly lifecycle?: {
        readonly resize?: {
            readonly native: (width: number, height: number) => void;
        };
        readonly update?: {
            readonly idle: (deltaTime: number) => void;
            readonly active: (renderable: Renderable) => boolean;
        };
    };
    readonly beforeAfter?: boolean;
    readonly paintBuffer?: "destination";
    readonly bufferComposition?: "native";
    readonly lineInfo?: boolean;
    readonly measure?: (this: Renderable, ...constraints: Parameters<MeasureFunction>) => ReturnType<MeasureFunction>;
    /** Only an own description can promise that construction adds no hook class fields. */
    readonly construction?: "prototype" | "fields";
}
export declare function isRenderable(obj: any): obj is Renderable;
export declare abstract class BaseRenderable extends EventEmitter {
    [BrandedRenderable]: boolean;
    private static renderableNumber;
    protected _id: string;
    readonly num: number;
    protected _dirty: boolean;
    parent: BaseRenderable | null;
    protected _visible: boolean;
    constructor(options: BaseRenderableOptions);
    abstract add(obj: BaseRenderable | unknown, index?: number): number;
    abstract remove(child: BaseRenderable): void;
    abstract insertBefore(obj: BaseRenderable | unknown, anchor: BaseRenderable | unknown): void;
    abstract getChildren(): BaseRenderable[];
    abstract getChildrenCount(): number;
    abstract getRenderable(id: string): BaseRenderable | undefined;
    abstract requestRender(): void;
    abstract findDescendantById(id: string): BaseRenderable | undefined;
    get id(): string;
    set id(value: string);
    get isDirty(): boolean;
    protected markClean(): void;
    protected markDirty(): void;
    destroy(): void;
    destroyRecursively(): void;
    get visible(): boolean;
    set visible(value: boolean);
}
export declare abstract class Renderable extends BaseRenderable {
    /** Focusable state of new nodes; a nullish `focusable` write restores it. */
    protected static readonly defaultFocusable: boolean;
    static renderablesByNumber: Map<number, Renderable>;
    static readonly nativeIntegration: NativeRenderableIntegration;
    /** @internal Stable class description shared by creation, hook registration, and dispatch. */
    readonly nativeIntegration: NativeRenderableIntegration;
    protected _isDestroyed: boolean;
    private _cleanupInProgress;
    private _childCleanupInProgress;
    private _deferredCleanup?;
    protected _ctx: RenderContext;
    /** @internal Scene-backed Yoga handle stored on the wrapper; there is no JS Yoga Node. */
    _sceneHandle?: SceneNodeHandle;
    private _yogaFreed;
    protected _translateX: number;
    protected _translateY: number;
    protected _width: number | "auto" | `${number}%`;
    protected _height: number | "auto" | `${number}%`;
    private _destroyedLayout?;
    protected _zIndex: number;
    selectable: boolean;
    protected buffered: boolean;
    protected frameBuffer: OptimizedBuffer | null;
    protected _focusable: boolean;
    protected _focused: boolean;
    protected _hasFocusedDescendant: boolean;
    protected keypressHandler: ((key: KeyEvent) => void) | null;
    protected pasteHandler: ((event: PasteEvent) => void) | null;
    private _live;
    protected _liveCount: number;
    private _sizeChangeListener;
    private _nativeSceneHookFlags;
    protected _nativeSceneHookGeneration: bigint;
    private _nativeSceneHooksRegistered;
    private _nativeSceneResize;
    private _nativeSceneResizeCallbacks?;
    private _nativeSceneHookLayout?;
    private _observedLayout?;
    private _observedLayoutRevision;
    private _computedLayout?;
    private _computedLayoutRevision;
    private _nativeSceneMethods?;
    private _nativeSceneMethodsPending;
    private _mouseListener;
    private _mouseListeners;
    private _pasteListener;
    private _keyListeners;
    protected _positionType: PositionTypeString;
    protected _overflow: OverflowString;
    protected _position: Position;
    protected _opacity: number;
    private _flexShrink;
    protected _childrenInLayoutOrder: Renderable[];
    parent: Renderable | null;
    onLifecyclePass: (() => void) | null;
    renderBefore?: (this: Renderable, buffer: OptimizedBuffer, deltaTime: number) => void;
    renderAfter?: (this: Renderable, buffer: OptimizedBuffer, deltaTime: number) => void;
    constructor(ctx: RenderContext, options: RenderableOptions<any>);
    protected abortConstruction(error: unknown, cleanup?: (run: (step: () => void) => void) => void): never;
    /** Completed base layers need full cleanup even before a subclass destroy override can run. */
    protected rollbackConstruction(error: unknown): never;
    protected runCleanup(steps: (run: (step: () => void) => void) => void): void;
    protected assignOptions(target: Renderable, options: object | undefined): void;
    get focusable(): boolean;
    set focusable(value: boolean);
    get ctx(): RenderContext;
    get visible(): boolean;
    get primaryAxis(): "row" | "column";
    set visible(value: boolean);
    get opacity(): number;
    set opacity(value: number);
    hasSelection(): boolean;
    onSelectionChanged(selection: Selection | null): boolean;
    getSelectedText(): string;
    shouldStartSelection(x: number, y: number): boolean;
    focus(): void;
    protected propagateFocusChange(hasFocus: boolean): void;
    blur(): void;
    get focused(): boolean;
    get hasFocusedDescendant(): boolean;
    get live(): boolean;
    get liveCount(): number;
    set live(value: boolean);
    protected propagateLiveCount(delta: number): void;
    protected onLiveCountChanged(previous: number): void;
    handleKeyPress?(key: KeyEvent): boolean;
    handlePaste?(event: PasteEvent): void;
    findDescendantById(id: string): Renderable | undefined;
    requestRender(): void;
    /** @internal Native built-ins may suspend lifecycle work without losing their registration position. */
    _needsLifecyclePass(): boolean;
    get translateX(): number;
    set translateX(value: number);
    get translateY(): number;
    set translateY(value: number);
    get screenX(): number;
    get screenY(): number;
    protected get _screenX(): number;
    protected get _screenY(): number;
    private getNativeScenePaintLayout;
    get x(): number;
    set x(value: number);
    get top(): number | "auto" | `${number}%` | undefined;
    set top(value: number | "auto" | `${number}%` | null | undefined);
    get right(): number | "auto" | `${number}%` | undefined;
    set right(value: number | "auto" | `${number}%` | null | undefined);
    get bottom(): number | "auto" | `${number}%` | undefined;
    set bottom(value: number | "auto" | `${number}%` | null | undefined);
    get left(): number | "auto" | `${number}%` | undefined;
    set left(value: number | "auto" | `${number}%` | null | undefined);
    get y(): number;
    set y(value: number);
    get width(): number;
    set width(value: number | "auto" | `${number}%` | null | undefined);
    get height(): number;
    /** The `width` or `height` that a nullish write restores. A class that sizes itself overrides it. */
    protected defaultDimension(_kind: "width" | "height"): number | "auto" | `${number}%`;
    private styledDimension;
    private getNativeSceneLayout;
    set height(value: number | "auto" | `${number}%` | null | undefined);
    private setDimension;
    get zIndex(): number;
    set zIndex(value: number | undefined);
    getChildrenSortedByPrimaryAxis(): Renderable[];
    /** @internal Bind the native scene handle. Scene-backed layout has no JS Yoga Node. */
    _bindSceneHandle(handle: SceneNodeHandle): void;
    /** @internal Only the matching scene can use this node's handle. */
    _getSceneHandle(owner: NativeScene): SceneNodeHandle;
    /** @internal Invalidate the handle after native release. */
    _releaseSceneHandle(): void;
    isFreed(): boolean;
    assertMutable(): void;
    /** A destroyed renderable skips the operation: writes to it are no-ops, as on `main`. */
    runMutation<T>(operation: () => T): T;
    private yogaSetEnum;
    private yogaGetEnum;
    private yogaGetFloat;
    private yogaSetFloat;
    private yogaSetValue;
    private yogaGetValue;
    private setDisplay;
    getFlexDirection(): FlexDirection;
    private setFlexDirection;
    private setFlexWrap;
    private setAlignItems;
    private setJustifyContent;
    private setAlignSelf;
    private setPositionType;
    private setOverflow;
    private setFlexGrow;
    private setFlexShrink;
    private setFlexBasis;
    private setWidth;
    private setHeight;
    private setMinWidth;
    private setMaxWidth;
    private setMinHeight;
    private setMaxHeight;
    private setMargin;
    getMargin(edge: Edge): Value;
    private setPadding;
    protected setGap(gutter: Gutter, gap: number | `${number}%` | undefined): void;
    getWidth(): Value;
    getFlexWrap(): Wrap;
    getAlignItems(): Align;
    getJustifyContent(): Justify;
    getAlignSelf(): Align;
    getPositionType(): PositionType;
    getFlexGrow(): number;
    getFlexShrink(): number;
    getFlexBasis(): Value;
    getHeight(): Value;
    getMinWidth(): Value;
    getMinHeight(): Value;
    getMaxWidth(): Value;
    getMaxHeight(): Value;
    getPadding(edge: Edge): Value;
    getGap(gutter: Gutter): Value;
    getComputedLayout(): Layout;
    private setMeasureFunc;
    private hasMeasureFunc;
    private setupYogaProperties;
    private setupMarginAndPadding;
    set position(positionType: PositionTypeString | null | undefined);
    get overflow(): OverflowString;
    set overflow(overflow: OverflowString | null | undefined);
    setPosition(position: Position): void;
    private updateYogaPosition;
    set flexGrow(grow: number | null | undefined);
    set flexShrink(shrink: number | null | undefined);
    set flexDirection(direction: FlexDirectionString | null | undefined);
    set flexWrap(wrap: WrapString | null | undefined);
    set alignItems(alignItems: AlignString | null | undefined);
    set justifyContent(justifyContent: JustifyString | null | undefined);
    set alignSelf(alignSelf: AlignString | null | undefined);
    set flexBasis(basis: number | "auto" | null | undefined);
    set minWidth(minWidth: number | `${number}%` | null | undefined);
    set maxWidth(maxWidth: number | `${number}%` | null | undefined);
    set minHeight(minHeight: number | `${number}%` | null | undefined);
    set maxHeight(maxHeight: number | `${number}%` | null | undefined);
    set margin(margin: number | "auto" | `${number}%` | null | undefined);
    set marginX(marginX: number | "auto" | `${number}%` | null | undefined);
    set marginY(marginY: number | "auto" | `${number}%` | null | undefined);
    set marginTop(margin: number | "auto" | `${number}%` | null | undefined);
    get marginTop(): number | "auto" | `${number}%`;
    set marginRight(margin: number | "auto" | `${number}%` | null | undefined);
    set marginBottom(margin: number | "auto" | `${number}%` | null | undefined);
    set marginLeft(margin: number | "auto" | `${number}%` | null | undefined);
    set padding(padding: number | `${number}%` | null | undefined);
    set paddingX(paddingX: number | `${number}%` | null | undefined);
    set paddingY(paddingY: number | `${number}%` | null | undefined);
    set paddingTop(padding: number | `${number}%` | null | undefined);
    set paddingRight(padding: number | `${number}%` | null | undefined);
    set paddingBottom(padding: number | `${number}%` | null | undefined);
    set paddingLeft(padding: number | `${number}%` | null | undefined);
    private setStyleValue;
    setMeasureProvider(provider: MeasureFunction | null): void;
    invalidateIntrinsicSize(): void;
    getLayout(): Readonly<Layout>;
    protected onLayoutResize(width: number, height: number): void;
    protected handleFrameBufferResize(width: number, height: number): void;
    protected createFrameBuffer(): void;
    /**
     * This will be called during a render pass.
     * Requesting a render during a render pass will drop the requested render.
     * If you need to request a render during a render pass, use process.nextTick.
     */
    protected onResize(width: number, height: number): void;
    private placeChild;
    add(obj: Renderable | VNode<any, any[]> | unknown, index?: number): number;
    insertBefore(obj: Renderable | VNode<any, any[]> | unknown, anchor?: Renderable | unknown): number;
    getRenderable(id: string): Renderable | undefined;
    remove(child: BaseRenderable): void;
    protected onRemove(): void;
    getChildren(): Renderable[];
    getChildrenCount(): number;
    protected onUpdate(deltaTime: number): void;
    protected renderSelf(buffer: OptimizedBuffer, deltaTime: number): void;
    protected getNativeScenePaint(): NativeScenePaint;
    protected setNativeScenePaint(paint?: Partial<NativeScenePaint>): void;
    private static nativeSceneMethods;
    /** Declare integration once per class, before instances exist. Prototype methods retain
     * super calls, while assignment publishes through the same accessors as discovered fields. */
    protected static defineNativeIntegration(integration: NativeRenderableIntegration): NativeRenderableIntegration;
    private static installNativeSceneMethod;
    /** Snapshot reflective hook replacements and restore normal callback assignment.
     * Call after defineProperty/delete, or to finalize fields after early constructor attachment.
     * Ordinary paint and style changes do not discover hooks. */
    refreshHooks(): void;
    /** @internal Snapshot hooks for construction, explicit refresh, or retry. */
    _scanNativeSceneHooks(): void;
    private ensureNativeSceneMethods;
    private nativeSceneNeedsHookPublish;
    private usesNativeDrawing;
    private needsHostResize;
    private hostUpdateFlags;
    private refreshNativeSceneMethods;
    protected refreshNativeSceneHooks(): void;
    /** @internal Retained surfaces restore their binding accessor during the same construction refresh. */
    _refreshNativeSceneSurface(): void;
    private setNativeSceneHooks;
    /** @internal Refresh only requested host hooks, never walk wrappers to collect layout. */
    _runNativeSceneHook(request: NativeSceneFrameRequest, deltaTime: number): void;
    /** @internal Record this node's paint hooks for one slot. Native code paints the
     * recording at the slot's prepared position after every slot has recorded. */
    _recordNativeScenePaint(slot: NativeScenePaintSlot, index: number, deltaTime: number, frame: OptimizedBuffer, recorder: NativePaintRecorder, geometryRevision: number | undefined): void;
    protected _invokeNativePaint(buffer: OptimizedBuffer, deltaTime: number): void;
    get isDestroyed(): boolean;
    destroy(): void;
    destroyRecursively(): void;
    /** @internal Defer renderer finalization until active cleanup in its context completes. */
    _deferUntilCleanupComplete(resume: () => void): boolean;
    protected destroyOwnedResources(): void;
    protected destroySelf(): void;
    private destroyLayoutBacking;
    private completeCleanup;
    private removeLayoutChildAt;
    private detachFromParent;
    processMouseEvent(event: MouseEvent): void;
    private assertSupportedEvent;
    on(event: string | symbol, listener: (...args: any[]) => void): this;
    addListener(event: string | symbol, listener: (...args: any[]) => void): this;
    prependListener(event: string | symbol, listener: (...args: any[]) => void): this;
    off(event: string | symbol, listener: (...args: any[]) => void): this;
    removeListener(event: string | symbol, listener: (...args: any[]) => void): this;
    removeAllListeners(event?: string | symbol): this;
    private changeSceneListeners;
    protected onMouseEvent(event: MouseEvent): void;
    set onMouse(handler: ((event: MouseEvent) => void) | undefined);
    set onMouseDown(handler: ((event: MouseEvent) => void) | undefined);
    set onMouseUp(handler: ((event: MouseEvent) => void) | undefined);
    set onMouseMove(handler: ((event: MouseEvent) => void) | undefined);
    set onMouseDrag(handler: ((event: MouseEvent) => void) | undefined);
    set onMouseDragEnd(handler: ((event: MouseEvent) => void) | undefined);
    set onMouseDrop(handler: ((event: MouseEvent) => void) | undefined);
    set onMouseOver(handler: ((event: MouseEvent) => void) | undefined);
    set onMouseOut(handler: ((event: MouseEvent) => void) | undefined);
    set onMouseScroll(handler: ((event: MouseEvent) => void) | undefined);
    set onPaste(handler: ((event: PasteEvent) => void) | undefined);
    get onPaste(): ((event: PasteEvent) => void) | undefined;
    set onKeyDown(handler: ((key: KeyEvent) => void) | undefined);
    get onKeyDown(): ((key: KeyEvent) => void) | undefined;
    set onSizeChange(handler: (() => void) | undefined);
    get onSizeChange(): (() => void) | undefined;
    private applyEventOptions;
}
export declare class RootRenderable extends Renderable {
    static readonly nativeIntegration: NativeRenderableIntegration;
    private _currentRenderable;
    constructor(ctx: RenderContext);
    get currentRenderable(): Renderable | undefined;
    /** @internal Clear after successful dispatch; error handling consumes the failing node. */
    _setCurrentRenderable(renderable: Renderable | undefined): void;
    takeCurrentRenderable(): Renderable | undefined;
    protected propagateLiveCount(delta: number): void;
    protected onLiveCountChanged(previous: number): void;
    resize(width: number, height: number): void;
}
export {};
